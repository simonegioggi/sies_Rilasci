insert into cg_ref_codes values ('TIPO_FUNZIONE', 'F', null, null, 'Compilazione Foglio Complementare', null, null, null, null);
commit;