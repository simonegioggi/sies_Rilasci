CREATE OR REPLACE VIEW VW_MS_PROCEDIMENTI
(FASC_SIEP,DESC_MS,COD_MS,COD_UFF_INS,ANNO_ISC,TRIMESTRE,NUMERO_FASC,DATA_ARCH,DATA_ISCR,COD_STATO_FASCICOLO,MOT_ARCHIVIAZIONE)
AS
SELECT A.ID_FASCICOLO_SIEP FASC_SIEP,
       C.RV_MEANING        DESC_MS,
       C.RV_LOW_VALUE      COD_MS,
       A.Cod_Ufficio_Inserimento Cod_Uff_Ins,
       to_char(A.DATA_ISCRIZIONE,'yyyy')   ANNO_ISC,
       TO_CHAR(A.DATA_ISCRIZIONE, 'Q')  Trimestre,
       -- inizio parte aggiunta per gestione provvisorie
       CASE
         WHEN (select distinct count(provv.FASC_SIEP)
                 from VW_MS_APPL_GIU_COGNIZIONE provv
                where provv.FASC_SIEP = a.id_fascicolo_siep) > 0 THEN
         '-'||a.chiave_anno || A.CHIAVE_PROGR
         ELSE
          a.chiave_anno || A.CHIAVE_PROGR
       END Numero_Fasc,
       -- fine parte aggiunta per gestione provvisorie
       a.data_archiviazione Data_Arch,
       a.data_iscrizione Data_Iscr,
       -- INZIO @EMMA 07022018
       a.cod_stato_fascicolo cod_stato_fascicolo,
       a.cod_motivo_archiviazione mot_archiviazione--,
       --a.data_ultima_riapertura data_riapertura
       --  FINE @EMMA 07022018
  FROM FASCICOLO_SIEP   A,
       SENTENZA         B,
       MISURA_SICUREZZA AA,
       CG_REF_CODES     C
 WHERE A.SEN_ID_SENTENZA = B.ID_SENTENZA
   AND AA.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
   AND C.RV_LOW_VALUE = AA.COD_TIPO
   AND C.RV_DOMAIN = 'TIPO_MISURA_SICUREZZA'
   AND C.RV_LOW_VALUE <> '-'
   -- INZIO @EMMA 07022018 LA MISURA NON DEVE ESSERE STATA ANNULLATA
    AND (AA.FLAG_ANNULLA_MISURA IS NULL OR AA.FLAG_ANNULLA_MISURA != 'A')
    AND  AA.DATA_FINE_VALIDITA IS NULL
   --  FINE @EMMA 07022018
   -- Ticket#202302280124 - Non vanno esclusi i risperti
   -- and A.ID_FASCICOLO_SIEP not in (select c1.FASC_SIEP from vw_ms_proc_riaperti c1)
   -- Ticket#202302280124 - FINE
   AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
       (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999));
/