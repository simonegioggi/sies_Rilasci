CREATE OR REPLACE FORCE EDITIONABLE VIEW "VW_MS_PROC_ESAURITI_MAG" ("FASC_SIEP", "DESC_MS", "COD_MS", "COD_UFF_INS", "ANNO_ISC", "TRIMESTRE", "NUMERO_FASC", "DATA_ARCH", "DATA_ISCR", "COD_STATO_FASCICOLO", "MOT_ARCHIVIAZIONE", "COD_MAGISTRATO") AS 
  SELECT A.ID_FASCICOLO_SIEP FASC_SIEP,
       C.RV_MEANING        DESC_MS,
       C.RV_LOW_VALUE      COD_MS,
       A.Cod_Ufficio_Inserimento Cod_Uff_Ins,
       to_char(A.DATA_ISCRIZIONE,'yyyy')   ANNO_ISC,
       TO_CHAR(A.DATA_ISCRIZIONE, 'Q')  Trimestre,
       -- inizio parte aggiunta per gestione provvisorie
       CASE
         WHEN (select distinct count(provv.FASC_SIEP)
                 from VW_MS_APPL_GIU_COGNIZIONE provv
                where provv.FASC_SIEP = a.id_fascicolo_siep) > 0 THEN
         '-'||a.chiave_anno || A.CHIAVE_PROGR
         ELSE
          a.chiave_anno || A.CHIAVE_PROGR
       END Numero_Fasc,
       -- fine parte aggiunta per gestione provvisorie
       a.data_archiviazione Data_Arch,
       a.data_iscrizione Data_Iscr,
       a.cod_stato_fascicolo cod_stato_fascicolo,
       a.cod_motivo_archiviazione mot_archiviazione,
       MA.COD_MAGISTRATO
  FROM FASCICOLO_SIEP   A,
       SENTENZA         B,
       MISURA_SICUREZZA AA,
       CG_REF_CODES     C,
       MAGISTRATO_COMPETENTE MC,
       MAGISTRATO MA
 WHERE A.SEN_ID_SENTENZA = B.ID_SENTENZA
   AND AA.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
   AND C.RV_LOW_VALUE = AA.COD_TIPO
   AND C.RV_DOMAIN = 'TIPO_MISURA_SICUREZZA'
   AND C.RV_LOW_VALUE <> '-'
   --  LA MISURA NON DEVE ESSERE STATA ANNULLATA
   AND (AA.FLAG_ANNULLA_MISURA IS NULL OR AA.FLAG_ANNULLA_MISURA != 'A')
   AND  AA.DATA_FINE_VALIDITA IS NULL
   and A.DATA_ARCHIVIAZIONE is not null
   -- archiviati nel periodo
   -- occore aggiungere un controllo sullo stato del fascicolo e la data di archiviazione copresa nello stesso
   -- range di inscrizione (archiviati nel periodo)
   -- Ticket#202302280124 - Vanno conteggiati tra gli archiviati anche i riaperti
   -- and A.COD_STATO_FASCICOLO = '01' -- Archiviato/Definito
   -- Ticket#202302280124 - FINE   
   -- CONDIZIONI PER ESTRARRE IL MAGISTRATO ASSOCIATO AL FASCICOLO
   AND A.ID_FASCICOLO_SIEP=MC.FAS_SIE_ID_FASCICOLO_SIEP(+)
   AND MC.MAG_COD_MAGISTRATO=MA.COD_MAGISTRATO
   and ma.cod_ufficio_appartenenza=a.cod_ufficio_inserimento
   and mc.cod_ufficio_inserimento=a.cod_ufficio_inserimento
   AND mc.data_fine IS NULL
   AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
       (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999));
/