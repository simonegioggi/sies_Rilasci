CREATE OR REPLACE PACKAGE BODY Pulisci
IS
--
--
-- Purpose: PACKAGE contenente le procedure per la cancellazione degli eventi
--          e la pulizia del fascicolo
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
PROCEDURE Pulisci_Evento ( IdEvento           IN     NUMBER,
                           EsitoPulisciEvento IN OUT VARCHAR2) IS

  -- modifiche per integrazione BDMC
  annotazione_rec ANNOTAZIONE_MANUALE%ROWTYPE;
  TYPE annotazione_cur IS REF CURSOR RETURN annotazione_rec%TYPE;
  annotazione_cur1 annotazione_cur;

  --Enter the procedure variables here. As shown below
  idOrdinanza            NUMBER := 0;
  iddecreto              NUMBER := 0;
  appo_evento            NUMBER;
  idpenaresidua          NUMBER:=0;
  idnotifica             NUMBER:=0;
  ID_EVENTO_GENERATO     NUMBER;
  ID_EVENTO_GENERANTE    NUMBER;
  Esito_Pulisci          VARCHAR2(100);
  v_fascicolo_siep       FASCICOLO_SIEP.id_fascicolo_siep%TYPE;
  v_primo_cumulo         CUMULO.primo_cumulo%TYPE;
  v_ann_id_annot         NUMBER := NULL;
  v_id_annotazione       NUMBER := NULL;
  v_eve_annot            NUMBER := NULL;
  v_pen_id_pena_residua  NUMBER := 0;
  v_id_pena_residua      NUMBER := NULL;
  v_eve_pena_residua     NUMBER := 0;

  -- Definizione dei param da passare allo scadenzario !
  par_id_fascicolo_siep  NUMBER := NULL;
  par_ufficio            evento.cod_ufficio_inserimento%type;
  par_bdi                VARCHAR2(2);
  par_anno               number;

  BEGIN

    --dbms_output.put_line('*************************************************************************************************');
    --dbms_output.put_line('--------------------- INIZIO PULISCI EVENTO ---------------------');
    --dbms_output.put_line('*************************************************************************************************');

    -- Dicembre 2008 Aggiunto su segnalazione di Cherubini
    SELECT fas_sie_id_fascicolo_siep,
           cod_ufficio_inserimento
      INTO par_id_fascicolo_siep,
           par_ufficio
      FROM EVENTO
     WHERE ID_EVENTO = IdEvento;

    SELECT descrizione
      INTO par_bdi
      FROM jms_code
     WHERE dominio = 'PROGR_BDI'
       AND codice  = ( ( select descrizione
                           from jms_code
                          where dominio = 'BDI'
                            and codice  = (select cod_distretto
					                                   from ufficio
									                          where cod_ufficio = par_ufficio)) );
    par_anno := to_number(to_char(sysdate,'yyyy'));

	 dbms_output.put_line('EVENTO ------ >>>  IdEvento!'||IdEvento) ;

    -- 27.11.2008 Daniela : INIZIO (segnalazione di Fabio)
    -- Cancellazione tabella COMPETENZA (per implementazioni rilascio 4.0)
    DELETE FROM COMPETENZA WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete COMPETENZA ------ >>>  OK!');
    -- 27.11.2008 Daniela : FINE

    DELETE FROM MISURA_ALTERNATIVA WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete MISURA_ALTERNATIVA ------ >>>  OK!');

    -- new d.f. 13/01/2014
    DELETE FROM ANNOTAZIONE_ESITO_TRASMISSIONE WHERE EVE_ID_EVENTO = IdEvento;

    -- new d.f. 03/09/2014
    DELETE FROM SOLLECITO_ESITO_TRASMISSIONE WHERE EVE_ID_EVENTO = IdEvento;

    DELETE FROM SCADENZARIO_SIEP WHERE NOT_ID_NOTIFICA IN
       (SELECT id_notifica FROM NOTIFICA
         WHERE Eve_ID_EVENTO = IdEvento) ;
        --dbms_output.put_line('Delete SCADENZARIO_SIEP ------ >>>  OK!');

    -- 3 Febbraio 2012 Paolo Cherubini vado ad eliminare la chiamata allo scadenzario perch?? se cancello il Decreto di Irreperibilit? 
    -- crea un nuovo scadenzario e quindi ce ne sono 2. In effetti qui non ci dovrebbe essere la chiamata allo scadenzario non essendo
    -- un annullamento evento ma una cancellazione
          -- Dicembre 2008 Aggiunto su segnalazione di Cherubini
          -- Aggiunto richiamo gestione scadenzario - dicembre 2008
          -- Aggiorna_Scadenzario_Pregresso.update_scadenzario (par_anno,par_bdi,par_ufficio,par_id_fascicolo_siep);
          -- fine Dicembre 2008
    -- fine 3 Febbraio 2012 Paolo Cherubini

    DELETE FROM RINNOVO WHERE NOT_ID_NOTIFICA IN
       (SELECT id_notifica FROM NOTIFICA
         WHERE Eve_ID_EVENTO = IdEvento) ;
  --dbms_output.put_line('Delete RINNOVO ------ >>>  OK!');

    DELETE FROM RINNOVO WHERE VER_ID_VERBALE IN
       (SELECT id_verbale FROM VERBALE
         WHERE Eve_ID_EVENTO = IdEvento);
  --dbms_output.put_line('Delete RINNOVO ------ >>>  OK!');

    DELETE FROM NOME_PROVVEDIMENTO WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete NOME_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM MOTIVO_EVENTO WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete MOTIVO_EVENTO ------ >>>  OK!');

    DELETE FROM MOTIVAZIONE_DECRETO  WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete MOTIVAZIONE_DECRETO  ------ >>>  OK!');

    DELETE FROM ISTANZA WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete ISTANZA ------ >>>  OK!');

    DELETE FROM CAMPO_NOTA WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete CAMPO_NOTA ------ >>>  OK!');

    BEGIN
       SELECT fas_sie_id_fascicolo_siep,primo_cumulo
         INTO v_fascicolo_siep,v_primo_cumulo
         FROM CUMULO
        WHERE Eve_ID_EVENTO = IdEvento;

       IF v_primo_cumulo='P' THEN
           UPDATE FASCICOLO_SIEP
           SET flag_cumulante= NULL
           WHERE id_fascicolo_siep=v_fascicolo_siep;
       END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      NULL;
    END;

    DELETE FROM PENA_CUMULO WHERE CUM_ID_CUMULO IN
       (SELECT id_cumulo FROM CUMULO
            WHERE Eve_ID_EVENTO = IdEvento) ;

        --dbms_output.put_line('Delete PENA_CUMULO ------ >>>  OK!'); ---aggiunto il 13/12/2006

    DELETE FROM PRESCRIZIONE WHERE EVE_ID_EVENTO IN IdEvento;
	dbms_output.put_line('Delete Prescrizione ------ >>>  OK!');  --- AGGIUNTO IL 13/1/2010 - UMBERTO


    DELETE FROM ULTERIORE_SANZIONE_CUMULO WHERE CUM_ID_CUMULO IN
       (SELECT id_cumulo FROM CUMULO
            WHERE Eve_ID_EVENTO = IdEvento) ;
        --dbms_output.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');

    DELETE FROM CUMULO WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete CUMULO ------ >>>  OK!');

    DELETE FROM DOCUMENTO_ALLEGATO WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete DOCUMENTO_ALLEGATO ------ >>>  OK!');

    DELETE FROM VERBALE WHERE Eve_ID_EVENTO = IdEvento;
     --dbms_output.put_line('Delete VERBALE ------ >>>  OK!');

    DELETE FROM NOTIFICA WHERE Eve_ID_EVENTO = IdEvento;
      --dbms_output.put_line('Delete NOTIFICA ------ >>>  OK!');

    DELETE FROM REFERTO_SCARCERAZIONE WHERE Eve_ID_EVENTO = IdEvento;
     --dbms_output.put_line('Delete REFERTO_SCARCERAZIONE ------ >>>  OK!');

    DELETE FROM POSIZIONE_GIURIDICA WHERE ID_EVENTO_RIFERIMENTO = IdEvento;
    --dbms_output.put_line('Delete POSIZIONE_GIURIDICA ------ >>>  OK!');

-- Umberto 12/12/2014 - Inserita cancellazione della Misura di Sicurezza
    DELETE FROM MISURA_SICUREZZA WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete MISURA_SICUREZZA ------ >>>  OK!');
    --==========================================================================
    -- Gestione cancellazione annotazioni manuali puntate dall'evento o che
    -- puntano l'evento
    --==========================================================================
    BEGIN
      SELECT ann_id_annotazione_manuale
        INTO v_ann_id_annot
        FROM EVENTO
       WHERE id_evento = IdEvento;

      --dbms_output.put_line('v_ann_id_annot '||v_ann_id_annot);
      --==============================================================================
      -- se l'evento punta una annotazione devo verificare se ?? possibile cancellarla
      --==============================================================================
      IF v_ann_id_annot IS NOT NULL THEN
        BEGIN
          SELECT eve_id_evento
            INTO v_eve_annot
            FROM ANNOTAZIONE_MANUALE
           WHERE id_annotazione_manuale=v_ann_id_annot;

          --dbms_output.put_line('v_eve_annot '||v_eve_annot);

          IF v_eve_annot IS NOT NULL THEN
             --dbms_output.put_line('v_eve_annot ?? not null'||v_eve_annot);
            IF v_eve_annot= IdEvento THEN   ----quindi ?? unico evento
              --dbms_output.put_line('v_eve_annot ?? unico evento'||v_eve_annot);
              UPDATE EVENTO
                 SET ann_id_annotazione_manuale=NULL
               WHERE id_evento = IdEvento;

             -- modifiche per integrazione bdmc
             BEGIN
               OPEN annotazione_cur1 FOR
               SELECT *  FROM  ANNOTAZIONE_MANUALE  WHERE EVE_ID_EVENTO = IdEvento ;

              LOOP
                 FETCH annotazione_cur1 INTO  annotazione_rec;
                 EXIT WHEN annotazione_cur1%NOTFOUND;

                 UPDATE MISURA_CAUTELARE_BDMC
                   SET FLAG_STATO = 'C'
                  WHERE id_annotazione_manuale = annotazione_rec.id_annotazione_manuale;

              END LOOP;

                CLOSE annotazione_cur1;
              EXCEPTION
               WHEN NO_DATA_FOUND THEN
              CLOSE annotazione_cur1;
             END;
             -- fine modifiche per integrazione bdmc

              -- Daniela 07.2011
              DELETE FROM ANNMAN_PENACOMPL WHERE ANNOTAZIONEMANUALE_ID = v_ann_id_annot;
              --dbms_output.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');

              -- Daniela 07.2011
              DELETE FROM ANNMAN_REATO WHERE ANNOTAZIONEMANUALE_ID = v_ann_id_annot;
              --dbms_output.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');

              DELETE FROM ANNOTAZIONE_MANUALE WHERE Eve_ID_EVENTO = IdEvento;
              --dbms_output.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');
            ELSIF v_eve_annot!= IdEvento THEN ----l'annotazione ?? legata ad un altro evento e non si pu?? cancellare
              --dbms_output.put_line('UPDATE EVENTO PER ANNOTAZIONE_MANUALE ------ >>>  OK!');
              UPDATE EVENTO
                 SET ann_id_annotazione_manuale=NULL
               WHERE id_evento = IdEvento;
            END IF;
          END IF; -- v_eve_annot IS NOT NULL

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
             NULL;
        END;
      ELSE
        -- L'evento non punta una annotazione
        --dbms_output.put_line('v_eve_annot ?? null'||v_eve_annot);
        -- modifiche per integrazione bdmc
        BEGIN
         OPEN annotazione_cur1 FOR
            SELECT * FROM ANNOTAZIONE_MANUALE WHERE EVE_ID_EVENTO = IdEvento ;

        LOOP
           FETCH annotazione_cur1 INTO  annotazione_rec;
           EXIT WHEN annotazione_cur1%NOTFOUND;

           UPDATE MISURA_CAUTELARE_BDMC
            SET FLAG_STATO = 'C'
            WHERE id_annotazione_manuale = annotazione_rec.id_annotazione_manuale;

        END LOOP;

          CLOSE annotazione_cur1;
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
          CLOSE annotazione_cur1;
       END;
        -- fine modifiche per integrazione bdmc

        DELETE FROM ANNOTAZIONE_MANUALE WHERE Eve_ID_EVENTO = IdEvento;
        --dbms_output.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      --dbms_output.put_line('non ci sono dati v_ann_id_annot  ?? null');
      NULL;
    END;
    -- Fine gestione Annotazioni Manuali

    --==========================================================================
    -- Gestione PENA RESIDUA
    --==========================================================================
    BEGIN
      SELECT pen_id_pena_residua
        INTO v_pen_id_pena_residua
        FROM EVENTO
       WHERE id_evento = IdEvento;

      --dbms_output.put_line('v_pen_id_pena_residua '||v_pen_id_pena_residua);
      --dbms_output.put_line('IdEvento '||IdEvento);
      IF v_pen_id_pena_residua IS NOT NULL THEN
        -- L'evento punta una pena residua, devo verificare se ?? cancellabile o meno
        -- n.b. la PR ?? cancellabile solo se a sua volta punta l'evento
        --dbms_output.put_line('v_pen_id_pena_residua ?? not null');
        BEGIN
          SELECT eve_id_evento
            INTO v_eve_pena_residua
            FROM PENA_RESIDUA
           WHERE id_pena_residua=v_pen_id_pena_residua;

          --dbms_output.put_line('v_eve_pena_residua '||v_eve_pena_residua);

          IF v_eve_pena_residua IS NOT NULL OR v_eve_pena_residua!=0 THEN
            --dbms_output.put_line('v_eve_pena_residua ?? not null');

            IF TO_CHAR(v_eve_pena_residua) = TO_CHAR(IdEvento) THEN  -- la PR punta a sua volta l'evento, posso cancellarla
              --dbms_output.put_line('v_eve_pena_residua ?? unico evento'||v_eve_annot);
              -- if idpenaresidua!=0 then
              DELETE FROM SOSPENSIONE WHERE PEN_RES_ID_PENA_RESIDUA IN
                                 (SELECT id_pena_residua FROM PENA_RESIDUA
                                   WHERE Eve_ID_EVENTO = IdEvento) ;
                                 --dbms_output.put_line('Delete SOSPENSIONE ------ >>>  OK!');

              DELETE FROM SANZIONE_SOST_RESIDUA WHERE PEN_RES_ID_PENA_RESIDUA IN
                      (SELECT id_pena_residua FROM PENA_RESIDUA
                           WHERE Eve_ID_EVENTO = IdEvento) ;
              -- end if;
              UPDATE EVENTO
                 SET pen_id_pena_residua=NULL
               WHERE id_evento = IdEvento;

              DELETE FROM PENA_RESIDUA WHERE Eve_ID_EVENTO = IdEvento;
                              --dbms_output.put_line('Delete PENA_RESIDUA ------ >>>  OK!');
            ELSIF v_eve_pena_residua!= IdEvento THEN ----la pena ?? legata ad un altro evento e non si pu?? cancellare
              --dbms_output.put_line('UPDATE EVENTO PER PENA RESIDUA ------ >>>  OK!');
              UPDATE EVENTO
                 SET pen_id_pena_residua=NULL
               WHERE id_evento = IdEvento;
            END IF;
          END IF;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
             NULL;
        END;
      ELSE
        --=================================================================
        -- L'evento NON punta direttamente una PR, vado in cancellazione delle PR
        -- che puntano l'evento e dei record collegati alle PR:
        -- SOSPENSIONE
        -- SANZIONE_SOST_RESIDUA
        --=================================================================
        --dbms_output.put_line('v_pen_id_pena_residua ?? null');
        -- if idpenaresidua!=0 then
        DELETE FROM SOSPENSIONE WHERE PEN_RES_ID_PENA_RESIDUA IN
                      (SELECT id_pena_residua FROM PENA_RESIDUA
                           WHERE Eve_ID_EVENTO = IdEvento) ;
                       --dbms_output.put_line('Delete SOSPENSIONE ------ >>>  OK!');
        -- end if;

        DELETE FROM SANZIONE_SOST_RESIDUA WHERE PEN_RES_ID_PENA_RESIDUA IN
                      (SELECT id_pena_residua FROM PENA_RESIDUA
                           WHERE Eve_ID_EVENTO = IdEvento) ;

        DELETE FROM PENA_RESIDUA WHERE Eve_ID_EVENTO = IdEvento;
                    --dbms_output.put_line('Delete PENA_RESIDUA ------ >>>  OK!');
      END IF;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      --dbms_output.put_line('non ci sono dati v_pen_id_pena_residua ?? null');
      --dbms_output.put_line('v_pen_id_pena_residua ?? null');
        -- if idpenaresidua!=0 then
        DELETE FROM SOSPENSIONE WHERE PEN_RES_ID_PENA_RESIDUA IN
                      (SELECT id_pena_residua FROM PENA_RESIDUA
                           WHERE Eve_ID_EVENTO = IdEvento) ;
                       --dbms_output.put_line('Delete SOSPENSIONE ------ >>>  OK!');
                 -- end if;

        DELETE FROM SANZIONE_SOST_RESIDUA WHERE PEN_RES_ID_PENA_RESIDUA IN
                      (SELECT id_pena_residua FROM PENA_RESIDUA
                           WHERE Eve_ID_EVENTO = IdEvento) ;

        DELETE FROM PENA_RESIDUA WHERE Eve_ID_EVENTO = IdEvento;
                    --dbms_output.put_line('Delete PENA_RESIDUA ------ >>>  OK!');

    END;

    --==================================================
    -- GESTIONE DECRETI E ORDINANZE
    --==================================================
    BEGIN
      SELECT id_deposito_ordinanza_pc INTO idOrdinanza FROM DEPOSITO_ORDINANZA_PC
       WHERE ID_EVENTO_GENERATO = IdEvento;

    EXCEPTION WHEN NO_DATA_FOUND THEN
        idordinanza:=0;
    END;

    BEGIN
      SELECT id_deposito_decreto INTO iddecreto FROM DEPOSITO_DECRETO
       WHERE ID_EVENTO_GENERATO = IdEvento;

    EXCEPTION WHEN NO_DATA_FOUND THEN
        iddecreto:=0;
    END;

    IF idOrdinanza !=0 OR iddecreto!=0 THEN
      DELETE FROM TENORE WHERE DEP_OPID_DEPOSITO_ORDINANZA_PC = idOrdinanza OR
         DEP_DEC_ID_DEPOSITO_DECRETO = iddecreto;
        dbms_output.put_line('Delete TENORE ------ >>>  OK!');
      DELETE FROM IMPUGNAZIONE WHERE DEP_OPID_DEPOSITO_ORDINANZA_PC = idOrdinanza OR
         DEP_DEC_ID_DEPOSITO_DECRETO = iddecreto;
        dbms_output.put_line('Delete IMPUGNAZIONE ------ >>>  OK!');
    END IF;

    DELETE FROM DEPOSITO_ORDINANZA_PC WHERE ID_EVENTO_GENERATO = IdEvento;
    --dbms_output.put_line('Delete DEPOSITO_ORDINANZA_PC ------ >>>  OK!');

    DELETE FROM DECRETO_ORDINANZA_SIEP WHERE ID_EVENTO_GENERATO = IdEvento;
    --dbms_output.put_line('Delete DECRETO_ORDINANZA_SIEP ------ >>>  OK!');

    DELETE FROM DEPOSITO_DECRETO WHERE ID_EVENTO_GENERATO = IdEvento;
    --dbms_output.put_line('Delete DEPOSITO_DECRETO ------ >>>  OK!');

    DELETE FROM RIEPILOGO_PROVVEDIMENTO WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete RIEPILOGO_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM FUNGIBILITA WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete FUNGIBILITA ------ >>>  OK!');

    DELETE FROM ARCHIVIAZIONE WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete ARCHIVIAZIONE ------ >>>  OK!');

    DELETE FROM UDIENZA_PROCEDIMENTO WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete UDIENZA_PROCEDIMENTO ------ >>>  OK!');

    DELETE FROM SCADENZARIO_SIEP  WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete SCADENZARIO_SIEP  ------ >>>  OK!');

    DELETE FROM SCAMBIO_SANZIONE  WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete SCAMBIO_SANZIONE  ------ >>>  OK!');

    DELETE FROM PERIODO_ALTRA_SANZIONE  WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete PERIODO_ALTRA_SANZIONE  ------ >>>  OK!');

	DELETE FROM UDIENZA_PROCEDIMENTO_SIGE WHERE Eve_ID_EVENTO = IdEvento;   --- AGGIUNTO IL 13/1/2010  -  UMBERTO
    dbms_output.put_line('Delete UDIENZA_PROCEDIMENTO_SIGE ------ >>>  OK!');
   
    --==================================================
    -- GESTIONE RATEIZZAZIONI - 2023.03 MEV_2023-13 
    --==================================================
    UPDATE RATEIZZAZIONE_PP SET EVE_ID_EVENTO = NULL WHERE EVE_ID_EVENTO = IdEvento;
   
    --==========================================================================
    -- modifica per gestire l'evento generato dall'evento che sto cancellando.
    --==========================================================================
    BEGIN
      BEGIN
        SELECT ID_EVENTO
          INTO ID_EVENTO_GENERATO
          FROM EVENTO
         WHERE EVE_ID_EVENTO = IdEvento;

      EXCEPTION WHEN NO_DATA_FOUND THEN
        DELETE FROM EVENTO WHERE id_evento = IdEvento;
        --dbms_output.put_line('Delete EVENTO ------ >>>  OK!');
        ID_EVENTO_GENERATO:=0;
      END;

      IF ID_EVENTO_GENERATO > 0 THEN
        ID_EVENTO_GENERANTE:=IdEvento;

        --dbms_output.put_line('CHIAMO LA PULISCI1');
        Pulisci1.pulisci_evento(ID_EVENTO_GENERATO,esito_pulisci);

        DELETE FROM EVENTO WHERE id_evento = ID_EVENTO_GENERANTE;
        --dbms_output.put_line('Delete EVENTO ------ >>>  OK!');
      END IF;
    END;

    COMMIT;
    EsitoPulisciEvento := 'Evviva Abbiamo pulito tutto!!!';

  END Pulisci_Evento;

--==============================================================================
-- PROCEDURE  PULISCI_FASCICOLO
--==============================================================================
  PROCEDURE Pulisci_Fascicolo
    ( IdFascicolo IN NUMBER,
       EsitoPulisciFascicolo IN OUT VARCHAR2)
  IS
      -- Enter the procedure variables here. As shown below

  BEGIN
    --dbms_output.put_line('*************************************************************************************************');
    --dbms_output.put_line('--------------------- INIZIO PULISCI FASCICOLO ---------------------');
    --dbms_output.put_line('*************************************************************************************************');

 DELETE FROM SOSPENSIONE WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete SOSPENSIONE ------ >>>  OK!');

    DELETE FROM SANZIONE_SOST_RESIDUA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;

    DELETE FROM ANNOTAZIONE_MANUALE WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');
    DELETE FROM PENA_COMPLESSIVA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete PENA_COMPLESSIVA ------ >>>  OK!');

    DELETE FROM PENA_RESIDUA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete PENA_RESIDUA ------ >>>  OK!');
    DELETE FROM REATO WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete REATO------ >>>  OK!');
    DELETE FROM CIRCOSTANZA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete CIRCOSTANZA----- >>>  OK!');

    DELETE FROM LUOGO_DETENZIONE WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete LUOGO_DETENZIONE ------ >>>  OK!');

    DELETE FROM STATO_PROCEDIMENTO WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete STATO_PROCEDIMENTO ------ >>>  OK!');

    DELETE FROM ALTRA_CAUSA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete ALTRA_CAUSA ------ >>>  OK!');

    DELETE FROM POSIZIONE_GIURIDICA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete POSIZIONE_GIURIDICA ------ >>>  OK!');

    DELETE FROM SCADENZARIO_SIEP WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete SCADENZARIO_SIEP ------ >>>  OK!');

    DELETE FROM FUNGIBILITA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete FUNGIBILITA ------ >>>  OK!');
    DELETE FROM RESIDENZA_FASCICOLO_SIEP WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete RESIDENZA_FASCICOLO_SIEP------ >>>  OK!');
    DELETE FROM MAGISTRATO_COMPETENTE WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete MAGISTRATO_COMPETENTE------ >>>  OK!');

    DELETE FROM ARCHIVIAZIONE WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete ARCHIVIAZIONE ------ >>>  OK!');

    DELETE FROM CAMPO_NOTA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete CAMPO_NOTA ------ >>>  OK!');

    DELETE FROM RIEPILOGO_PROVVEDIMENTO WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete RIEPILOGO_PROVVEDIMENTO ------ >>>  OK!');
    DELETE FROM MAX_STATO_PROCEDIMENTO WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete MAX_STATO_PROCEDIMENTO ------ >>>  OK!');

    DELETE FROM MISURA_SICUREZZA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete MISURA_SICUREZZA ------ >>>  OK!');

    DELETE FROM RICHIESTA_CONVERSIONE WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('Delete RICHIESTA_CONVERSIONE------ >>>  OK!');

    DELETE FROM AVVOCATO_FASCICOLO_SIEP WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --dbms_output.put_line('DeleteAVVOCATO_FASCICOLO_SIEP------ >>>  OK!');
    COMMIT;
    EsitoPulisciFascicolo := 'Evviva Abbiamo pulito tutto!!!';

  END Pulisci_Fascicolo;

--==============================================================================
-- PROCEDURE PULISCI_EVENTI
--==============================================================================
  PROCEDURE Pulisci_Eventi
    ( IdFascicolo IN NUMBER,
       EsitoPulisciFascicolo IN OUT VARCHAR2)
  IS
      -- Enter the procedure variables here. As shown below
    CURSOR elenco_eventi(IdFascicolo IN NUMBER) IS

    SELECT id_evento
      FROM EVENTO
     WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo
     ORDER BY id_evento DESC;

    appo_evento  NUMBER;
    esito_pulisci VARCHAR2(100);

  BEGIN
    --dbms_output.put_line('*************************************************************************************************');
    --dbms_output.put_line('--------------------- INIZIO PULISCI EVENTI ---------------------');
    --dbms_output.put_line('*************************************************************************************************');

    OPEN elenco_eventi(IdFascicolo);

    LOOP
      FETCH elenco_eventi INTO   appo_evento;
      --dbms_output.put_line('appo_evento = ' || appo_evento);
      Pulisci.pulisci_evento(appo_evento,esito_pulisci);

      EXIT WHEN elenco_eventi%NOTFOUND;
    END LOOP;
   --commit;

    CLOSE elenco_eventi;

    Pulisci.pulisci_fascicolo(IdFascicolo,esito_pulisci);
    EsitoPulisciFascicolo := 'Evviva Abbiamo pulito tutto!!!';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('ERRORE!!!');
  END Pulisci_Eventi;

--==============================================================================
-- PROCEDURE PULISCI_FASCICOLO_SIUS
--==============================================================================

      PROCEDURE Pulisci_Fascicolo_SIUS
    ( IdFascicoloSIUS IN NUMBER,
       EsitoPulisciFascicolo IN OUT VARCHAR2)
    IS
      -- Enter the procedure variables here. As shown below

    CURSOR elenco_eventi(IdFascicolo IN NUMBER) IS

    SELECT id_evento
      FROM EVENTO
     WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS
     ORDER BY id_evento DESC;

    appo_evento  NUMBER;
    esito_pulisci VARCHAR2(100);

   BEGIN
    DBMS_OUTPUT.PUT_LINE('*************************************************************************************************');
    DBMS_OUTPUT.PUT_LINE('--------------------- INIZIO PULISCI FASCICOLO SIUS---------------------');
    DBMS_OUTPUT.PUT_LINE('*************************************************************************************************');

        OPEN elenco_eventi(IdFascicoloSIUS);
  DBMS_OUTPUT.PUT_LINE('INIZIO FETCH EVENTI ------ >>>  OK!');
    LOOP
      FETCH elenco_eventi INTO   appo_evento;
      --dbms_output.put_line('appo_evento = ' || appo_evento);
      Pulisci.pulisci_evento(appo_evento,esito_pulisci);

      EXIT WHEN elenco_eventi%NOTFOUND;
    END LOOP;
	  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('NESSUN EVENTO TROVATO');
   --commit;

    CLOSE elenco_eventi;
     DBMS_OUTPUT.PUT_LINE('FINE FETCH EVENTI ------ >>>  OK!');

	   DELETE FROM MAGISTRATO_RELATORE WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
        DBMS_OUTPUT.PUT_LINE('Delete MAGISTRATO_RELATORE ------ >>>  OK!');

       DELETE FROM AVVOCATO_FASCICOLO_SIUS WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete AVVOCATO_FASCICOLO_SIUS ------ >>>  OK!');

  DELETE FROM CANC_ASS_FASC_SIUS WHERE FAS_SIUS_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete CANC_ASS_FASC_SIUS ------ >>>  OK!');

  DELETE FROM ESECUZIONE_MISURA_ALTERNATIVA WHERE GEN_PRID_GENERALE_PROCEDIMENTO IN
       (SELECT ID_GENERALE_PROCEDIMENTO FROM GENERALE_PROCEDIMENTO
            WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS);
     DBMS_OUTPUT.PUT_LINE('Delete ESECUZIONE_MISURA_ALTERNATIVA ------ >>>  OK!');

     DELETE FROM ESECUZIONE_SANZIONE_SOST WHERE GEN_PRID_GENERALE_PROCEDIMENTO IN
       (SELECT ID_GENERALE_PROCEDIMENTO FROM GENERALE_PROCEDIMENTO
            WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS);
     DBMS_OUTPUT.PUT_LINE('Delete ESECUZIONE_SANZIONE_SOS ------ >>>  OK!');

     DELETE FROM TENORE WHERE GEN_PRID_GENERALE_PROCEDIMENTO IN
       (SELECT ID_GENERALE_PROCEDIMENTO FROM GENERALE_PROCEDIMENTO
            WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS);
     DBMS_OUTPUT.PUT_LINE('Delete TENORE ------ >>>  OK!');

     DELETE FROM UDIENZA_PROCEDIMENTO WHERE GEN_PRID_GENERALE_PROCEDIMENTO IN
       (SELECT ID_GENERALE_PROCEDIMENTO FROM GENERALE_PROCEDIMENTO
            WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS);
     DBMS_OUTPUT.PUT_LINE('Delete UDIENZA_PROCEDIMENTO------ >>>  OK!');

    DELETE FROM LUOGO_DETENZIONE WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete LUOGO_DETENZIONE ------ >>>  OK!');

    DELETE FROM NOTE WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete NOTE ------ >>>  OK!');

    DELETE FROM PERIODO_ALTRA_SANZIONE WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete PERIODO_ALTRA_SANZIONE ------ >>>  OK!');

  DELETE FROM SCADENZARIO_SIUS WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete SCADENZARIO_SIUS ------ >>>  OK!');

  DELETE FROM POSIZIONE_MATERIALE_FASC_SIUS WHERE FAS_SIUS_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
   DBMS_OUTPUT.PUT_LINE('POSIZIONE_MATERIALE_FASC_SIUS ------ >>>  OK!');

   DELETE FROM RESIDENZA_FASCICOLO_SIUS WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
   DBMS_OUTPUT.PUT_LINE('Delete RESIDENZA_FASCICOLO_SIUS ------ >>>  OK!');

   DELETE FROM RICHIESTA_CONVERSIONE WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
   DBMS_OUTPUT.PUT_LINE('Delete RICHIESTA_CONVERSIONE ------ >>>  OK!');

     DELETE FROM ULTERIORE_ISTANZA_TENORE WHERE ULT_IST_ID_ULTERIORE_ISTANZA IN
       (SELECT ID_ULTERIORE_ISTANZA FROM ULTERIORE_ISTANZA
            WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS);
     DBMS_OUTPUT.PUT_LINE('Delete ULTERIORE_ISTANZA_TENORE ------ >>>  OK!');

   DELETE FROM ULTERIORE_ISTANZA WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
   DBMS_OUTPUT.PUT_LINE('Delete ULTERIORE_ISTANZA ------ >>>  OK!');

   DELETE FROM GENERALE_PROCEDIMENTO WHERE FAS_SIU_ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete GENERALE_PROCEDIMENTO ------ >>>  OK!');

   DELETE FROM FASCICOLO_SIUS WHERE ID_FASCICOLO_SIUS = IdFascicoloSIUS;
     DBMS_OUTPUT.PUT_LINE('Delete FASCICOLO_SIUS ------ >>>  OK!');

    COMMIT;
    EsitoPulisciFascicolo := 'Evviva Abbiamo pulito tutto FASCICOLO_SIUS!!!';

   END Pulisci_Fascicolo_SIUS;

--==============================================================================
-- PROCEDURE PULISCI_FASCICOLO_SIGE
--==============================================================================

      PROCEDURE Pulisci_Fascicolo_SIGE
	   ( IdFascicoloSIGE IN NUMBER,
       EsitoPulisciFascicolo IN OUT VARCHAR2)
    IS
      -- Enter the procedure variables here. As shown below

	    idRichiestaSIGE            NUMBER := 0;

    CURSOR elenco_PROVVEDIMENTI(IdFascicoloSIGE IN NUMBER) IS

    SELECT id_provvedimento_sige,id_evento_generato
	FROM PROVVEDIMENTO_SIGE
            WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE
     ORDER BY id_PROVVEDIMENTO_SIGE DESC;

    appo_provvedimento NUMBER;
	appo_evento_generato  NUMBER;
    esito_pulisci VARCHAR2(100);

   BEGIN
    DBMS_OUTPUT.PUT_LINE('*************************************************************************************************');
    DBMS_OUTPUT.PUT_LINE('--------------------- INIZIO PULISCI FASCICOLO SIGE---------------------');
    DBMS_OUTPUT.PUT_LINE('*************************************************************************************************');

	   DELETE FROM MAGISTRATO_ASSEGNATARIO WHERE FAS_SIGE_ID_FASCICOLO_SIGE = IdFascicoloSIGE;
        DBMS_OUTPUT.PUT_LINE('Delete MAGISTRATO_ASSEGNATARIO ------ >>>  OK!');

       DELETE FROM AVVOCATO_FASCICOLO_SIGE WHERE FAS_SIGE_ID_FASCICOLO_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete AVVOCATO_FASCICOLO_SIGE ------ >>>  OK!');

       DELETE FROM RESIDENZA_FASCICOLO_SIGE WHERE FAS_SIGE_ID_FASCICOLO_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete RESIDENZA_FASCICOLO_SIGE ------ >>>  OK!');

	 	 DELETE FROM UDIENZA_PROCEDIMENTO_SIGE WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete UDIENZA_PROCEDIMENTO_SIGE ------ >>>  OK!');

  DELETE FROM FAS_SIGE_DETENZIONE WHERE FAS_ID_FAS_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete FAS_SIGE_DETENZIONE ------ >>>  OK!');

  DELETE FROM PENA_COMPLESSIVA_SENTENZA_SIGE WHERE FAS_SIGE_SEN_ID IN
       (SELECT ID_FAS_SIGE_SENTENZA FROM FAS_SIGE_SENTENZA
            WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE);
     DBMS_OUTPUT.PUT_LINE('Delete PENA_COMPLESSIVA_SENTENZA_SIGE ------ >>>  OK!');

     DELETE FROM PENA_ACCESSORIA_SENTENZA_SIGE WHERE FAS_SIGE_SEN_ID IN
       (SELECT ID_FAS_SIGE_SENTENZA FROM FAS_SIGE_SENTENZA
            WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE);
     DBMS_OUTPUT.PUT_LINE('Delete PENA_ACCESSORIA_SENTENZA_SIGE ------ >>>  OK!');

     DELETE FROM REATO_SENTENZA_SIGE WHERE FAS_SIGE_SEN_ID IN
       (SELECT ID_FAS_SIGE_SENTENZA FROM FAS_SIGE_SENTENZA
            WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE);
     DBMS_OUTPUT.PUT_LINE('Delete REATO_SENTENZA_SIGE ------ >>>  OK!');

  	 DELETE FROM FAS_SIGE_SENTENZA WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete FAS_SIGE_SENTENZA ------ >>>  OK!');

     DELETE FROM TENORE_SENTENZA_REATO WHERE TEN_ID_TENORE_SIGE IN
       (SELECT ID_TENORE_SIGE FROM TENORE_SIGE
            WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE);
     DBMS_OUTPUT.PUT_LINE('Delete TENORE_SENTENZA_REATO------ >>>  OK!');

	 DELETE FROM DATI_PROVVEDIMENTO_SIGE WHERE TEN_ID_TENORE_SIGE IN
       (SELECT ID_TENORE_SIGE FROM TENORE_SIGE
            WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE);
     DBMS_OUTPUT.PUT_LINE('Delete DATI_PROVVEDIMENTO_SIGE------ >>>  OK!');

	 DELETE FROM TENORE_SIGE WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete TENORE_SIGE ------ >>>  OK!');

	 OPEN elenco_provvedimenti(IdFascicoloSIGE);
  	 DBMS_OUTPUT.PUT_LINE('INIZIO FETCH EVENTI ------ >>>  OK!');
    LOOP
      FETCH elenco_provvedimenti INTO   appo_provvedimento, appo_evento_generato;
      dbms_output.put_line('appo_evento_generato = ' || appo_evento_generato);
	  	 DELETE FROM PROVVEDIMENTO_SIGE WHERE FAS_ID_FASCICOLO_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete PROVVEDIMENTO_SIGE ------ >>>  OK!');
      Pulisci.pulisci_evento(appo_evento_generato,esito_pulisci);

     EXIT WHEN elenco_provvedimenti%NOTFOUND;
    END LOOP;
	  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('NESSUN PROVVEDIMENTO TROVATO');
   --commit;

    CLOSE elenco_provvedimenti;
     DBMS_OUTPUT.PUT_LINE('FINE FETCH provvedimenti ------ >>>  OK!');

      SELECT RIC_ID_RICHIESTA_SIGE
        INTO idRichiestaSIGE
        FROM FASCICOLO_SIGE
       WHERE ID_FASCICOLO_SIGE = IdFascicoloSIGE;

  DELETE FROM FASCICOLO_SIGE WHERE ID_FASCICOLO_SIGE = IdFascicoloSIGE;
     DBMS_OUTPUT.PUT_LINE('Delete FASCICOLO_SIGE ------ >>>  OK!');

  DELETE FROM RICHIESTA_SIGE WHERE ID_RICHIESTA_SIGE = idRichiestaSIGE;
   DBMS_OUTPUT.PUT_LINE('RICHIESTA_SIGE ------ >>>  OK!');

    COMMIT;
    EsitoPulisciFascicolo := 'Evviva Abbiamo pulito tutto FASCICOLO_SIGE!!!';

   END Pulisci_Fascicolo_SIGE;

   -- Enter further code below as specified in the Package spec.
END; -- Package Body PULISCI;
/