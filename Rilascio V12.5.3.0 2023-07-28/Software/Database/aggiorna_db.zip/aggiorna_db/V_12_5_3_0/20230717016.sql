-- Nuovo codice per "Decisioni della Sorveglianza -> Rigetto Misure Alternative"
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES('MOTIVO_PROVVEDIMENTO', '1099', NULL, NULL, 'per la carcerazione', null, NULL, NULL, NULL);

-- Nuovo dettaglio/validazione per "Decisioni della Sorveglianza -> Rigetto Misure Alternative"
INSERT INTO DETTAGLIO_PROVVEDIMENTO
(COD_TIPO_EVENTO, COD_TIPO_PROVVEDIMENTO, COD_MOTIVO, ACTION_DETTAGLIO, NOTE, ACTION_UPLOAD)
VALUES('01', '06', '1099'
, 'siap.siep.misuraalternativa.action.ActDettaglioMARigetto'
, 'Decisioni della Sorveglianza -> Rigetto Misure Alternative'
, 'siap.siep.misuraalternativa.action.ActUploadRigetto');

-- Nuova classificazione per le statistiche per il nuovo codice
INSERT INTO STATO_ESECUZIONE_PROCEDIMENTO
(COD_TIPO_PROVVEDIMENTO, COD_MOTIVO, COD_STATO_PROCEDIMENTO, COD_STATO_FASCICOLO_RES, COD_POSIZIONE_GIURIDICA)
VALUES('06', '1099', '0122', '7', NULL);