update jms_code c set c.descrizione = 'BOLZANO/BOZEN' where c.descrizione = 'BOLZANO' and c.dominio = 'BDI';
update jms_code c set c.codice = 'BOLZANO/BOZEN' where c.codice = 'BOLZANO' and c.dominio = 'CONN_JMS_STRING';
update jms_code c set c.codice = 'BOLZANO/BOZEN' where c.codice = 'BOLZANO'	and c.dominio = 'PROGR_BDI';