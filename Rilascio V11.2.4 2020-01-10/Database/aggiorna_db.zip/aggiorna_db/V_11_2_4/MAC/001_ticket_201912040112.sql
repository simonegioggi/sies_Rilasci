Insert into DETTAGLIO_PROVVEDIMENTO
    (COD_TIPO_EVENTO, 
     COD_TIPO_PROVVEDIMENTO, COD_MOTIVO, ACTION_DETTAGLIO, NOTE, ACTION_UPLOAD)
  Values
    ('01', '25', '1786', 'siap.siep.archiviazione.action.ActLoadDettaglioProvvAltraAutorita', 'Definizione Procedimento -> archiviazione per declaratoria estinzione liberta'' controllata', 
     'siap.siep.archiviazione.action.ActUploadNonLuogoAProvvedere');
 Insert into TEMPLATE
    (ID_TEMPLATE, 
     NOME_TEMPLATE, DESCR, PATH_RICERCA, COD_TIPO_EVENTO, COD_TIPO_PROVVEDIMENTO, 
     COD_MOTIVO, FLAG_TEMPLATE, COD_ESITO, COD_OGGETTO_PROCEDIMENTO, MAG_COD_MAGISTRATO, 
     COD_TIPO_PROVVEDIMENTO_SIGE)
  Values
    ('ARCHI_AA_1786', 'SIEP_ARC_GENERICO.rtf', 'Dichiara estinta la liberta'' controllata', '/var/SIES/template/siep/arc/', '01', 
     '25', '1786', '0', NULL, NULL, 
     NULL, NULL);
