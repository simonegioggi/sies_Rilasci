insert into template
values
  ('SIUS_OR_114',
   'SIUS_OR_GENERICOU067.rtf',
   'Ordinanza Generica Riesame Misure Sicurezza',
   '/var/SIES/template/sius/or/',
   '01',
   '03',
   null,
   null,
   null,
   'U114',
   null,
   Null);
