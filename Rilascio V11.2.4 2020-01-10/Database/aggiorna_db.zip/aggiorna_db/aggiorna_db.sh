#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/V_11_2_4/aggiorna_db.sql