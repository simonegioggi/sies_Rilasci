#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/V_12_7_1_0/aggiorna_db.sql