#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/V_12_4_19_0/aggiorna_db.sql