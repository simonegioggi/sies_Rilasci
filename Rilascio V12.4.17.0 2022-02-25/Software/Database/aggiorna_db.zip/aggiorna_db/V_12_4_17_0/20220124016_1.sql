CREATE OR REPLACE PACKAGE BODY ISPETTORATO_MS IS
  /* -------------------------------------------------*/

  eseguo_insert             EXCEPTION;
  salta_record              EXCEPTION;
  registra_scarto           EXCEPTION;
  close_cur                 EXCEPTION;
  duplico_pena_residua      EXCEPTION;
  caso_non_sviluppato       EXCEPTION;
  gestione_MA               EXCEPTION;
  gestione_lib_condizionale EXCEPTION;
  v_id_evento                EVENTO.ID_EVENTO%TYPE := NULL;
  v_cod_tipo_evento          EVENTO.cod_tipo_evento%TYPE := '';
  v_cod_tipo_provvedimento   EVENTO.cod_tipo_provvedimento%TYPE := '';
  v_cod_motivo               EVENTO.cod_motivo%TYPE := '';
  v_desc_motivo              CG_REF_CODES.rv_meaning%TYPE;
  v_conta                    NUMBER;
  v_progressivo              NUMBER;
  v_progressivo_nota         NUMBER;
  v_progressivo_pg           NUMBER := NULL;
  v_progressivo_pen          NUMBER;
  v_progressivo_ann          NUMBER;
  v_progressivo_lib          NUMBER;
  v_progressivo_fun          NUMBER;
  v_progressivo_sos          NUMBER;
  v_progressivo_ist          NUMBER;
  v_progressivo_not          NUMBER;
  v_progressivo_ten          NUMBER;
  v_progressivo_dep_ord      NUMBER;
  v_progressivo_dec_ord      NUMBER;
  v_progressivo_dep_dec      NUMBER;
  v_progressivo_mis_alt      NUMBER;
  v_progressivo_cum          NUMBER;
  v_progressivo_pen_cum      NUMBER;
  v_progressivo_ult_san      NUMBER;
  v_cod_tipo_evento_1        EVENTO.cod_tipo_evento%TYPE := '';
  v_cod_tipo_provvedimento_1 EVENTO.cod_tipo_provvedimento%TYPE := '';
  v_cod_motivo_1             EVENTO.cod_motivo%TYPE := '';
  v_cod_tipo_provvedimento_2 EVENTO.cod_tipo_provvedimento%TYPE := '';
  v_cod_motivo_2             EVENTO.cod_motivo%TYPE := '';
  v_cod_tipo_provvedimento_3 EVENTO.cod_tipo_provvedimento%TYPE := '';
  v_cod_motivo_3             EVENTO.cod_motivo%TYPE := '';
  v_cod_tipo_provvedimento_4 EVENTO.cod_tipo_provvedimento%TYPE := '';
  v_cod_motivo_4             EVENTO.cod_motivo%TYPE := '';
  v_cod_tipo_provvedimento_5 EVENTO.cod_tipo_provvedimento%TYPE := '';
  v_cod_motivo_5             EVENTO.cod_motivo%TYPE := '';
  v_data_appo                VARCHAR2(30);
  v_data_appo1               VARCHAR2(30);
  v_data_inserimento         DATE;
  v_data_verifica            DATE;
  glb_tipo_provv             tbl_tipo_provv := tbl_tipo_provv();
  glb_motivo                 tbl_motivo := tbl_motivo();
  glb_ufficio_emit           tbl_ufficio_emit := tbl_ufficio_emit();
  glb_comune_emit            tbl_comune_emit := tbl_comune_emit();
  glb_data_emis              tbl_data_emis := tbl_data_emis();
  glb_data_tras              tbl_data_tras := tbl_data_tras();

  v_cod_stat_fas VARCHAR2(4) := '';
  v_note         VARCHAR2(2000);

  glb_tipo_sanz  tbl_tipo_sanz := tbl_tipo_sanz();
  glb_anni       tbl_anni := tbl_anni();
  glb_mesi       tbl_mesi := tbl_mesi();
  glb_giorni     tbl_giorni := tbl_giorni();

  -----------------------------------------------------------------------------------------------------------------------
  ------------------------------------PROCEDURA CARICA_PROVVEDIMENTI-------------------------------------------------------
  -----------------------------------------------------------------------------------------------------------------------

  PROCEDURE stat_provvedimenti

  (par_ufficio       IN VARCHAR2,
   par_ufficio1      IN VARCHAR2,
   par_ufficio2      IN VARCHAR2,
   par_ufficio3      IN VARCHAR2,
   par_data_verifica IN VARCHAR2,
   par_data_inizio   IN VARCHAR2,
   par_data_fine     IN VARCHAR2) IS

    --DEFINIZIONE VARIABILI
    v_note1 VARCHAR2(2000);

    v_tipo_richiesta          CAMPO_NOTA.oggetto_nota_res%TYPE;
    v_id_fascicolo_siep       FASCICOLO_SIEP.fas_sie_id_fascicolo_siep%TYPE;
    v_anno_af8_nrgem          EVENTO.anno_protocollo%TYPE;
    v_progr_af8_nrgem         EVENTO.progr_protocollo%TYPE;
    v_chiave_anno             FASCICOLO_SIEP.chiave_anno%TYPE;
    v_chiave_progr            FASCICOLO_SIEP.chiave_progr%TYPE;
    v_cod_ufficio_inserimento FASCICOLO_SIEP.cod_ufficio_inserimento%TYPE;
    v_chiave_progr_orig       FASCICOLO_SIEP.chiave_progr_orig%TYPE;
    v_cod_posizione_giuridica POSIZIONE_GIURIDICA.cod_posizione_giuridica%TYPE;
    v_con_rev                 VARCHAR2(30);
    v_tip_aut                 VARCHAR2(70);
    v_tip_att                 VARCHAR2(80);
    v_motiv                   VARCHAR2(50);
    v_af8_nres                FASCICOLO_SIEP.fas_sie_id_fascicolo_siep%TYPE;

    v_cod_stato_procedimento    STATO_PROCEDIMENTO.cod_stato_procedimento%TYPE;
    flag_no_riepilogo           CHAR(1);
    tot_recl                    NUMBER;
    tot_arre                    NUMBER;
    v_num_anni_reclusione       NUMBER(4);
    v_num_mesi_reclusione       NUMBER(4);
    v_num_giorni_reclusione     NUMBER(4);
    v_importo_multa             NUMBER(11, 2);
    v_num_anni_arresto          NUMBER(4);
    v_num_mesi_arresto          NUMBER(4);
    v_num_giorni_arresto        NUMBER(4);
    v_importo_ammenda           NUMBER(11, 2);
    gg_tot                      NUMBER;
    tot_pres                    NUMBER;
    v_data_inizio_pena_residua  PENA_RESIDUA.data_inizio%TYPE;
    v_data_fine_pena_residua    PENA_RESIDUA.data_fine%TYPE;
    v_flag_ergastolo            PENA_RESIDUA.flag_ergastolo%TYPE;
    v_id_fascicolo_siep_old     FASCICOLO_SIEP.fas_sie_id_fascicolo_siep%TYPE;
    v_id_evento_old             FASCICOLO_SIEP.fas_sie_id_fascicolo_siep%TYPE;
    v_cod_stato_fascicolo       FASCICOLO_SIEP.cod_stato_fascicolo%TYPE;
    v_cod_stato_fascicolo_res   STATO_FASCICOLO_RES_MS.cod_stato_fascicolo%TYPE := '';
    v_num_anni_reclusione_sen   NUMBER(4);
    v_num_mesi_reclusione_sen   NUMBER(4);
    v_num_giorni_reclusione_sen NUMBER(4);
    v_importo_multa_sen         NUMBER(11, 2);
    v_num_anni_arresto_sen      NUMBER(4);
    v_num_mesi_arresto_sen      NUMBER(4);
    v_num_giorni_arresto_sen    NUMBER(4);
    v_importo_ammenda_sen       NUMBER(11, 2);

    -- variabile generali
    conta_commit NUMBER;
	conta_classificazioni NUMBER;
    v_trovato NUMBER;

    num_record_scritti NUMBER := 0;
    num_record_letti   NUMBER := 0;
    --num_record_scartati       NUMBER:= 0;
    v_anno_res           NUMBER(4) := NULL;
    v_num_res            VARCHAR2(6) := '';
    v_quantum            VARCHAR2(1) := '';
    v_quantum_pena_compl VARCHAR2(1) := '';
    salta_record EXCEPTION;
    v_uscita           VARCHAR2(1) := 'N';
    v_conta_provv      NUMBER := 0;
    v_conta_scarti     NUMBER := 0;
    v_data_inserimento DATE;

    v_fasc_archiviato          VARCHAR2(1) := 'N';
    esiste_altri               NUMBER;
    v_desc_ufficio_inserimento VARCHAR2(200);

    -- dichiarazione variabile tipo misura di sicurezza
    v_tipo_misura_sic              VARCHAR2(2 CHAR);
    v_quantum_inizio_misura_anni   NUMBER;
    v_quantum_inizio_misura_mesi   NUMBER;
    v_quantum_inizio_misura_giorni NUMBER;
    -- dichiarazione variabile data scadenza comunicazione Ms alla sorveglianza
    -- � calcolata dalla data_fine_pena_residura - quantum (PARAMETRO INIZIO_MISURA)
    v_data_scadenza_comunicazione DATE;
    v_cod_ufficio_competente      COMPETENZA.CHIAVE_UFFICIO%Type := NULL;
    v_flag_visto                  messaggio.flag_visto%type;
    v_evento_inoltro_UDS          VARCHAR2(1) := 'N';

  -- DICHIARAZIONE DEL CURSORE DEI FASCICOLI LA CUI ASSEGNAZIONE DELLA CATEGOIA
  -- VIENE FATTA IN BASE ALLO STATO DEL PROCEDIMENTO
  CURSOR my_curFascicoli IS
      SELECT DISTINCT id_fascicolo_siep,
                    chiave_anno,
                    chiave_progr,
                    e.cod_tipo_provvedimento,
                    e.cod_motivo,
                    sp.cod_stato_procedimento,
                    PG.COD_POSIZIONE_GIURIDICA,
                    a.cod_ufficio_inserimento,
                    comune_fasc_siep.DESCRIZIONE sede_ufficio_siep,
                    a.cod_stato_fascicolo
      FROM FASCICOLO_SIEP      a,
           MISURA_SICUREZZA    MS,
           EVENTO              E,
           COMUNE              comune_fasc_siep,
           UFFICIO             ufficio_fasc_siep,
          stato_procedimento  sp,
           POSIZIONE_GIURIDICA PG
     WHERE
         -- ULTIMA POSIZIONE GIURIDICA
         PG.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
         AND PG.ID_POSIZIONE_GIURIDICA =
         (SELECT MAX(PPG.id_posizione_giuridica)
            FROM POSIZIONE_GIURIDICA PPG
           WHERE PPG.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
             AND (A.cod_ufficio_inserimento = par_ufficio OR
                 A.cod_ufficio_inserimento = par_ufficio1 OR
                 A.cod_ufficio_inserimento = par_ufficio2 OR
                 A.cod_ufficio_inserimento = par_ufficio3))
        -- ULTIMO  STATO PROCEDIMENTO
        AND sp.fas_sie_id_fascicolo_siep = a.id_fascicolo_siep
        AND ( (sp.DATA, sp.progressivo) IN
        (SELECT MAX(DATA), MAX(progressivo)
          FROM STATO_PROCEDIMENTO PP
         WHERE PP.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
           AND (a.cod_ufficio_inserimento = par_ufficio OR
               a.cod_ufficio_inserimento = par_ufficio1 OR
               a.cod_ufficio_inserimento = par_ufficio2 OR
               a.cod_ufficio_inserimento = par_ufficio3)) OR sp.DATA IS NULL OR sp.progressivo IS NULL)
        -- VALORI DA PASSARE IN INPUT IN RIFERIMENTO AL FASCICOLO
         AND (a.cod_ufficio_inserimento = par_ufficio OR
         a.cod_ufficio_inserimento = par_ufficio1 OR
         a.cod_ufficio_inserimento = par_ufficio2 OR
         a.cod_ufficio_inserimento = par_ufficio3)
        -- la statistica deve interessare solo i fascicoli di classe I
         AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
         (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
         (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
         (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
        -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
         AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
         TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
         TO_DATE(par_data_fine, 'dd/mm/yyyy')
        -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
         AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
         AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
         AND MS.DATA_FINE_VALIDITA IS NULL
        -- join per ufficio
         AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
         AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
        -- ULTIVO EVENTO DI INTERESSE
         AND E.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
         AND ( E.ID_EVENTO =
         (SELECT MAX(EE.ID_EVENTO)
            FROM EVENTO EE
           WHERE EE.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
           AND EE.FLAG_DOCUMENTO_REGISTRATO = 'S'
             AND (EE.cod_ufficio_inserimento = par_ufficio OR
                 EE.cod_ufficio_inserimento = par_ufficio1 OR
                 EE.cod_ufficio_inserimento = par_ufficio2 OR
                 EE.cod_ufficio_inserimento = par_ufficio3)) OR E.ID_EVENTO IS NULL )
         ORDER BY id_fascicolo_siep;

        -- Ticket#20220124016 - Rif. TT 20211102011 - Recupero procedimenti con dati incompleti
        -- dichiarazione del cursore fascicoli siep per recupero fascicoli non estratti negli altri cursori
      CURSOR curFascicoliSIEP IS
      SELECT id_fascicolo_siep,
             chiave_anno,
             chiave_progr,
             a.cod_ufficio_inserimento,
             a.cod_stato_fascicolo,
             MS.COD_TIPO  tipo_misura_sic
        FROM FASCICOLO_SIEP         a,
             STATO_PROCEDIMENTO     b,
--             MAX_STATO_PROCEDIMENTO c,
             MISURA_SICUREZZA       MS
       WHERE
      -- VALORI DA PASSARE IN INPUT
       (a.cod_ufficio_inserimento = par_ufficio OR
       a.cod_ufficio_inserimento = par_ufficio1 OR
       a.cod_ufficio_inserimento = par_ufficio2 OR
       a.cod_ufficio_inserimento = par_ufficio3)
      ----------
      -- la statistica deve interessare solo i fascicoli di classe IV in stato differente da iscritto (COD_STATO_FASCICOLO <> '02')
       AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
       (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
      -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
       AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
       TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
       TO_DATE(par_data_fine, 'dd/mm/yyyy')
--	   AND A.COD_STATO_FASCICOLO <> '02'
	   ---
        AND a.id_fascicolo_siep = b.fas_sie_id_fascicolo_siep(+)
--       AND b.fas_sie_id_fascicolo_siep = c.fas_sie_id_fascicolo_siep(+)
--       AND b.progressivo = c.sta_pro_progressivo
      -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
       AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
       AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
       AND MS.DATA_FINE_VALIDITA IS NULL
       ORDER BY id_fascicolo_siep;
    -- Ticket#20220124016 -  FINE
	
    -- dichiarazione del cursore degli eventi legati ai fascicoli
/*    CURSOR cur_evento(par_id_fascicolo_siep IN NUMBER) IS
      SELECT e.id_evento,
             cod_tipo_evento,
             cod_tipo_provvedimento,
             cod_motivo,
             TO_DATE(TO_CHAR(data_inserimento, 'dd/mm/yyyy'), 'dd/mm/yyyy')
        FROM EVENTO e
       WHERE fas_sie_id_fascicolo_siep = par_id_fascicolo_siep
         AND (cod_ufficio_inserimento = par_ufficio OR
             cod_ufficio_inserimento = par_ufficio1 OR
             cod_ufficio_inserimento = par_ufficio2 OR
             cod_ufficio_inserimento = par_ufficio3)
         AND flag_documento_registrato = 'S'
         AND fas_siu_id_fascicolo_sius IS NULL
         AND cod_tipo_provvedimento NOT IN ('02', '03', '-') --decreti ordinanza ISTRUTTORIA
       ORDER BY data_inserimento DESC, id_evento DESC;*/

    -- dichiarazione del cursore ATTI RICEVUTI PER COMPETENZA
    CURSOR curAttiRicevuti_NO_Iscr IS

      SELECT MESSAGGIO.CHIAVE_ANNO_SIEP,
             MESSAGGIO.CHIAVE_PROGR_SIEP,
             MESSAGGIO.CHIAVE_UFFICIO_SIEP,
             comune_fasc_siep.DESCRIZIONE sede_ufficio_siep,
             FLAG_VISTO
        FROM MESSAGGIO
        LEFT OUTER JOIN FASC_MS_TO_FASC_SIEP
          ON (MESSAGGIO.ID_MESSAGGIO =
             FASC_MS_TO_FASC_SIEP.MES_ID_MESSAGGIO), JMS_CODE
       tipoMess, JMS_CODE tipOperazione, JMS_CODE ESITO, JMS_CODE
       bdiMitt, UFFICIO uffMitt, COMUNE comuffMitt, CG_REF_CODES
       tipuffMitt, JMS_CODE bdiDest, UFFICIO uffdest, COMUNE
       comuffdest, CG_REF_CODES tipuffdest, UFFICIO uffInoltro,
       COMUNE comUffInoltro, CG_REF_CODES tipUffInoltro, UFFICIO
       uffReplyTo, COMUNE comuffReplyTo, CG_REF_CODES tipuffReplyTo,
       UFFICIO ufficio_fasc_siep, COMUNE comune_fasc_siep,
       CG_REF_CODES tipo_ufficio_fasc_siep
       WHERE COD_TIPO_MESSAGGIO = tipoMess.CODICE
         and tipoMess.dominio = 'TIPO_MESSAGGIO'
         AND COD_TIPO_OPERAZIONE = tipOperazione.CODICE
         and tipOperazione.dominio = 'TIPO_OPERAZIONE'
         AND COD_ESITO = esito.CODICE
         AND esito.DOMINIO = 'CODICE_ESITO'
         AND COD_BDI_MITTENTE = bdiMitt.CODICE
         and bdiMitt.dominio = 'BDI'
         AND COD_UFFICIO_MITTENTE = uffMitt.COD_UFFICIO
         AND uffMitt.COD_COMUNE = comuffMitt.COD_COMUNE
         AND uffMitt.COD_TIPO_UFFICIO = tipuffMitt.RV_LOW_VALUE
         AND tipuffMitt.RV_DOMAIN = 'TIPO_UFFICIO'
         AND COD_BDI_DESTINATARIA = bdiDest.CODICE
         and bdiDest.dominio = 'BDI'
         AND COD_UFFICIO_DESTINATARIO = uffdest.COD_UFFICIO
         AND comuffdest.COD_COMUNE = uffdest.COD_COMUNE
         AND uffdest.COD_TIPO_UFFICIO = tipuffdest.RV_LOW_VALUE
         AND tipuffdest.RV_DOMAIN = 'TIPO_UFFICIO'
         AND ufficio_fasc_siep.COD_UFFICIO =
             nvl(MESSAGGIO.CHIAVE_UFFICIO_SIEP, '-')
         AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
         AND ufficio_fasc_siep.COD_TIPO_UFFICIO =
             tipo_ufficio_fasc_siep.RV_LOW_VALUE
         AND tipo_ufficio_fasc_siep.RV_DOMAIN = 'TIPO_UFFICIO'
         AND uffInoltro.COD_UFFICIO =
             nvl(MESSAGGIO.COD_UFFICIO_INOLTRO, '-')
         AND uffInoltro.COD_COMUNE = comUffInoltro.COD_COMUNE
         AND uffInoltro.COD_TIPO_UFFICIO = tipUffInoltro.RV_LOW_VALUE
         AND tipUffInoltro.RV_DOMAIN = 'TIPO_UFFICIO'
         AND uffReplyTo.COD_UFFICIO =
             nvl(MESSAGGIO.COD_UFFICIO_REPLY_TO, '-')
         AND uffReplyTo.COD_COMUNE = comuffReplyTo.COD_COMUNE
         AND uffReplyTo.COD_TIPO_UFFICIO = tipuffReplyTo.RV_LOW_VALUE
         AND tipuffReplyTo.RV_DOMAIN = 'TIPO_UFFICIO'
         AND DELIVERY_MODE = '00002'
         AND COD_TIPO_MESSAGGIO = '01'
         AND COD_TIPO_OPERAZIONE in ('00071', '00074')
         AND (FLAG_VISTO = 'N' or
             (COD_ESITO in ('01001') and FLAG_VISTO = 'S'))
         AND COD_UFFICIO_DESTINATARIO = par_ufficio
            -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
         AND TO_DATE(TO_CHAR(data_invio, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
             TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
             TO_DATE(par_data_fine, 'dd/mm/yyyy')
       order by DATA_INVIO DESC;


    -- dichiarazione del cursore per Ordinanze pervenute in attesa di esecuzione.
    CURSOR curAttiInAttesaEsecuzione IS
      -- PROCEDIMENTI ISCRITTI IN CLASSE IV CHE NON HANNO ANCORA EVENTI
      SELECT M.CHIAVE_ANNO_SIEP,
             M.CHIAVE_PROGR_SIEP,
             M.CHIAVE_UFFICIO_SIEP,
             comune_fasc_siep.DESCRIZIONE sede_ufficio_siep
        FROM MESSAGGIO            M,
             fasc_ms_to_fasc_siep A,
             EVENTO               E,
             UFFICIO              ufficio_fasc_siep,
             COMUNE               comune_fasc_siep
       WHERE 1 = 1
         AND M.DELIVERY_MODE = '00002'
         AND M.COD_TIPO_MESSAGGIO = '01'
         AND M.COD_TIPO_OPERAZIONE in ('00071', '00074') -- TRASFERIMENTO_COMPETENZA_MS = "00071"; TRASFERIMENTO_ESECUZIONE_MS = "00074";
         AND M.COD_ESITO in ('01005') -- ISCRITTI IN CLASSE IV
         AND M.FLAG_VISTO = 'S'
         AND M.COD_UFFICIO_DESTINATARIO = par_ufficio
         AND A.MES_ID_MESSAGGIO = M.ID_MESSAGGIO
         AND E.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.FAS_SIE_ID_FASCICOLO_SIEP
            -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
         AND TO_DATE(TO_CHAR(M.data_invio, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
             TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
             TO_DATE(par_data_FINE, 'dd/mm/yyyy')
            --
         AND ufficio_fasc_siep.COD_UFFICIO = nvl(M.CHIAVE_UFFICIO_SIEP, '-')
         AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
       HAVING COUNT(E.ID_EVENTO) = 0
       GROUP BY M.CHIAVE_ANNO_SIEP,
                M.CHIAVE_PROGR_SIEP,
                M.CHIAVE_UFFICIO_SIEP,
                comune_fasc_siep.DESCRIZIONE
      -- PROCEDIMENTI ISCRITTI IN CLASSE IV CHE TRA GLI EVENTI NON HANNO nessun evento di esecuzione MS
      -- con tali motivi '1126', '1128', '1131', '1132', '1129'
      UNION
      SELECT M.CHIAVE_ANNO_SIEP,
             M.CHIAVE_PROGR_SIEP,
             M.CHIAVE_UFFICIO_SIEP,
             comune_fasc_siep.DESCRIZIONE sede_ufficio_siep
        FROM MESSAGGIO            M,
             fasc_ms_to_fasc_siep A,
             EVENTO               E,
             UFFICIO              ufficio_fasc_siep,
             COMUNE               comune_fasc_siep
       WHERE 1 = 1
         AND M.DELIVERY_MODE = '00002'
         AND M.COD_TIPO_MESSAGGIO = '01'
         AND M.COD_TIPO_OPERAZIONE in ('00071', '00074') -- TRASFERIMENTO_COMPETENZA_MS = "00071"; TRASFERIMENTO_ESECUZIONE_MS = "00074";
         AND M.COD_ESITO in ('01005') -- ISCRITTI IN CLASSE IV
         AND M.FLAG_VISTO = 'S'
         AND M.COD_UFFICIO_DESTINATARIO = par_ufficio
         AND A.MES_ID_MESSAGGIO = M.ID_MESSAGGIO
         AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.FAS_SIE_ID_FASCICOLO_SIEP
         -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
         AND TO_DATE(TO_CHAR(M.data_invio, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
             TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
             TO_DATE(par_data_fine, 'dd/mm/yyyy')
         -- CHE NON HANNO UN'ESECUZIONE DI MS
         -- Ticket#202109290111_NEW: va testato il 'not exists' e non il 'not in' 
         -- il fascicolo usciva anche in presenza di un evento esecutivo
         -- bastava che esistesse un altro evento. Aggiunto test anche sulla 
         -- validazione dell'evento
         -- AND E.COD_MOTIVO NOT IN ('1126', '1128', '1131', '1132', '1129')
         AND NOT EXISTS (SELECT * FROM EVENTO EV2 
           WHERE EV2.FAS_SIE_ID_FASCICOLO_SIEP = A.FAS_SIE_ID_FASCICOLO_SIEP
             AND EV2.COD_MOTIVO IN ('1126', '1128', '1131', '1132', '1129')
             AND EV2.FLAG_DOCUMENTO_REGISTRATO = 'S'
         )
         -- FINE - Ticket#202109290111_NEW
         AND ufficio_fasc_siep.COD_UFFICIO = nvl(M.CHIAVE_UFFICIO_SIEP, '-')
         AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
       HAVING COUNT(E.ID_EVENTO) > 0
       GROUP BY M.CHIAVE_ANNO_SIEP,
                M.CHIAVE_PROGR_SIEP,
                M.CHIAVE_UFFICIO_SIEP,
                comune_fasc_siep.DESCRIZIONE;

    -- dichiarazione del cursore per PROCEDIMENTI DI CLASSE I
    -- per i quali � stata fatta richiesta di abitualit�/delinquenza abituale
    CURSOR curAttiRichiestaDelinqAbituale IS
       SELECT DISTINCT id_fascicolo_siep,
                chiave_anno,
                chiave_progr,
                a.cod_ufficio_inserimento,
                comune_fasc_siep.DESCRIZIONE sede_ufficio_siep
        FROM FASCICOLO_SIEP         a,
             MISURA_SICUREZZA       MS,
             EVENTO                 E,
             COMUNE               comune_fasc_siep,
             UFFICIO              ufficio_fasc_siep
         WHERE
            -- VALORI DA PASSARE IN INPUT
             (a.cod_ufficio_inserimento = par_ufficio OR
             a.cod_ufficio_inserimento = par_ufficio1 OR
             a.cod_ufficio_inserimento = par_ufficio2 OR
             a.cod_ufficio_inserimento = par_ufficio3)
            -- la statistica deve interessare solo i fascicoli di classe I
             AND ((A.CHIAVE_PROGR < 20000) OR
             (A.CHIAVE_PROGR BETWEEN 1000000000000 AND 10000000019999) OR
             (A.CHIAVE_PROGR BETWEEN 2000000000000 AND 20000000019999) OR
             (A.CHIAVE_PROGR BETWEEN 3000000000000 AND 30000000019999))
            -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
             AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
             TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
             TO_DATE(par_data_fine, 'dd/mm/yyyy')
             -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
             AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
             AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
             AND MS.DATA_FINE_VALIDITA IS NULL
              -- join per ufficio
              AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
              AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
            -- ULTIVO EVENTO DI INTERESSE
             AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
             AND E.COD_MOTIVO = '5408' --dichiarazione di abituabilit�/professionalit� nel reato
             AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
             AND E.ID_EVENTO =
                 (SELECT MAX(EE.ID_EVENTO)
                    FROM EVENTO EE
                   WHERE EE.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
                     AND (EE.cod_ufficio_inserimento = par_ufficio OR
                         EE.cod_ufficio_inserimento = par_ufficio1 OR
                         EE.cod_ufficio_inserimento = par_ufficio2 OR
                         EE.cod_ufficio_inserimento = par_ufficio3))
             AND (E.cod_ufficio_inserimento = par_ufficio OR
                 E.cod_ufficio_inserimento = par_ufficio1 OR
                 E.cod_ufficio_inserimento = par_ufficio2 OR
                 E.cod_ufficio_inserimento = par_ufficio3)
             ORDER BY id_fascicolo_siep;

     -- dichiarazione del cursore per PROCEDIMENTI DI CLASSE IV
     -- per i quali � stata fatta ricervuta un'ordinanza di sospespensione di MS (Esecuzioni sospese per espiazione pena detentiva)
     CURSOR curAttiConSospensioneMS IS
            SELECT DISTINCT id_fascicolo_siep,
                    chiave_anno,
                    chiave_progr,
                    e.cod_tipo_provvedimento,
                    e.cod_motivo,
                    sp.cod_stato_procedimento,
                    PG.COD_POSIZIONE_GIURIDICA,
                    a.cod_ufficio_inserimento,
                    comune_fasc_siep.DESCRIZIONE sede_ufficio_siep
            FROM FASCICOLO_SIEP         a,
                 MISURA_SICUREZZA       MS,
                 EVENTO                 E,
                 COMUNE                 comune_fasc_siep,
                 UFFICIO                ufficio_fasc_siep,
                 stato_procedimento  sp,
                 POSIZIONE_GIURIDICA PG
            WHERE
              -- ULTIMA POSIZIONE GIURIDICA
               PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
               AND PG.ID_POSIZIONE_GIURIDICA =
               (SELECT MAX(PPG.id_posizione_giuridica)
                  FROM POSIZIONE_GIURIDICA PPG
                 WHERE PPG.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                   AND (A.cod_ufficio_inserimento = par_ufficio OR
                       A.cod_ufficio_inserimento = par_ufficio1 OR
                       A.cod_ufficio_inserimento = par_ufficio2 OR
                       A.cod_ufficio_inserimento = par_ufficio3))
              -- ULTIMO  STATO PROCEDIMENTO
               AND sp.fas_sie_id_fascicolo_siep = a.id_fascicolo_siep
               AND (sp.DATA, sp.progressivo) IN
               (SELECT MAX(DATA), MAX(progressivo)
                  FROM STATO_PROCEDIMENTO PP
                 WHERE PP.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                   AND (a.cod_ufficio_inserimento = par_ufficio OR
                       a.cod_ufficio_inserimento = par_ufficio1 OR
                       a.cod_ufficio_inserimento = par_ufficio2 OR
                       a.cod_ufficio_inserimento = par_ufficio3))
              -- VALORI DA PASSARE IN INPUT IN RIFERIMENTO AL FASCICOLO
               AND (a.cod_ufficio_inserimento = par_ufficio OR
                a.cod_ufficio_inserimento = par_ufficio1 OR
                a.cod_ufficio_inserimento = par_ufficio2 OR
                a.cod_ufficio_inserimento = par_ufficio3)
               -- la statistica deve interessare solo i fascicoli di classe I
                AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
               (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
               (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
               (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
              -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
               AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
               TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
               TO_DATE(par_data_fine, 'dd/mm/yyyy')
               -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
               AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
               AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
               AND MS.DATA_FINE_VALIDITA IS NULL
               -- join per ufficio
               AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
               AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
               -- ULTIVO EVENTO DI INTERESSE
               AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
               -- 1135: --Provvedimento Sospensione misura di sicurezza (PROVVEDIMENTO EMESO DA PROCURA)
               AND E.COD_MOTIVO = '1135'--Sospensione per espiazione pena detentiva
               AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
               AND E.ID_EVENTO =
                   (SELECT MAX(EE.ID_EVENTO)
                      FROM EVENTO EE
                     WHERE EE.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
                       AND (EE.cod_ufficio_inserimento = par_ufficio OR
                       EE.cod_ufficio_inserimento = par_ufficio1 OR
                       EE.cod_ufficio_inserimento = par_ufficio2 OR
                       EE.cod_ufficio_inserimento = par_ufficio3)
                        )
           ORDER BY id_fascicolo_siep;

       -- CURSORE Emessa comunicazione provvedimento per l�esecuzione - attesa riscontro forze di polizia
       CURSOR curAttiEmessaComunicazione is
       SELECT DISTINCT id_fascicolo_siep,
                    chiave_anno,
                    chiave_progr,
                    e.cod_tipo_provvedimento,
                    e.cod_motivo,
                    sp.cod_stato_procedimento,
                    PG.COD_POSIZIONE_GIURIDICA,
                    a.cod_ufficio_inserimento,
                    comune_fasc_siep.DESCRIZIONE sede_ufficio_siep
            FROM FASCICOLO_SIEP         a,
                 MISURA_SICUREZZA       MS,
                 EVENTO                 E,
                 COMUNE                 comune_fasc_siep,
                 UFFICIO                ufficio_fasc_siep,
                 stato_procedimento  sp,
                 POSIZIONE_GIURIDICA PG
            WHERE
              -- ULTIMA POSIZIONE GIURIDICA
               PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
               AND PG.ID_POSIZIONE_GIURIDICA =
               (SELECT MAX(PPG.id_posizione_giuridica)
                  FROM POSIZIONE_GIURIDICA PPG
                 WHERE PPG.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                   AND (A.cod_ufficio_inserimento = par_ufficio OR
                       A.cod_ufficio_inserimento = par_ufficio1 OR
                       A.cod_ufficio_inserimento = par_ufficio2 OR
                       A.cod_ufficio_inserimento = par_ufficio3))
              -- deve essere LIBERO
              AND PG.COD_POSIZIONE_GIURIDICA IN ('01', '10')
              -- ULTIMO  STATO PROCEDIMENTO
               AND sp.fas_sie_id_fascicolo_siep = a.id_fascicolo_siep
               AND (sp.DATA, sp.progressivo) IN
               (SELECT MAX(DATA), MAX(progressivo)
                  FROM STATO_PROCEDIMENTO PP
                 WHERE PP.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                   AND (a.cod_ufficio_inserimento = par_ufficio OR
                       a.cod_ufficio_inserimento = par_ufficio1 OR
                       a.cod_ufficio_inserimento = par_ufficio2 OR
                       a.cod_ufficio_inserimento = par_ufficio3))
              -- VALORI DA PASSARE IN INPUT IN RIFERIMENTO AL FASCICOLO
               AND (a.cod_ufficio_inserimento = par_ufficio OR
                a.cod_ufficio_inserimento = par_ufficio1 OR
                a.cod_ufficio_inserimento = par_ufficio2 OR
                a.cod_ufficio_inserimento = par_ufficio3)
               -- la statistica deve interessare solo i fascicoli di classe I
                AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
               (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
               (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
               (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
              -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
               AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
               TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
               TO_DATE(par_data_fine, 'dd/mm/yyyy')
               -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
               AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
               AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
               AND MS.DATA_FINE_VALIDITA IS NULL
               -- join per ufficio
               AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
               AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
               -- ULTIVO EVENTO DI INTERESSE
               AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
               -- 1131: --Esecuzione Misure Sicurezza
               AND E.COD_MOTIVO = '1131'
               AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
               AND E.ID_EVENTO =
                   (SELECT MAX(EE.ID_EVENTO)
                      FROM EVENTO EE
                     WHERE EE.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
                       AND (EE.cod_ufficio_inserimento = par_ufficio OR
                       EE.cod_ufficio_inserimento = par_ufficio1 OR
                       EE.cod_ufficio_inserimento = par_ufficio2 OR
                       EE.cod_ufficio_inserimento = par_ufficio3)
                        )
           ORDER BY id_fascicolo_siep;

       -- CURSORE ESECUZIONI SOSPESE PER DIFFERIMENTO MISURA
       CURSOR curAttiSospesiPerDifferimento is
       SELECT DISTINCT id_fascicolo_siep,
                    chiave_anno,
                    chiave_progr,
                    e.cod_tipo_provvedimento,
                    e.cod_motivo,
                    sp.cod_stato_procedimento,
                    PG.COD_POSIZIONE_GIURIDICA,
                    a.cod_ufficio_inserimento,
                    comune_fasc_siep.DESCRIZIONE sede_ufficio_siep
            FROM FASCICOLO_SIEP         a,
                 MISURA_SICUREZZA       MS,
                 EVENTO                 E,
                 COMUNE                 comune_fasc_siep,
                 UFFICIO                ufficio_fasc_siep,
                 stato_procedimento  sp,
                 POSIZIONE_GIURIDICA PG
            WHERE
              -- ULTIMA POSIZIONE GIURIDICA
               PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
               AND PG.ID_POSIZIONE_GIURIDICA =
               (SELECT MAX(PPG.id_posizione_giuridica)
                  FROM POSIZIONE_GIURIDICA PPG
                 WHERE PPG.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                   AND (A.cod_ufficio_inserimento = par_ufficio OR
                       A.cod_ufficio_inserimento = par_ufficio1 OR
                       A.cod_ufficio_inserimento = par_ufficio2 OR
                       A.cod_ufficio_inserimento = par_ufficio3))
              -- ULTIMO  STATO PROCEDIMENTO
               AND sp.fas_sie_id_fascicolo_siep = a.id_fascicolo_siep
               AND (sp.DATA, sp.progressivo) IN
               (SELECT MAX(DATA), MAX(progressivo)
                  FROM STATO_PROCEDIMENTO PP
                 WHERE PP.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                   AND (a.cod_ufficio_inserimento = par_ufficio OR
                       a.cod_ufficio_inserimento = par_ufficio1 OR
                       a.cod_ufficio_inserimento = par_ufficio2 OR
                       a.cod_ufficio_inserimento = par_ufficio3))
              -- VALORI DA PASSARE IN INPUT IN RIFERIMENTO AL FASCICOLO
               AND (a.cod_ufficio_inserimento = par_ufficio OR
                a.cod_ufficio_inserimento = par_ufficio1 OR
                a.cod_ufficio_inserimento = par_ufficio2 OR
                a.cod_ufficio_inserimento = par_ufficio3)
               -- la statistica deve interessare solo i fascicoli di classe I
                AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
               (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
               (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
               (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
              -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
               AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
               TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
               TO_DATE(par_data_fine, 'dd/mm/yyyy')
               -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
               AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
               AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
               AND MS.DATA_FINE_VALIDITA IS NULL
               -- join per ufficio
               AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
               AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
               -- ULTIVO EVENTO DI INTERESSE
               AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
               -- 1139: --Provvedimento Rinvio dell'esecuzione della Misura di sicurezza (art. 684 cpp. c.2)
               -- viene iscritto per la casistica di differimento MS
               AND E.COD_MOTIVO = '1139'
               AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
               AND E.ID_EVENTO =
                   (SELECT MAX(EE.ID_EVENTO)
                      FROM EVENTO EE
                     WHERE EE.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
                       AND (EE.cod_ufficio_inserimento = par_ufficio OR
                       EE.cod_ufficio_inserimento = par_ufficio1 OR
                       EE.cod_ufficio_inserimento = par_ufficio2 OR
                       EE.cod_ufficio_inserimento = par_ufficio3)
                        )
           ORDER BY id_fascicolo_siep;

       -- CURSORE DELLE MS IN ESPIAZIONE (NON SCADUTE)
       CURSOR curAttiConMSInEspiazione IS
           SELECT DISTINCT id_fascicolo_siep,
                chiave_anno,
                chiave_progr,
                e.cod_tipo_provvedimento,
                e.cod_motivo,
                sp.cod_stato_procedimento,
                PG.COD_POSIZIONE_GIURIDICA,
                a.cod_ufficio_inserimento,
                comune_fasc_siep.DESCRIZIONE sede_ufficio_siep
              --  E.ID_EVENTO,
              --  P.DATA_SCADENZA,
              --  P.FLAG_MOTIVO --
          FROM FASCICOLO_SIEP       a,
               MISURA_SICUREZZA     MS,
               EVENTO               E,
               COMUNE               comune_fasc_siep,
               UFFICIO              ufficio_fasc_siep,
               stato_procedimento   sp,
               POSIZIONE_GIURIDICA  PG,
               PERIODO_ALTRA_MISURA P
         WHERE
            -- PERIODO MISURA DI SICUREZZ
             P.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
            -- ULTIMA POSIZIONE GIURIDICA
             AND PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
             AND PG.ID_POSIZIONE_GIURIDICA =
             (SELECT MAX(PPG.id_posizione_giuridica)
                FROM POSIZIONE_GIURIDICA PPG
               WHERE PPG.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                 AND (A.cod_ufficio_inserimento = par_ufficio OR
                     A.cod_ufficio_inserimento = par_ufficio1 OR
                     A.cod_ufficio_inserimento = par_ufficio2 OR
                     A.cod_ufficio_inserimento = par_ufficio3))
            -- ULTIMO  STATO PROCEDIMENTO
             AND sp.fas_sie_id_fascicolo_siep = a.id_fascicolo_siep
             AND (sp.DATA, sp.progressivo) IN
             (SELECT MAX(DATA), MAX(progressivo)
                FROM STATO_PROCEDIMENTO PP
               WHERE PP.fas_sie_id_fascicolo_siep = A.ID_FASCICOLO_SIEP
                 AND (a.cod_ufficio_inserimento = par_ufficio OR
                     a.cod_ufficio_inserimento = par_ufficio1 OR
                     a.cod_ufficio_inserimento = par_ufficio2 OR
                     a.cod_ufficio_inserimento = par_ufficio3))
             AND (a.cod_ufficio_inserimento = par_ufficio OR
             a.cod_ufficio_inserimento = par_ufficio1 OR
             a.cod_ufficio_inserimento = par_ufficio2 OR
             a.cod_ufficio_inserimento = par_ufficio3)
            -- la statistica deve interessare solo i fascicoli di classe IV
             AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
             (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
             (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
             (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
            -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
             AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
             TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
             TO_DATE(par_data_fine, 'dd/mm/yyyy')
            -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
             AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
             AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
             AND MS.DATA_FINE_VALIDITA IS NULL
            -- join per ufficio
             AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
             AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
            -- ULTIVO EVENTO DI INTERESSE
             AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
             AND E.COD_MOTIVO = '0047' --comunicazione di inizio misura
             AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
             AND TO_DATE(TO_CHAR(p.data_scadenza, 'dd/mm/yyyy'), 'dd/mm/yyyy') >=
             TO_DATE(par_data_fine, 'dd/mm/yyyy')
             AND P.FLAG_MOTIVO = '01' -- comunicazione di inizio iscrizione
             GROUP BY id_fascicolo_siep,
                      chiave_anno,
                      chiave_progr,
                      a.cod_ufficio_inserimento,
                      e.cod_tipo_provvedimento,
                      e.cod_motivo,
                      sp.cod_stato_procedimento,
                      PG.COD_POSIZIONE_GIURIDICA,
                      comune_fasc_siep.DESCRIZIONE,
                      E.ID_EVENTO,
                      P.DATA_SCADENZA,
                      P.FLAG_MOTIVO
             ORDER BY id_fascicolo_siep;

-- Fascicoli con Emesso provvedimento in attesa scadenza pena detentiva (detenuti)
     CURSOR curAttiAttesaScadPenaDetent IS
     SELECT DISTINCT ID_FASCICOLO_SIEP,
                CHIAVE_ANNO,
                CHIAVE_PROGR,
                E.COD_TIPO_PROVVEDIMENTO,
                E.COD_MOTIVO,
                SP.COD_STATO_PROCEDIMENTO,
                PG.COD_POSIZIONE_GIURIDICA,
                A.COD_UFFICIO_INSERIMENTO,
                COMUNE_FASC_SIEP.DESCRIZIONE SEDE_UFFICIO_SIEP --,
    FROM FASCICOLO_SIEP       A,
         MISURA_SICUREZZA     MS,
         EVENTO               E,
         COMUNE               COMUNE_FASC_SIEP,
         UFFICIO              UFFICIO_FASC_SIEP,
         STATO_PROCEDIMENTO   SP,
         POSIZIONE_GIURIDICA  PG,
         FASC_MS_TO_FASC_SIEP F,
         PENA_RESIDUA         P
   WHERE
      -- DEVO RECUPERARE IL FINE PENA DEL CLASSE I A CUI � COLLEGATO IL CLASSE IV
       F.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND F.FAS_SIE_ID_FASCICOLO_COLLEGATO = P.FAS_SIE_ID_FASCICOLO_SIEP
       AND P.FLAG_VALIDATO = 'S'
       AND P.DATA_INSERIMENTO =
       (SELECT MAX(AA.DATA_INSERIMENTO)
          FROM PENA_RESIDUA AA
         WHERE AA.FAS_SIE_ID_FASCICOLO_SIEP = F.FAS_SIE_ID_FASCICOLO_COLLEGATO
           AND AA.FLAG_VALIDATO = 'S')
       AND TO_DATE(TO_CHAR(P.DATA_FINE, 'dd/mm/yyyy'), 'dd/mm/yyyy') >=
       TO_DATE(par_data_fine, 'dd/mm/yyyy')
      -- ULTIMA POSIZIONE GIURIDICA
       AND PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND PG.ID_POSIZIONE_GIURIDICA =
       (SELECT MAX(PPG.ID_POSIZIONE_GIURIDICA)
          FROM POSIZIONE_GIURIDICA PPG
         WHERE PPG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
           AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
      -- ULTIMO  STATO PROCEDIMENTO
       AND SP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND (SP.DATA, SP.PROGRESSIVO) IN
       (SELECT MAX(DATA), MAX(PROGRESSIVO)
          FROM STATO_PROCEDIMENTO PP
         WHERE PP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
           AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
      -- LA STATISTICA DEVE INTERESSARE SOLO I FASCICOLI DI CLASSE IV DELL'UFFICIO DI RICERCA
       AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
       (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
       AND (a.cod_ufficio_inserimento = par_ufficio OR
       a.cod_ufficio_inserimento = par_ufficio1 OR
       a.cod_ufficio_inserimento = par_ufficio2 OR
       a.cod_ufficio_inserimento = par_ufficio3)
      -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
       AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'DD/MM/YYYY'), 'DD/MM/YYYY') BETWEEN
       TO_DATE(par_data_inizio, 'DD/MM/YYYY') AND
       TO_DATE(par_data_fine, 'DD/MM/YYYY')
      -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
       AND MS.FAS_SIE_ID_FASCICOLO_SIEP(+) = A.ID_FASCICOLO_SIEP
       AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
       AND MS.DATA_FINE_VALIDITA IS NULL
      -- join per ufficio
       AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
       AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
      -- ULTIVO EVENTO DI INTERESSE
       AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND E.ID_EVENTO =
       (SELECT MAX(EE.ID_EVENTO)
          FROM EVENTO EE
         WHERE EE.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
           AND (EE.cod_ufficio_inserimento = par_ufficio OR
               EE.cod_ufficio_inserimento = par_ufficio1 OR
               EE.cod_ufficio_inserimento = par_ufficio2 OR
               EE.cod_ufficio_inserimento = par_ufficio3))
       AND E.COD_MOTIVO IN ('1126', '1128', '1131', '1132', '1129')
       AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
       ORDER BY id_fascicolo_siep;

--Procedimenti in attesa esecuzione pena principale (liberi)
       CURSOR curAttiAttesaEsecuzPena IS
       SELECT DISTINCT ID_FASCICOLO_SIEP,
                CHIAVE_ANNO,
                CHIAVE_PROGR,
                E.COD_TIPO_PROVVEDIMENTO,
                E.COD_MOTIVO,
                SP.COD_STATO_PROCEDIMENTO,
                PG.COD_POSIZIONE_GIURIDICA,
                A.COD_UFFICIO_INSERIMENTO,
                COMUNE_FASC_SIEP.DESCRIZIONE SEDE_UFFICIO_SIEP --,
      FROM FASCICOLO_SIEP      A,
           MISURA_SICUREZZA    MS,
           EVENTO              E,
           COMUNE              COMUNE_FASC_SIEP,
           UFFICIO             UFFICIO_FASC_SIEP,
           STATO_PROCEDIMENTO  SP,
           POSIZIONE_GIURIDICA PG
     WHERE
        -- ULTIMA POSIZIONE GIURIDICA
         PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND PG.ID_POSIZIONE_GIURIDICA =
         (SELECT MAX(PPG.ID_POSIZIONE_GIURIDICA)
            FROM POSIZIONE_GIURIDICA PPG
           WHERE PPG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
             AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
        -- L'ULTIMA POS GIURIDICA DEVE ESSERE LIBERO
        AND PG.COD_POSIZIONE_GIURIDICA IN ('07' ,'10')
        -- ULTIMO  STATO PROCEDIMENTO
         AND SP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND (SP.DATA, SP.PROGRESSIVO) IN
         (SELECT MAX(DATA), MAX(PROGRESSIVO)
            FROM STATO_PROCEDIMENTO PP
           WHERE PP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
             AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
        -- LA STATISTICA DEVE INTERESSARE SOLO I FASCICOLI DI CLASSE IV DELL'UFFICIO DI RICERCA
         AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
         (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
         (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
         (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
         AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
         A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
         A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
         A.COD_UFFICIO_INSERIMENTO = par_ufficio3)
        -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
         AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'DD/MM/YYYY'), 'DD/MM/YYYY') BETWEEN
         TO_DATE(par_data_inizio, 'DD/MM/YYYY') AND
         TO_DATE(par_data_fine, 'DD/MM/YYYY')
        -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
         AND MS.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
         AND MS.DATA_FINE_VALIDITA IS NULL
        -- join per ufficio
         AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
         AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
        --  EVENTO DI INTERESSE
         AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
       -- Ticket#202109290111_NEW: la query NOT IN è estremamente inefficiente in 
       -- quanto si carica TUTTI gli eventi della BASE DATI.
       -- Aggiunta la condizione sullo stato di validazione dell'EVENTO
       /*
       AND A.ID_FASCICOLO_SIEP NOT IN
       (SELECT EE.FAS_SIE_ID_FASCICOLO_SIEP
          FROM EVENTO EE
         WHERE EE.COD_MOTIVO IN ('1126', '1128', '1131', '1132', '1129')) 
         */
       AND NOT EXISTS (SELECT EE.ID_EVENTO
                         FROM EVENTO EE
                        WHERE EE.COD_MOTIVO IN ('1126', '1128', '1131', '1132', '1129')
                          AND EE.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
--                          AND EE.FLAG_DOCUMENTO_REGISTRATO = 'S'
                      )
       -- Ticket#202109290111_NEW 
         ORDER BY id_fascicolo_siep;

       -- Cursore di Fascicoli in attesa di definizione per cessata MS
        CURSOR AttiConCessataMS is
         SELECT DISTINCT ID_FASCICOLO_SIEP,
                A.CHIAVE_ANNO,
                A.CHIAVE_PROGR,
                E.COD_TIPO_PROVVEDIMENTO,
                E.COD_MOTIVO,
                SP.COD_STATO_PROCEDIMENTO,
                PG.COD_POSIZIONE_GIURIDICA,
                A.COD_UFFICIO_INSERIMENTO,
                COMUNE_FASC_SIEP.DESCRIZIONE SEDE_UFFICIO_SIEP
        FROM FASCICOLO_SIEP      A,
             MISURA_SICUREZZA    MS,
             EVENTO              E,
             COMUNE              COMUNE_FASC_SIEP,
             UFFICIO             UFFICIO_FASC_SIEP,
             STATO_PROCEDIMENTO  SP,
             POSIZIONE_GIURIDICA PG,
             FASCICOLO_SIUS      FS
       WHERE
      -- COLLEGAMENTO A FASCICOLO SIUS
       FS.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND E.FAS_SIU_ID_FASCICOLO_SIUS = FS.ID_FASCICOLO_SIUS
       AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
       AND E.COD_ESITO IN ('0054', '0052', '0118', '0351', '0193', '0194', '0195')
      -- ULTIMA POSIZIONE GIURIDICA
       AND PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND PG.ID_POSIZIONE_GIURIDICA =
       (SELECT MAX(PPG.ID_POSIZIONE_GIURIDICA)
          FROM POSIZIONE_GIURIDICA PPG
         WHERE PPG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
           AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
      -- L'ULTIMA POS GIURIDICA DEVE ESSERE LIBERO
       AND PG.COD_POSIZIONE_GIURIDICA IN ('07', '10')
      -- ULTIMO  STATO PROCEDIMENTO
       AND SP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND (SP.DATA, SP.PROGRESSIVO) IN
       (SELECT MAX(DATA), MAX(PROGRESSIVO)
          FROM STATO_PROCEDIMENTO PP
         WHERE PP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
           AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
               A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
       -- LA STATISTICA DEVE INTERESSARE SOLO I FASCICOLI DI CLASSE IV DELL'UFFICIO DI RICERCA
       AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
       (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
       (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
       AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
       A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
       A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
       A.COD_UFFICIO_INSERIMENTO = par_ufficio3)
       -- ESTAGGO SOLO QUELLI con evento di interesse RELATIVo AL PERIODO RICHIESTO PER LA STATISTICA
       AND TO_DATE(TO_CHAR(E.DATA_INSERIMENTO, 'DD/MM/YYYY'), 'DD/MM/YYYY') BETWEEN
       TO_DATE(par_data_inizio, 'DD/MM/YYYY') AND
       TO_DATE(par_data_fine, 'DD/MM/YYYY')
       -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
       AND MS.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
       AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
       AND MS.DATA_FINE_VALIDITA IS NULL
       -- JOIN PER UFFICIO
       AND UFFICIO_FASC_SIEP.COD_UFFICIO = NVL(A.CHIAVE_UFFICIO, '-')
       AND UFFICIO_FASC_SIEP.COD_COMUNE = COMUNE_FASC_SIEP.COD_COMUNE
       ---
       AND SP.COD_STATO_PROCEDIMENTO NOT IN ('0076') -- NON ARCHIVIATO
       ORDER BY ID_FASCICOLO_SIEP;


   --Procedimenti non hanno un evento di inoltro all'UDS (evento diverso da 2110,2114 o 1130)
       CURSOR curAttiSenzaInoltroSorv IS
       SELECT DISTINCT ID_FASCICOLO_SIEP,
                CHIAVE_ANNO,
                CHIAVE_PROGR,
                E.COD_TIPO_PROVVEDIMENTO,
                E.COD_MOTIVO,
                SP.COD_STATO_PROCEDIMENTO,
                PG.COD_POSIZIONE_GIURIDICA,
                A.COD_UFFICIO_INSERIMENTO,
                COMUNE_FASC_SIEP.DESCRIZIONE SEDE_UFFICIO_SIEP --,
      FROM FASCICOLO_SIEP      A,
           MISURA_SICUREZZA    MS,
           EVENTO              E,
           COMUNE              COMUNE_FASC_SIEP,
           UFFICIO             UFFICIO_FASC_SIEP,
           STATO_PROCEDIMENTO  SP,
           POSIZIONE_GIURIDICA PG
     WHERE
        -- ULTIMA POSIZIONE GIURIDICA
         PG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND PG.ID_POSIZIONE_GIURIDICA =
         (SELECT MAX(PPG.ID_POSIZIONE_GIURIDICA)
            FROM POSIZIONE_GIURIDICA PPG
           WHERE PPG.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
             AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
        -- ULTIMO  STATO PROCEDIMENTO
         AND SP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND (SP.DATA, SP.PROGRESSIVO) IN
         (SELECT MAX(DATA), MAX(PROGRESSIVO)
            FROM STATO_PROCEDIMENTO PP
           WHERE PP.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
             AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
                 A.COD_UFFICIO_INSERIMENTO = par_ufficio3))
        -- LA STATISTICA DEVE INTERESSARE SOLO I FASCICOLI DI CLASSE IV DELL'UFFICIO DI RICERCA
         AND ((A.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
         (A.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
         (A.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
         (A.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
         AND (A.COD_UFFICIO_INSERIMENTO = par_ufficio OR
         A.COD_UFFICIO_INSERIMENTO = par_ufficio1 OR
         A.COD_UFFICIO_INSERIMENTO = par_ufficio2 OR
         A.COD_UFFICIO_INSERIMENTO = par_ufficio3)
        -- ESTAGGO SOLO QUELLI RELATIVI AL PERIODO RICHIESTO PER LA STATISTICA
         AND TO_DATE(TO_CHAR(a.Data_Iscrizione, 'DD/MM/YYYY'), 'DD/MM/YYYY') BETWEEN
         TO_DATE(par_data_inizio, 'DD/MM/YYYY') AND
         TO_DATE(par_data_fine, 'DD/MM/YYYY')
        -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO(SE LE HA)
         AND MS.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND (MS.FLAG_ANNULLA_MISURA IS NULL OR MS.FLAG_ANNULLA_MISURA != 'A')
         AND MS.DATA_FINE_VALIDITA IS NULL
        -- join per ufficio
         AND ufficio_fasc_siep.COD_UFFICIO = nvl(A.CHIAVE_UFFICIO, '-')
         AND ufficio_fasc_siep.COD_COMUNE = comune_fasc_siep.COD_COMUNE
        --  EVENTO DI INTERESSE
         AND E.FAS_SIE_ID_FASCICOLO_SIEP = A.ID_FASCICOLO_SIEP
         AND E.FLAG_DOCUMENTO_REGISTRATO = 'S'
         AND A.ID_FASCICOLO_SIEP NOT IN
         (SELECT EE.FAS_SIE_ID_FASCICOLO_SIEP
            FROM EVENTO EE
           WHERE EE.COD_MOTIVO IN ('2110', '2114', '1130'))
         ORDER BY id_fascicolo_siep;


    --- inizio procedura
  BEGIN
    -- DBMS_OUTPUT.ENABLE;
    DBMS_OUTPUT.ENABLE (buffer_size => NULL);
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('  I N I Z I O   P R O C E D U R E '||to_char(sysdate, 'dd/MM/yyyy hh24:mi:ss'));
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('par_ufficio:       '||par_ufficio);
    DBMS_OUTPUT.PUT_LINE('par_ufficio1:      '||par_ufficio1);
    DBMS_OUTPUT.PUT_LINE('par_ufficio2:      '||par_ufficio2);
    DBMS_OUTPUT.PUT_LINE('par_ufficio3:      '||par_ufficio3);
    DBMS_OUTPUT.PUT_LINE('par_data_verifica: '||par_data_verifica);
    DBMS_OUTPUT.PUT_LINE('par_data_inizio:   '||par_data_inizio);
    DBMS_OUTPUT.PUT_LINE('par_data_fine:     '||par_data_fine);
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   conta_commit := 1;

    DELETE FROM STATIS.ISP_PROVVEDIMENTI_MS;
    DELETE FROM STATIS.ISP_SCARTI_MS;

    COMMIT;

    -- LETTURA DELLA TABELLA PARAMETRO DEL QUANTUM PER UFFICIO PER LA
    -- COMUNICAZIONE DI INIZIO MISURA
    BEGIN
      select P.ANNI, P.MESI, P.GIORNI
        INTO v_quantum_inizio_misura_anni,
             v_quantum_inizio_misura_mesi,
             v_quantum_inizio_misura_giorni
        from PARAMETRO P
       WHERE P.NOME_PARAMETRO = 'INIZIO MISURA'
         AND P.COD_UFFICIO_VALIDITA = par_ufficio;

      -- PER QUANTUM INIZIO MISURA NON TROVATO, IL VALORE DI DEFAULT E' DI 6 MESI
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_quantum_inizio_misura_anni   := NULL;
        v_quantum_inizio_misura_mesi   := NULL;
        v_quantum_inizio_misura_giorni := NULL;
    END;

    -- Aggiungo subito alla tabella ISP_PROVVEDIMENTI_MS i
    -- record relativi ai titoli1 e titoli2 per la creazione del foglio excel in
    -- fase di estrazione.
    Insert into statis.ISP_PROVVEDIMENTI_MS
      (COD_STATO_FASCICOLO_RES)
      select COD_STATO_FASCICOLO
        from STATO_FASCICOLO_RES_MS
       WHERE TIPO_CAMPO in ('T1', 'T2');

    -- RICERCA DEL CODICE COMUNE DI APPARTENENZA DELL'UFFICIO
     BEGIN
      SELECT cod_comune
        INTO APPO_VAR.cod_comune
        FROM UFFICIO
       WHERE cod_ufficio = par_ufficio;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        APPO_VAR.cod_comune := '-';
    END; 

    ---- routine recupero descrizione ufficio inserimento
    ---- RICERCA LUOGO UFFICIO INSERIMENTO
    BEGIN
      SELECT descrizione
        INTO v_desc_ufficio_inserimento
        FROM COMUNE
       WHERE cod_comune = SUBSTR(v_cod_ufficio_inserimento, 1, 6);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_desc_ufficio_inserimento := '-';
    END;


    -- APERTURA CURSORE DEI FASCICOLI RICEVUTI E NON ISCRITTI
    DBMS_OUTPUT.PUT_LINE('curAttiRicevuti_NO_Iscr - OPEN');
    OPEN curAttiRicevuti_NO_Iscr;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curAttiRicevuti_NO_Iscr
      INTO v_chiave_anno,
           v_chiave_progr,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento,
           v_flag_visto;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiRicevuti_NO_Iscr PER OGNI RECORD RILASCIATO DALLA FETCH
    DBMS_OUTPUT.PUT_LINE('inizio ciclo sugli atti ricevuti');
    WHILE curAttiRicevuti_NO_Iscr%FOUND LOOP

      BEGIN
        IF (v_flag_visto = 'S') THEN
          --ATTI PERVENUTI PER COMPETENZA PRESI IN CARICO E NON ANCORA ISCRITTI
          v_cod_stato_fascicolo_res := '3';
        ELSIF (v_flag_visto = 'N') THEN
          --ATTI PERVENUTI PER COMPETENZA E NON ANCORA ISCRITTI
          v_cod_stato_fascicolo_res := '2';
        END IF;
        DBMS_OUTPUT.PUT_LINE('curAttiRicevuti_NO_Iscr: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (NULL,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           NULL,
           NULL,
           NULL,
           NULL,
           par_ufficio,
           NULL,
           NULL,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
          DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX ');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiRicevuti_NO_Iscr
        INTO v_chiave_anno,
             v_chiave_progr,
             v_cod_ufficio_inserimento,
             v_desc_ufficio_inserimento,
             v_flag_visto;
      -- END;

    END LOOP;

    CLOSE curAttiRicevuti_NO_Iscr;
	DBMS_OUTPUT.PUT_LINE('curAttiRicevuti_NO_Iscr - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    -- APERTURA CURSORE DEI FASCICOLI PEVENUTI IN ATTESA DI ESECUZIONE
    DBMS_OUTPUT.PUT_LINE('curAttiInAttesaEsecuzione - OPEN');
    OPEN curAttiInAttesaEsecuzione;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curAttiInAttesaEsecuzione
      INTO v_chiave_anno,
           v_chiave_progr,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiInAttesaEsecuzione
    DBMS_OUTPUT.PUT_LINE('inizio ciclo SULLE Ordinanze pervenute in attesa di esecuzione');
    WHILE curAttiInAttesaEsecuzione%FOUND LOOP
      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          --Ordinanze pervenute in attesa di esecuzione
          v_cod_stato_fascicolo_res := '16';
        END IF;
        DBMS_OUTPUT.PUT_LINE('curAttiInAttesaEsecuzione: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (NULL,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           NULL,
           NULL,
           NULL,
           NULL,
           par_ufficio,
           NULL,
           NULL,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiInAttesaEsecuzione
        INTO v_chiave_anno,
             v_chiave_progr,
             v_cod_ufficio_inserimento,
             v_desc_ufficio_inserimento;
      -- END;

    END LOOP;

    CLOSE curAttiInAttesaEsecuzione;
	DBMS_OUTPUT.PUT_LINE('curAttiInAttesaEsecuzione - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    -- APERTURA CURSORE DEI FASCICOLI CON RICHIESTA DI DELINQUENZA ABITUALE
    DBMS_OUTPUT.PUT_LINE('curAttiRichiestaDelinqAbituale - OPEN');
    OPEN curAttiRichiestaDelinqAbituale;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curAttiRichiestaDelinqAbituale
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiInAttesaEsecuzione
    DBMS_OUTPUT.PUT_LINE('inizio ciclo SULLE Ordinanze pervenute in attesa di esecuzione');
    WHILE curAttiRichiestaDelinqAbituale%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          --Procedimenti inoltrati all�Ufficio di Sorveglianza in attesa di decisione (accertamento pericolosit� sociale)
          v_cod_stato_fascicolo_res := '5';
        END IF;

       DBMS_OUTPUT.PUT_LINE('curAttiRichiestaDelinqAbituale: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           NULL,
           NULL,
           NULL,
           NULL,
           par_ufficio,
           NULL,
           NULL,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiRichiestaDelinqAbituale
        INTO v_id_fascicolo_siep,
             v_chiave_anno,
             v_chiave_progr,
             v_cod_ufficio_inserimento,
             v_desc_ufficio_inserimento;
      -- END;

    END LOOP;

    CLOSE curAttiRichiestaDelinqAbituale;
	DBMS_OUTPUT.PUT_LINE('curAttiRichiestaDelinqAbituale - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    --Esecuzioni sospese per espiazione pena detentiva
    DBMS_OUTPUT.PUT_LINE('curAttiConSospensioneMS - OPEN');
    OPEN curAttiConSospensioneMS;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curAttiConSospensioneMS
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiInAttesaEsecuzione
    DBMS_OUTPUT.PUT_LINE('Inizio Ciclo Esecuzioni sospese per espiazione pena detentiva');
    WHILE curAttiConSospensioneMS%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          --Esecuzioni sospese per espiazione pena detentiva
          v_cod_stato_fascicolo_res := '15';
        END IF;
       
        DBMS_OUTPUT.PUT_LINE('curAttiConSospensioneMS: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiConSospensioneMS
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;
      -- END;

    END LOOP;

    CLOSE curAttiConSospensioneMS;
    DBMS_OUTPUT.PUT_LINE('curAttiConSospensioneMS - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    --fascicoli con MS In corso di espiazione
    DBMS_OUTPUT.PUT_LINE('curAttiConMSInEspiazione - OPEN');
    OPEN curAttiConMSInEspiazione;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curAttiConMSInEspiazione
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiConMSInEspiazione
    DBMS_OUTPUT.PUT_LINE('Inizio ciclo In corso di espiazione');
    WHILE curAttiConMSInEspiazione%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          -- In corso di espiazione
          v_cod_stato_fascicolo_res := '13';
        END IF;
       
        DBMS_OUTPUT.PUT_LINE('curAttiConMSInEspiazione: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiConMSInEspiazione
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;
      -- END;

    END LOOP;

    CLOSE curAttiConMSInEspiazione;
    DBMS_OUTPUT.PUT_LINE('curAttiConMSInEspiazione - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    --fascicoli con  Emesso provvedimento in attesa scadenza pena detentiva (detenuti)
    DBMS_OUTPUT.PUT_LINE('curAttiAttesaScadPenaDetent - OPEN');
    OPEN curAttiAttesaScadPenaDetent;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curAttiAttesaScadPenaDetent
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiAttesaScadPenaDetent
    DBMS_OUTPUT.PUT_LINE('INIZIO CICLO Emesso provvedimento in attesa scadenza pena detentiva (detenuti)');
    WHILE curAttiAttesaScadPenaDetent%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          --Emesso provvedimento in attesa scadenza pena detentiva (detenuti)
          v_cod_stato_fascicolo_res := '12';
        END IF;
       
        DBMS_OUTPUT.PUT_LINE('curAttiAttesaScadPenaDetent: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiAttesaScadPenaDetent
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;
      -- END;

    END LOOP;

    CLOSE curAttiAttesaScadPenaDetent;
	DBMS_OUTPUT.PUT_LINE('curAttiAttesaScadPenaDetent - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    -- Procedimenti in attesa esecuzione pena principale (liberi)
    DBMS_OUTPUT.PUT_LINE('curAttiAttesaEsecuzPena - OPEN');
    OPEN curAttiAttesaEsecuzPena;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curAttiAttesaEsecuzPena
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiAttesaScadPenaDetent
    DBMS_OUTPUT.PUT_LINE('INIZIO CICLO DI ESTRAZIONE: Procedimenti in attesa esecuzione pena principale (liberi) ');
    WHILE curAttiAttesaEsecuzPena%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          -- Procedimenti in attesa esecuzione pena principale (liberi)
          v_cod_stato_fascicolo_res := '11';
 		END IF;
      --  Ticket#20220124016 - - Classificazione proc. con richiesta 2110 o 2114
        IF ( v_cod_motivo in ('2110','2114'))
           THEN
          -- PROCEDIMENTI INOLTRATI ALL'UFFICIO DI SORVEGLIANZA IN ATTESA DI DECISIONE 
		  -- (accertamento pericolosità sociale, Accertamento Pericolosità Sociale e Unificazione Delle Misure di Sicurezza)
            v_cod_stato_fascicolo_res := '5';
        END IF;
       
        DBMS_OUTPUT.PUT_LINE('curAttiAttesaEsecuzPena: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiAttesaEsecuzPena
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    END LOOP;

    CLOSE curAttiAttesaEsecuzPena;
    DBMS_OUTPUT.PUT_LINE('curAttiAttesaEsecuzPena - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    -- Atti in attesa di definizione per cessata MS
    DBMS_OUTPUT.PUT_LINE('AttiConCessataMS - OPEN');
    OPEN AttiConCessataMS;

    FETCH AttiConCessataMS
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiAttesaScadPenaDetent
    DBMS_OUTPUT.PUT_LINE('INIZIO CICLO: Procedimenti in attesa definizione LIBERI');
    WHILE AttiConCessataMS%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          -- Procedimenti in attesa definizione LIBERI
          v_cod_stato_fascicolo_res := '17';
        END IF;
       
        DBMS_OUTPUT.PUT_LINE('AttiConCessataMS: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH AttiConCessataMS
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    END LOOP;
   
    CLOSE AttiConCessataMS;
    DBMS_OUTPUT.PUT_LINE('AttiConCessataMS - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    -- cursore Esecuzioni sospese per differimento Misura Sicurezza
    DBMS_OUTPUT.PUT_LINE('curAttiSospesiPerDifferimento - OPEN');
    OPEN curAttiSospesiPerDifferimento;

    FETCH curAttiSospesiPerDifferimento
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiSospesiPerDifferimento
    DBMS_OUTPUT.PUT_LINE('INIZIO CICLO: Esecuzioni sospese per differimento Misura Sicurezza');
    WHILE curAttiSospesiPerDifferimento%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          -- Esecuzioni sospese per differimento Misura Sicurezza
          v_cod_stato_fascicolo_res := '14';
        END IF;
       
        DBMS_OUTPUT.PUT_LINE('curAttiSospesiPerDifferimento: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiSospesiPerDifferimento
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    END LOOP;
   
    CLOSE curAttiSospesiPerDifferimento;
	DBMS_OUTPUT.PUT_LINE('curAttiSospesiPerDifferimento - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    -- cursore Emessa comunicazione provvedimento per l�esecuzione - attesa riscontro forze di polizia
    DBMS_OUTPUT.PUT_LINE('curAttiEmessaComunicazione - OPEN');
    OPEN curAttiEmessaComunicazione;

    FETCH curAttiEmessaComunicazione
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiEmessaComunicazione
    DBMS_OUTPUT.PUT_LINE('INIZIO CICLO: Emessa comunicazione provvedimento per l''esecuzione');
    WHILE curAttiEmessaComunicazione%FOUND LOOP

      BEGIN
        IF ((v_chiave_anno IS NOT NULL OR v_chiave_anno <> 0) AND
           (v_chiave_progr IS NOT NULL OR v_chiave_progr <> 0) AND
           (v_cod_ufficio_inserimento IS NOT NULL OR v_cod_ufficio_inserimento <> 0)
          ) THEN
          -- Emessa comunicazione provvedimento per l'esecuzione
          v_cod_stato_fascicolo_res := '8';
        END IF;
       
        DBMS_OUTPUT.PUT_LINE('curAttiEmessaComunicazione: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiEmessaComunicazione
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    END LOOP;
    CLOSE curAttiEmessaComunicazione;
    DBMS_OUTPUT.PUT_LINE('curAttiEmessaComunicazione - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    --curAttiSenzaInoltroSorv
    DBMS_OUTPUT.PUT_LINE('curAttiSenzaInoltroSorv - OPEN');
    OPEN curAttiSenzaInoltroSorv;

    FETCH curAttiSenzaInoltroSorv
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiSenzaInoltroSorv
    DBMS_OUTPUT.PUT_LINE('INIZIO CICLO: atti senza inoltro alla sorveglianza');
    WHILE curAttiSenzaInoltroSorv%FOUND LOOP
    DBMS_OUTPUT.PUT_LINE('curAttiSenzaInoltroSorv: Inizio elaborazione FASCICOLO '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

    v_data_scadenza_comunicazione := null;
    -- per ogni fascicolo trovato devo recuperare
    -- 1) quantum scadenza MS (� gi� settata ad inizio procedura per l'uffico ch sta facendo la statistica)

    -- 2) data Fine Pena Residua
    ----RICERCA PENA RESIDUA
        BEGIN
          SELECT data_inizio,
                 data_fine,
                 num_anni_reclusione,
                 num_mesi_reclusione,
                 num_giorni_reclusione,
                 num_anni_arresto,
                 num_mesi_arresto,
                 num_giorni_arresto,
                 flag_ergastolo
            INTO v_data_inizio_pena_residua,
                 v_data_fine_pena_residua,
                 v_num_anni_reclusione,
                 v_num_mesi_reclusione,
                 v_num_giorni_reclusione,
                 v_num_anni_arresto,
                 v_num_mesi_arresto,
                 v_num_giorni_arresto,
                 v_flag_ergastolo
            FROM PENA_RESIDUA,
                 (SELECT MAX(data_inserimento) max_data
                    FROM PENA_RESIDUA
                   WHERE fas_sie_id_fascicolo_siep = v_id_fascicolo_siep
                     AND cod_ufficio_inserimento = par_ufficio) pena_res
           WHERE fas_sie_id_fascicolo_siep = v_id_fascicolo_siep
             AND (cod_ufficio_inserimento = par_ufficio OR
                 cod_ufficio_inserimento = par_ufficio1 OR
                 cod_ufficio_inserimento = par_ufficio2 OR
                 cod_ufficio_inserimento = par_ufficio3)
             AND data_inserimento = pena_res.max_data
             AND id_pena_residua =
                 (SELECT MAX(id_pena_residua)
                    FROM PENA_RESIDUA
                   WHERE fas_sie_id_fascicolo_siep = v_id_fascicolo_siep
                     AND data_inserimento = pena_res.max_data);

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_data_inizio_pena_residua := NULL;
            v_data_fine_pena_residua   := NULL;
        END;

        --CALCOLO DA DATA DI SCADENZA DELLA COMUNICAZIONE
        IF (v_data_fine_pena_residua IS NOT NULL) THEN

          --CONTROLLO SE � VALORIZZATO IL PARAMETRO INIZIO_MISURA NELLA TABELLA PARAMETRO
          --v_quantum_inizio_misura_anni    NUMBER;
          --v_quantum_inizio_misura_mesi    NUMBER;
          --v_quantum_inizio_misura_giorni  NUMBER;
          IF (v_quantum_inizio_misura_anni IS NOT NULL AND v_quantum_inizio_misura_anni<>0) THEN
            v_data_scadenza_comunicazione := ADD_MONTHS(v_data_fine_pena_residua,
                                                        v_quantum_inizio_misura_anni * 12);
          END IF;
          IF (v_quantum_inizio_misura_mesi IS NOT NULL AND v_quantum_inizio_misura_mesi <>0) THEN
            v_data_scadenza_comunicazione := ADD_MONTHS(v_data_fine_pena_residua,
                                                        v_quantum_inizio_misura_mesi);
          END IF;
          IF (v_quantum_inizio_misura_giorni IS NOT NULL AND v_quantum_inizio_misura_giorni<> 0) THEN
             v_data_scadenza_comunicazione := v_data_fine_pena_residua + v_quantum_inizio_misura_giorni;
          END IF;
          -- AGGIUNGO DI DEFAULT 6 MESI
          IF (v_data_scadenza_comunicazione IS NULL) THEN
            v_data_scadenza_comunicazione := ADD_MONTHS(v_data_fine_pena_residua,
                                                        6);
          END IF;
        END IF;

        DBMS_OUTPUT.PUT_LINE('v_data_fine_pena_residua  ' || v_data_fine_pena_residua );
        DBMS_OUTPUT.PUT_LINE('v_data_scadenza_comunicazione  ' || v_data_scadenza_comunicazione );


      BEGIN
      -- Sono tutti i procedimenti che hanno come data scadenza comunicazione MS >= Periodo finale indicato nella statistica e che non hanno un evento di inoltro all'UDS (ento diverso da 2110,2114 o 1130)
        IF (v_data_scadenza_comunicazione IS NOT NULL) THEN
          -- Ticket#202109290111_NEW 2021-12-01 Errore nella TO_DATE(v_data_scadenza_comunicazione) la variabile è già una DATE
          -- IF (TO_DATE(v_data_scadenza_comunicazione, 'dd/mm/yyyy') >= TO_DATE(par_data_fine, 'dd/mm/yyyy')) THEN
          IF (v_data_scadenza_comunicazione >= TO_DATE(par_data_fine, 'dd/mm/yyyy')) THEN
            v_cod_stato_fascicolo_res := '9'; -- 9 Attesa scadenza termini per inoltro all'Ufficio di Sorveglianza
            -- Sono tutti i procedimenti che hanno come data scadenza comunicazione MS < Periodo iniziale indicato nella statistica e che non hanno un evento di inoltro all'UDS (eVEnto diverso da 2110,2114 o 1130)
--          ELSIF (TO_DATE(v_data_scadenza_comunicazione, 'dd/mm/yyyy') < TO_DATE(par_data_inizio, 'dd/mm/yyyy')) THEN
          ELSIF (v_data_scadenza_comunicazione < TO_DATE(par_data_inizio, 'dd/mm/yyyy')) THEN
            v_cod_stato_fascicolo_res := '10'; -- 10 Attesa scadenza termini per inoltro all'Ufficio di Sorveglianza Procedimenti con termini scaduti e atti non inoltrati
          END IF;
        END IF;

      -- PROCEDO CON L'INSERIMENTO IN TABELLAA ISP_PROVVEDIMENTI_MS
         DBMS_OUTPUT.PUT_LINE('curAttiSenzaInoltroSorv: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curAttiSenzaInoltroSorv
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento;

    END LOOP;
    CLOSE curAttiSenzaInoltroSorv;
    DBMS_OUTPUT.PUT_LINE('curAttiSenzaInoltroSorv - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
   
    -- cursore FINALE DEI PROCEDIMENTI CHE CATEGORIZZO IN BASE AL SOLO STATO DEL PROCEDIMENTO
    -- PER CUI NON LAVORA SU PARTICOLARI MOTIVI DI EVENTI
           -- cursore Emessa comunicazione provvedimento per l�esecuzione - attesa riscontro forze di polizia
    DBMS_OUTPUT.PUT_LINE('my_curFascicoli - OPEN');
    OPEN my_curFascicoli;

    FETCH my_curFascicoli
      INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento,
           v_cod_stato_fascicolo;



    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curAttiEmessaComunicazione
    WHILE my_curFascicoli%FOUND LOOP

      v_cod_stato_fascicolo_res :='';
      DBMS_OUTPUT.PUT_LINE('my_curFascicoli: Inizio elaborazione FASCICOLO '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);

      BEGIN

            IF v_cod_motivo IS NULL THEN
               v_cod_stato_fascicolo_res :='1';  -- ISCRITTO
            END IF;

            IF v_cod_stato_procedimento = '0109' THEN
              --Validato
              v_cod_stato_fascicolo_res := '1'; --lo metto tra gli ISCITTI (MT ha detto SI)

            ELSIF v_cod_stato_procedimento = '0076' THEN
              --Archiviato, Definito
              v_cod_stato_fascicolo_res := '18'; --lo metto tra i definiti

            ELSIF v_cod_stato_procedimento = '0129' THEN
              -- Ultimo Provvedimento Annullato
              v_cod_stato_fascicolo_res := '19'; -- ALTRE POSIZIONI

            ELSIF v_cod_stato_procedimento = '0108' THEN
              --ISCITTO
              v_cod_stato_fascicolo_res := '1'; --lo metto tra gli ISCITTI

            ELSIF v_cod_stato_procedimento = '9999' THEN
              --Altre Posizioni
              v_cod_stato_fascicolo_res := '19'; -- Altre Posizioni
            END IF;


          ---- SE NON HA PROVVEDIMENTI MA HA MISURE DI SICUREZZA ED E' LIBERO
          -- DEVE RIENTRARE NELLA CATEGORIA DEI Procedimenti in attesa esecuzione pena principale (liberi)
          IF v_cod_motivo IS NULL THEN
            IF ( v_cod_posizione_giuridica = '07' OR  v_cod_posizione_giuridica = '10')  AND
               ( v_tipo_misura_sic IS NOT NULL AND v_tipo_misura_sic <> '-')  THEN
               v_cod_stato_fascicolo_res := '11'; --Procedimenti in attesa esecuzione pena principale (liberi)
            END IF;
          END IF;

          IF v_cod_stato_fascicolo = '01' THEN
              --STATO FASCICOLO = Archiviato/Definito
              v_cod_stato_fascicolo_res := '18'; -- 18:  DEFINITI

              -- In attesa di archiviazione
            ELSIF v_cod_stato_procedimento = '0154' AND -- STATO PROCEDIMENTO: In attesa di archiviazione
                  (v_cod_posizione_giuridica = '10' OR  v_cod_posizione_giuridica = '07') THEN
              -- 10:   Libero Cumulo; 07 = Libero
              v_cod_stato_fascicolo_res := '17'; -- 17:  Attesa Definizione Procedimento

              -- Trasmessi Atti per competenza per emissione provvedimento di cumulo
            ELSIF v_cod_stato_procedimento = '0139' THEN
              -- 0139:  Trasmessi Atti per competenza per emissione provvedimento di cumulo
              -- per capire se la trasmissione � al proprio distretto oppure ad altro distretto
              -- devo verificare se nella tabella COMPETENZA il campo cod_ufficio � uguale o meno al campo cod_ufficio_inserimento dell'evento
              BEGIN
                SELECT C.CHIAVE_UFFICIO
                  INTO v_cod_ufficio_competente
                  FROM COMPETENZA C
                 WHERE C.EVE_ID_EVENTO = v_id_evento
                   AND C.COD_UFFICIO_INSERIMENTO =
                       v_cod_ufficio_inserimento;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  v_cod_ufficio_competente := NULL;
              END;
              IF v_cod_ufficio_competente = v_cod_ufficio_inserimento THEN
                v_cod_stato_fascicolo_res := '7'; -- PROCEDIMENTI TRASMESSI PER COMPETENZA AL CUMULO PROPRIO UFFICIO
              ELSIF v_cod_ufficio_competente != v_cod_ufficio_inserimento THEN
                v_cod_stato_fascicolo_res := '6'; --  PROCEDIMENTI TRASMESSI PER COMPETENZA AL CUMULO ALTRO UFFICIO
              END IF;

            ELSIF v_cod_stato_procedimento = '9999' THEN
              -- 9999: Altre Posizioni
              v_cod_stato_fascicolo_res := '19'; --  19: Altre Posizioni

              -- 0450: Trasmessi Atti per competenza ai fini dell'esecuzione della misura di sicurezza ex artt. 658 e 659 comma 2 c.p.p.
              -- 0437: Trasmessi Atti per competenza ex artt. 658 e 679 comma 1 c.p.p.
            ELSIF v_cod_stato_procedimento in ('0450', '0437') THEN
              v_cod_stato_fascicolo_res := '4'; --  4: ATTI TRASMESSI PER COMPETENZA PROCURA PRESSO MAGISTRATO DI SORVEGLIANZA (IN ATTESA DI RISPOSTA)

              --0552: Trasmessa richiesta accertamento pericolosita' sociale all'UDS Minori il
              --0553: Trasmessa richiesta accertamento pericolosita' sociale e unificazione delle Misure di Sicurezza all'UDS Minori il
              --0510: Trasmessa richiesta accertamento pericolosit� sociale all'UDS il
              --0511: Trasmessa richiesta accertamento pericolosit� sociale e unificazione delle Misure di Sicurezza all'UDS il
              --0410: Atti trasmessi all'UDS il
              --0555: Atti trasmessi all'UDS Minori il
            ELSIF v_cod_stato_procedimento in
                  ('0552', '0553', '0510', '0511', '0410', '0555') THEN
              v_cod_stato_fascicolo_res := '5'; -- 5=  PROCEDIMENTI INOLTRATI ALL'UFFICIO DI SORVEGLIANZA IN ATTESA DI DECISIONE

            END IF;
            -- SE v_cod_stato_fascicolo_res NON ANCORA ASSEGNATO
            IF v_cod_stato_fascicolo_res IS NULL THEN
              DBMS_OUTPUT.PUT_LINE('>>>>> STATO NON ANCORA ASSEGNATO ricerco su STATO_ESECUZIONE_PROCEDIMENTO per STATO,MOTIVO e PG[' ||
                                   v_cod_stato_procedimento || '-' ||
                                   v_cod_motivo || '-' ||
                                   v_cod_posizione_giuridica || ']... ');

              ----RICERCA STATO FASCICOLO RES
              BEGIN
                SELECT COD_STATO_FASCICOLO_RES
                  INTO v_cod_stato_fascicolo_res
                  FROM STATO_ESECUZIONE_PROCEDIMENTO
                 WHERE (cod_stato_procedimento = v_cod_stato_procedimento)
                   AND (COD_POSIZIONE_GIURIDICA = v_cod_posizione_giuridica OR
                       COD_POSIZIONE_GIURIDICA IS NULL)
                   AND cod_motivo = v_cod_motivo
                   AND ROWNUM = 1;

                DBMS_OUTPUT.PUT_LINE('trovato ;-) ' ||
                                     v_cod_stato_fascicolo_res);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  BEGIN
                    DBMS_OUTPUT.PUT_LINE(' non trovato su STATO_ESECUZIONE_PROCEDIMENTO, provo solo STATO... ');
                    SELECT COD_STATO_FASCICOLO_RES
                      INTO v_cod_stato_fascicolo_res
                      FROM STATO_ESECUZIONE_PROCEDIMENTO
                     WHERE cod_motivo = v_cod_motivo
                       AND ROWNUM = 1;
                    DBMS_OUTPUT.PUT_LINE(' trovato ;-) ' ||
                                         v_cod_stato_fascicolo_res);
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      DBMS_OUTPUT.PUT_LINE(' niente da fare su STATO_ESECUZIONE_PROCEDIMENTO. 19 Altre posizioni SCARTI. ');
                      v_cod_stato_fascicolo_res := '19';
                      DBMS_OUTPUT.PUT_LINE('my_curFascicoli SCARTO: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);
                     
                      INSERT INTO STATIS.ISP_SCARTI_MS
                        (ID_FASCICOLO_SIEP,
                         NRES,
                         CHIAVE_ANNO,
                         CHIAVE_PROGR,
                         ULT_TIPO_PROVVEDIMENTO,
                         ULT_COD_MOTIVO,
                         PEN_TIPO_PROVVEDIMENTO,
                         PEN_COD_MOTIVO,
                         COD_UFFICIO,
                         COD_POSIZIONE_GIURIDICA,
                         COD_STATO_PROCEDIMENTO,
                         COD_STATO_FASCICOLO_RES,
                         COD_UFFICIO_INSERIMENTO,
                         CHIAVE_PROGR_ORIG,
                         DESC_UFFICIO_INSERIMENTO)
                      VALUES
                        (v_id_fascicolo_siep,
                         v_af8_nres,
                         v_chiave_anno,
                         v_chiave_progr,
                         v_cod_tipo_provvedimento,
                         v_cod_motivo,
                         v_cod_tipo_provvedimento_1,
                         v_cod_motivo_1,
                         par_ufficio,
                         v_cod_posizione_giuridica,
                         v_cod_stato_procedimento,
                         v_cod_stato_fascicolo_res,
                         v_cod_ufficio_inserimento,
                         v_chiave_progr_orig,
                         v_desc_ufficio_inserimento);
                  END;
              END;
            END IF;

            DBMS_OUTPUT.PUT_LINE(' Procedimento classificato: ' ||  v_cod_stato_fascicolo_res);

        DBMS_OUTPUT.PUT_LINE('my_curFascicoli: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', stato_fascicolo_res >> '||v_cod_stato_fascicolo_res);
       
        -- Ticket#20211102019 - Rif. TT 20211102011
        -- Ticket#202109290111 - Se classificato come Archiviato (18) da questo cursore
        -- rimuovo una eventuale classificazione dei cursori precedenti
        IF (v_cod_stato_fascicolo_res = '18') THEN
          DBMS_OUTPUT.PUT_LINE('Archiviato: controllo se gia'' classificato.. . ');
          BEGIN
            conta_classificazioni := 0;
            SELECT count(*)
              INTO conta_classificazioni
              FROM STATIS.ISP_PROVVEDIMENTI_MS
             WHERE CHIAVE_ANNO = v_chiave_anno
               AND CHIAVE_PROGR = v_chiave_progr
               AND COD_UFFICIO = par_ufficio;
          
            DBMS_OUTPUT.PUT_LINE('
                               conta_classificazioni = ' ||
                                 conta_classificazioni);
          
            IF (conta_classificazioni > 0) THEN
              DBMS_OUTPUT.PUT_LINE('Procedimento gia'' classificato. Procedo alla cancellazione');
              DELETE FROM STATIS.ISP_PROVVEDIMENTI_MS
               WHERE CHIAVE_ANNO = v_chiave_anno
                 AND CHIAVE_PROGR = v_chiave_progr
                 AND COD_UFFICIO = par_ufficio;
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              DBMS_OUTPUT.put_line('ERRORE conta_classificazioni!!!');
              DBMS_OUTPUT.put_line(SQLCODE);
              DBMS_OUTPUT.put_line(SQLERRM);
          END;
        
        END IF;
        -- Ticket#202109290111 - FINE
       
        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           NULL,
           NULL,
           par_ufficio,
           v_cod_posizione_giuridica,
           v_cod_stato_procedimento,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        --RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
         DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH my_curFascicoli
        INTO v_id_fascicolo_siep,
           v_chiave_anno,
           v_chiave_progr,
           v_cod_tipo_provvedimento,
           v_cod_motivo,
           v_cod_stato_procedimento,
           v_cod_posizione_giuridica,
           v_cod_ufficio_inserimento,
           v_desc_ufficio_inserimento,
           v_cod_stato_fascicolo;

    END LOOP;
    CLOSE my_curFascicoli;
    DBMS_OUTPUT.PUT_LINE('my_curFascicoli - CLOSE');

  -- Ticket#20220124016 - Recupero e Inserisco in ISP_PROVVEDIMENTI_MS solo i procedimenti non già inseriti da precedenti estrazioni
  -- APERTURA CURSORE DEI FASCICOLI NON ESTRATTI NEGLI ALTRI CURSORI
    DBMS_OUTPUT.PUT_LINE('curFascicoliSIEP - OPEN');
    OPEN curFascicoliSIEP;

    -- LETTURA FUORI CICLO DEI DATI DEL FASCICOLO
    FETCH curFascicoliSIEP
      INTO v_id_fascicolo_siep,
      	   v_chiave_anno,
           v_chiave_progr,
           v_cod_ufficio_inserimento,
           v_cod_stato_fascicolo,
           v_tipo_misura_sic;

    -- INIZIO CICLO DI ESTRAZIONE DATI sul cursone curFascicoliSIEP PER OGNI RECORD RILASCIATO DALLA FETCH
    DBMS_OUTPUT.PUT_LINE('inizio ciclo su curFascicoliSIEP');
    WHILE curFascicoliSIEP%FOUND LOOP

      BEGIN
        IF (v_cod_stato_fascicolo in ('02','03')) THEN
          --catalogati in PROCEDIMENTI ISCRITTI
          v_cod_stato_fascicolo_res := '1';
        ELSIF (v_cod_stato_fascicolo = '01') THEN
          --catalogati in PROCEDIMENTI DEFINITI
          v_cod_stato_fascicolo_res := '18';
        END IF;
        DBMS_OUTPUT.PUT_LINE('curFascicoliSIEP: '||v_chiave_anno||'/'||v_chiave_progr||' - '||v_cod_ufficio_inserimento||', v_cod_stato_fascicolo >> '||v_cod_stato_fascicolo_res);

        INSERT INTO STATIS.ISP_PROVVEDIMENTI_MS
          (ID_FASCICOLO_SIEP,
           NRES,
           CHIAVE_ANNO,
           CHIAVE_PROGR,
           ULT_TIPO_PROVVEDIMENTO,
           ULT_COD_MOTIVO,
           PEN_TIPO_PROVVEDIMENTO,
           PEN_COD_MOTIVO,
           COD_UFFICIO,
           COD_POSIZIONE_GIURIDICA,
           COD_STATO_PROCEDIMENTO,
           COD_STATO_FASCICOLO_RES,
           COD_UFFICIO_INSERIMENTO,
           CHIAVE_PROGR_ORIG,
           DESC_UFFICIO_INSERIMENTO)
        VALUES
          (v_id_fascicolo_siep,  
           NULL,
           v_chiave_anno,
           v_chiave_progr,
           NULL,                  
           NULL,
           NULL,
           NULL,
           par_ufficio,
           NULL,
           v_cod_stato_fascicolo,
           v_cod_stato_fascicolo_res,
           v_cod_ufficio_inserimento,
           NULL,
           v_desc_ufficio_inserimento);
        -- RAISE close_cur;
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
         -- RAISE close_cur;
          DBMS_OUTPUT.PUT_LINE('DUP_VAL_ON_INDEX ');
        WHEN close_cur THEN
          DBMS_OUTPUT.PUT_LINE('forzo chiusura cursore ');
          EXIT;
      END;
      COMMIT;

      -- LETTURA IN CICLO
      FETCH curFascicoliSIEP
        INTO v_id_fascicolo_siep,
      	   	 v_chiave_anno,
             v_chiave_progr,
             v_cod_ufficio_inserimento,
             v_cod_stato_fascicolo,
             v_tipo_misura_sic;
    END LOOP;

    CLOSE curFascicoliSIEP;
	DBMS_OUTPUT.PUT_LINE('curFascicoliSIEP - CLOSE');
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('');
-- Ticket#20220124016 -  FINE
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('===================================================');
    DBMS_OUTPUT.PUT_LINE('   F I N E    P R O C E D U R A '||to_char(sysdate, 'dd/MM/yyyy hh24:mi:ss'));
    DBMS_OUTPUT.PUT_LINE('===================================================');
  END; --- fine procedura carica provvedimenti

   -----------------------------------------------------------------------------------------------------------------------
  ------------------------------------PROCEDURA ATTIVITA MAGISTRATI----------------------------------------------------
  -----------------------------------------------------------------------------------------------------------------------

  PROCEDURE attivita_magistrati(par_data_inizio IN VARCHAR2,
                                par_data_fine   IN VARCHAR2,
                                par_ufficio     IN VARCHAR2) IS

    -- DEFINIZIONE VARIABILI

    v_id_fascicolo_siep       FASCICOLO_SIEP.fas_sie_id_fascicolo_siep%TYPE;
    v_anno_af8_nrgem          EVENTO.anno_protocollo%TYPE;
    v_progr_af8_nrgem         EVENTO.progr_protocollo%TYPE;
    v_chiave_anno             FASCICOLO_SIEP.chiave_anno%TYPE;
    v_chiave_progr            FASCICOLO_SIEP.chiave_progr%TYPE;
    v_cod_ufficio_inserimento FASCICOLO_SIEP.cod_ufficio_inserimento%TYPE;
    v_chiave_progr_orig       FASCICOLO_SIEP.chiave_progr_orig%TYPE;
    v_cod_posizione_giuridica POSIZIONE_GIURIDICA.cod_posizione_giuridica%TYPE;
    v_con_rev                 VARCHAR2(30);
    v_tip_aut                 VARCHAR2(70);
    v_tip_att                 VARCHAR2(80);
    v_motiv                   VARCHAR2(50);
    v_af8_nres                FASCICOLO_SIEP.fas_sie_id_fascicolo_siep%TYPE;

    v_cod_stato_procedimento  STATO_PROCEDIMENTO.cod_stato_procedimento%TYPE;
    flag_no_riepilogo         CHAR(1);
    tot_recl                  NUMBER;
    tot_arre                  NUMBER;
    v_num_anni_reclusione     NUMBER(4);
    v_num_mesi_reclusione     NUMBER(4);
    v_num_giorni_reclusione   NUMBER(4);
    v_importo_multa           NUMBER(11, 2);
    v_num_anni_arresto        NUMBER(4);
    v_num_mesi_arresto        NUMBER(4);
    v_num_giorni_arresto      NUMBER(4);
    v_importo_ammenda         NUMBER(11, 2);
    gg_tot                    NUMBER;
    tot_pres                  NUMBER;
    v_data_inizio             PENA_RESIDUA.data_inizio%TYPE;
    v_data_fine               PENA_RESIDUA.data_fine%TYPE;
    v_id_fascicolo_siep_old   FASCICOLO_SIEP.fas_sie_id_fascicolo_siep%TYPE;
    v_id_evento               EVENTO.id_evento%TYPE;
    v_cod_magistrato          EVENTO.cod_magistrato%TYPE;
    v_cod_tipo_provvedimento  EVENTO.cod_tipo_provvedimento%TYPE;
    v_cod_magistrato_ass      MAGISTRATO_COMPETENTE.mag_cod_magistrato%TYPE;
    v_cod_magistrato_comp     MAGISTRATO_COMPETENTE.mag_cod_magistrato%TYPE;
    v_cod_stato_fascicolo_res STATO_FASCICOLO_RES_MS.cod_stato_fascicolo%TYPE := '';
    -- variabile generali
    conta_commit NUMBER;

    v_trovato  NUMBER;
    v_inserito NUMBER := 0;

    num_record_scritti NUMBER := 0;
    num_record_letti   NUMBER := 0;
    --num_record_scartati         NUMBER:= 0;
    v_anno_res                 NUMBER(4) := NULL;
    v_num_res                  VARCHAR2(6) := '';
    v_data_iscrizione          DATE;
    v_data_arrivo_atto         DATE;
    v_data_emissione           DATE;
    v_iscrizione_emissione     NUMBER := 0;
    primo_record_letto         VARCHAR2(1) := 'N';
    secondo_record_letto       VARCHAR2(1) := 'N';
    terzo_record_letto         VARCHAR2(1) := 'N';
    v_id_evento_provv          EVENTO.id_evento%TYPE := '';
    v_motivo_provv             EVENTO.cod_motivo%TYPE := '';
    v_data_emissione_provv     DATE;
    v_desc_motivo_provv        CG_REF_CODES.rv_meaning%TYPE;
    v_id_evento_rich           EVENTO.id_evento%TYPE := '';
    v_motivo_rich              EVENTO.cod_motivo%TYPE := '';
    v_data_emissione_rich      DATE;
    v_desc_motivo_rich         CG_REF_CODES.rv_meaning%TYPE;
    v_id_evento_ord            EVENTO.id_evento%TYPE := '';
    v_motivo_ord               EVENTO.cod_motivo%TYPE := '';
    v_data_emissione_ord       DATE;
    v_desc_motivo_ord          CG_REF_CODES.rv_meaning%TYPE;
    v_caso_rich                VARCHAR2(1) := 'N';
    v_tipologia                VARCHAR2(2);
    v_desc_ufficio_inserimento VARCHAR2(200);
    v_cod_tipo_misura_sicur    misura_sicurezza.cod_tipo%TYPE;
    v_tipo_ms                  statis.isp_attivita_magistrati_ms.tipo_ms%TYPE;
    v_cod_ufficio_competente    COMPETENZA.CHIAVE_UFFICIO%TYPE;
    -- dichiarazione del cursore

    CURSOR cur_evento IS
      SELECT a.id_evento,
             a.cod_motivo,
             a.data_emissione,
             a.cod_magistrato,
             a.cod_tipo_provvedimento,
             c.mag_cod_magistrato,
             b.id_fascicolo_siep,
             b.chiave_anno,
             b.cod_ufficio_inserimento,
             b.chiave_progr_orig,
             b.chiave_progr,
             MS.COD_TIPO TIPO_MS
        FROM EVENTO                a,
             FASCICOLO_SIEP        b,
             MAGISTRATO_COMPETENTE c,
             MISURA_SICUREZZA      MS
       WHERE a.cod_ufficio_inserimento = par_ufficio
         AND a.FLAG_DOCUMENTO_REGISTRATO = 'S' -- NON Annullato
         AND TO_DATE(TO_CHAR(a.data_emissione, 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN
             TO_DATE(par_data_inizio, 'dd/mm/yyyy') AND
             TO_DATE(par_data_fine, 'dd/mm/yyyy')
         AND a.fas_sie_id_fascicolo_siep = b.id_fascicolo_siep
         AND a.cod_ufficio_inserimento = par_ufficio
            -- reinserito scarto decreti e ordinanze, eccetto decreto irreperibilit�
         AND (a.cod_tipo_provvedimento NOT IN ('02', '03') OR
             (a.cod_tipo_provvedimento = '02' AND a.COD_MOTIVO = '0282'))
         AND b.id_fascicolo_siep = c.fas_sie_id_fascicolo_siep(+)
         AND c.data_fine IS NULL
            -- EVENTI RELATIVI SOLO A PROCEDIMENTI DI CLASSE IV
         AND ((b.CHIAVE_PROGR BETWEEN 40000 AND 49999) OR
             (b.CHIAVE_PROGR BETWEEN 10000000040000 AND 10000000049999) OR
             (b.CHIAVE_PROGR BETWEEN 20000000040000 AND 20000000049999) OR
             (b.CHIAVE_PROGR BETWEEN 30000000040000 AND 30000000049999))
            -- ESTRAGGO I DATI RELATIVI ALLE MISURA DI SICUREZZE LEGATE AL FASCICOLO
         AND MS.FAS_SIE_ID_FASCICOLO_SIEP = B.ID_FASCICOLO_SIEP
         AND (MS.FLAG_ANNULLA_MISURA IS NULL OR
             MS.FLAG_ANNULLA_MISURA != 'A')
         AND MS.DATA_FINE_VALIDITA IS NULL

       ORDER BY id_evento;

    --
  BEGIN
    ---inizio procedura

    conta_commit := 1;

    v_id_evento                := NULL;
    v_cod_motivo               := NULL;
    v_data_emissione           := NULL;
    v_cod_magistrato           := NULL;
    v_cod_tipo_provvedimento   := NULL;
    v_id_fascicolo_siep        := NULL;
    v_chiave_anno              := NULL;
    v_chiave_progr             := NULL;
    v_cod_magistrato_ass       := NULL;
    v_cod_tipo_provvedimento   := NULL;
    v_desc_ufficio_inserimento := NULL;
    v_cod_tipo_misura_sicur    := NULL;

    ---CANCELLO tabelle di appoggio
    DELETE FROM STATIS.ISP_ATTIVITA_MAGISTRATI_MS;
    COMMIT;

    OPEN cur_evento;

    FETCH cur_evento
      INTO v_id_evento,
           v_cod_motivo,
           v_data_emissione,
           v_cod_magistrato,
           v_cod_tipo_provvedimento,
           v_cod_magistrato_comp,
           v_id_fascicolo_siep,
           v_chiave_anno,
           v_cod_ufficio_inserimento,
           v_chiave_progr_orig,
           v_chiave_progr,
           v_cod_tipo_misura_sicur;

    DBMS_OUTPUT.PUT_LINE('fetch fuori ciclo ');

    -- CALCOLO DELL'ORA DI CARICAMENTO
    v_data_inserimento := SYSDATE;

    v_motivo_provv         := '';
    v_tipologia            := '';
    v_id_evento_provv      := NULL;
    v_data_emissione_provv := NULL;
    v_tipo_ms              := '';

    ----RICERCA LUOGO UFFICIO INSERIMENTO
    BEGIN
      SELECT descrizione
        INTO v_desc_ufficio_inserimento
        FROM COMUNE
       WHERE cod_comune = SUBSTR(v_cod_ufficio_inserimento, 1, 6);
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_desc_ufficio_inserimento := '-';
    END;

    WHILE cur_evento%FOUND LOOP
      BEGIN
        ---inizio loop

        DBMS_OUTPUT.PUT_LINE('INIZIO DEL LOOP ');

        DBMS_OUTPUT.PUT_LINE('v_id_fascicolo_siep ' || v_id_fascicolo_siep);
        DBMS_OUTPUT.PUT_LINE('v_chiave_anno ' || v_chiave_anno);
        DBMS_OUTPUT.PUT_LINE('v_chiave_progr ' || v_chiave_progr);

        v_cod_stato_fascicolo_res := NULL;
        v_motivo_provv            := '';
        v_tipologia               := '';
        v_id_evento_provv         := NULL;
        v_data_emissione_provv    := NULL;
        v_cod_magistrato_ass      := NULL;
        v_tipo_ms                 := '';
        num_record_letti          := 0;

        num_record_letti := num_record_letti + 1;

        DBMS_OUTPUT.PUT_LINE('v_cod_motivo ' || v_cod_motivo);
        DBMS_OUTPUT.PUT_LINE('num_record_letti ' || num_record_letti);
        DBMS_OUTPUT.PUT_LINE('v_cod_magistrato ' || v_cod_magistrato);
        DBMS_OUTPUT.PUT_LINE('v_cod_magistrato_comp ' ||
                             v_cod_magistrato_comp);
        DBMS_OUTPUT.PUT_LINE('v_cod_magistrato_ass ' ||
                             v_cod_magistrato_ass);

        DBMS_OUTPUT.PUT_LINE('v_motivo_provv ' || v_motivo_provv);

        ----RICERCA LUOGO UFFICIO INSERIMENTO
        BEGIN
          SELECT descrizione
            INTO v_desc_ufficio_inserimento
            FROM COMUNE
           WHERE cod_comune = SUBSTR(v_cod_ufficio_inserimento, 1, 6);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_desc_ufficio_inserimento := '-';
        END;

        --============================================
        --============================================
        BEGIN
          SELECT i.cod_attivita, i.tipo_ms
            INTO v_tipologia, v_tipo_ms
            FROM isp_motivo_attivita_ms i
           WHERE i.cod_motivo = v_cod_motivo
             AND i.tipo_ms = v_cod_tipo_misura_sicur;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            BEGIN
              SELECT i.cod_attivita, i.tipo_ms
                INTO v_tipologia, v_tipo_ms
                FROM isp_motivo_attivita_ms i
               WHERE i.cod_motivo = v_cod_motivo
                 AND i.tipo_ms is null;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                IF (v_cod_motivo <> '0340') THEN
                   v_tipologia := '-';
                   v_tipo_ms   := '-';
                ELSIF (v_cod_motivo = '0340') THEN
                  -- IN CORRISPONDENZA DELLO STESSO MOTIVO, SULLA STATISTICA VOGLIONO 2 RIGHE SEPARATE
                  -- IN BASE ALLA COMPENZA
                  -- devo capire di chi � la competenza
                  BEGIN
                  SELECT C.CHIAVE_UFFICIO
                    INTO v_cod_ufficio_competente
                    FROM COMPETENZA C
                   WHERE C.EVE_ID_EVENTO = v_id_evento
                     AND C.COD_UFFICIO_INSERIMENTO =
                         v_cod_ufficio_inserimento;
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                      v_cod_ufficio_competente := NULL;
                  END;
                 END IF;
                 IF v_cod_ufficio_competente = v_cod_ufficio_inserimento THEN
                      v_tipologia := '01';
                      v_tipo_ms := 'PU'; -- PROPRIO UFFICIO (mi appoggio alla variabile v_tipo_ms per portare il dato fuori per java)
                 ELSIF v_cod_ufficio_competente != v_cod_ufficio_inserimento THEN
                      v_tipologia := '01';
                      v_tipo_ms := 'AU'; --  ALTRO UFFICIO (mi appoggio alla variabile v_tipo_ms per portare il dato fuori per java)
                 END IF;
                 ---
            END;

            IF v_tipologia IS NULL THEN
              v_tipologia := '-';
              v_tipo_ms   := '-';
            end if;
        END;

        v_motivo_provv       := v_cod_motivo;
        v_cod_magistrato_ass := v_cod_magistrato;

        DBMS_OUTPUT.PUT_LINE('SONO della FINE ' || v_cod_motivo || ' ' ||
                             v_motivo_provv);

        IF v_motivo_provv IS NOT NULL AND v_tipologia <> '-' THEN
          DBMS_OUTPUT.PUT_LINE('FIN v_cod_magistrato ' || v_cod_magistrato);
          DBMS_OUTPUT.PUT_LINE('FIN v_cod_magistrato_comp ' ||
                               v_cod_magistrato_comp);
          DBMS_OUTPUT.PUT_LINE('FIN v_cod_magistrato_ass ' ||
                               v_cod_magistrato_ass);
          DBMS_OUTPUT.PUT_LINE('eseguo insert ');

          v_id_evento_provv      := v_id_evento;
          v_data_emissione_provv := v_data_emissione;

          INSERT INTO STATIS.ISP_ATTIVITA_MAGISTRATI_MS
            (ID_FASCICOLO_SIEP,
             CHIAVE_ANNO,
             CHIAVE_PROGR,
             COD_UFFICIO,
             COD_MAGISTRATO,
             DATA_EMISSIONE,
             COD_MOTIVO,
             TIPOLOGIA,
             COD_UFFICIO_INSERIMENTO,
             CHIAVE_PROGR_ORIG,
             DESC_UFFICIO_INSERIMENTO,
             ID_EVENTO,
             TIPO_MS)
          VALUES
            (v_id_fascicolo_siep,
             v_chiave_anno,
             v_chiave_progr,
             par_ufficio,
             v_cod_magistrato_ass,
             v_data_emissione_provv,
             v_motivo_provv,
             v_tipologia,
             v_cod_ufficio_inserimento,
             v_chiave_progr_orig,
             v_desc_ufficio_inserimento,
             v_id_evento_provv,
             v_tipo_ms);
        END IF;

        COMMIT;

      END; ----fine loop

      -- LETTURA IN CICLO
      FETCH cur_evento
        INTO v_id_evento,
             v_cod_motivo,
             v_data_emissione,
             v_cod_magistrato,
             v_cod_tipo_provvedimento,
             v_cod_magistrato_comp,
             v_id_fascicolo_siep,
             v_chiave_anno,
             v_cod_ufficio_inserimento,
             v_chiave_progr_orig,
             v_chiave_progr,
             v_tipo_ms;

    -- CHIUSURA DEL WHILE
    END LOOP;

    CLOSE cur_evento;

    COMMIT;

    --  I records con magistrato a NULL vengono accorpati a quelli con magistrato a '-'
    UPDATE STATIS.ISP_ATTIVITA_MAGISTRATI_MS
       SET COD_MAGISTRATO = '-'
     WHERE COD_MAGISTRATO IS NULL;

  END; ---fine procedura attivita magistrati

END;
-- Empty source;
/