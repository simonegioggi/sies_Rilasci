comment on column AVVISI_AVVOCATO.cognome_soggetto
  is 'Cognome del Soggetto del provvedimento a cui fa riferimento l''avviso';
comment on column AVVISI_AVVOCATO.nome_soggetto
  is 'Nome del Soggetto del provvedimento a cui fa riferimento l''avviso';
