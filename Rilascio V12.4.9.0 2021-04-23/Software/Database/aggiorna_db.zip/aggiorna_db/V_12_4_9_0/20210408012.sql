update funzione_profilo fp
   set fp.data_fine_validita          = fp.data_inizio_validita,
       fp.data_aggiornamento          = sysdate,
       fp.cod_operatore_aggiornamento = 'Ticket#20210408012'
 where fp.fun_id_funzione = '90110640';