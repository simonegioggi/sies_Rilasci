--- inserisce nuovo record in ISP_MOTIVO_ATTIVITA per cod_motivo = 0488
INSERT INTO ISP_MOTIVO_ATTIVITA
(COD_MOTIVO, DESCRIZIONE_MOTIVO, COD_ATTIVITA, PROGR)
VALUES('0488', 'Visto del Pubblico Ministero per archiviazione', '17', '002');
--commit;