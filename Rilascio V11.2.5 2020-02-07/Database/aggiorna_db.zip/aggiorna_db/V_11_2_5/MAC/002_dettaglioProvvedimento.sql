Insert into DETTAGLIO_PROVVEDIMENTO
  (COD_TIPO_EVENTO,
   COD_TIPO_PROVVEDIMENTO,
   COD_MOTIVO,
   ACTION_DETTAGLIO,
   NOTE,
   ACTION_UPLOAD)
Values
  ('01',
   '09',
   '9154',
   'siap.sico.libertaanticipata.action.ActDettaglioOSRimediRisarcitori',
   'Decisione Della Sorveglianza -> Rimedi Risarcitori -> Dettaglio Ordine Scarcerazione DL92',
   'siap.sico.libertaanticipata.action.ActUploadOSRimediRisarcitori');
   
   Insert into DETTAGLIO_PROVVEDIMENTO
  (COD_TIPO_EVENTO,
   COD_TIPO_PROVVEDIMENTO,
   COD_MOTIVO,
   ACTION_DETTAGLIO,
   NOTE,
   ACTION_UPLOAD)
Values
  ('01',
   '09',
   '9254',
   'siap.sico.libertaanticipata.action.ActDettaglioOSRimediRisarcitori',
   'Decisione Della Sorveglianza -> Rimedi Risarcitori -> Dettaglio Ordine Scarcerazione DL92',
   'siap.sico.libertaanticipata.action.ActUploadOSRimediRisarcitori');
