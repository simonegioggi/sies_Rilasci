Insert into DETTAGLIO_PROVVEDIMENTO
  (COD_TIPO_EVENTO,
   COD_TIPO_PROVVEDIMENTO,
   COD_MOTIVO,
   ACTION_DETTAGLIO,
   NOTE,
   ACTION_UPLOAD)
Values
  ('01',
   '12',
   '9032',
   'siap.sico.libertaanticipata.action.ActDettaglioComunicazioneRimediRisarcitori',
   'Decisione Della Sorveglianza -> Rimedi Risarcitori -> Dettaglio Comunicazione DL92',
   'siap.sico.libertaanticipata.action.ActUploadComunicazioneRimediRisarcitori');
Insert into DETTAGLIO_PROVVEDIMENTO
  (COD_TIPO_EVENTO,
   COD_TIPO_PROVVEDIMENTO,
   COD_MOTIVO,
   ACTION_DETTAGLIO,
   NOTE,
   ACTION_UPLOAD)
Values
  ('01',
   '12',
   '9033',
   'siap.sico.libertaanticipata.action.ActDettaglioComunicazioneRimediRisarcitori',
   'Decisione Della Sorveglianza -> Rimedi Risarcitori -> Dettaglio Comunicazione DL92',
   'siap.sico.libertaanticipata.action.ActUploadComunicazioneRimediRisarcitori');   

Insert into DETTAGLIO_PROVVEDIMENTO
  (COD_TIPO_EVENTO,
   COD_TIPO_PROVVEDIMENTO,
   COD_MOTIVO,
   ACTION_DETTAGLIO,
   NOTE,
   ACTION_UPLOAD)
Values
  ('01',
   '12',
   '9034',
   'siap.sico.libertaanticipata.action.ActDettaglioComunicazioneRimediRisarcitori',
   'Decisione Della Sorveglianza -> Rimedi Risarcitori -> Dettaglio Comunicazione DL92',
   'siap.sico.libertaanticipata.action.ActUploadComunicazioneRimediRisarcitori'); 
