insert into CG_REF_CODES
  (RV_DOMAIN,
   RV_LOW_VALUE,
   RV_HIGH_VALUE,
   RV_ABBREVIATION,
   RV_MEANING,
   RV_ALT2_VALUE,
   RV_ALT3_VALUE,
   RV_ALT4_VALUE,
   RV_ALT5_VALUE)
values
  ('STATO_PROCEDIMENTO',
   '0499',
   null,
   'In esecuzione',
   'Emesso Ordine di Scarcerazione per Concessione Reclamo Risarcimento Danni D.L. 92/2014 il',
   null,
   null,
   null,
   null);
