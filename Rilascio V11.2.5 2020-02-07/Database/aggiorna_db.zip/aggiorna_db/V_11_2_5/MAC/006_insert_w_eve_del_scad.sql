INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0652', 'di unificazione di pene concorrenti', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0661', 'di unificazione di pene concorrenti (con contestuale Decreto di Sospensione ex art. 656 Comma 5 CPP)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0635', 'di unificazione di pene concorrenti (con contestuale Decreto di Sospensione ex art. 656 Comma 5 CPP)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0642', 'di unificazione di pene concorrenti (con contestuale Decreto di Sospensione ex art. 656 Comma 5 CPP)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0637', 'di unificazione di pene concorrenti (con contestuale Decreto di Sospensione ex art. 656 Comma 5 CPP)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0644', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione - prosecuzione in regime di misura alternativa)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0651', 'di unificazione di pene concorrenti con contestuale Ordine di Esecuzione cessazione misura alternativa (art. 51 Bis legge 354/75)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0649', 'di unificazione di pene concorrenti con contestuale Ordine di Esecuzione cessazione misura alternativa (art. 51 Bis legge 354/75)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0647', 'di unificazione di pene concorrenti con contestuale Ordine di Esecuzione cessazione misura alternativa (art. 51 Bis legge 354/75)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0639', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Arresti Domiciliari)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0645', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Detenuto)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0643', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Detenuto)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0640', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Detenuto)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0638', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Detenuto - ex Art 656 comma 1 cpp)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0630', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Libero)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0641', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Libero)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0636', 'di unificazione di pene concorrenti (con contestuale Ordine di Esecuzione Condannato Libero)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0646', 'di unificazione di pene concorrenti prosecuzione dell''espiazione nel regime attuale di espiazione (art. 51 Bis legge 354/75 affidamento in prova)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0648', 'di unificazione di pene concorrenti prosecuzione dell''espiazione nel regime attuale di espiazione (art. 51 Bis legge 354/75 Detenzione Domiciliare)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0650', 'di unificazione di pene concorrenti prosecuzione dell''espiazione nel regime attuale di espiazione (art. 51 Bis legge 354/75 Semiliberta'')', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0653', 'di unificazione di pene concorrenti (con contestuale Decreto di Sospensione ex art. 656 Comma 10 CPP)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0663', 'di unificazione di pene concorrenti (prosecuzione agli Arresti Domiciliari ex art. 656 Comma 10 CPP)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0654', 'di unificazione di pene concorrenti sospensione pena detentiva  - (differimento pena)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0662', 'di unificazione di pene concorrenti sospensione pena detentiva  - (differimento pena provvisoria)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0655', 'di unificazione di pene concorrenti (non luogo a provvedere)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0656', 'di unificazione di pene concorrenti (con contestuale Decreto di Sospensione legge 26.11.2010 n. 199)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0657', 'di unificazione di pene concorrenti (con contestuale Ordine Scarcerazione legge 26.11.2010 n. 199)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0658', 'di unificazione di pene concorrenti (prosecuzione in regime di arresti domiciliari legge 26.11.2010 n. 199)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0659', 'di unificazione di pene concorrenti (Comunicazione ex art. 656 co. 4 bis c.p.p. - D.L. 78/2013)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0664', 'di unificazione di pene concorrenti (Comunicazione ex art. 656 co. 4 bis c.p.p. - D.L. 78/2013)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0660', 'di unificazione di pene concorrenti (Ordine esecuzione e Comunicazione ex art. 656 co. 4 ter c.p.p. - D.L. 78/2013)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0667', 'di unificazione di pene concorrenti (con contestuale Revoca Decreto di Sospensione ex art. 656 Comma 8 CPP)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0668', 'di unificazione di pene concorrenti prosecuzione dell''espiazione nel regime attuale di espiazione (art. 51 Bis legge 354/75 Detenzione Domiciliare art. 47 ter comma 1 ter)', '01', sysdate, null);

INSERT INTO w_eve_del_scad(cod_motivo, descrizione, cod_tipo_scad, data_inserimento, note)
values ('0665', 'di unificazione di pene concorrenti ', '01', sysdate, null);


