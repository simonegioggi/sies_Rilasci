insert into CG_REF_CODES
  (RV_DOMAIN,
   RV_LOW_VALUE,
   RV_HIGH_VALUE,
   RV_ABBREVIATION,
   RV_MEANING,
   RV_ALT2_VALUE,
   RV_ALT3_VALUE,
   RV_ALT4_VALUE,
   RV_ALT5_VALUE)
values
  ('MOTIVO_PROVVEDIMENTO',
   '9154',
   null,
   null,
   'Nuova scadenza pena a seguito concessione Reclamo Risarcimento Danni D.L. 92/2014',
   null,
   null,
   null,
   null);
   
insert into CG_REF_CODES
  (RV_DOMAIN,
   RV_LOW_VALUE,
   RV_HIGH_VALUE,
   RV_ABBREVIATION,
   RV_MEANING,
   RV_ALT2_VALUE,
   RV_ALT3_VALUE,
   RV_ALT4_VALUE,
   RV_ALT5_VALUE)
values
  ('MOTIVO_PROVVEDIMENTO',
   '9254',
   null,
   null,
   'Nuova scadenza pena a seguito concessione Reclamo Risarcimento Danni D.L. 92/2014',
   null,
   null,
   null,
   null);   
