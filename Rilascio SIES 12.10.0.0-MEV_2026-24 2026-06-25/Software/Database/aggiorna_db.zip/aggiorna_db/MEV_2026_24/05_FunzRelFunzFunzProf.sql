-- FUNZIONE
insert into FUNZIONE values (36160027,'Ricerca Fine Pena Procedimenti Pendenti per Excel','R','siap.sius.scadenzario.action.RicercaFinePenaProcedimentiPendentiExcel');
insert into FUNZIONE values (36160028,'Ricerca Fine Pena Procedimenti Pendenti per Excel','R','siap.sius.scadenzario.action.ActRicercaFinePenaProcedimentiPendentiExcel');
insert into FUNZIONE values (36160029,'Ricerca Fine Pena Procedimenti Pendenti','R','siap.sius.scadenzario.action.ActRicercaFinePenaProcedimentiPendenti');
insert into FUNZIONE values (36160030,'Load Ricerca Fine Pena Procedimenti Pendenti','R','siap.sius.scadenzario.action.ActLoadRicercaFinePenaProcedimentiPendenti');
-- RELAZIONE_FUNZIONE
insert into RELAZIONE_FUNZIONE values (10509,36160030,'ME','Ricerca Fine Pena Procedimenti Pendenti',2,null);
-- FUNZIONE_PROFILO
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

-- ======================================================================================
-- Storico
--  4 - Superutente
-- 30 - Lettura
-- 40 - Lettura/Scrittura
-- 50 - Lettura/Scrittura/Modifica
-- ======================================================================================
-- Action per il caricamento della lista degli storici 
-- 23000001
-- ======================================================================================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(23000001, 'Load Storico Pena Virtuale DL92', 'R'
, 'siap.siep.calcolopena.action.ActLoadStoricoCalcoloPenaDL92');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 30, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 50, 'S');

-- Si abilita la funzione alcnhe alla sorveglianza - TDS
-- 14 - SUPERUTENTE PER IL TRIBUNALE DI SORVEGLIANZA
-- 31 - LETTURA PER IL TRIBUNALE DI SORVEGLIANZA
-- 41 - LETTURA/SCRITTURA PER IL TRIBUNALE di SORVEGLIANZA
-- 51 - LETTURA/SCRITTURA/MODIFICA PER IL TRIBUNALE DI SORVEGLIANZA
INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 14, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 31, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 41, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 51, 'S');

-- Si abilita la funzione alcnhe alla sorveglianza UDS
-- 24 - SUPERUTENTE PER L' UFFICIO DI SORVEGLIANZA
-- 32 - LETTURA PER L'UFFICIO DI SORVEGLIANZA
-- 42 - LETTURA/SCRITTURA PER L' UFFICIO di SORVEGLIANZA
-- 52 - LETTURA/SCRITTURA/MODIFICA PER L' UFFICIO di SORVEGLIANZA
INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 24, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 32, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 42, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000001, 52, 'S');

-- ======================================================================================
-- Action per caricare il Dettaglio del singolo calcolo
-- 23000002
-- ======================================================================================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(23000002, 'Load Dettaglio Storico Pena Virtuale DL92', 'D'
, 'siap.siep.calcolopena.action.ActDettStoricoCalcoloPenaDL92');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 30, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 50, 'S');

-- Si abilita la funzione alcnhe alla sorveglianza - TDS
-- 14 - SUPERUTENTE PER IL TRIBUNALE DI SORVEGLIANZA
-- 31 - LETTURA PER IL TRIBUNALE DI SORVEGLIANZA
-- 41 - LETTURA/SCRITTURA PER IL TRIBUNALE di SORVEGLIANZA
-- 51 - LETTURA/SCRITTURA/MODIFICA PER IL TRIBUNALE DI SORVEGLIANZA
INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 14, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 31, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 41, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 51, 'S');

-- Si abilita la funzione alcnhe alla sorveglianza UDS
-- 24 - SUPERUTENTE PER L' UFFICIO DI SORVEGLIANZA
-- 32 - LETTURA PER L'UFFICIO DI SORVEGLIANZA
-- 42 - LETTURA/SCRITTURA PER L' UFFICIO di SORVEGLIANZA
-- 52 - LETTURA/SCRITTURA/MODIFICA PER L' UFFICIO di SORVEGLIANZA
INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 24, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 32, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 42, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000002, 52, 'S');

-- ======================================================================================
-- Action la cancellazione dello storico
-- 23000003
-- ======================================================================================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(23000003, 'Cancellazioe Storico Pena Virtuale DL92', 'C'
, 'siap.siep.calcolopena.action.ActCancStoricoCalcoloPenaDL92');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000003, 4, 'S');

--INSERT INTO FUNZIONE_PROFILO
-- (DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
-- VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000003, 30, 'S');

-- INSERT INTO FUNZIONE_PROFILO
-- (DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
-- VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000003, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2026-01-01 00:00:00.000000', NULL, 23000003, 50, 'S');