CREATE OR REPLACE PACKAGE BODY pulisci_altre_bdi IS

  /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
  -- Forward declaration delle procedure aggiunte un coda al package
  PROCEDURE pulisci_benefici (idfascicolo          IN NUMBER,
                              esitoPulisciBenefici IN OUT VARCHAR2);
  PROCEDURE pulisci_circostanza (idfascicolo             IN NUMBER,
                                 esitoPulisciCircostanza IN OUT VARCHAR2);
  PROCEDURE pulisci_reati (idFascicolo       IN NUMBER,
                           esitoPulisciReati IN OUT VARCHAR2);
  PROCEDURE pulisci_pena_complessiva (idFascicolo       IN NUMBER,
                                      esitoPulisciPenaCompl IN OUT VARCHAR2);
  PROCEDURE pulisci_pene_accessorie (idFascicolo       IN NUMBER,
                                     esitoPulisciPeneAcc IN OUT VARCHAR2);
  PROCEDURE pulisci_luogo_detenzione (idFascicolo       IN NUMBER,
                                      esitoPulisciLuogoDet IN OUT VARCHAR2);
  PROCEDURE pulisci_altra_causa (idFascicolo     IN NUMBER,
                                 esitoAltraCausa IN OUT VARCHAR2);
  /* MEV_2025-48 - FINE Forward declaration */

  PROCEDURE pulisci_evento(idevento           IN NUMBER,
                           esitopuliscievento IN OUT VARCHAR2) IS

	-- modifiche per integrazione BDMC
    annotazione_rec annotazione_manuale%ROWTYPE;

    TYPE annotazione_cur IS REF CURSOR RETURN annotazione_rec%TYPE;

    annotazione_cur1 annotazione_cur;
    idordinanza           NUMBER := 0;
    iddecreto             NUMBER := 0;
    appo_evento           NUMBER := 0;
    idmisuraalternativa   NUMBER := 0;
    idlicenzaliban        NUMBER := 0;
    idpenaresidua         NUMBER := 0;
    v_ann_id_annot        NUMBER := NULL;
    v_id_annotazione      NUMBER := NULL;
    v_eve_annot           NUMBER := NULL;
    v_pen_id_pena_residua NUMBER := NULL;
    v_id_pena_residua     NUMBER := NULL;
    v_eve_pena_residua    NUMBER := NULL;

    -- Ticket#202103180118 - variabili START
    TYPE elenco_PG_per_evento_cur IS REF CURSOR;

    v_elenco_PG_per_evento_cur elenco_PG_per_evento_cur;
    v_id_posizione_giuridica NUMBER := NULL;
    v_id_altra_causa         NUMBER := NULL;
    -- Ticket#202103180118 - variabili END

    CURSOR lic_lib IS
      SELECT id_licenza_libanticipata
        FROM licenza_libanticipata
       WHERE eve_id_evento = idevento;

  BEGIN
    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('--------------------- INIZIO PULISCI EVENTO ');
    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('id_evento = ' || idevento);

    DELETE FROM beneficio WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete BENEFICIO ------ >>>  OK!');

    DELETE FROM campo_nota WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete CAMPO_NOTA ------ >>>  OK!');

    DELETE FROM pena_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo FROM cumulo WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete PENA_CUMULO ------ >>>  OK!');
    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');
    ---aggiunto il 13/12/2006

    DELETE FROM ulteriore_sanzione_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo FROM cumulo WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');

    DELETE FROM cumulo WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete CUMULO ------ >>>  OK!');

    DELETE FROM documento_allegato WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete DOCUMENTO_ALLEGATO ------ >>>  OK!');

    DELETE FROM scadenzario_siep
     WHERE not_id_notifica IN
           (SELECT id_notifica FROM notifica WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete SCADENZARIO_SIEP ------ >>>  OK!');

    DELETE FROM rinnovo
     WHERE not_id_notifica IN
           (SELECT id_notifica FROM notifica WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete RINNOVO ------ >>>  OK!');

    DELETE FROM rinnovo
     WHERE ver_id_verbale IN
           (SELECT id_verbale FROM verbale WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete RINNOVO ------ >>>  OK!');

    DELETE FROM verbale WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete VERBALE ------ >>>  OK!');

    DELETE FROM notifica WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete NOTIFICA ------ >>>  OK!');

    DELETE FROM nome_provvedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete NOME_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM motivo_evento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MOTIVO_EVENTO ------ >>>  OK!');

    DELETE FROM motivazione_decreto WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MOTIVAZIONE_DECRETO  ------ >>>  OK!');

    DELETE FROM referto_scarcerazione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete REFERTO_SCARCERAZIONE ------ >>>  OK!');

    DELETE FROM istanza WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete ISTANZA ------ >>>  OK!');

    /* -- 17/01/2018[EC]: commento a favore di quanto riportato sotto
    DELETE FROM nuova_istanza
            WHERE eve_id_evento = idevento;*/

    -- 17/01/2018[EC] CANCELLO LE NUOVE ISTANZE COLLEGATE A LIVELLO AL FASCICOLO_SIEP
    -- PERCH?????? SE L'EVENTO E' STATO ANNULLATO LA CANCELLAZIONE NON VA A BUON FINE
    DELETE FROM nuova_istanza aa
     WHERE aa.fas_sie_id_fascicolo_siep IN
           (SELECT e.fas_sie_id_fascicolo_siep
              FROM evento e
             WHERE e.id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete NUOVA_ISTANZA ------ >>>  OK!');

    -- Ticket#202103180118 - La cancellazione a tappeto dei record ALTRA_CAUSA
    -- collegati al fascicolo genera un errore di FK se collegati ad altre posizioni giuridiche
    -- Si cancellano solo i record AC collegati alla PG oggetto di cancellazione
    -- in questa fase. Gli altri record saranno cancellati dalla PULISCI_FASCICOLO
    BEGIN
	  DBMS_OUTPUT.put_line('APERTURA CURSORE su PG collegatie ad EVENTO');

      OPEN v_elenco_PG_per_evento_cur FOR
	  	SELECT ID_POSIZIONE_GIURIDICA, ALT_CAU_ID_ALTRA_CAUSA
		FROM POSIZIONE_GIURIDICA
		WHERE ID_EVENTO_RIFERIMENTO = idevento;

	  DBMS_OUTPUT.put_line('INIZIO LOOP');
      LOOP
      	DBMS_OUTPUT.put_line('LOOP...');
        FETCH v_elenco_PG_per_evento_cur
          INTO v_id_posizione_giuridica, v_id_altra_causa;

        EXIT WHEN v_elenco_PG_per_evento_cur%NOTFOUND;

        DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA v_id_posizione_giuridica = '||v_id_posizione_giuridica);
	    DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA v_id_altra_causa         = '||v_id_altra_causa);

        DELETE FROM posizione_giuridica WHERE id_posizione_giuridica = v_id_posizione_giuridica;
        DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA NEW  id: '||v_id_posizione_giuridica||' ------ >>>  OK!');

        DELETE FROM altra_causa WHERE id_altra_causa = v_id_altra_causa;
        DBMS_OUTPUT.put_line('Delete ALTRA_CAUSA NEW  id: '||v_id_altra_causa||' ------ >>>  OK!');
      END LOOP;

      CLOSE v_elenco_PG_per_evento_cur;

	EXCEPTION
	    WHEN OTHERS THEN
	      -- Comunque PG e AC verranno cancellate dalla PULISCI_FASCICOLO
	      DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA OTHERS');
	      DBMS_OUTPUT.put_line(SQLCODE);
	      DBMS_OUTPUT.put_line(SQLERRM);
	END;

    /*
     * VECCHIO CODICE COMMENTATO
    DELETE FROM posizione_giuridica WHERE id_evento_riferimento = idevento;

    DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA ------ >>>  OK!');

    -- 12/10/2018[EC] INIZIO MEV_67 CANCELLO DALLA TABELLA ALTRA CAUSA
    DELETE FROM altra_causa aa
     where aa.fas_sie_id_fascicolo_siep =
           (SELECT e.fas_sie_id_fascicolo_siep
              FROM evento e
             WHERE e.id_evento = idevento);
    -- FINE MEV_67
    */
   -- Ticket#202103180118 - FINE

    -- MEV26 CUMULO aggiunta cancellazione record COMPETENZA caricato in
    --              fase di presa in carico (01/2016)
    DELETE FROM COMPETENZA WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete COMPETENZA ------ >>>  OK!');

    BEGIN
      SELECT id_misura_alternativa
        INTO idmisuraalternativa
        FROM misura_alternativa
       WHERE eve_id_evento = idevento;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        idmisuraalternativa := 0;
    END;

    IF idmisuraalternativa != 0 THEN
      DELETE FROM pena_residua
       WHERE mis_alt_id_misura_alternativa = idmisuraalternativa;

      DBMS_OUTPUT.put_line('Delete PENA_RESIDUA per MA------ >>>  OK!');
    END IF;

    BEGIN
      SELECT ann_id_annotazione_manuale
        INTO v_ann_id_annot
        FROM evento
       WHERE id_evento = idevento;

      DBMS_OUTPUT.put_line('v_ann_id_annot ' || v_ann_id_annot);

      IF v_ann_id_annot IS NOT NULL THEN
        BEGIN
          SELECT eve_id_evento
            INTO v_eve_annot
            FROM annotazione_manuale
           WHERE id_annotazione_manuale = v_ann_id_annot;

          DBMS_OUTPUT.put_line('v_eve_annot ' || v_eve_annot);

          IF v_eve_annot IS NOT NULL THEN
            DBMS_OUTPUT.put_line('v_eve_annot ?????? not null' || v_eve_annot);

            IF v_eve_annot = idevento THEN
              ----quindi ?????? unico evento
              DBMS_OUTPUT.put_line('v_eve_annot ?????? unico evento' ||
                                   v_eve_annot);

              UPDATE evento
                 SET ann_id_annotazione_manuale = NULL
               WHERE id_evento = idevento;

              -- modifiche per integrazione bdmc
              BEGIN
                OPEN annotazione_cur1 FOR
                  SELECT *
                    FROM annotazione_manuale
                   WHERE eve_id_evento = idevento;

                LOOP
                  FETCH annotazione_cur1
                    INTO annotazione_rec;

                  EXIT WHEN annotazione_cur1%NOTFOUND;

                  UPDATE misura_cautelare_bdmc
                     SET flag_stato = 'C'
                   WHERE id_annotazione_manuale =
                         annotazione_rec.id_annotazione_manuale;
                END LOOP;

                CLOSE annotazione_cur1;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  CLOSE annotazione_cur1;
              END;

              -- fine modifiche per integrazione bdmc
              DELETE FROM annotazione_manuale
               WHERE eve_id_evento = idevento;

              DBMS_OUTPUT.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');
            ELSIF v_eve_annot != idevento THEN
              ----l'annotazione ?????? legata ad un altro evento e non si pu?????? cancellare
              DBMS_OUTPUT.put_line('UPDATE EVENTO PER ANNOTAZIONE_MANUALE ------ >>>  OK!');

              UPDATE evento
                 SET ann_id_annotazione_manuale = NULL
               WHERE id_evento = idevento;
            END IF;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      ELSE
        DBMS_OUTPUT.put_line('v_eve_annot ?????? null' || v_eve_annot);

        -- modifiche per integrazione bdmc
        BEGIN
          OPEN annotazione_cur1 FOR
            SELECT *
              FROM annotazione_manuale
             WHERE eve_id_evento = idevento;

          LOOP
            FETCH annotazione_cur1
              INTO annotazione_rec;

            EXIT WHEN annotazione_cur1%NOTFOUND;

            UPDATE misura_cautelare_bdmc
               SET flag_stato = 'C'
             WHERE id_annotazione_manuale =
                   annotazione_rec.id_annotazione_manuale;
          END LOOP;

          CLOSE annotazione_cur1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            CLOSE annotazione_cur1;
        END;

        -- fine modifiche per integrazione bdmc
        DELETE FROM annotazione_manuale WHERE eve_id_evento = idevento;

        DBMS_OUTPUT.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.put_line('non ci sono dati v_ann_id_annot  ?????? null');
        NULL;
    END;

    --==========================================================================
    -- Gestione PENA RESIDUA
    --==========================================================================
    BEGIN
      SELECT pen_id_pena_residua
        INTO v_pen_id_pena_residua
        FROM evento
       WHERE id_evento = idevento;

      DBMS_OUTPUT.put_line('v_pen_id_pena_residua ' ||
                           v_pen_id_pena_residua);
      DBMS_OUTPUT.put_line('IdEvento ' || idevento);

      IF v_pen_id_pena_residua IS NOT NULL THEN
        -- L'evento punta una pena residua, devo verificare se ?????? cancellabile o meno
        -- n.b. la PR ?????? cancellabile solo se a sua volta punta l'evento
        DBMS_OUTPUT.put_line('v_pen_id_pena_residua ?????? not null');

        BEGIN
          SELECT eve_id_evento
            INTO v_eve_pena_residua
            FROM pena_residua
           WHERE id_pena_residua = v_pen_id_pena_residua;

          DBMS_OUTPUT.put_line('v_eve_pena_residua ' || v_eve_pena_residua);

          IF v_eve_pena_residua IS NOT NULL OR v_eve_pena_residua != 0 THEN
            DBMS_OUTPUT.put_line('v_eve_pena_residua ?????? not null');

            IF TO_CHAR(v_eve_pena_residua) = TO_CHAR(idevento) THEN
              -- la PR punta a sua volta l'evento, posso cancellarla
              DBMS_OUTPUT.put_line('v_eve_pena_residua ?????? unico evento' ||
                                   v_eve_annot);

              -- if idpenaresidua!=0 then
              DELETE FROM sospensione
               WHERE pen_res_id_pena_residua IN
                     (SELECT id_pena_residua
                        FROM pena_residua
                       WHERE eve_id_evento = idevento);

              DBMS_OUTPUT.put_line('Delete SOSPENSIONE ------ >>>  OK!');

              -- end if;
              DELETE FROM sanzione_sost_residua
               WHERE pen_res_id_pena_residua IN
                     (SELECT id_pena_residua
                        FROM pena_residua
                       WHERE eve_id_evento = idevento);

              UPDATE evento
                 SET pen_id_pena_residua = NULL
               WHERE id_evento = idevento;

              DELETE FROM pena_residua WHERE eve_id_evento = idevento;

              DBMS_OUTPUT.put_line('Delete PENA_RESIDUA ------ >>>  OK!');
            ELSIF v_eve_pena_residua != idevento THEN
              ----la pena ?????? legata ad un altro evento e non si pu?????? cancellare
              DBMS_OUTPUT.put_line('UPDATE EVENTO PER PENA RESIDUA ------ >>>  OK!');

              UPDATE evento
                 SET pen_id_pena_residua = NULL
               WHERE id_evento = idevento;
            END IF;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      ELSE
        --=================================================================
        -- L'evento NON punta direttamente una PR, vado in cancellazione delle PR
        -- che puntano l'evento e dei record collegati alle PR:
        -- SOSPENSIONE
        -- SANZIONE_SOST_RESIDUA
        --=================================================================
        DBMS_OUTPUT.put_line('v_pen_id_pena_residua ?????? null');

        -- if idpenaresidua!=0 then
        DELETE FROM sospensione
         WHERE pen_res_id_pena_residua IN
               (SELECT id_pena_residua
                  FROM pena_residua
                 WHERE eve_id_evento = idevento);

        DBMS_OUTPUT.put_line('Delete SOSPENSIONE ------ >>>  OK!');

        -- end if;
        DELETE FROM sanzione_sost_residua
         WHERE pen_res_id_pena_residua IN
               (SELECT id_pena_residua
                  FROM pena_residua
                 WHERE eve_id_evento = idevento);

        DELETE FROM pena_residua WHERE eve_id_evento = idevento;

        DBMS_OUTPUT.put_line('Delete PENA_RESIDUA ------ >>>  OK!');
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.put_line('non ci sono dati v_pen_id_pena_residua ?????? null');
        NULL;
    END;

    -- FINE gestione ENA_RESIDUA
    DELETE FROM misura_alternativa WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MISURA_ALTERNATIVA ------ >>>  OK!');

    DELETE FROM fungibilita WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete FUNGIBILITA ------ >>>  OK!');

    DELETE FROM archiviazione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete ARCHIVIAZIONE ------ >>>  OK!');

    BEGIN
      OPEN lic_lib;
      LOOP
        FETCH lic_lib
          INTO idLicenzaLiban;
        EXIT WHEN lic_lib%NOTFOUND;

        DELETE FROM PERIODO_LIBANTICIPATA
         WHERE lic_id_licenza_libanticipata = idLicenzaLiban;
        DBMS_OUTPUT.PUT_LINE('Delete PERIODO_LIBANTICIPATA ------ >>>  OK!');

      END LOOP;

      DELETE FROM LICENZA_LIBANTICIPATA WHERE EVE_ID_EVENTO = idevento;
      DBMS_OUTPUT.PUT_LINE('Delete LICENZA_LIBANTICIPATA ------ >>>  OK!');

      CLOSE lic_lib;
    END;

    DELETE FROM misura_cautelare WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MISURA_CAUTELARE ------ >>>  OK!');

    DELETE FROM misura_sicurezza WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MISURA_SICUREZZA ------ >>>  OK!');

    --DELETE FROM PASSAGGIO_EVENTO WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete PASSAGGIO_EVENTO ------ >>>  OK!');

    --DELETE FROM PENA_ACCESSORIA WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete PENA_ACCESSORIA ------ >>>  OK!');
    DELETE FROM pena_pecuniaria WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete PENA_PECUNIARIA ------ >>>  OK!');

    DELETE FROM prescrizione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete PRESCRIZIONE ------ >>>  OK!');

    DELETE FROM sanzione_amministrativa WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete SANZIONE_AMMINISTRATIVA ------ >>>  OK!');

    --==================================================
    -- GESTIONE DECRETI E ORDINANZE
    --==================================================
    BEGIN
      SELECT id_deposito_ordinanza_pc
        INTO idordinanza
        FROM deposito_ordinanza_pc
       WHERE id_evento_generato = idevento;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        idordinanza := 0;
    END;

    BEGIN
      SELECT id_deposito_decreto
        INTO iddecreto
        FROM deposito_decreto
       WHERE id_evento_generato = idevento;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        iddecreto := 0;
    END;

    IF idordinanza != 0 OR iddecreto != 0 THEN
      DELETE FROM tenore
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete TENORE ------ >>>  OK!');

      DELETE FROM esecuzione_misura_alternativa
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete ESECUZIONE_MISURA_ALTERNATIVA ------ >>>  OK!');

      DELETE FROM impugnazione
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete IMPUGNAZIONE ------ >>>  OK!');

      DELETE FROM motivazione_decreto
       WHERE dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete MOTIVAZIONE_DECRETO ------ >>>  OK!');

      DELETE FROM rinvio_provvedimento
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete RINVIO_PROVVEDIMENTO ------ >>>  OK!');
    END IF;

    DELETE FROM decreto_ordinanza_siep WHERE id_evento_generato = idevento;

    DBMS_OUTPUT.put_line('Delete DECRETO_ORDINANZA_SIEP ------ >>>  OK!');

    DELETE FROM deposito_ordinanza_pc WHERE id_evento_generato = idevento;

    DBMS_OUTPUT.put_line('Delete DEPOSITO_ORDINANZA_PC ------ >>>  OK!');

    DELETE FROM riepilogo_provvedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete RIEPILOGO_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM udienza_procedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete UDIENZA_PROCEDIMENTO ------ >>>  OK!');

    DELETE FROM scadenzario_siep WHERE eve_id_evento = idevento;

    --dbms_output.put_line('Delete SCADENZARIO_SIEP  ------ >>>  OK!');
    DELETE FROM scambio_sanzione WHERE eve_id_evento = idevento;

    --dbms_output.put_line('Delete SCAMBIO_SANZIONE  ------ >>>  OK!');
    DELETE FROM periodo_altra_sanzione WHERE eve_id_evento = idevento;

    --dbms_output.put_line('Delete PERIODO_ALTRA_SANZIONE  ------ >>>  OK!');
    DELETE FROM deposito_decreto WHERE id_evento_generato = idevento;

    DBMS_OUTPUT.put_line('Delete DEPOSITO_DECRETO ------ >>>  OK!');

    -- Cherubini Giugno 2010
    -- Inizio
    DELETE FROM stato_procedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete STATO_PROCEDIMENTO ------ >>>  OK!');
    -- Fine

    --========================================================================
    -- Ticket 202010140112 aggiunta la cancellazione delle richiesta
    -- conversione che punta l'evento
    DELETE FROM richiesta_conversione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete RICHIESTA_CONVERSIONE ------ >>>  OK!');
    --========================================================================

    DELETE FROM evento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete EVENTO ------ >>>  OK!');

    DELETE FROM evento WHERE id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete EVENTO ------ >>>  OK!');
    --COMMIT;
    esitopuliscievento := 'Evviva Abbiamo pulito tutto!!!';
  END pulisci_evento;

  --==============================================================================
  --
  --==============================================================================
  PROCEDURE pulisci_fascicolo(idfascicolo           IN NUMBER,
                              esitopuliscifascicolo IN OUT VARCHAR2) IS

    CURSOR elenco_eventi(idfascicolo IN NUMBER) IS
      SELECT id_evento
        FROM evento
       WHERE fas_sie_id_fascicolo_siep = idfascicolo
       ORDER BY id_evento DESC;

    appo_evento         NUMBER;
    esito_pulisci       VARCHAR2(100);
    ctrl_sius           NUMBER := 0;
    idreato             NUMBER := 0;
    idpenacomplessiva   NUMBER := 0;
    idlicenzaliban      NUMBER := 0;
    idpenaresidua       NUMBER := 0;
    idmisuraalternativa NUMBER := 0;
    idavvocato          NUMBER := 0;

    CURSOR avv_fas_sie IS
      SELECT id_avvocato_fascicolo_siep
        FROM avvocato_fascicolo_siep
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR pen_comp IS
      SELECT id_pena_complessiva
        FROM pena_complessiva
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR lic_lib IS
      SELECT id_licenza_libanticipata
        FROM licenza_libanticipata
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR pen_res IS
      SELECT id_pena_residua
        FROM pena_residua
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR mis_alt IS
      SELECT id_misura_alternativa
        FROM misura_alternativa
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    --MEV 42 Cumulo - Aggiunta cancellazione Istruttorie
    v_idIstruttoria    NUMBER := 0;
    esito_pulisci_istr VARCHAR2(50) := null;
    CURSOR elenco_istruttorie_cur(idfascicolo IN NUMBER) IS
      SELECT ID_ISTRUTTORIA_CUMULO
        FROM ISTRUTTORIA_CUMULO
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo
       ORDER BY ID_ISTRUTTORIA_CUMULO DESC;

    /* MEV_2025-48 */
    v_esito_pulisci_ben      VARCHAR2(1000);
    v_esito_pulisci_cir      VARCHAR2(1000);
    v_esito_pulisci_reati    VARCHAR2(1000);
    v_esito_pulisci_penacomp VARCHAR2(1000);
    v_esito_pulisci_peneacc  VARCHAR2(1000);
    v_esito_pulisci_luogodet VARCHAR2(1000);
    v_esito_pulisci_altra_causa VARCHAR2(1000);
    /* MEV_2025-48 */
  BEGIN
    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('--------------------- INIZIO PULISCI ALTRE BDI ---------------------');
    DBMS_OUTPUT.put_line('*************************************************************************************************');

    OPEN elenco_eventi(idfascicolo);

    LOOP
      FETCH elenco_eventi
        INTO appo_evento;

      EXIT WHEN elenco_eventi%NOTFOUND;

      BEGIN
        SELECT fas_siu_id_fascicolo_sius
          INTO ctrl_sius
          FROM evento
         WHERE id_evento = appo_evento;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          ctrl_sius := 0;
      END;

      DBMS_OUTPUT.put_line('ctrl_sius = ' || ctrl_sius);

      IF ctrl_sius = 0 OR ctrl_sius IS NULL THEN
        DBMS_OUTPUT.put_line('chiamo pulisci evento ');
        pulisci_altre_bdi.pulisci_evento(appo_evento, esito_pulisci);
      END IF;
    END LOOP;

    DBMS_OUTPUT.put_line('appo_evento = ' || appo_evento);

    CLOSE elenco_eventi;

    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('--------------------- INIZIO PULISCI FASCICOLO ---------------------');
    DBMS_OUTPUT.put_line('*************************************************************************************************');

    DELETE FROM annotazione_manuale
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');

    BEGIN
      OPEN avv_fas_sie;

      LOOP
        FETCH avv_fas_sie
          INTO idavvocato;

        EXIT WHEN avv_fas_sie%NOTFOUND;

        DELETE FROM notifica
         WHERE avv_id_avvocato_fascicolo_siep = idavvocato;

        DBMS_OUTPUT.put_line('Delete NOTIFICA ------ >>>  OK!');

        DELETE FROM avvocato_fascicolo_siep
         WHERE fas_sie_id_fascicolo_siep = idfascicolo;

        --AND avv_id_avvocato = IdAvvocato;
        DBMS_OUTPUT.put_line('Delete AVVOCATO_FASCICOLO_SIEP ------ >>>  OK!');
      END LOOP;

      CLOSE avv_fas_sie;
    END;


    /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
    DBMS_OUTPUT.put_line('MEV_2025-48: chiamo procedure PULISCI_BENEFICI con idfascicolo = ' ||idfascicolo);

    pulisci_benefici (idfascicolo, v_esito_pulisci_ben);

    DBMS_OUTPUT.put_line('MEV_2025-48: v_esito_pulisci_ben: ' ||v_esito_pulisci_ben);
    /* MEV_2025-48 - */

    DELETE FROM beneficio WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete BENEFICIO ------ >>>  OK!');

    DELETE FROM archiviazione
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete ARCHIVIAZIONE ------ >>>  OK!');

    DELETE FROM campo_nota WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete CAMPO_NOTA ------ >>>  OK!');

    /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
    DBMS_OUTPUT.put_line('MEV_2025-48: chiamo procedure PULISCI_CIRCOSTANZA con idfascicolo = ' ||idfascicolo);

    pulisci_circostanza (idfascicolo, v_esito_pulisci_cir);

    DBMS_OUTPUT.put_line('MEV_2025-48: v_esito_pulisci_cir: ' ||v_esito_pulisci_cir);
    /* MEV_2025-48 - */


    DELETE FROM circostanza WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete CIRCOSTANZA ------ >>>  OK!');

    /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
    DBMS_OUTPUT.put_line('MEV_2025-48: chiamo procedure PULISCI_REATI con idfascicolo = ' ||idfascicolo);
    pulisci_reati (idFascicolo, v_esito_pulisci_reati);
    DBMS_OUTPUT.put_line('MEV_2025-48: v_esito_pulisci_reati: ' ||v_esito_pulisci_reati);
    /* MEV_2025-48 - */

    DELETE FROM reato WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete REATO ------ >>>  OK!');

    BEGIN
      OPEN pen_comp;

      LOOP
        FETCH pen_comp
          INTO idpenacomplessiva;

        EXIT WHEN pen_comp%NOTFOUND;

        DELETE FROM continuazione
         WHERE pen_com_id_pena_complessiva = idpenacomplessiva;

        DBMS_OUTPUT.put_line('Delete CONTINUAZIONE ------ >>>  OK!');

        DELETE FROM sanzione_sostitutiva
         WHERE pen_com_id_pena_complessiva = idpenacomplessiva;

        DBMS_OUTPUT.put_line('Delete SANZIONE_SOSTITUTIVA ------ >>>  OK!');
      END LOOP;

      /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
      DBMS_OUTPUT.put_line('MEV_2025-48: chiamo procedure PULISCI_PENA_COMPLESSIVA con idfascicolo = ' ||idfascicolo);
      pulisci_pena_complessiva (idFascicolo, v_esito_pulisci_penacomp);
      DBMS_OUTPUT.put_line('MEV_2025-48: v_esito_pulisci_penacomp: ' ||v_esito_pulisci_penacomp);
      /* MEV_2025-48 - */

      DELETE FROM pena_complessiva
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

      DBMS_OUTPUT.put_line('Delete PENA_COMPLESSIVA ------ >>>  OK!');

      CLOSE pen_comp;
    END;

    DELETE FROM pena_pecuniaria
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete PENA_PECUNIARIA ------ >>>  OK!');

    DELETE FROM sanzione_sost_residua
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DELETE FROM pena_presunta
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete PENA_PRESUNTA ------ >>>  OK!');

    DELETE FROM pena_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo
              FROM cumulo
             WHERE fas_sie_id_fascicolo_siep = idfascicolo);

    DBMS_OUTPUT.put_line('Delete PENA_CUMULO ------ >>>  OK!');
    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');
    ---aggiunto il 13/12/2006

    DELETE FROM ulteriore_sanzione_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo
              FROM cumulo
             WHERE fas_sie_id_fascicolo_siep = idfascicolo);

    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');

    DELETE FROM cumulo WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete CUMULO ------ >>>  OK!');

    DELETE FROM fungibilita WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete FUNGIBILITA ------ >>>  OK!');

    --   UMBERTO 29-6-2009 - Commentato ciclo cancellazione LICENZA_LIBANTICIPATA e PERIODO_LIBANTICIPATA
    --                       la cancellazione viene effettuata solo pergli eventi privi di fascicolo_sius e
    --                       pilotati da cancella evento
    --    BEGIN
    --      OPEN lic_lib;
    --      LOOP
    --         FETCH lic_lib  INTO   idLicenzaLiban;
    --         EXIT WHEN lic_lib%NOTFOUND;
    --
    --         DELETE FROM PERIODO_LIBANTICIPATA WHERE lic_id_licenza_libanticipata = idLicenzaLiban;
    --        DBMS_OUTPUT.PUT_LINE('Delete PERIODO_LIBANTICIPATA ------ >>>  OK!');
    --
    --     END LOOP;
    --
    --      DELETE FROM LICENZA_LIBANTICIPATA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --      DBMS_OUTPUT.PUT_LINE('Delete LICENZA_LIBANTICIPATA ------ >>>  OK!');
    --
    --
    --     CLOSE lic_lib;
    --    END;
    --
    --    FINE INTERVENTO UMBERTO 29-6-2009
    DELETE FROM magistrato_competente
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MAGISTRATO_COMPETENTE ------ >>>  OK!');

    BEGIN
      OPEN pen_res;

      LOOP
        FETCH pen_res
          INTO idpenaresidua;

        EXIT WHEN pen_res%NOTFOUND;

        DELETE FROM sospensione
         WHERE pen_res_id_pena_residua = idpenaresidua;

        DBMS_OUTPUT.put_line('Delete SOSPENSIONE------ >>>  OK!');
      END LOOP;

      DELETE FROM pena_residua
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

      DBMS_OUTPUT.put_line('Delete PENA_RESIDUA ------ >>>  OK!');

      CLOSE pen_res;
    END;

    --     BEGIN
    --      OPEN mis_alt;
    --      LOOP
    --          FETCH mis_alt  INTO   idMisuraAlternativa;
    --          EXIT WHEN mis_alt%NOTFOUND;
    --
    --        DELETE FROM PENA_RESIDUA WHERE Mis_alt_id_misura_alternativa = idMisuraAlternativa;
    --     dbms_output.put_line('Delete PENA_RESIDUA per MA------ >>>  OK!');
    --
    --    END LOOP;
    --
    DELETE FROM misura_alternativa
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MISURA_ALTERNATIVA ------ >>>  OK!');

    --
    --    CLOSE mis_alt;
    --
    --     END;
    DELETE FROM reato WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete REATO ------ >>>  OK!');

    DELETE FROM misura_cautelare
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MISURA_CAUTELARE ------ >>>  OK!');

    DELETE FROM misura_sicurezza
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MISURA_SICUREZZA ------ >>>  OK!');

    /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
    DBMS_OUTPUT.put_line('MEV_2025-48: chiamo procedure PULISCI_PENA_ACCESSORIE con idfascicolo = ' ||idfascicolo);
    pulisci_pene_accessorie (idFascicolo, v_esito_pulisci_peneacc);
    DBMS_OUTPUT.put_line('MEV_2025-48: v_esito_pulisci_peneacc: ' ||v_esito_pulisci_peneacc);
    /* MEV_2025-48 - */

    DELETE FROM pena_accessoria
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete PENA_ACCESSORIA ------ >>>  OK!');

    DELETE FROM residenza_fascicolo_siep
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete RESIDENZA_FASCICOLO_SIEP ------ >>>  OK!');

    DELETE FROM sanzione_amministrativa
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete SANZIONE_AMMINISTRATIVA ------ >>>  OK!');

    DELETE FROM scadenzario_siep
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete SCADENZARIO_SIEP ------ >>>  OK!');

    /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
    DBMS_OUTPUT.put_line('MEV_2025-48: chiamo procedure PULISCI_LUOGO_DETENZIONE con idfascicolo = ' ||idfascicolo);
    pulisci_luogo_detenzione (idFascicolo, v_esito_pulisci_luogodet);
    DBMS_OUTPUT.put_line('MEV_2025-48: v_esito_pulisci_luogodet: ' ||v_esito_pulisci_luogodet);
    /* MEV_2025-48 - */

    DELETE FROM luogo_detenzione
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete LUOGO_DETENZIONE ------ >>>  OK!');

    DELETE FROM stato_procedimento
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete STATO_PROCEDIMENTO ------ >>>  OK!');

    -- Ticket#20200915014 invertito ordine di cancellazione tra PG e AC
    -- in quanto PG punta AC se presente ed andava in errore di violazione
    -- referenziale
    DELETE FROM posizione_giuridica
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA ------ >>>  OK!');

    /* MEV_2025-48 - Presa in carico procedimenti da fuori distretto */
    DBMS_OUTPUT.put_line('MEV_2025-48: chiamo procedure PULISCI_ALTRA_CAUSA con idfascicolo = ' ||idfascicolo);
    pulisci_altra_causa (idFascicolo, v_esito_pulisci_altra_causa);
    DBMS_OUTPUT.put_line('MEV_2025-48: v_esito_pulisci_altra_causa: ' ||v_esito_pulisci_altra_causa);
    /* MEV_2025-48 - */

    -- MEV_67 : SPOSTO LA CANCELLAZIONE DALLA TABELLA ALTRA_CAUSA
    -- DOPO LA CANCELLAZIONE DELLA POSIZIONE_GIURIDICA
    DELETE FROM altra_causa WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete ALTRA_CAUSA ------ >>>  OK!');
    -- MEV_67
    -- END Ticket#20200915014

    DELETE FROM riepilogo_provvedimento
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete RIEPILOGO_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM decreto_ordinanza_siep
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete DECRETO_ORDINANZA_SIEP ------ >>>  OK!');

    DBMS_OUTPUT.put_line('Inizio Delete ISTRUTTORIE CUMULO E DATI ANNESSI...!');
    OPEN elenco_istruttorie_cur(idfascicolo);
    LOOP
      FETCH elenco_istruttorie_cur
        INTO v_idIstruttoria;

      EXIT WHEN elenco_istruttorie_cur%NOTFOUND;

      BEGIN
        DBMS_OUTPUT.put_line('v_idIstruttoria = ' || v_idIstruttoria);
        --esito_pulisci_istr
        PULISCI_ALTRE_BDI.PULISCI_ISTRUTTORIA_CUM(v_idIstruttoria,
                                                  esito_pulisci_istr);

        DBMS_OUTPUT.put_line('esito_pulisci_istr = ' || esito_pulisci_istr);
      END;
    END LOOP;

    DBMS_OUTPUT.put_line('Uscita dal LOOP sulle ISTRUTTORIE');

    CLOSE elenco_istruttorie_cur;

    ---   COMMIT;
    esitopuliscifascicolo := '0000';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.put_line('ERRORE NO_DATA_FOUND!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitopuliscifascicolo := '1111';
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      -- esitopuliscifascicolo := '1111';
      esitopuliscifascicolo := SQLCODE||' - '||SQLERRM;
  END;

  --==============================================================================
  --
  --==============================================================================
  PROCEDURE pulisci_istruttoria_cum(p_IdIstrutoria            IN NUMBER,
                                    p_EsitoPulisciIstruttoria IN OUT VARCHAR2) IS
    v_esito_pulisci VARCHAR2(100);

    --v_idIstruttoria  ISTRUTTORIA_CUMULO.ID_ISTRUTTORIA_CUMULO%type:= 0;
    v_idTitolo TITOLO_CUMULATO.ID_TITOLO_CUMULATO%type := 0;

    CURSOR titoli_cur(idIstruttoria IN NUMBER) IS
      SELECT ID_TITOLO_CUMULATO
        FROM TITOLO_CUMULATO
       WHERE ISTR_ID_ISTRUTTORIA_CUMULO = idIstruttoria;

  BEGIN
    DBMS_OUTPUT.put_line('************************************************');
    DBMS_OUTPUT.put_line('-----  INIZIO Cancellazione Istruttoria id = ' ||
                         p_IdIstrutoria);
    DBMS_OUTPUT.put_line('-----  DATA ' ||
                         to_char(sysdate, 'dd/MM/yyyy hh24:mi:ss'));
    DBMS_OUTPUT.put_line('************************************************');

    --========================================================================
    -- Cancellazione delle RICHIESTE in CUMULO
    --========================================================================
    DBMS_OUTPUT.put_line('================================');
    DBMS_OUTPUT.put_line(' INIZIO CANCELLAZIONE RICHIESTE ');
    DBMS_OUTPUT.put_line('================================');

    DBMS_OUTPUT.put_line('DELETE RICHPM_BENEFICIO_CUM...');
    DELETE FROM RICHPM_BENEFICIO_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_BENEFICIO_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_MISSICUR_CUM...');
    DELETE FROM RICHPM_MISSICUR_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_MISSICUR_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_PENACC_CUM...');
    DELETE FROM RICHPM_PENACC_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_PENACC_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_REATO_CUM...');
    DELETE FROM RICHPM_REATO_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_REATO_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_SANZIONE_SOST_CUM...');
    DELETE FROM RICHPM_SANZIONE_SOST_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_SANZIONE_SOST_CUM = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_STATO_ESEC_CUM...');
    DELETE FROM RICHPM_STATO_ESEC_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_STATO_ESEC_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_TITOLO_CUM...');
    DELETE FROM RICHPM_TITOLO_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_TITOLO_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('UPDATE RICHIESTE_PM_IN_CUMULO set FK RICH INVIATE NULL');
    UPDATE RICHIESTE_PM_IN_CUMULO
       SET RIC_ID_RICHIESTE_INVIATE_CUM = null
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE RICHIESTE_PM_IN_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHIESTE_INVIATE_CUM...');
    DELETE FROM RICHIESTE_INVIATE_CUM
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE RICHIESTE_INVIATE_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE PROVVEDIMENTO_GE_SORV_CUM...');
    DELETE FROM PROVVEDIMENTO_GE_SORV_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE PROVVEDIMENTO_GE_SORV_CUM = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHIESTE_PM_IN_CUMULO...');
    DELETE FROM RICHIESTE_PM_IN_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE RICHIESTE_PM_IN_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('==============================');
    DBMS_OUTPUT.put_line(' FINE CANCELLAZIONE RICHIESTE ');
    DBMS_OUTPUT.put_line('==============================');
    --========================================================================
    -- Cancellazione delle RICHIESTE in CUMULO
    --========================================================================

    OPEN titoli_cur(p_IdIstrutoria);
    LOOP
      FETCH titoli_cur
        INTO v_idTitolo;

      EXIT WHEN titoli_cur%NOTFOUND;

      BEGIN
        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE DATI ANALITICI PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');

        DBMS_OUTPUT.put_line('DELETE MISURA_SICUREZZA_CUMULO...');
        DELETE FROM MISURA_SICUREZZA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE MISURA_SICUREZZA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE PENA_ACCESSORIA_CUMULO...');
        DELETE FROM PENA_ACCESSORIA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE PENA_ACCESSORIA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE MISURA_CAUTELARE_CUMULO...');
        DELETE FROM MISURA_CAUTELARE_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE MISURA_CAUTELARE_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE CONTINUAZIONE_CUMULO...');
        DELETE FROM CONTINUAZIONE_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE CONTINUAZIONE_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE REATO_CUMULO...');
        DELETE FROM REATO_CUMULO WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE REATO_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE CIRCOSTANZA_CUMULO...');
        DELETE FROM CIRCOSTANZA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE CIRCOSTANZA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE SANZIONE_SOST_CUM...');
        DELETE FROM SANZIONE_SOST_CUM
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE SANZIONE_SOST_CUM = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE PENA_COMPLESSIVA_CUMULO...');
        DELETE FROM PENA_COMPLESSIVA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE MISURA_CAUTELARE_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO collegate a benefici_cumulo...');
        DELETE FROM TIPOLOGIA_ORARIO
         WHERE BEN_ID_BENEFICIO_CUMULO IN
               (SELECT ID_BENEFICIO_CUMULO
                  FROM BENEFICIO_CUMULO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);

        DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE BENEFICIO_CUMULO...');
        DELETE FROM BENEFICIO_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE BENEFICIO_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('FINE CANCELLAZIONE DATI ANALITICI PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('');
        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE STATO ESECUZIONE PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');

        DBMS_OUTPUT.put_line('DELETE PERIODO_LIB_ANT_CUMULO ...');
        DELETE FROM PERIODO_LIB_ANT_CUMULO
         WHERE LIB_ID_LIB_ANTICIPATA_CUMULO IN
               (SELECT ID_LIB_ANTICIPATA_CUMULO
                  FROM LIB_ANTICIPATA_CUMULO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);
        DBMS_OUTPUT.put_line('DELETE PERIODO_LIB_ANT_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE LIB_ANTICIPATA_CUMULO...');
        DELETE FROM LIB_ANTICIPATA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE LIB_ANTICIPATA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE NOTIFICA_CUMULO...');
        DELETE FROM NOTIFICA_CUMULO
         WHERE STAT_ID_STATO_ESEC_TIT_CUM IN
               (SELECT ID_STATO_ESEC_TITOLO_CUMULATO
                  FROM STATO_ESEC_TITOLO_CUMULATO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);
        DBMS_OUTPUT.put_line('DELETE NOTIFICA_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE COMPUTI_CUMULO...');
        DELETE FROM COMPUTI_CUMULO
         WHERE STAT_ID_STATO_ESEC_TIT_CUM IN
               (SELECT ID_STATO_ESEC_TITOLO_CUMULATO
                  FROM STATO_ESEC_TITOLO_CUMULATO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);
        DBMS_OUTPUT.put_line('DELETE COMPUTI_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE STATO_ESEC_TITOLO_CUMULATO...');
        DELETE FROM STATO_ESEC_TITOLO_CUMULATO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE STATO_ESEC_TITOLO_CUMULATO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('FINE CANCELLAZIONE STATO ESECUZIONE PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');

      END;
    END LOOP;
    CLOSE titoli_cur;

    DBMS_OUTPUT.put_line('Uscita dal LOOP sui titoli');

    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE DATI FINALI ');
    DBMS_OUTPUT.put_line('====================================================');

    DBMS_OUTPUT.put_line('DELETE POSIZIONE_GIURIDICA_CUMULO...');
    DELETE FROM POSIZIONE_GIURIDICA_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE POSIZIONE_GIURIDICA_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE PENA_RIDETERMINATA_CUMULO...');
    DELETE FROM PENA_RIDETERMINATA_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE PENA_RIDETERMINATA_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO collegate a DATI_FINALI_ULTERIORI_SANZIONI...');
    DELETE FROM TIPOLOGIA_ORARIO
     WHERE DAT_FIN_CUM_ULT_SANZIONI IN
           (SELECT ID_DATI_FINALI_ULTERIORI_SANZ
              FROM DATI_FINALI_ULTERIORI_SANZIONI
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_ULTERIORI_SANZIONI...');
    DELETE FROM DATI_FINALI_ULTERIORI_SANZIONI
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_ULTERIORI_SANZIONI = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE COMPUTI_CUMULO collegate a DATI_FINALI...');
    DELETE FROM COMPUTI_CUMULO
     WHERE DAT_ID_DATI_FINALI_CUMULO IN
           (SELECT ID_DATI_FINALI_CUMULO
              FROM DATI_FINALI_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_CUMULO...');
    DELETE FROM DATI_FINALI_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_CUMULO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('FINE CANCELLAZIONE DATI FINALI ');
    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('');
    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE DATI ISTRUTTORIA ');
    DBMS_OUTPUT.put_line('====================================================');

    DBMS_OUTPUT.put_line('DELETE PROCEDIMENTO_CUMULATO collegate a DATI_FINALI...');
    DELETE FROM PROCEDIMENTO_CUMULATO
     WHERE TIT_ID_TITOLO_CUMULATO IN
           (SELECT ID_TITOLO_CUMULATO
              FROM TITOLO_CUMULATO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE PROCEDIMENTO_CUMULATO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE SOGGETTO_CUMULATO collegate a DATI_FINALI...');
    DELETE FROM SOGGETTO_CUMULATO
     WHERE TIT_ID_TITOLO_CUMULATO IN
           (SELECT ID_TITOLO_CUMULATO
              FROM TITOLO_CUMULATO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE SOGGETTO_CUMULATO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE TITOLO_CUMULATO collegate a DATI_FINALI...');
    DELETE FROM TITOLO_CUMULATO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE TITOLO_CUMULATO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE ISTRUTTORIA_CUMULO...');
    DELETE FROM ISTRUTTORIA_CUMULO
     WHERE ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE ISTRUTTORIA_CUMULO = ' || Sql%Rowcount);

    p_EsitoPulisciIstruttoria := '0000';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.put_line('ERRORE NO_DATA_FOUND!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      p_EsitoPulisciIstruttoria := '1111';
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      p_EsitoPulisciIstruttoria := '1111';
  END;




/*
  MEV_2025-48 - Presa in carico procedimenti da fuori distretto
  Se il record BENEFICIO � agganciato da SIGE tramite BENEFICIO_SENTENZA_SIGE 
  prima di essere eliminato va duplicato e sganciato dal fascicolo SIEP
*/
PROCEDURE pulisci_benefici (idfascicolo          IN NUMBER,
                            esitopuliscibenefici IN OUT VARCHAR2) IS
    CURSOR elenco_benefici (idfascicolo IN NUMBER) IS
      SELECT *
        FROM BENEFICIO
       WHERE BENEFICIO.FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo;

    CURSOR cur_ben_sent_sige (idBeneficio IN NUMBER) IS
      SELECT FAS_SIGE_SEN_ID, BEN_ID_BENEFICIO
        FROM BENEFICIO_SENTENZA_SIGE
       WHERE BENEFICIO_SENTENZA_SIGE.BEN_ID_BENEFICIO = idBeneficio;

    v_fas_sige_sen_id   BENEFICIO_SENTENZA_SIGE.FAS_SIGE_SEN_ID%TYPE;
    v_ben_id_beneficio  BENEFICIO_SENTENZA_SIGE.BEN_ID_BENEFICIO%TYPE;
    v_new_id_beneficio  BENEFICIO.ID_BENEFICIO%TYPE;
    v_prg_bdi       VARCHAR2(2);
    v_updated_count NUMBER := 0;
    v_deleted_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  START - pulisci_benefici - MEV_2025-48 - idfascicolo: '||idfascicolo);
    DBMS_OUTPUT.put_line('********************************************************************');

    BEGIN
        DBMS_OUTPUT.put_line('MEV_2025-48: cursore sui benefici.. ');
        FOR recBen IN elenco_benefici (idfascicolo) LOOP
            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: CIRCOSTANZA trovata con id: '||recBen.ID_BENEFICIO);
            DBMS_OUTPUT.put_line('MEV_2025-48:   Apro cursore BENEFICIO_SENTENZA_SIGE.. ');
            v_prg_bdi:='';
            FOR recBenSenSige IN cur_ben_sent_sige (recBen.ID_BENEFICIO) LOOP
                v_fas_sige_sen_id  := recBenSenSige.FAS_SIGE_SEN_ID;
                v_ben_id_beneficio := recBenSenSige.BEN_ID_BENEFICIO;

                DBMS_OUTPUT.put_line('MEV_2025-48:   - il beneficio con id '||v_ben_id_beneficio||' � puntato da SIGE '||v_fas_sige_sen_id);

                DBMS_OUTPUT.put_line('MEV_2025-48:     Duplico il record...');
                v_prg_bdi := SUBSTR(v_fas_sige_sen_id, LENGTH(v_fas_sige_sen_id) - 5, 2);

                -- DBMS_OUTPUT.put_line('MEV_2025-48: v_prg_bdi: '||v_prg_bdi);
                INSERT INTO BENEFICIO (ID_BENEFICIO
                                    , COD_NATURA_BENEFICIO, COD_TIPO_BENEFICIO, COD_TIPO_SOSP_SUBORDINATA
                                    , NUM_ANNI_RECLUSIONE, NUM_MESI_RECLUSIONE, NUM_GIORNI_RECLUSIONE, IMPORTO_MULTA
                                    , NUM_ANNI_ARRESTO, NUM_MESI_ARRESTO, NUM_GIORNI_ARRESTO, IMPORTO_AMMENDA
                                    , COD_DPR, NOTE, INAPPLICABILITA_MIS_SICUREZZA
                                    , COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO
                                    , COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO
                                    , FAS_SIE_ID_FASCICOLO_SIEP
                                    , EVE_ID_EVENTO             -- <<<<<<<<<<<<<<<<
                                    , COD_SOTTOTIPO_BENEFICIO
                                    , NUM_ANNI_SOSPENSIONE, NUM_MESI_PRESTAZIONE, NUM_GIORNI_PRESTAZIONE
                                    , NUM_ORE_SETTIMANALI, FLAG_FREQUENZA_SETTIMANALE
                                    , RIF_ID_PROVVEDIMENTO
                                    , RIF_COD_TIPO_PROVVEDIMENTO, RIF_DATA_PROVVEDIMENTO, RIF_COD_TIPO_AUTO_EMITTENTE
                                    , RIF_COD_LUOGO_EMITTENTE, RIF_NUM_SEZIONE_AUTO_EMITTENTE, RIF_ANNO_PROVVEDIMENTO
                                    , RIF_NUMERO_PROVVEDIMENTO
                                    , NUM_ANNI_ADEMPIMENTO, NUM_MESI_ADEMPIMENTO, NUM_GIORNI_ADEMPIMENTO
                                    , BEN_ID_BENEFICIO
                                    , RIF_DATA_IRREVOCABILITA)
                VALUES (BEN_SEQ.NEXTVAL||v_prg_bdi||to_char(sysdate,'YYYY')
                        , recBen.COD_NATURA_BENEFICIO, recBen.COD_TIPO_BENEFICIO, recBen.COD_TIPO_SOSP_SUBORDINATA
                        , recBen.NUM_ANNI_RECLUSIONE, recBen.NUM_MESI_RECLUSIONE, recBen.NUM_GIORNI_RECLUSIONE, recBen.IMPORTO_MULTA
                        , recBen.NUM_ANNI_ARRESTO, recBen.NUM_MESI_ARRESTO, recBen.NUM_GIORNI_ARRESTO, recBen.IMPORTO_AMMENDA
                        , recBen.COD_DPR, recBen.NOTE, recBen.INAPPLICABILITA_MIS_SICUREZZA
                        , recBen.COD_OPERATORE_INSERIMENTO, recBen.DATA_INSERIMENTO, recBen.COD_UFFICIO_INSERIMENTO
                        , recBen.COD_OPERATORE_AGGIORNAMENTO, recBen.DATA_AGGIORNAMENTO, recBen.COD_UFFICIO_AGGIORNAMENTO
                        , NULL -- recBen.FAS_SIE_ID_FASCICOLO_SIEP -- Sgancio il beneficio dal fascicolo SIEP
                        , NULL -- EVE_ID_EVENTO <<<<<<<<<<<<<<<< DA VERIFICARE
                        , recBen.COD_SOTTOTIPO_BENEFICIO
                        , recBen.NUM_ANNI_SOSPENSIONE, recBen.NUM_MESI_PRESTAZIONE, recBen.NUM_GIORNI_PRESTAZIONE
                        , recBen.NUM_ORE_SETTIMANALI, recBen.FLAG_FREQUENZA_SETTIMANALE
                        , recBen.RIF_ID_PROVVEDIMENTO
                        , recBen.RIF_COD_TIPO_PROVVEDIMENTO, recBen.RIF_DATA_PROVVEDIMENTO, recBen.RIF_COD_TIPO_AUTO_EMITTENTE
                        , recBen.RIF_COD_LUOGO_EMITTENTE, recBen.RIF_NUM_SEZIONE_AUTO_EMITTENTE, recBen.RIF_ANNO_PROVVEDIMENTO
                        , recBen.RIF_NUMERO_PROVVEDIMENTO
                        , recBen.NUM_ANNI_ADEMPIMENTO, recBen.NUM_MESI_ADEMPIMENTO, recBen.NUM_GIORNI_ADEMPIMENTO
                        , recBen.BEN_ID_BENEFICIO  -- non � una FK <<<<<<<<<<<<<<<< DA VERIFICARE
                        , recBen.RIF_DATA_IRREVOCABILITA
                )
                RETURNING ID_BENEFICIO INTO v_new_id_beneficio;

                DBMS_OUTPUT.put_line('MEV_2025-48:     BENEFICIO inserito con id: '||v_new_id_beneficio);

                DBMS_OUTPUT.put_line('MEV_2025-48:     Aggiorno il puntamento SIGE...');
                UPDATE BENEFICIO_SENTENZA_SIGE
                   SET BEN_ID_BENEFICIO = v_new_id_beneficio
                 WHERE FAS_SIGE_SEN_ID = v_fas_sige_sen_id
                   AND BEN_ID_BENEFICIO = v_ben_id_beneficio;
                v_updated_count := SQL%ROWCOUNT;
                DBMS_OUTPUT.put_line('MEV_2025-48:     BENEFICIO_SENTENZA_SIGE aggiornato: '||v_updated_count);
                v_updated_count:=0;
            END LOOP;

            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: Elimino il record BENEFICIO con id:'||v_ben_id_beneficio);
            DELETE FROM beneficio WHERE fas_sie_id_fascicolo_siep = idfascicolo and id_beneficio = v_ben_id_beneficio;
            v_deleted_count := SQL%ROWCOUNT;
            DBMS_OUTPUT.put_line('MEV_2025-48: Record BENEFICIO eliminato: '||v_deleted_count);
            v_deleted_count:=0;

        END LOOP;
    END;
    esitopuliscibenefici := '0000'; -- OK
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  END - pulisci_benefici - MEV_2025-48 - esitopuliscibenefici: '||esitopuliscibenefici);
    DBMS_OUTPUT.put_line('********************************************************************');
EXCEPTION
  WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitopuliscibenefici:='1111';
END pulisci_benefici;

/*
  MEV_2025-48 - Presa in carico procedimenti da fuori distretto
  Se il record CIRCOSTANZA � agganciato da SIGE tramite CIRCOSTANZA_SENTENZA_SIGE 
  prima di essere eliminato va duplicato e sganciato dal fascicolo SIEP
*/
PROCEDURE pulisci_circostanza (idfascicolo             IN NUMBER,
                               esitopuliscicircostanza IN OUT VARCHAR2) IS
    CURSOR elenco_circostanze (idfascicolo IN NUMBER) IS
      SELECT *
        FROM CIRCOSTANZA
       WHERE CIRCOSTANZA.FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo;

    CURSOR cur_circ_sent_sige (idCircostanza IN NUMBER) IS
      SELECT FAS_SIGE_SEN_ID, CIR_ID_CIRCOSTANZA
        FROM CIRCOSTANZA_SENTENZA_SIGE
       WHERE CIR_ID_CIRCOSTANZA = idCircostanza;

    v_fas_sige_sen_id     CIRCOSTANZA_SENTENZA_SIGE.FAS_SIGE_SEN_ID%TYPE;
    v_cir_id_circostanza  CIRCOSTANZA_SENTENZA_SIGE.CIR_ID_CIRCOSTANZA%TYPE;
    v_new_id_circostanza  CIRCOSTANZA.ID_CIRCOSTANZA%TYPE;
    v_prg_bdi       VARCHAR2(2);
    v_updated_count NUMBER := 0;
    v_deleted_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  START - pulisci_circostanza - MEV_2025-48 - idfascicolo: '||idfascicolo);
    DBMS_OUTPUT.put_line('********************************************************************');

    BEGIN
        DBMS_OUTPUT.put_line('MEV_2025-48: cursore sulle circostanze.. ');
        FOR recCirc IN elenco_circostanze (idfascicolo) LOOP
            v_prg_bdi:='';
            DBMS_OUTPUT.put_line('MEV_2025-48: ');
            DBMS_OUTPUT.put_line('MEV_2025-48: CIRCOSTANZA trovata con id: '||recCirc.ID_CIRCOSTANZA);
            DBMS_OUTPUT.put_line('MEV_2025-48:   Apro cursore CIRCOSTANZA_SENTENZA_SIGE.. ');
            FOR recCircSenSige IN cur_circ_sent_sige (recCirc.ID_CIRCOSTANZA) LOOP
                v_fas_sige_sen_id    := recCircSenSige.FAS_SIGE_SEN_ID;
                v_cir_id_circostanza := recCircSenSige.CIR_ID_CIRCOSTANZA;

                DBMS_OUTPUT.put_line('MEV_2025-48:     - la circostanza con id '||v_cir_id_circostanza||' � puntata da SIGE '||v_fas_sige_sen_id);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Duplico il record...');
                v_prg_bdi := SUBSTR(v_fas_sige_sen_id, LENGTH(v_fas_sige_sen_id) - 5, 2);

                -- DBMS_OUTPUT.put_line('MEV_2025-48:     v_prg_bdi: '||v_prg_bdi);
                INSERT INTO CIRCOSTANZA (ID_CIRCOSTANZA
                                        , COD_TIPO_CIRCOSTANZA, COD_FONTE, ANNO_FONTE, NUMERO_FONTE
                                        , COD_SOTTONUMERAZIONE, COMMA, LETTERA, NUMERO, ARTICOLO
                                        , NOTE
                                        , COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO
                                        , COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO
                                        , FAS_SIE_ID_FASCICOLO_SIEP
                                        , FLAG_SENTENZA_APPLICAZ_PENA, FLAG_GIUDIZIO_ABBREVIATO
                                        , COD_BILANCIAMENTO_CIRCOSTANZE, NOTE_BILANCIAMENTO, COMMA_QUALIFICANTE)
                VALUES (CIR_SEQ.NEXTVAL||v_prg_bdi||to_char(sysdate,'YYYY')
                        , recCirc.COD_TIPO_CIRCOSTANZA, recCirc.COD_FONTE, recCirc.ANNO_FONTE, recCirc.NUMERO_FONTE
                        , recCirc.COD_SOTTONUMERAZIONE, recCirc.COMMA, recCirc.LETTERA, recCirc.NUMERO, recCirc.ARTICOLO
                        , recCirc.NOTE
                        , recCirc.COD_OPERATORE_INSERIMENTO, recCirc.DATA_INSERIMENTO, recCirc.COD_UFFICIO_INSERIMENTO
                        , recCirc.COD_OPERATORE_AGGIORNAMENTO, recCirc.DATA_AGGIORNAMENTO, recCirc.COD_UFFICIO_AGGIORNAMENTO
                        , NULL -- recCirc.FAS_SIE_ID_FASCICOLO_SIEP  -- Sgancio la circostanza dal fascicolo SIEP
                        , recCirc.FLAG_SENTENZA_APPLICAZ_PENA, recCirc.FLAG_GIUDIZIO_ABBREVIATO
                        , recCirc.COD_BILANCIAMENTO_CIRCOSTANZE, recCirc.NOTE_BILANCIAMENTO, recCirc.COMMA_QUALIFICANTE
                )
                RETURNING ID_CIRCOSTANZA INTO v_new_id_circostanza;

                DBMS_OUTPUT.put_line('MEV_2025-48:       CIRCOSTANZA inserita con id: '||v_new_id_circostanza);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Aggiorno il puntamento SIGE...');
                UPDATE CIRCOSTANZA_SENTENZA_SIGE
                   SET CIR_ID_CIRCOSTANZA = v_new_id_circostanza
                 WHERE FAS_SIGE_SEN_ID = v_fas_sige_sen_id
                   AND CIR_ID_CIRCOSTANZA = v_cir_id_circostanza;
                v_updated_count := SQL%ROWCOUNT;
                DBMS_OUTPUT.put_line('MEV_2025-48:       CIRCOSTANZA_SENTENZA_SIGE aggiornato: '||v_updated_count);
                v_updated_count:=0;
            END LOOP;

            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: Elimino il record CIRCOSTANZA con id:'||v_cir_id_circostanza);
            DELETE FROM CIRCOSTANZA WHERE fas_sie_id_fascicolo_siep = idfascicolo and ID_CIRCOSTANZA = v_cir_id_circostanza;
            v_deleted_count := SQL%ROWCOUNT;
            DBMS_OUTPUT.put_line('MEV_2025-48: Record CIRCOSTANZA eliminato: '||v_deleted_count);
            v_deleted_count:=0;

        END LOOP;
    END;
    esitopuliscicircostanza := '0000'; -- OK
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  END - pulisci_circostanza - MEV_2025-48 - esitopuliscicircostanza: '||esitopuliscicircostanza);
    DBMS_OUTPUT.put_line('********************************************************************');
EXCEPTION
  WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitopuliscicircostanza:='1111';
END pulisci_circostanza;

/*
  MEV_2025-48 - Presa in carico procedimenti da fuori distretto
  Se il record REATO � agganciato da SIGE tramite REATO_SENTENZA_SIGE  
  prima di essere eliminato va duplicato e sganciato dal fascicolo SIEP

  Potrebbe essere puntato anche da TENORE_SENTENZA_REATO dopo la presa in carico
*/
PROCEDURE pulisci_reati (idFascicolo       IN NUMBER,
                         esitoPulisciReati IN OUT VARCHAR2) IS
    CURSOR elenco_reati (idFascicolo IN NUMBER) IS
      SELECT *
        FROM REATO
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo;

    CURSOR cur_reato_sent_sige (idReato IN NUMBER) IS
      SELECT FAS_SIGE_SEN_ID , REA_ID_REATO
        FROM REATO_SENTENZA_SIGE
       WHERE REATO_SENTENZA_SIGE.REA_ID_REATO = idReato;

    v_fas_sige_sen_id  REATO_SENTENZA_SIGE.FAS_SIGE_SEN_ID%TYPE;
    v_rea_id_reato     REATO_SENTENZA_SIGE.REA_ID_REATO%TYPE;
    v_new_id_reato     REATO.ID_REATO%TYPE;
    v_prg_bdi       VARCHAR2(2);
    v_updated_count NUMBER := 0;
    v_deleted_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  START - pulisci_reati - MEV_2025-48 - idfascicolo: '||idfascicolo);
    DBMS_OUTPUT.put_line('********************************************************************');

    BEGIN
        DBMS_OUTPUT.put_line('MEV_2025-48: cursore sui reati... ');
        FOR recReato IN elenco_reati (idfascicolo) LOOP
            v_prg_bdi:='';
            DBMS_OUTPUT.put_line('MEV_2025-48: ');
            DBMS_OUTPUT.put_line('MEV_2025-48: REATO trovato con id: '||recReato.ID_REATO);
            DBMS_OUTPUT.put_line('MEV_2025-48:   Apro cursore REATO_SENTENZA_SIGE.. ');
            FOR recReatoSenSige IN cur_reato_sent_sige (recReato.ID_REATO) LOOP
                v_fas_sige_sen_id := recReatoSenSige.FAS_SIGE_SEN_ID;
                v_rea_id_reato    := recReatoSenSige.REA_ID_REATO;

                DBMS_OUTPUT.put_line('MEV_2025-48:     - il Reato con id '||v_rea_id_reato||' � puntato da SIGE '||v_fas_sige_sen_id);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Duplico il record...');
                v_prg_bdi := SUBSTR(v_fas_sige_sen_id, LENGTH(v_fas_sige_sen_id) - 5, 2);

                -- DBMS_OUTPUT.put_line('MEV_2025-48:     v_prg_bdi: '||v_prg_bdi);
                INSERT INTO REATO (ID_REATO
                                , COD_TIPO_REATO, DATA_REATO, PROGR_NUMERO_MANUALE, PROGR_REATO, PROGR_CIRCOSTANZA
                                , DATA_INIZIO, ANNO_INIZIO, MESE_INIZIO, GIORNO_INIZIO
                                , DATA_FINE, ANNO_FINE, MESE_FINE, GIORNO_FINE
                                , COD_PERIODO_CONSUMAZIONE, DESC_LUOGO, COD_FONTE, ANNO_FONTE, NUMERO_FONTE
                                , COD_SOTTONUMERAZIONE, COMMA, LETTERA, NUMERO, ARTICOLO, NOTE
                                , COD_TIPO_PENA_DETENTIVA, NUM_ANNI, NUM_MESI, NUM_GIORNI, SANZIONE_PECUNIARIA, FLAG_ERGASTOLO
                                , DATA_INIZIO_ISOLAMENTO_DIURNO, DATA_FINE_ISOLAMENTO_DIURNO
                                , COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO
                                , COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO
                                , FAS_SIE_ID_FASCICOLO_SIEP
                                , COD_TIPO_SANZIONE, GIORNI_ISOLAMENTO_DIURNO, MESI_ISOLAMENTO_DIURNO, ANNI_ISOLAMENTO_DIURNO
                                , ID_CONTINUAZIONE_REATO
                                , TIPO_CONTINUAZIONE_REATO, KEY_REATO_NSC, COMMA_QUALIFICANTE)
                VALUES(REA_SEQ.NEXTVAL||v_prg_bdi||to_char(sysdate,'YYYY')
                    , recReato.COD_TIPO_REATO, recReato.DATA_REATO, recReato.PROGR_NUMERO_MANUALE, recReato.PROGR_REATO, recReato.PROGR_CIRCOSTANZA
                    , recReato.DATA_INIZIO, recReato.ANNO_INIZIO, recReato.MESE_INIZIO, recReato.GIORNO_INIZIO
                    , recReato.DATA_FINE, recReato.ANNO_FINE, recReato.MESE_FINE, recReato.GIORNO_FINE
                    , recReato.COD_PERIODO_CONSUMAZIONE, recReato.DESC_LUOGO, recReato.COD_FONTE, recReato.ANNO_FONTE, recReato.NUMERO_FONTE
                    , recReato.COD_SOTTONUMERAZIONE, recReato.COMMA, recReato.LETTERA, recReato.NUMERO, recReato.ARTICOLO, recReato.NOTE
                    , recReato.COD_TIPO_PENA_DETENTIVA, recReato.NUM_ANNI, recReato.NUM_MESI, recReato.NUM_GIORNI, recReato.SANZIONE_PECUNIARIA, recReato.FLAG_ERGASTOLO
                    , recReato.DATA_INIZIO_ISOLAMENTO_DIURNO, recReato.DATA_FINE_ISOLAMENTO_DIURNO
                    , recReato.COD_OPERATORE_INSERIMENTO, recReato.DATA_INSERIMENTO, recReato.COD_UFFICIO_INSERIMENTO
                    , recReato.COD_OPERATORE_AGGIORNAMENTO, recReato.DATA_AGGIORNAMENTO, recReato.COD_UFFICIO_AGGIORNAMENTO
                    , NULL  -- recReato.FAS_SIE_ID_FASCICOLO_SIEP -- Sgancio il REATO dal fascicolo SIEP
                    , recReato.COD_TIPO_SANZIONE, recReato.GIORNI_ISOLAMENTO_DIURNO, recReato.MESI_ISOLAMENTO_DIURNO, recReato.ANNI_ISOLAMENTO_DIURNO
                    , recReato.ID_CONTINUAZIONE_REATO -- <<<<<<<<<<<<< non � una FK: VERIFICARE
                    , recReato.TIPO_CONTINUAZIONE_REATO, recReato.KEY_REATO_NSC, recReato.COMMA_QUALIFICANTE
                )
                RETURNING ID_REATO INTO v_new_id_reato;

                DBMS_OUTPUT.put_line('MEV_2025-48:       REATO inserito con id: '||v_new_id_reato);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Aggiorno il puntamento REATO_SENTENZA_SIGE...');
                UPDATE REATO_SENTENZA_SIGE
                   SET REA_ID_REATO = v_new_id_reato
                 WHERE FAS_SIGE_SEN_ID = v_fas_sige_sen_id
                   AND REA_ID_REATO = v_rea_id_reato;

                v_updated_count := SQL%ROWCOUNT;
                DBMS_OUTPUT.put_line('MEV_2025-48:       REATO_SENTENZA_SIGE aggiornato: '||v_updated_count);
                v_updated_count:=0;

                DBMS_OUTPUT.put_line('MEV_2025-48:       Aggiorno eventuali puntamenti TENORE_SENTENZA_REATO...');
                UPDATE TENORE_SENTENZA_REATO
                   SET REA_ID_REATO = v_new_id_reato
                 WHERE REA_ID_REATO = v_rea_id_reato;

                v_updated_count := SQL%ROWCOUNT;
                DBMS_OUTPUT.put_line('MEV_2025-48:       TENORE_SENTENZA_REATO aggiornati: '||v_updated_count);
                v_updated_count:=0;
            END LOOP;

            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: Elimino il record REATO con id:'||v_rea_id_reato);
            DELETE FROM REATO WHERE fas_sie_id_fascicolo_siep = idfascicolo and ID_REATO = v_rea_id_reato;
            v_deleted_count := SQL%ROWCOUNT;
            DBMS_OUTPUT.put_line('MEV_2025-48: Record REATO eliminato: '||v_deleted_count);
            v_deleted_count:=0;

        END LOOP;
    END;
    esitoPulisciReati := '0000'; -- OK
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  END - pulisci_reati - MEV_2025-48 - esitoPulisciReati: '||esitoPulisciReati);
    DBMS_OUTPUT.put_line('********************************************************************');
EXCEPTION
  WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitoPulisciReati:='1111';
END pulisci_reati;

/*
  MEV_2025-48 - Presa in carico procedimenti da fuori distretto
  Se il record PENA_COMPLESSIVA � agganciato da SIGE tramite PENA_COMPLESSIVA_SENTENZA_SIGE   
  prima di essere eliminato va duplicato e sganciato dal fascicolo SIEP
*/
PROCEDURE pulisci_pena_complessiva (idFascicolo       IN NUMBER,
                                    esitoPulisciPenaCompl IN OUT VARCHAR2) IS
    CURSOR elenco_pene_compl (idFascicolo IN NUMBER) IS
      SELECT *
        FROM PENA_COMPLESSIVA
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo;

    CURSOR cur_penacomp_sent_sige (idPenaComp IN NUMBER) IS
      SELECT FAS_SIGE_SEN_ID , PNC_ID_PENA_COMPLESSIVA
        FROM PENA_COMPLESSIVA_SENTENZA_SIGE
       WHERE PENA_COMPLESSIVA_SENTENZA_SIGE.PNC_ID_PENA_COMPLESSIVA = idPenaComp;

    v_fas_sige_sen_id  PENA_COMPLESSIVA_SENTENZA_SIGE.FAS_SIGE_SEN_ID%TYPE;
    v_pnc_id_penacomp  PENA_COMPLESSIVA_SENTENZA_SIGE.PNC_ID_PENA_COMPLESSIVA%TYPE;
    v_new_id_penacomp  PENA_COMPLESSIVA.ID_PENA_COMPLESSIVA%TYPE;
    v_prg_bdi       VARCHAR2(2);
    v_updated_count NUMBER := 0;
    v_deleted_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  START - pulisci_pena_complessiva - MEV_2025-48 - idfascicolo: '||idfascicolo);
    DBMS_OUTPUT.put_line('********************************************************************');

    BEGIN
        DBMS_OUTPUT.put_line('MEV_2025-48: cursore su PENA_COMPLESSIVA... ');
        FOR recPenaComp IN elenco_pene_compl (idfascicolo) LOOP
            v_prg_bdi:='';
            DBMS_OUTPUT.put_line('MEV_2025-48: ');
            DBMS_OUTPUT.put_line('MEV_2025-48: PENA_COMPLESSIVA trovata con id: '||recPenaComp.ID_PENA_COMPLESSIVA);
            DBMS_OUTPUT.put_line('MEV_2025-48:   Apro cursore PENA_COMPLESSIVA_SENTENZA_SIGE... ');
            FOR recPncSenSige IN cur_penacomp_sent_sige (recPenaComp.ID_PENA_COMPLESSIVA) LOOP
                v_fas_sige_sen_id := recPncSenSige.FAS_SIGE_SEN_ID;
                v_pnc_id_penacomp := recPncSenSige.PNC_ID_PENA_COMPLESSIVA;

                DBMS_OUTPUT.put_line('MEV_2025-48:     - la Pena Complessiva con id '||v_pnc_id_penacomp||' � puntata da SIGE '||v_fas_sige_sen_id);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Duplico il record...');
                v_prg_bdi := SUBSTR(v_fas_sige_sen_id, LENGTH(v_fas_sige_sen_id) - 5, 2);

                -- DBMS_OUTPUT.put_line('MEV_2025-48:     v_prg_bdi: '||v_prg_bdi);
                INSERT INTO PENA_COMPLESSIVA (ID_PENA_COMPLESSIVA
                                            , COD_TIPO_PENA_DETENTIVA
                                            , NUM_ANNI_RECLUSIONE, NUM_MESI_RECLUSIONE, NUM_GIORNI_RECLUSIONE
                                            , IMPORTO_MULTA
                                            , NUM_ANNI_ARRESTO, NUM_MESI_ARRESTO, NUM_GIORNI_ARRESTO
                                            , IMPORTO_AMMENDA
                                            , DATA_INIZIO, DATA_FINE
                                            , COD_TIPO_RITO
                                            , DATA_INIZIO_ISOLAMENTO_DIURNO, DATA_FINE_ISOLAMENTO_DIURNO
                                            , NUM_ANNI_ISOLAMENTO_DIURNO, NUM_MESI_ISOLAMENTO_DIURNO, NUM_GIORNI_ISOLAMENTO_DIURNO
                                            , FLAG_PENA_IN_CONTINUAZIONE
                                            , NUM_ANNI_CONDONATI, NUM_MESI_CONDONATI, NUM_GIORNI_CONDONATI
                                            , IMPORTO_CONDONATO
                                            , COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO
                                            , COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO
                                            , FAS_SIE_ID_FASCICOLO_SIEP
                                            , DATA_PRESCRIZIONE)
                VALUES (PEN_COM_SEQ.NEXTVAL||v_prg_bdi||to_char(sysdate,'YYYY')
                        , recPenaComp.COD_TIPO_PENA_DETENTIVA
                        , recPenaComp.NUM_ANNI_RECLUSIONE, recPenaComp.NUM_MESI_RECLUSIONE, recPenaComp.NUM_GIORNI_RECLUSIONE
                        , recPenaComp.IMPORTO_MULTA
                        , recPenaComp.NUM_ANNI_ARRESTO, recPenaComp.NUM_MESI_ARRESTO, recPenaComp.NUM_GIORNI_ARRESTO
                        , recPenaComp.IMPORTO_AMMENDA
                        , recPenaComp.DATA_INIZIO, recPenaComp.DATA_FINE
                        , recPenaComp.COD_TIPO_RITO
                        , recPenaComp.DATA_INIZIO_ISOLAMENTO_DIURNO, recPenaComp.DATA_FINE_ISOLAMENTO_DIURNO
                        , recPenaComp.NUM_ANNI_ISOLAMENTO_DIURNO, recPenaComp.NUM_MESI_ISOLAMENTO_DIURNO, recPenaComp.NUM_GIORNI_ISOLAMENTO_DIURNO
                        , recPenaComp.FLAG_PENA_IN_CONTINUAZIONE
                        , recPenaComp.NUM_ANNI_CONDONATI, recPenaComp.NUM_MESI_CONDONATI, recPenaComp.NUM_GIORNI_CONDONATI
                        , recPenaComp.IMPORTO_CONDONATO
                        , recPenaComp.COD_OPERATORE_INSERIMENTO, recPenaComp.DATA_INSERIMENTO, recPenaComp.COD_UFFICIO_INSERIMENTO
                        , recPenaComp.COD_OPERATORE_AGGIORNAMENTO, recPenaComp.DATA_AGGIORNAMENTO, recPenaComp.COD_UFFICIO_AGGIORNAMENTO
                        , NULL  -- recPenaComp.FAS_SIE_ID_FASCICOLO_SIEP -- Sgancio la PENA_COMPLESSIVA dal fascicolo SIEP
                        , recPenaComp.DATA_PRESCRIZIONE
                )
                RETURNING ID_PENA_COMPLESSIVA INTO v_new_id_penacomp;

                DBMS_OUTPUT.put_line('MEV_2025-48:       PENA_COMPLESSIVA inserita con id: '||v_new_id_penacomp);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Aggiorno il puntamento SIGE...');
                UPDATE PENA_COMPLESSIVA_SENTENZA_SIGE
                   SET PNC_ID_PENA_COMPLESSIVA = v_new_id_penacomp
                 WHERE FAS_SIGE_SEN_ID = v_fas_sige_sen_id
                   AND PNC_ID_PENA_COMPLESSIVA = v_pnc_id_penacomp;

                v_updated_count := SQL%ROWCOUNT;
                DBMS_OUTPUT.put_line('MEV_2025-48:       PENA_COMPLESSIVA_SENTENZA_SIGE aggiornato: '||v_updated_count);
                v_updated_count:=0;
            END LOOP;

            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: Elimino il record PENA_COMPLESSIVA con id:'||v_pnc_id_penacomp);
            DELETE FROM PENA_COMPLESSIVA WHERE fas_sie_id_fascicolo_siep = idfascicolo and ID_PENA_COMPLESSIVA = v_pnc_id_penacomp;
            v_deleted_count := SQL%ROWCOUNT;
            DBMS_OUTPUT.put_line('MEV_2025-48: Record PENA_COMPLESSIVA eliminato: '||v_deleted_count);
            v_deleted_count:=0;

        END LOOP;
    END;
    esitoPulisciPenaCompl := '0000'; -- OK
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  END - pulisci_pena_complessiva - MEV_2025-48 - esitoPulisciPenaCompl: '||esitoPulisciPenaCompl);
    DBMS_OUTPUT.put_line('********************************************************************');
EXCEPTION
  WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitoPulisciPenaCompl:='1111';
END pulisci_pena_complessiva;


/*
  MEV_2025-48 - Presa in carico procedimenti da fuori distretto
  Se il record PENA_ACCESSORIA � agganciato da SIGE tramite PENA_ACCESSORIA_SENTENZA_SIGE   
  prima di essere eliminato va duplicato e sganciato dal fascicolo SIEP
*/
PROCEDURE pulisci_pene_accessorie (idFascicolo       IN NUMBER,
                                    esitoPulisciPeneAcc IN OUT VARCHAR2) IS
    CURSOR elenco_pene_acc (idFascicolo IN NUMBER) IS
      SELECT *
        FROM PENA_ACCESSORIA
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo;

    CURSOR cur_penaacc_sent_sige (idPenaAcc IN NUMBER) IS
      SELECT FAS_SIGE_SEN_ID , PNA_ID_PENA_ACCESSORIA
        FROM PENA_ACCESSORIA_SENTENZA_SIGE
       WHERE PNA_ID_PENA_ACCESSORIA = idPenaAcc;

    v_fas_sige_sen_id  PENA_ACCESSORIA_SENTENZA_SIGE.FAS_SIGE_SEN_ID%TYPE;
    v_pna_id_penaacc   PENA_ACCESSORIA_SENTENZA_SIGE.PNA_ID_PENA_ACCESSORIA%TYPE;
    v_new_id_penaacc   PENA_ACCESSORIA.ID_PENA_ACCESSORIA%TYPE;
    v_prg_bdi       VARCHAR2(2);
    v_updated_count NUMBER := 0;
    v_deleted_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  START - pulisci_pene_accessorie - MEV_2025-48 - idfascicolo: '||idfascicolo);
    DBMS_OUTPUT.put_line('********************************************************************');

    BEGIN
        DBMS_OUTPUT.put_line('MEV_2025-48: cursore su PENA_ACCESSORIA... ');
        FOR recPenaAcc IN elenco_pene_acc (idfascicolo) LOOP
            v_prg_bdi:='';
            DBMS_OUTPUT.put_line('MEV_2025-48: ');
            DBMS_OUTPUT.put_line('MEV_2025-48: PENA_ACCESSORIA trovata con id: '||recPenaAcc.ID_PENA_ACCESSORIA);
            DBMS_OUTPUT.put_line('MEV_2025-48:   Apro cursore PENA_ACCESSORIA_SENTENZA_SIGE... ');
            FOR recPnaSenSige IN cur_penaacc_sent_sige (recPenaAcc.ID_PENA_ACCESSORIA) LOOP
                v_fas_sige_sen_id := recPnaSenSige.FAS_SIGE_SEN_ID;
                v_pna_id_penaacc  := recPnaSenSige.PNA_ID_PENA_ACCESSORIA;

                DBMS_OUTPUT.put_line('MEV_2025-48:     - la Pena Accessoria con id '||v_pna_id_penaacc||' � puntata da SIGE '||v_fas_sige_sen_id);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Duplico il record...');
                v_prg_bdi := SUBSTR(v_fas_sige_sen_id, LENGTH(v_fas_sige_sen_id) - 5, 2);

                -- DBMS_OUTPUT.put_line('MEV_2025-48:     v_prg_bdi: '||v_prg_bdi);
                INSERT INTO PENA_ACCESSORIA (ID_PENA_ACCESSORIA
                                    , COD_TIPO_PENA_ACCESSORIA, DURATA, NUM_ANNI, NUM_MESI, NUM_GIORNI
                                    , FLAG_CONDONATA, DATA_DPR, NUM_DPR, FLAG_DICHIARAZIONE_FALSITA
                                    , FLAG_REVOCA_CONDONO, DATA_SENTENZA_REVOCA, ANNO_SENTENZA_REVOCA
                                    , NUMERO_SENTENZA_REVOCA, COD_TIPO_UFFICIO_SENTENZA_REVO, COD_LUOGO_SENTENZA_REVOCA
                                    , ANNO_REGE_PM_REVOCA, NUMERO_REGE_PM_REVOCA, ANNO_REGE_GIP_REVOCA
                                    , NUMERO_REGE_GIP_REVOCA, ANNO_REGE_DIB_REVOCA, NUMERO_REGE_DIB_REVOCA
                                    , ANNO_REGE_CAS_REVOCA, NUMERO_REGE_CAS_REVOCA, ANNO_REGE_CAP_REVOCA
                                    , NUMERO_REGE_CAP_REVOCA, ANNO_REGE_CASAP_REVOCA, NUMERO_REGE_CASAP_REVOCA
                                    , NOTE
                                    , COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO
                                    , COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO
                                    , FAS_SIE_ID_FASCICOLO_SIEP
                                    , DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA
                                    , ANNO_ORDINANZA_GE, NUMERO_ORDINANZA_GE, DATA_ORDINANZA_GE
                                    , ESTREMI_CONDONO
                                    , ID_PENA_ACCESSORIA_ORIGINE
                                    , COD_NUOVO_TIPO_PENA_ACCESSORIA, COD_TIPO_UFFICIO_ORDINANZA_GE, COD_LUOGO_UFFICIO_ORDINANZA_GE
                                    , DATA_ORDINANZA_PA, ANNO_ORDINANZA_PA, NUMERO_ORDINANZA_PA
                                    , COD_TIPO_UFFICIO_ORDINANZA_PA, COD_LUOGO_UFFICIO_ORDINANZA_PA, DESCR_ALTRE_PA
                                    , COD_FONTE_GE, ANNO_FONTE_GE, NUMERO_FONTE_GE, COD_SOTTONUMERAZIONE_GE
                                    , COMMA_GE, LETTERA_GE, NUMERO_GE, ARTICOLO_GE
                                    , BEN_ID_BENEFICIO)
                VALUES(PEN_ACC_SEQ.NEXTVAL||v_prg_bdi||to_char(sysdate,'YYYY')
                        , recPenaAcc.COD_TIPO_PENA_ACCESSORIA, recPenaAcc.DURATA, recPenaAcc.NUM_ANNI, recPenaAcc.NUM_MESI, recPenaAcc.NUM_GIORNI
                        , recPenaAcc.FLAG_CONDONATA, recPenaAcc.DATA_DPR, recPenaAcc.NUM_DPR, recPenaAcc.FLAG_DICHIARAZIONE_FALSITA
                        , recPenaAcc.FLAG_REVOCA_CONDONO, recPenaAcc.DATA_SENTENZA_REVOCA, recPenaAcc.ANNO_SENTENZA_REVOCA
                        , recPenaAcc.NUMERO_SENTENZA_REVOCA, recPenaAcc.COD_TIPO_UFFICIO_SENTENZA_REVO, recPenaAcc.COD_LUOGO_SENTENZA_REVOCA
                        , recPenaAcc.ANNO_REGE_PM_REVOCA, recPenaAcc.NUMERO_REGE_PM_REVOCA, recPenaAcc.ANNO_REGE_GIP_REVOCA
                        , recPenaAcc.NUMERO_REGE_GIP_REVOCA, recPenaAcc.ANNO_REGE_DIB_REVOCA, recPenaAcc.NUMERO_REGE_DIB_REVOCA
                        , recPenaAcc.ANNO_REGE_CAS_REVOCA, recPenaAcc.NUMERO_REGE_CAS_REVOCA, recPenaAcc.ANNO_REGE_CAP_REVOCA
                        , recPenaAcc.NUMERO_REGE_CAP_REVOCA, recPenaAcc.ANNO_REGE_CASAP_REVOCA, recPenaAcc.NUMERO_REGE_CASAP_REVOCA
                        , recPenaAcc.NOTE
                        , recPenaAcc.COD_OPERATORE_INSERIMENTO, recPenaAcc.DATA_INSERIMENTO, recPenaAcc.COD_UFFICIO_INSERIMENTO
                        , recPenaAcc.COD_OPERATORE_AGGIORNAMENTO, recPenaAcc.DATA_AGGIORNAMENTO, recPenaAcc.COD_UFFICIO_AGGIORNAMENTO
                        , NULL  -- FAS_SIE_ID_FASCICOLO_SIEP -- Sgancio la PENA_COMPLESSIVA dal fascicolo SIEP
                        , recPenaAcc.DATA_INIZIO_VALIDITA, recPenaAcc.DATA_FINE_VALIDITA
                        , recPenaAcc.ANNO_ORDINANZA_GE, recPenaAcc.NUMERO_ORDINANZA_GE, recPenaAcc.DATA_ORDINANZA_GE
                        , recPenaAcc.ESTREMI_CONDONO
                        , recPenaAcc.ID_PENA_ACCESSORIA_ORIGINE -- >>>>>>>>>>>>>>> non � una FK
                        , recPenaAcc.COD_NUOVO_TIPO_PENA_ACCESSORIA, recPenaAcc.COD_TIPO_UFFICIO_ORDINANZA_GE, recPenaAcc.COD_LUOGO_UFFICIO_ORDINANZA_GE
                        , recPenaAcc.DATA_ORDINANZA_PA, recPenaAcc.ANNO_ORDINANZA_PA, recPenaAcc.NUMERO_ORDINANZA_PA
                        , recPenaAcc.COD_TIPO_UFFICIO_ORDINANZA_PA, recPenaAcc.COD_LUOGO_UFFICIO_ORDINANZA_PA, recPenaAcc.DESCR_ALTRE_PA
                        , recPenaAcc.COD_FONTE_GE, recPenaAcc.ANNO_FONTE_GE, recPenaAcc.NUMERO_FONTE_GE, recPenaAcc.COD_SOTTONUMERAZIONE_GE
                        , recPenaAcc.COMMA_GE, recPenaAcc.LETTERA_GE, recPenaAcc.NUMERO_GE, recPenaAcc.ARTICOLO_GE
                        , recPenaAcc.BEN_ID_BENEFICIO  -- >>>>>>>>>>>>>>> non � una FK
                )
                RETURNING ID_PENA_ACCESSORIA INTO v_new_id_penaacc;

                DBMS_OUTPUT.put_line('MEV_2025-48:       PENA_ACCESSORIA inserita con id: '||v_new_id_penaacc);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Aggiorno il puntamento SIGE...');
                UPDATE PENA_ACCESSORIA_SENTENZA_SIGE
                   SET PNA_ID_PENA_ACCESSORIA = v_new_id_penaacc
                 WHERE FAS_SIGE_SEN_ID = v_fas_sige_sen_id
                   AND PNA_ID_PENA_ACCESSORIA = v_pna_id_penaacc;

                v_updated_count := SQL%ROWCOUNT;
                DBMS_OUTPUT.put_line('MEV_2025-48:       PENA_ACCESSORIA_SENTENZA_SIGE aggiornato: '||v_updated_count);
                v_updated_count:=0;
            END LOOP;

            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: Elimino il record PENA_COMPLESSIVA con id:'||v_pna_id_penaacc);
            DELETE FROM PENA_ACCESSORIA WHERE fas_sie_id_fascicolo_siep = idfascicolo and ID_PENA_ACCESSORIA = v_pna_id_penaacc;
            v_deleted_count := SQL%ROWCOUNT;
            DBMS_OUTPUT.put_line('MEV_2025-48: Record PENA_ACCESSORIA eliminato: '||v_deleted_count);
            v_deleted_count:=0;

        END LOOP;
    END;
    esitoPulisciPeneAcc := '0000'; -- OK
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  END - pulisci_pene_accessorie - MEV_2025-48 - esitoPulisciPeneAcc: '||esitoPulisciPeneAcc);
    DBMS_OUTPUT.put_line('********************************************************************');
EXCEPTION
  WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitoPulisciPeneAcc:='1111';
END pulisci_pene_accessorie;

/*
  MEV_2025-48 - Presa in carico procedimenti da fuori distretto
  Se il record LUOGO_DETENZIONE � agganciato da SIGE tramite FAS_SIGE_DETENZIONE   
  prima di essere eliminato va duplicato e sganciato dal fascicolo SIEP
*/
PROCEDURE pulisci_luogo_detenzione (idFascicolo       IN NUMBER,
                                    esitoPulisciLuogoDet IN OUT VARCHAR2) IS
    CURSOR elenco_luoghi_det (idFascicolo IN NUMBER) IS
      SELECT *
        FROM LUOGO_DETENZIONE
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo;

    CURSOR cur_fas_sige_det (idLuogoDet IN NUMBER) IS
      SELECT ID_FAS_SIGE_DETENZIONE,  LD_ID_LUOGO_DETENZIONE
        FROM FAS_SIGE_DETENZIONE
       WHERE LD_ID_LUOGO_DETENZIONE = idLuogoDet;

    v_fas_sige_det_id  FAS_SIGE_DETENZIONE.ID_FAS_SIGE_DETENZIONE%TYPE;
    v_ld_id_luogodet   FAS_SIGE_DETENZIONE.LD_ID_LUOGO_DETENZIONE%TYPE;
    v_new_id_luogodet  LUOGO_DETENZIONE.ID_LUOGO_DETENZIONE%TYPE;
    v_prg_bdi       VARCHAR2(2);
    v_updated_count NUMBER := 0;
    v_deleted_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  START - pulisci_luogo_detenzione - MEV_2025-48 - idfascicolo: '||idfascicolo);
    DBMS_OUTPUT.put_line('********************************************************************');

    BEGIN
        DBMS_OUTPUT.put_line('MEV_2025-48: cursore su LUOGO_DETENZIONE... ');
        FOR recLuogoDet IN elenco_luoghi_det (idfascicolo) LOOP
            v_prg_bdi:='';
            DBMS_OUTPUT.put_line('MEV_2025-48: ');
            DBMS_OUTPUT.put_line('MEV_2025-48: LUOGO_DETENZIONE trovato con id: '||recLuogoDet.ID_LUOGO_DETENZIONE);
            DBMS_OUTPUT.put_line('MEV_2025-48:   Apro cursore FAS_SIGE_DETENZIONE... ');
            FOR recFasSigeDet IN cur_fas_sige_det (recLuogoDet.ID_LUOGO_DETENZIONE) LOOP
                v_fas_sige_det_id := recFasSigeDet.ID_FAS_SIGE_DETENZIONE;
                v_ld_id_luogodet  := recFasSigeDet.LD_ID_LUOGO_DETENZIONE;

                DBMS_OUTPUT.put_line('MEV_2025-48:     - il Luogo Detenzine con id '||v_ld_id_luogodet||' � puntato da SIGE '||v_fas_sige_det_id);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Duplico il record...');
                v_prg_bdi := SUBSTR(v_fas_sige_det_id, LENGTH(v_fas_sige_det_id) - 5, 2);

                -- DBMS_OUTPUT.put_line('MEV_2025-48:     v_prg_bdi: '||v_prg_bdi);
                INSERT INTO LUOGO_DETENZIONE (ID_LUOGO_DETENZIONE
                                            , NOTE, DATA_INIZIO_DETENZIONE, DATA_FINE_DETENZIONE
                                            , COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO
                                            , COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO
                                            , FAS_SIE_ID_FASCICOLO_SIEP
                                            , FAS_SIU_ID_FASCICOLO_SIUS
                                            , POS_GIU_ID_POSIZIONE_GIURIDICA
                                            , ALTRO_LUOGO
                                            , IST_DET_ID_ISTITUTO_DETENZIONE
                )
                VALUES(LUO_DET_SEQ.NEXTVAL||v_prg_bdi||to_char(sysdate,'YYYY')
                    , recLuogoDet.NOTE, recLuogoDet.DATA_INIZIO_DETENZIONE, recLuogoDet.DATA_FINE_DETENZIONE
                    , recLuogoDet.COD_OPERATORE_INSERIMENTO, recLuogoDet.DATA_INSERIMENTO, recLuogoDet.COD_UFFICIO_INSERIMENTO
                    , recLuogoDet.COD_OPERATORE_AGGIORNAMENTO, recLuogoDet.DATA_AGGIORNAMENTO, recLuogoDet.COD_UFFICIO_AGGIORNAMENTO
                    , NULL -- FAS_SIE_ID_FASCICOLO_SIEP -- Sgancio la LUOGO_DETENZIONE dal fascicolo SIEP
                    , recLuogoDet.FAS_SIU_ID_FASCICOLO_SIUS         -- ?? non � una FK
                    , recLuogoDet.POS_GIU_ID_POSIZIONE_GIURIDICA    -- ?? non � una FK
                    , recLuogoDet.ALTRO_LUOGO
                    , recLuogoDet.IST_DET_ID_ISTITUTO_DETENZIONE    -- ?? non � una FK
                )
                RETURNING ID_LUOGO_DETENZIONE INTO v_new_id_luogodet;

                DBMS_OUTPUT.put_line('MEV_2025-48:       LUOGO_DETENZIONE inserito con id: '||v_new_id_luogodet);

                DBMS_OUTPUT.put_line('MEV_2025-48:       Aggiorno il puntamento SIGE...');
                UPDATE FAS_SIGE_DETENZIONE
                   SET LD_ID_LUOGO_DETENZIONE = v_new_id_luogodet
                 WHERE ID_FAS_SIGE_DETENZIONE = v_fas_sige_det_id;

                v_updated_count := SQL%ROWCOUNT;
                DBMS_OUTPUT.put_line('MEV_2025-48:       FAS_SIGE_DETENZIONE aggiornato: '||v_updated_count);
                v_updated_count:=0;
            END LOOP;

            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: Elimino il record LUOGO_DETENZIONE con id:'||recLuogoDet.ID_LUOGO_DETENZIONE);
            DELETE FROM LUOGO_DETENZIONE WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo and ID_LUOGO_DETENZIONE = recLuogoDet.ID_LUOGO_DETENZIONE;
            v_deleted_count := SQL%ROWCOUNT;
            DBMS_OUTPUT.put_line('MEV_2025-48: Record LUOGO_DETENZIONE eliminato: '||v_deleted_count);
            v_deleted_count:=0;

        END LOOP;
    END;
    esitoPulisciLuogoDet := '0000'; -- OK
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  END - pulisci_luogo_detenzione - MEV_2025-48 - esitoPulisciLuogoDet: '||esitoPulisciLuogoDet);
    DBMS_OUTPUT.put_line('********************************************************************');
EXCEPTION
  WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitoPulisciLuogoDet:='1111';
END pulisci_luogo_detenzione;


/*
  MEV_2025-48 - Presa in carico procedimenti da fuori distretto
  Se il record ALTRA_CAUSA � agganciato da SIGE tramite FAS_SIGE_DETENZIONE   
  prima di essere eliminato andrebbe duplicato e sganciato dal fascicolo SIEP

  Il problema � che ha FK NOT NULL sul fascicolo SIEP per cui non � duplicabile
  si pu� solo sganciare

  ATTENZIONE sembra che AC non venga acquisito per un problema tra Luogo det e AC
  Si impelelmnta comuqneu il metodo
*/
PROCEDURE pulisci_altra_causa (idFascicolo     IN NUMBER,
                               esitoAltraCausa IN OUT VARCHAR2) IS
    CURSOR elenco_altra_causa (idFascicolo IN NUMBER) IS
      SELECT *
        FROM ALTRA_CAUSA
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo;

    CURSOR cur_fas_sige_det (idAltraCausa IN NUMBER) IS
      SELECT ID_FAS_SIGE_DETENZIONE, LD_ID_LUOGO_DETENZIONE, AC_ID_ALTRA_CAUSA
        FROM FAS_SIGE_DETENZIONE
       WHERE AC_ID_ALTRA_CAUSA = idAltraCausa;

    v_fas_sige_det_id   FAS_SIGE_DETENZIONE.ID_FAS_SIGE_DETENZIONE%TYPE;
    v_ld_id_luogodet    FAS_SIGE_DETENZIONE.LD_ID_LUOGO_DETENZIONE%TYPE;
    v_ac_id_altracausa  FAS_SIGE_DETENZIONE.AC_ID_ALTRA_CAUSA%TYPE;
    v_updated_count NUMBER := 0;
    v_deleted_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  START - pulisci_altra_causa - MEV_2025-48 - idfascicolo: '||idfascicolo);
    DBMS_OUTPUT.put_line('********************************************************************');

    BEGIN
        DBMS_OUTPUT.put_line('MEV_2025-48: cursore su ALTRA_CAUSA... ');
        FOR recAltraCausa IN elenco_altra_causa (idfascicolo) LOOP
            DBMS_OUTPUT.put_line('MEV_2025-48: ');
            DBMS_OUTPUT.put_line('MEV_2025-48: ALTRA_CAUSA trovato con id: '||recAltraCausa.ID_ALTRA_CAUSA);
            DBMS_OUTPUT.put_line('MEV_2025-48:   Apro cursore FAS_SIGE_DETENZIONE... ');
            FOR recFasSigeDet IN cur_fas_sige_det (recAltraCausa.ID_ALTRA_CAUSA) LOOP
                v_fas_sige_det_id   := recFasSigeDet.ID_FAS_SIGE_DETENZIONE;
                v_ld_id_luogodet    := recFasSigeDet.LD_ID_LUOGO_DETENZIONE;
                v_ac_id_altracausa  := recFasSigeDet.AC_ID_ALTRA_CAUSA;

                DBMS_OUTPUT.put_line('MEV_2025-48:     - Altra Causa con id '||v_ac_id_altracausa||' � puntato da SIGE '||v_fas_sige_det_id);
                DBMS_OUTPUT.put_line('MEV_2025-48:       v_ld_id_luogodet: '||v_ld_id_luogodet);
                IF (v_ld_id_luogodet IS NULL) THEN
                    DBMS_OUTPUT.put_line('MEV_2025-48:       LD_ID_LUOGO_DETENZIONE is not null');
                    DBMS_OUTPUT.put_line('MEV_2025-48:       Cancello il record FAS_SIGE_DETENZIONE con id: '||recFasSigeDet.ID_FAS_SIGE_DETENZIONE);
                    DELETE FROM FAS_SIGE_DETENZIONE WHERE ID_FAS_SIGE_DETENZIONE = recFasSigeDet.ID_FAS_SIGE_DETENZIONE;
                    v_deleted_count := SQL%ROWCOUNT;
                    DBMS_OUTPUT.put_line('MEV_2025-48:       FAS_SIGE_DETENZIONE cancellato: '||v_deleted_count);
                    v_deleted_count:=0;
                ELSE
                    DBMS_OUTPUT.put_line('MEV_2025-48:       LD_ID_LUOGO_DETENZIONE not null aggiorno AC_ID_ALTRA_CAUSA a NULL');
                    UPDATE FAS_SIGE_DETENZIONE SET AC_ID_ALTRA_CAUSA = NULL WHERE ID_FAS_SIGE_DETENZIONE = recFasSigeDet.ID_FAS_SIGE_DETENZIONE;
                    v_updated_count := SQL%ROWCOUNT;
                    DBMS_OUTPUT.put_line('MEV_2025-48:       FAS_SIGE_DETENZIONE aggiornato: '||v_updated_count);
                    v_updated_count:=0;
                END IF;
            END LOOP;

            DBMS_OUTPUT.put_line('MEV_2025-48:');
            DBMS_OUTPUT.put_line('MEV_2025-48: Elimino il record ALTRA_CAUSA con id:'||recAltraCausa.ID_ALTRA_CAUSA);
            DELETE FROM ALTRA_CAUSA WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo and ID_ALTRA_CAUSA = recAltraCausa.ID_ALTRA_CAUSA;
            v_deleted_count := SQL%ROWCOUNT;
            DBMS_OUTPUT.put_line('MEV_2025-48: Record ALTRA_CAUSA eliminato: '||v_deleted_count);
            v_deleted_count:=0;

        END LOOP;
    END;
    esitoAltraCausa := '0000'; -- OK
    DBMS_OUTPUT.put_line('********************************************************************');
    DBMS_OUTPUT.put_line('  END - pulisci_altra_causa - MEV_2025-48 - esitoAltraCausa: '||esitoAltraCausa);
    DBMS_OUTPUT.put_line('********************************************************************');
EXCEPTION
  WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitoAltraCausa:='1111';
END pulisci_altra_causa;
END;
/