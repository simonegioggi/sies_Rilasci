--- Inserimento nuovi records CG_REF_CODES per PASSAGGIO DI CLASSE
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('MOTIVO_ARCHIVIAZIONE', '14', NULL, NULL, 'Trasferimento in altra classe procedimenti', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('STATO_PROCEDIMENTO', '0370', NULL, 'Definito', 'Archiviazione per iscrizione procedimento in altra classe', NULL, NULL, NULL, NULL);
insert into cg_ref_codes
values ('MOTIVO_PROVVEDIMENTO', '0736', 'PC', null, 'archiviazione fascicolo con contestuale iscrizione in altra classe di appartenenza', null, null, null, null);

--- Inserimento nuovo dominio in CG_REF_CODES
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('MOTIVO_DETENZIONE', '01', NULL, NULL, 'Condannato per delitti art. 51, commi 3 bis e 3 quater c.p.p.', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('MOTIVO_DETENZIONE', '02', NULL, NULL, 'Detenuto in regime di  41 bis O.P.', NULL, NULL, NULL, NULL);

INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('TIPO_RITO', 'E', NULL, NULL, 'Confisca per equivalente', NULL, NULL, NULL, NULL);

---- Inserimento nuovo esito per contenuto SIUS U142
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_PROVVEDIMENTO', '0287', NULL, NULL, 'Dispone conversione pena  irrogata  dal GdP in  permanenza domiciliare', NULL, NULL, NULL, NULL);
-------
DELETE FROM CG_REF_CODES  WHERE RV_DOMAIN = 'ESITO_TENORE' AND RV_HIGH_VALUE = 'U142';
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3205', 'U142', '0276', 'Dispone conversione in semiliberta'' sostitutiva', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3206', 'U142', '0277', 'Dispone conversione in detenzione domiciliare sostitutiva', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3207', 'U142', '0278', 'Dispone conversione in lavoro di pubblica utilita'' sostitutivo', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3208', 'U142', '0279', 'Dispone conversione pena  irrogata  dal GdP in  lavoro  di pubblica utilita''', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3209', 'U142', '0287', 'Dispone conversione pena  irrogata  dal GdP in permanenza domiciliare', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3210', 'U142', '0158', 'Differisce la conversione', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3211', 'U142', '0159', 'Rateizza pagamento', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3212', 'U142', '0150', 'N.L.P. per irreperibilita'' - atti al PM', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3213', 'U142', '0151', 'N.L.P. per accertata solvibilita''', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3214', 'U142', '0152', 'N.L.P. per intervenuta prescrizione', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3215', 'U142', '0003', 'Dichiara L''Inammissibilita''', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3216', 'U142', '0005', 'Dichiara la Propria Incompetenza', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('ESITO_TENORE', '3239', 'U142', '0004', 'Dichiara N.D.P./N.L.P.', NULL, NULL, NULL, NULL);

--- Inserimento nuovo oggetto per contenuto 'U134'
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES ('MOTIVO_PROVVEDIMENTO', '3138', 'U134', 'art. 68 L. 689/1981', 'Sospensione pena sostituiva per arresto o fermo di condannato (art. 68 L. 689/1981) ', NULL, NULL, NULL, NULL);

insert into CG_REF_CODES t
values ('PESO_ESITO_TENORE', '0287', 'A21', null, 'Dispone conversione pena irrogata dal GdP in permanenza domiciliare', null, null, null, null);

--- Inserimento nuovo dominio 'RICERCA_EMA'
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0001', 'C001', '2019', 'Affidamento Servizio Sociale ex art. 94 DPR 309/90', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0002', 'C001', '2015', 'Affidamento al Servizio Sociale', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0003', 'C001', '2015', 'Affidamento art. 47 quater O.P.', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0004', 'C001', '2016', 'Semilibertà', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0005', 'C001', '2017', 'Detenzione Domiciliare art. 47 ter O.P.', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0010', 'C001', '2017', 'Detenzione Domiciliare art. 47 ter 1 bis', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0012', 'C001', '2017', 'Detenzione Domiciliare Speciale', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0013', 'C001', '2017', 'Detenzione Domiciliare art. 47 quater o.p.', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0025', 'C009', '2704', 'Liberazione Condizionale: Liberta'' Vigilata		', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0195', 'C001', '2017', 'Detenzione domiciliare per ultrasettantenni', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0361', 'C001', '2017', 'Detenzione domiciliare art.  16 nonies D.L. 8/1991', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0362', 'C001', '2017', 'Detenzione domiciliare per recidivi', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0610', 'C001', '2397', 'Esecuzione presso domicilio della pena detentiva ( TdS )', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0680', 'C050', '2015', 'Affidamento in Prova al Servizio Sociale (Art. 47 O.P. -  Art. 678 comma 1-ter c.p.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0681', 'C050', '2019', 'Affidamento in Prova al Servizio Sociale (Art. 94 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0682', 'C050', '2017', 'Detenzione Domiciliare (Art. 47 ter O.P. - Art. 678 comma 1-ter c.p.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0683', 'C050', '2016', 'Semiliberta'' (Art. 50 comma 1 O.P. - Art. 678 comma 1-ter c.p.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0684', 'C050', '0684', 'Sospensione dell''Esecuzione della Pena (Art. 90 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0690', 'C051', '2015', 'Affidamento in Prova al Servizio Sociale (art. 4 D.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0691', 'C051', '2019', 'Affidamento in Prova in casi particolari  (art. 4 D.lgs. 121/2018 -  94 DPR 309/90, art. 678 comma 1 ter cp.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0692', 'C051', '2015', 'Affidamento in prova in prova con detenzione domiciliare (art. 5 d.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0693', 'C051', '2017', 'Detenzione domiciliare (art. 6 d.lgs. 121/2018 , art. 678 comma 1 ter cp.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0694', 'C051', '2016', 'Semiliberta'' (art. 7 d.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '0695', 'C051', '0695', 'Sospensione dell''Esecuzione della Pena (Art. 90 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '2005', 'U002', '2367', 'Ammissione provvisoria a Detenzione Domiciliare', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '2006', 'U002', '2369', 'Ammissione provvisoria ad Affidamento Terapeutico ex art. 94 co. 2 DPR 309/90', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '2007', 'U002', '2016', 'Ammissione provvisoria a Semiliberta''', null, null, null, null);
 
insert into cg_ref_codes (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('RICERCA_EMA', '2008', 'U002', '2366', 'Ammissione provvisoria ad Affidamento in prova al Servizio Sociale - Art. 47 O.P. ', null, null, null, null);