-- ====================================================================
-- Si censisce l'oggetto U125 per fare in modo che in fase di deposito
-- vengo popolata la teballe SCAMBIO_SANZIONE
-- ====================================================
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
VALUES('INSERIMENTO_SS', 'U125', NULL, NULL, 'Applicazione Pene Sostitutive', NULL, NULL, NULL, NULL);


