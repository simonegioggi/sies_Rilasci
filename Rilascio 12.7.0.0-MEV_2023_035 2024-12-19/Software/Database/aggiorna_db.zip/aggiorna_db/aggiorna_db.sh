#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV_2023_35/aggiorna_db.sql