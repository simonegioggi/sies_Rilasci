package siap.bdmc.notifichesies.action;


/**
* <p>Title: ActLoadModificaNotificheSies</p>
* <p>Description: Classe Action per la load modifica di NotificheSies</p>
* <p>Copyright: Copyright (c) 2002</p>
* <p>Company: Bull</p>
* @version 1.0
*/

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import siap.bdmc.BDMCLookupRemote;
import siap.bdmc.notifichesies.controller.INotificheSies;
//import siap.bdmc.notifichesies.controller.INotificheSies;
import siap.bdmc.notifichesies.model.NotificheSiesModel;
//import per le combo
//import f3b.web.html.Option;
//import xxxx.decodifiche.controller.DecodificheManager;
import siap.sico.web.ActionSiap;
import siap.web.ISIAPCostantiWeb;
import f3b.util.F3BException;

public class ActLoadModificaNotificheSies extends ActionSiap implements ICostantiNotificheSies
{
  Logger logger = Logger.getLogger("AppLog");
 /*****************************************************************************
  * Azione di caricamento della pagina di Modifica dei dati. Si occupa anche 
  * di precaricare tutti i dati da visualizzare i tale pagina (es: combo) 
  * 
  * @return Nome della pagina JSP da visualizzare
  * @throws F3BException
  *****************************************************************************/
  public String processRequest() throws F3BException {
    logger.info("Start"); 
    //==========================================
    // Recupera la key del record da modificare 
    //==========================================
    BigDecimal lIdNotificheSies         = getRequestBigDecimalParameter ( CAMPO_ID_NOTIFICHE_SIES) ;
    logger.info("Key record = "); 

    //========================================== 
    // Recupera i dati del record da modificare  
    //========================================== 
    logger.info("Recupero i dati del record da modificare "); 
    INotificheSies lCtrl = BDMCLookupRemote.getNotificheSiesRemote();
    NotificheSiesModel lNotificheSies = lCtrl.ExRicercaNotificheSiesById( lIdNotificheSies );
 
    //===========================================================
    // Restituisce la msg se i dati non sono stati recuperati. 
    //===========================================================
    if (lNotificheSies==null){ 
      logger.error("Record non trovato!!"); 
      setRequestAttribute(ISIAPCostantiWeb.MESSAGE_TEXT, "I dati richiesti non sono stati trovati");
      // Specificare eventualmente la jump page dove verr� ridirezionata la 
      // PG_MESSAGE quando viene premuto OK. Se non viene attualizzato il 
      // parametro GOTO_PAGE, la PG_MESSAGE effettua un history.go(-1) 
      // n.b. il path da specificare nel parametro GOTO_PAGE deve essere completo 
      //      della root_dir es /siap/frame.htm  
    setRequestAttribute(ISIAPCostantiWeb.GOTO_PAGE, ISIAPCostantiWeb.ROOT_DIR); 
      return ISIAPCostantiWeb.PG_MESSAGE;
    }

    //==================================================== 
    // Passa il Model alla componente di visualizzazione  
    //==================================================== 
    logger.debug("Dati Record: "+lNotificheSies); 
    setRequestAttribute("notifichesies", lNotificheSies);

    // Inserire Eventuali ComboBOX precaricando i dati del model
    // Option lOption = new Option( DecodificheManager.getInstance().get???());
    // setRequestAttribute("???", "" + lOption );

    // Imposta Modalit�.
    setRequestAttribute("modalita", "M");

    //==========================================================================
    // Restituisce la pagina di modifica.
    // n.b. � la stessa della pagina di Inserimento ma con modalit� differente 
    //==========================================================================
    logger.debug("return: "+PG_LOAD_INSERISCINOTIFICHESIES); 
    return PG_LOAD_INSERISCINOTIFICHESIES; 
  }
}