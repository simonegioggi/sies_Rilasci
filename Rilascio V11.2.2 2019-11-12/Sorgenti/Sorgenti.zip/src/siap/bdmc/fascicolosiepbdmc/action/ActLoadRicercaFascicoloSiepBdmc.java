package siap.bdmc.fascicolosiepbdmc.action;


/**
* <p>Title: ActLoadRicercaFascicoloSiepBdmc</p>
* <p>Description: Classe Action per la load ricerca di FascicoloSiepBdmc</p>
* <p>Copyright: Copyright (c) 2002</p>
* <p>Company: Bull</p>
* @version 1.0
*/

import org.apache.log4j.Logger;

import siap.sico.decodifiche.controller.DecodificheManager;
import siap.sico.web.ActionSiap;
import f3b.util.F3BException;
import f3b.web.html.Option;
//import f3b.web.html.Option;

public class ActLoadRicercaFascicoloSiepBdmc extends ActionSiap implements ICostantiFascicoloSiepBdmc
{
  Logger logger = Logger.getLogger("AppLog");
 /*****************************************************************************
  * Azione di caricamento della pagina di ricerca. Si occupa di precaricare
  * tutti i dati da visualizzare i tale pagina (es: combo) 
  * 
  * @return Nome della pagina JSP da visualizzare
  * @throws F3BException
  *****************************************************************************/
  public String processRequest() throws F3BException {

    //=============================================================
    // Aggiungere qui eventuali caricamento di combo o altri dati 
    // da passare alla finestra di ricerca, e relative setRequest 
    //=============================================================
    // es: 

	  	Option lOption = new Option( DecodificheManager.getInstance().getTipoAutoritaEmittente(), "-");
	    // Imposta i provvedimenti Rif.
	     setRequestAttribute("autoritaEmi", "" + lOption );

		 String codUfficio =  this.getUfficioUtenteConnesso().getCodUfficio();              //          per il codice ufficio dell'operatore connesso
		 String descrUfficio = this.getUfficioUtenteConnesso().getDescrTipoUfficio();        //       per la descrizione del tipo ufficio dell'utente connesso
		 String descrComune = this.getUfficioUtenteConnesso().getDescrComune();             //      per il comune dell'ufficio connesso
		 String codProv = this.getUfficioUtenteConnesso().getCodProvincia();            //        per la sigla della provincia

		 setRequestAttribute("codUfficio", codUfficio);
		 setRequestAttribute("descrUfficio", descrUfficio);
		 setRequestAttribute("descrComune", descrComune);
		 setRequestAttribute("codProv", codProv);
		
		 setRequestAttribute("descrLuogoEmittente", "");
		 setRequestAttribute("codTipoAutoritaEmittente", "");
	  
    //restituisce la jsp di visualizzazione della pagina di ricerca 
    return PG_LOAD_RICERCAFASCICOLOSIEPBDMC;
  }
}