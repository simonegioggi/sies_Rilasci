package siap.bdmc.sbpren.action;

import java.math.BigDecimal;
import java.util.Vector;

import org.apache.log4j.Logger;

import siap.bdmc.sbperipren.model.SbPeriprenModel;
import siap.bdmc.sbpren.model.ProvvedimentoModelBDMC;
import siap.bdmc.sbviewprocpena.action.ICostantiSbViewProcpena;
import siap.bdmc.sbviewprocpena.model.SbViewProcpenaModel;
import siap.sico.soggetto.controller.ISoggetto;
import siap.sico.soggetto.model.SoggettoModel;
import siap.sico.util.SICOLookupRemote;
import siap.sico.web.ActionSiap;
import siap.web.ISIAPCostantiWeb;
import f3b.log.LogF3B;
import f3b.util.F3BException;

/*********************************************************
 * <p>Title: ActDettaglioProvvedimento</p>
 * <p>Description: Dettaglio Provvedimento proveniente da BDMC</p>
 * <p>Copyright: Copyright (c) 2006</p>
 * <p>Company: Bull Italia S.p.A.</p>
 ********************************************************/
public class ActConfermaImportaDatiBDMC extends ActionSiap implements ICostantiSbPren
{
	// [FT] - 03/08/2016 - MAC_LOG - Dichiaro un'istanza di Logger per SIESLog
	private static Logger siesLogger = Logger.getLogger(LogF3B.SIES_LOG);
  public String processRequest() throws F3BException
  {
    String lReturnPage = "";
    try
    {
      ProvvedimentoModelBDMC lProvvedimento = this.getProvvedimentoBDMCInSession();

      //Testo se � stato selezionata la modalit� si integrazione di uun fascicolo gi� presente
     /* if (!this.isRequestParameterNullObj("importa") && getRequestStringParameter("importa").equals("VECCHIO") &&
        !this.isSessionAttributeNullObj("fascicolo") && getSessionAttribute("fascicolo") != null)
      {
        FascicoloSiepModel lFasc = (FascicoloSiepModel) getSessionAttribute("fascicolo");
        if (lFasc.getFlagValidato().equalsIgnoreCase("S"))
          throw new SIEPException(SIEPException.USER_MESSAGE, "Il Procedimento N." +
          lFasc.getChiaveAnno() + "/" + lFasc.getChiaveProgr() +
          " � stato Validato. Impossibile eseguire l'integrazione.");

        lProvvedimento.setEstendiFascicoloSiep(true);
        lReturnPage = this.ActIntegrazioneDatiBDMC(lProvvedimento);
      }
      else
      {*/
        //Check dell'esistenza di un soggetto omonimo
        if (!getRequestStringParameter(CAMPO_SOGGETTO_OMONIMO).equals("NUOVO"))
        {
          //E' stato scelto un soggetto omonimo presente in SIEP
          //Piuttosto che un nuovo inserimento da BDMC
          BigDecimal lKeySoggettoOmonimo = getRequestBigDecimalParameter(CAMPO_SOGGETTO_OMONIMO);
          lProvvedimento.setIdSoggettoOmonimo(lKeySoggettoOmonimo);
          // Riempio il soggetto Omonimo
          ISoggetto lSogCtrl = SICOLookupRemote.getSoggettoRemote();
          SoggettoModel lSogRetMod = new SoggettoModel();
          lSogRetMod = lSogCtrl.ExRicercaSoggettoByKey(lKeySoggettoOmonimo);

          lProvvedimento.setSoggetto(lSogRetMod);
        }

        //??
        SbViewProcpenaModel lProcPenaMod = new SbViewProcpenaModel();
        if (lProvvedimento.getSbViewProcpena() != null)
        {
        	lProcPenaMod = (SbViewProcpenaModel) lProvvedimento.getSbViewProcpena().get(0);
        	if ( lProcPenaMod.getDataPassGiud() == null)
        		((SbViewProcpenaModel)lProvvedimento.getSbViewProcpena().get(0)).setDataPassGiud(getRequestDateParameter(CAMPO_ANNO_DATA_IRR, CAMPO_MESE_DATA_IRR, CAMPO_GIORNO_DATA_IRR));
        }
        
        lProvvedimento.setDataArrivoAtto(getRequestDateParameter(CAMPO_ANNO_DATA_ARRIVO_ATTO, CAMPO_MESE_DATA_ARRIVO_ATTO, CAMPO_GIORNO_DATA_ARRIVO_ATTO));
        System.out.println("DATA ATTO : "+lProvvedimento.getDataArrivoAtto().toString());
        //Setto i parametri da importare in SIEP
       
        if (!isRequestParameterNullObj(ICostantiSbViewProcpena.CAMPO_NUME_SENT_1GRA) && lProcPenaMod.getNumeSent1gra() == null  )
        {
        	lProcPenaMod.setNumeSent1gra(this.getRequestBigDecimalParameter(ICostantiSbViewProcpena.CAMPO_NUME_SENT_1GRA));
        	
        }       
        if (!isRequestParameterNullObj(ICostantiSbViewProcpena.CAMPO_ANNO_SENT_1GRA) && lProcPenaMod.getAnnoSent1gra() == null  )
        {
        	lProcPenaMod.setAnnoSent1gra(this.getRequestBigDecimalParameter(ICostantiSbViewProcpena.CAMPO_ANNO_SENT_1GRA));
        	
        }
        
        if (lProcPenaMod.getDataSent1gra() == null && lProcPenaMod.getDataSentGippGupp() == null )
        	lProcPenaMod.setDataSent1gra(getRequestDateParameter(ICostantiSbViewProcpena.CAMPO_ANNO_DATA_SENTENZA, ICostantiSbViewProcpena.CAMPO_MESE_DATA_SENTENZA, ICostantiSbViewProcpena.CAMPO_GIORNO_DATA_SENTENZA));
      try { 
        if (!isRequestParameterNullObj(ICostantiSbPren.CAMPO_AUTORITA) && (lProcPenaMod.getCodiUffiDibb() == null || lProcPenaMod.getCodiUffiDibb().length() == 0) )
        {
        	lProcPenaMod.setCodiUffiDibb(getCodUfficioByCodTipoUfficioDescrComune(getRequestStringParameter(ICostantiSbPren.CAMPO_AUTORITA),getRequestStringParameter(ICostantiSbPren.CAMPO_LUOGO_AUTORITA)));
        	lProcPenaMod.setDescriComuUffiDibb(getRequestStringParameter(ICostantiSbPren.CAMPO_LUOGO_AUTORITA));
        	lProcPenaMod.setDescriUffiDibb(getRequestStringParameter(ICostantiSbPren.CAMPO_AUTORITA));
        }
      }
      catch (Exception ex)
      {
    	  this.setRequestAttribute(ISIAPCostantiWeb.MESSAGE_TEXT, "Ufficio inesistente");
          return ISIAPCostantiWeb.PG_MESSAGE;
    	    
      }
        Vector ricaricaSbviewProcPena = new Vector();
        ricaricaSbviewProcPena.add(lProcPenaMod);
        lProvvedimento.setSbViewProcpena(ricaricaSbviewProcPena);
        lProvvedimento = this.setCheckField(lProvvedimento);
      
        //Fatto il check sugli attributi lo riporto in sessione
        this.setSessionAttribute("provvedimentoBDMC", lProvvedimento);
        this.setRequestAttribute("provvedimento", lProvvedimento);
        this.setSessionAttribute("esitoSoggetto","0");
        
        lReturnPage = PG_INSERISCIFASCICOLO;
      //}
    }
    catch (Exception ex)
    {
      // [FT] - 03/08/2016 - MAC_LOG - Utilizzo la variabile di istanza siesLogger al posto di LogF3B.getLogger()
      siesLogger.error("Errore = " + ex);
      ex.printStackTrace();
    }
    return lReturnPage;
  }

  /*********************************************************
   * Metodo che integra il fascicolo Siep con i dati di BDMC
   * @param lProvvedimento
   * @return percorso pagina JSP
   ********************************************************/
 /* private String ActIntegrazioneDatiBDMC(ProvvedimentoModelBDMC lProvvedimento) throws F3BException
  {

    this.setCheckField(lProvvedimento);

    //recupero l'intero fascicoo SIEP dalla sessione

    FascicoloSiepModel lFasc = (FascicoloSiepModel) getSessionAttribute("fascicolo");
    SoggettoModel lSogg = (SoggettoModel) getSessionAttribute("soggetto");
    SentenzaModel lSent = (SentenzaModel) getSessionAttribute("sentenza");

    lProvvedimento.setFascicoloSiep(lFasc);
    lProvvedimento.setSentenza(lSent);
    lProvvedimento.setSoggetto(lSogg);

    //Ricerca la sentenza in BDMC
    //IBDMCSentenza lCtrl = BDMCSiesLookupRemote.getBDMCSentenzaRemote();
    //ProvvedimentoModelBDMC lProv = lCtrl.ExIntegraFascicoloSiep(lProvvedimento);
    //Setto i parametri da importare in SIEP
    this.setCheckField(lProvvedimento);

    //Fatto il check sugli attributi lo riporto in sessione
    this.setSessionAttribute("provvedimentoBDMC", lProvvedimento);
    this.setRequestAttribute("provvedimento", lProvvedimento);

    return this.PG_RIASSUNTO_INTEGRAZIONE;
  }*/

  /*********************************************************
   * Metodo che setta le entit� selezionate da Importare
   * @param lProvvedimento
   ********************************************************/
  private ProvvedimentoModelBDMC setCheckField(ProvvedimentoModelBDMC lProvvedimento) throws F3BException
  {
	  System.out.println("CheckPeriodo - 4");
	  Vector periodiDaImportare = new Vector();
		Vector elencoPeriodi = lProvvedimento.getSbPeriPren();
	  if (!isRequestParameterNullObj(this.CAMPO_CHECK_PERIODI))
	    {
			if (elencoPeriodi != null && elencoPeriodi.size() ==1)  {
				lProvvedimento.setSbPeriPren(null);
				int i=0;
				System.out.println("CheckPeriodo");
				SbPeriprenModel lPeriodo= (SbPeriprenModel)elencoPeriodi.elementAt(i);  
				lPeriodo.setDataDaPeri(getRequestDateParameter(this.CAMPO_ANNO_DALLA_DATA+i, this.CAMPO_MESE_DALLA_DATA+i, this.CAMPO_GIORNO_DALLA_DATA+i));
		    	lPeriodo.setDataAPeri(getRequestDateParameter(this.CAMPO_ANNO_ALLA_DATA+i, this.CAMPO_MESE_ALLA_DATA+i, this.CAMPO_GIORNO_ALLA_DATA+i));
		    	System.out.println("DataDaPeri : "+lPeriodo.getDataDaPeri().toString());
		    	periodiDaImportare.add(lPeriodo);  	 
		    	lProvvedimento.setSbPeriPren(periodiDaImportare);			
			}
			else  {
					String[] idPeriodo=this.getRequestStringParameters(this.CAMPO_CHECK_PERIODI);
					lProvvedimento.setSbPeriPren(null);		
					System.out.println("Contatore selezionati = "+idPeriodo.length);
					for (int i=0;i<idPeriodo.length;i++)  
				    {
						System.out.println("periodo  selezionati = "+Integer.parseInt(idPeriodo[i]));
						SbPeriprenModel lPeriodo= (SbPeriprenModel)elencoPeriodi.elementAt(Integer.parseInt(idPeriodo[i]));  
						lPeriodo.setDataDaPeri(getRequestDateParameter(this.CAMPO_ANNO_DALLA_DATA+Integer.parseInt(idPeriodo[i]), this.CAMPO_MESE_DALLA_DATA+Integer.parseInt(idPeriodo[i]), this.CAMPO_GIORNO_DALLA_DATA+Integer.parseInt(idPeriodo[i])));
				    	lPeriodo.setDataAPeri(getRequestDateParameter(this.CAMPO_ANNO_ALLA_DATA+Integer.parseInt(idPeriodo[i]), this.CAMPO_MESE_ALLA_DATA+Integer.parseInt(idPeriodo[i]), this.CAMPO_GIORNO_ALLA_DATA+Integer.parseInt(idPeriodo[i])));
				    	System.out.println("periodo  selezionati = "+lPeriodo.getProgPeriPres());		
				    	periodiDaImportare.add(lPeriodo);  	  
				    }
					for (int i=0;i<elencoPeriodi.size();i++)  
				    {
						SbPeriprenModel lPeriodo= (SbPeriprenModel)elencoPeriodi.elementAt(i);
						if(lPeriodo.getCodStatPrenPeri().compareTo("3") ==0){
							lPeriodo.setDataDaPeri(lPeriodo.getDataInizPeri());
							lPeriodo.setDataAPeri(lPeriodo.getDataFinePeri());
							System.out.println("periodo  no comp selezionati = "+lPeriodo.getProgPeriPres());		
						    
							periodiDaImportare.add(lPeriodo);
						}
				    }
					lProvvedimento.setSbPeriPren(periodiDaImportare);
			}	   
		}else {
			for (int i=0;i<elencoPeriodi.size();i++)  
		    {
				SbPeriprenModel lPeriodo= (SbPeriprenModel)elencoPeriodi.elementAt(i);
				if(lPeriodo.getCodStatPrenPeri().compareTo("3") ==0){
					lPeriodo.setDataDaPeri(lPeriodo.getDataInizPeri());
					lPeriodo.setDataAPeri(lPeriodo.getDataFinePeri());
					periodiDaImportare.add(lPeriodo);
				}
		    }
			lProvvedimento.setSbPeriPren(periodiDaImportare);
		}
	if (!isRequestParameterNullObj(this.CAMPO_CHECK_SENTENZA))
    {
      if (getRequestStringParameter(this.CAMPO_CHECK_SENTENZA) != null)
        lProvvedimento.setIsSbProcPenaCheck(true);
    }

    if (!isRequestParameterNullObj(this.CAMPO_CHECK_REATO))
    {
      System.out.println("CheckReato");
    	if (this.getRequestStringParameter(CAMPO_CHECK_REATO) != null)
        lProvvedimento.setIsSbViewCapoImpuCheck(true);
        lProvvedimento.setIsSbViewReatCheck(true);
    }

    if (!isRequestParameterNullObj(this.CAMPO_CHECK_CIRCOSTANZA))
    {
    	System.out.println("CheckCircostanza");	
      if (getRequestStringParameter(CAMPO_CHECK_CIRCOSTANZA) != null)
        lProvvedimento.setIsSbCircostanzeCheck(true);
    }
return lProvvedimento;
  }
  /**
   * Restuituisce il ProvvedimentoBDMC in sessione
   * @return il provvedimento BDMC in sessione
   * @throws F3BException - se il Provvedimento non � in sessione
   */
  protected ProvvedimentoModelBDMC getProvvedimentoBDMCInSession() throws F3BException
  {
    ProvvedimentoModelBDMC lProvv = (ProvvedimentoModelBDMC) getSession().getAttribute("provvedimentoBDMC");
    if (lProvv == null)
      throw new F3BException(F3BException.USER_MESSAGE, "Impossibile eseguire l'operazione richiesta. " +
        "Non � stato selezionato nessun Provvedimento BDMC");

    return lProvv;
  }

  /**
   * Verifica che il provvedimento BDMC sia in sessione
   * @throws F3BException - se il Provvedimento non � in sessione
   */
  protected void isProvvedimentoBDMCInSession() throws F3BException
  {
    ProvvedimentoModelBDMC lProvv = (ProvvedimentoModelBDMC) getSession().getAttribute("provvedimentoBDMC");
    if (lProvv == null)
      throw new F3BException(F3BException.USER_MESSAGE, "Impossibile eseguire l'operazione richiesta. " +
        "Non � stato selezionato nessun Provvedimento BDMC");
  }

}