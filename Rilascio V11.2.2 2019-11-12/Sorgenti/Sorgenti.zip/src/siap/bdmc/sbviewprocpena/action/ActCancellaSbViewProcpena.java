package siap.bdmc.sbviewprocpena.action;


/**
* <p>Title: ActCancellaSbViewProcpena</p>
* <p>Description: Classe Action per la cancellazione di SbViewProcpena</p>
* <p>Copyright: Copyright (c) 2002</p>
* <p>Company: Bull</p>
* @version 1.0
*/

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import siap.bdmc.BDMCLookupRemote;
import siap.bdmc.sbviewprocpena.controller.ISbViewProcpena;
import siap.bdmc.sbviewprocpena.model.SbViewProcpenaModel;
import siap.sico.web.ActionSiap;
import siap.web.ISIAPCostantiWeb;
import f3b.util.F3BException;

public class ActCancellaSbViewProcpena extends ActionSiap implements ICostantiSbViewProcpena
{
  Logger logger = Logger.getLogger("AppLog");
 /*****************************************************************************
  * Azione per la cancellazione dei dati. 
  * 
  * @return PG_MESSAGE di avvenuta cancellazione
  * @throws F3BException
  *****************************************************************************/
  public String processRequest() throws F3BException {
    //==========================================
    // Recupera la key del record da Cancellare 
    //==========================================
    BigDecimal lIdPren           = getRequestBigDecimalParameter ( CAMPO_ID_PREN) ;

    //========================================== 
    // Istanzia il model   
    //========================================== 
    SbViewProcpenaModel lSbVMod = new SbViewProcpenaModel();

    lSbVMod.setIdPren           (lIdPren);

    //====================================================== 
    // Recupera il Controller ed effettua la cancellazione 
    //====================================================== 
    ISbViewProcpena lCtrl = BDMCLookupRemote.getSbViewProcpenaRemote();
    lCtrl.ExCancellaSbViewProcpena(lSbVMod);

    //===========================================================
    // Restituisce la pagina di Conferma avvenuta Cancellazione. 
    //===========================================================
    setRequestAttribute(ISIAPCostantiWeb.MESSAGE_TEXT, "Cancellazione effettuata");
    // Specificare eventualmente la jump page dove verr� ridirezionata la 
    // PG_MESSAGE quando viene premuto OK. Se non viene attualizzato il 
    // parametro GOTO_PAGE, la PG_MESSAGE effettua un history.go(-1) 
    // n.b. il path da specificare nel parametro GOTO_PAGE deve essere completo 
    //      della root_dir es /siap/frame.htm  
    setRequestAttribute(ISIAPCostantiWeb.GOTO_PAGE, ISIAPCostantiWeb.ROOT_DIR); 

    return ISIAPCostantiWeb.PG_MESSAGE;

  }
}