package siap.bdmc.sbviewprocpena.action;


/**
* <p>Title: ActLoadCancellaSbViewProcpena</p>
* <p>Description: Classe Action per la load cancella di SbViewProcpena</p>
* <p>Copyright: Copyright (c) 2002</p>
* <p>Company: Bull</p>
* @version 1.0
*/

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import siap.bdmc.BDMCLookupRemote;
import siap.bdmc.sbviewprocpena.controller.ISbViewProcpena;
import siap.bdmc.sbviewprocpena.model.SbViewProcpenaModel;
import siap.sico.web.ActionSiap;
import siap.web.ISIAPCostantiWeb;
import f3b.util.F3BException;

public class ActLoadCancellaSbViewProcpena extends ActionSiap implements ICostantiSbViewProcpena
{
  Logger logger = Logger.getLogger("AppLog");
 /*****************************************************************************
  * Azione di caricamento della pagina di Cancellazione dei dati. 
  * Viene caricata la stessa pagina di Dettaglio con il tasto cancella 
  * 
  * @return Nome della pagina JSP da visualizzare
  * @throws F3BException
  *****************************************************************************/
  public String processRequest() throws F3BException {
    //==========================================
    // Recupera la key del record da Visualizzare 
    //==========================================
    BigDecimal lIdPren           = getRequestBigDecimalParameter ( CAMPO_ID_PREN) ;

    //========================================== 
    // Recupera i dati del record da Cancellare  
    //========================================== 
    ISbViewProcpena lCtrl = BDMCLookupRemote.getSbViewProcpenaRemote();
    SbViewProcpenaModel lSbVMod = lCtrl.ExRicercaSbViewProcpenaById( lIdPren);

    //===========================================================
    // Restituisce la msg se i dati non sono stati recuperati. 
    //===========================================================
    if (lSbVMod==null){ 
      setRequestAttribute(ISIAPCostantiWeb.MESSAGE_TEXT, "I dati richiesti non sono stati trovati");
      // Specificare eventualmente la jump page dove verr� ridirezionata la 
      // PG_MESSAGE quando viene premuto OK. Se non viene attualizzato il 
      // parametro GOTO_PAGE, la PG_MESSAGE effettua un history.go(-1) 
      // n.b. il path da specificare nel parametro GOTO_PAGE deve essere completo 
      //      della root_dir es /siap/frame.htm  
    setRequestAttribute(ISIAPCostantiWeb.GOTO_PAGE, ISIAPCostantiWeb.ROOT_DIR); 
      return ISIAPCostantiWeb.PG_MESSAGE;
    }

    //==================================================== 
    // Passa il Model alla componente di visualizzazione  
    //==================================================== 
    setRequestAttribute("sbviewprocpena", lSbVMod);

    //=========================================================
    // Restituisce la pagina di Visualizzazione del Dettaglio.
    //=========================================================
    // Imposta Modalit�.
    setRequestAttribute("modalita", "C");
     
    return PG_LOAD_CANCELLASBVIEWPROCPENA;
  }
}