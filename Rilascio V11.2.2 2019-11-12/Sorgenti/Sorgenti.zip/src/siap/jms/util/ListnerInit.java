package siap.jms.util;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import siap.jms.SIAPReceiver;
import f3b.log.LogF3B;

public class ListnerInit extends HttpServlet {
	// [FT] - 03/08/2016 - MAC_LOG - Dichiaro un'istanza di Logger per SIESLog
	private static Logger siesLogger = Logger.getLogger(LogF3B.SIES_LOG);
  public void init(){
    // [FT] - 03/08/2016 - MAC_LOG - Utilizzo la variabile di istanza siesLogger al posto di LogF3B.getLogger()
    siesLogger.info("[JMS] : inizio");

    try {
      SIAPReceiver.getInstance();
      // [FT] - 03/08/2016 - MAC_LOG - Utilizzo la variabile di istanza siesLogger al posto di LogF3B.getLogger()
      siesLogger.info("[JMS] : Listners initiated.");
    }catch (Exception ex){
      
      // [FT] - 03/08/2016 - MAC_LOG - Utilizzo la variabile di istanza siesLogger al posto di LogF3B.getLogger()
      siesLogger.error("[JMS] : Errore su Connessione al JMS : ", ex);
    }

    /*
    Timer lTimer = new Timer();
    JMSTask lJMSTask = new JMSTask();
    lTimer.schedule(lJMSTask, 60000, 60000);
    */

    
    // [FT] - 03/08/2016 - MAC_LOG - Utilizzo la variabile di istanza siesLogger al posto di LogF3B.getLogger()
    siesLogger.info("[JMS] : fine");
    
    /*
    try
    {
			Thread.sleep(100000);

      System.out.println(" >>> Init dei Listner JMS <<<");

      SIAPReceiver.getInstance();

    }
    catch (Exception ex)
      {
        System.out.println("Exception in init Listner: " + ex);
      }
      */

  }

  public void doGet(HttpServletRequest req, HttpServletResponse res){
  }

  public void service(HttpServletRequest req, HttpServletResponse res){
  }
}