package siap.jms;

import java.io.IOException;
import java.io.InputStreamReader;

import siap.jms.messaggio.model.MessaggioModel;
import f3b.util.xml.TreeModel;

/**
 * <p>Title: MainTestReceive </p>
 * <p>Description: Classe di Test per la ricezione Batch dei messaggi </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
public class MainTestReceive
{
  public MainTestReceive()
  {}

	/**
	 * Main method.
	 * @param args     the topic used by the example
	 */
  public static void main(String[] args)
    {
        InputStreamReader       inputStreamReader = null;
        char                    answer = '\0';

      try{

           TreeModel aTree = new TreeModel();

           MessaggioModel lMessage = new MessaggioModel();
           lMessage.setTreeModel(aTree);

           SIAPReceiver.getInstance();

           inputStreamReader = new InputStreamReader(System.in);

           while (! ( (answer == 'q') || (answer == 'Q')))
            {
              try
              {
                answer = (char) inputStreamReader.read();
              }
              catch (IOException e)
              {
                System.out.println("I/O exception: "  + e.toString());
              }
            }

           System.out.println(">>>>>>>> MESSAGGIO RICEVUTO <<<<<<<<<");

          //System.exit(1);
          }
          catch (Exception e)
          {
            System.out.println("Exception occurred: " +   e.toString());
          }

        }
}










