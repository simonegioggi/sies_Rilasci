//
// Questo file � stato generato dall'architettura JavaTM per XML Binding (JAXB) Reference Implementation, v2.2.8-b130911.1802 
// Vedere <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Qualsiasi modifica a questo file andr� persa durante la ricompilazione dello schema di origine. 
// Generato il: 2016.09.27 alle 02:09:58 PM CEST 
//


package it.eng.giustizia.avvocatura.ws.type.ricercaSoggettiConProcedimenti;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java per AUTORITA_ESTERNA_TYPE complex type.
 * 
 * <p>Il seguente frammento di schema specifica il contenuto previsto contenuto in questa classe.
 * 
 * <pre>
 * &lt;complexType name="AUTORITA_ESTERNA_TYPE">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="mDescrTipoAutorita" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="mDescrSede" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AUTORITA_ESTERNA_TYPE", propOrder = {
    "mDescrTipoAutorita",
    "mDescrSede"
})
public class AUTORITAESTERNATYPE {

    @XmlElement(required = true)
    protected String mDescrTipoAutorita;
    @XmlElement(required = true)
    protected String mDescrSede;

    /**
     * Recupera il valore della propriet� mDescrTipoAutorita.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDescrTipoAutorita() {
        return mDescrTipoAutorita;
    }

    /**
     * Imposta il valore della propriet� mDescrTipoAutorita.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDescrTipoAutorita(String value) {
        this.mDescrTipoAutorita = value;
    }

    /**
     * Recupera il valore della propriet� mDescrSede.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDescrSede() {
        return mDescrSede;
    }

    /**
     * Imposta il valore della propriet� mDescrSede.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDescrSede(String value) {
        this.mDescrSede = value;
    }

}
