//
// Questo file � stato generato dall'architettura JavaTM per XML Binding (JAXB) Reference Implementation, v2.2.8-b130911.1802 
// Vedere <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Qualsiasi modifica a questo file andr� persa durante la ricompilazione dello schema di origine. 
// Generato il: 2016.08.24 alle 10:47:00 AM CEST 
//


package it.eng.giustizia.avvocatura.ws.type.dettaglioSentenza;

import java.math.BigInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java per anonymous complex type.
 * 
 * <p>Il seguente frammento di schema specifica il contenuto previsto contenuto in questa classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="annoProcedimentoSIUS" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="numeroProcedimentoSIUS" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="oggettoProcedimentoSIUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="annoFascicoloSIEP" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="numeroFascicoloSIEP" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="ufficioFascicoloSIEP" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dataFascicoloSIEP" type="{http://it/eng/giustizia/avvocatura/ws/type/dettaglioSentenza}DATA_TYPE"/>
 *         &lt;element name="nomeSoggetto" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cognomeSoggetto" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dataNascita" type="{http://it/eng/giustizia/avvocatura/ws/type/dettaglioSentenza}DATA_TYPE"/>
 *         &lt;element name="luogoNascita" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codiceProvincia" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dataUdienza" type="{http://it/eng/giustizia/avvocatura/ws/type/dettaglioSentenza}DATA_TYPE"/>
 *         &lt;element name="nomeMagistratoRelatore" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="cognomeMagistratoRelatore" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="etaPresuntaAnni" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="etaPresuntaMesi" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="sesso" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "annoProcedimentoSIUS",
    "numeroProcedimentoSIUS",
    "oggettoProcedimentoSIUS",
    "annoFascicoloSIEP",
    "numeroFascicoloSIEP",
    "ufficioFascicoloSIEP",
    "dataFascicoloSIEP",
    "nomeSoggetto",
    "cognomeSoggetto",
    "dataNascita",
    "luogoNascita",
    "codiceProvincia",
    "dataUdienza",
    "nomeMagistratoRelatore",
    "cognomeMagistratoRelatore",
    "etaPresuntaAnni",
    "etaPresuntaMesi",
    "sesso"
})
@XmlRootElement(name = "DATI_RIEPILOGO_PROCEDIMENTO")
public class DATIRIEPILOGOPROCEDIMENTO {

    @XmlElement(required = true)
    protected BigInteger annoProcedimentoSIUS;
    @XmlElement(required = true)
    protected BigInteger numeroProcedimentoSIUS;
    @XmlElement(required = true)
    protected String oggettoProcedimentoSIUS;
    @XmlElement(required = true)
    protected BigInteger annoFascicoloSIEP;
    @XmlElement(required = true)
    protected BigInteger numeroFascicoloSIEP;
    @XmlElement(required = true)
    protected String ufficioFascicoloSIEP;
    @XmlElement(required = true)
    protected DATATYPE dataFascicoloSIEP;
    @XmlElement(required = true)
    protected String nomeSoggetto;
    @XmlElement(required = true)
    protected String cognomeSoggetto;
    @XmlElement(required = true)
    protected DATATYPE dataNascita;
    @XmlElement(required = true)
    protected String luogoNascita;
    @XmlElement(required = true)
    protected String codiceProvincia;
    @XmlElement(required = true)
    protected DATATYPE dataUdienza;
    @XmlElement(required = true)
    protected String nomeMagistratoRelatore;
    @XmlElement(required = true)
    protected String cognomeMagistratoRelatore;
    @XmlElement(required = true, nillable = true)
    protected BigInteger etaPresuntaAnni;
    @XmlElement(required = true, nillable = true)
    protected BigInteger etaPresuntaMesi;
    @XmlElement(required = true)
    protected String sesso;

    /**
     * Recupera il valore della propriet� annoProcedimentoSIUS.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAnnoProcedimentoSIUS() {
        return annoProcedimentoSIUS;
    }

    /**
     * Imposta il valore della propriet� annoProcedimentoSIUS.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAnnoProcedimentoSIUS(BigInteger value) {
        this.annoProcedimentoSIUS = value;
    }

    /**
     * Recupera il valore della propriet� numeroProcedimentoSIUS.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumeroProcedimentoSIUS() {
        return numeroProcedimentoSIUS;
    }

    /**
     * Imposta il valore della propriet� numeroProcedimentoSIUS.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumeroProcedimentoSIUS(BigInteger value) {
        this.numeroProcedimentoSIUS = value;
    }

    /**
     * Recupera il valore della propriet� oggettoProcedimentoSIUS.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOggettoProcedimentoSIUS() {
        return oggettoProcedimentoSIUS;
    }

    /**
     * Imposta il valore della propriet� oggettoProcedimentoSIUS.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOggettoProcedimentoSIUS(String value) {
        this.oggettoProcedimentoSIUS = value;
    }

    /**
     * Recupera il valore della propriet� annoFascicoloSIEP.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAnnoFascicoloSIEP() {
        return annoFascicoloSIEP;
    }

    /**
     * Imposta il valore della propriet� annoFascicoloSIEP.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAnnoFascicoloSIEP(BigInteger value) {
        this.annoFascicoloSIEP = value;
    }

    /**
     * Recupera il valore della propriet� numeroFascicoloSIEP.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumeroFascicoloSIEP() {
        return numeroFascicoloSIEP;
    }

    /**
     * Imposta il valore della propriet� numeroFascicoloSIEP.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumeroFascicoloSIEP(BigInteger value) {
        this.numeroFascicoloSIEP = value;
    }

    /**
     * Recupera il valore della propriet� ufficioFascicoloSIEP.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUfficioFascicoloSIEP() {
        return ufficioFascicoloSIEP;
    }

    /**
     * Imposta il valore della propriet� ufficioFascicoloSIEP.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUfficioFascicoloSIEP(String value) {
        this.ufficioFascicoloSIEP = value;
    }

    /**
     * Recupera il valore della propriet� dataFascicoloSIEP.
     * 
     * @return
     *     possible object is
     *     {@link DATATYPE }
     *     
     */
    public DATATYPE getDataFascicoloSIEP() {
        return dataFascicoloSIEP;
    }

    /**
     * Imposta il valore della propriet� dataFascicoloSIEP.
     * 
     * @param value
     *     allowed object is
     *     {@link DATATYPE }
     *     
     */
    public void setDataFascicoloSIEP(DATATYPE value) {
        this.dataFascicoloSIEP = value;
    }

    /**
     * Recupera il valore della propriet� nomeSoggetto.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeSoggetto() {
        return nomeSoggetto;
    }

    /**
     * Imposta il valore della propriet� nomeSoggetto.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeSoggetto(String value) {
        this.nomeSoggetto = value;
    }

    /**
     * Recupera il valore della propriet� cognomeSoggetto.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCognomeSoggetto() {
        return cognomeSoggetto;
    }

    /**
     * Imposta il valore della propriet� cognomeSoggetto.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCognomeSoggetto(String value) {
        this.cognomeSoggetto = value;
    }

    /**
     * Recupera il valore della propriet� dataNascita.
     * 
     * @return
     *     possible object is
     *     {@link DATATYPE }
     *     
     */
    public DATATYPE getDataNascita() {
        return dataNascita;
    }

    /**
     * Imposta il valore della propriet� dataNascita.
     * 
     * @param value
     *     allowed object is
     *     {@link DATATYPE }
     *     
     */
    public void setDataNascita(DATATYPE value) {
        this.dataNascita = value;
    }

    /**
     * Recupera il valore della propriet� luogoNascita.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLuogoNascita() {
        return luogoNascita;
    }

    /**
     * Imposta il valore della propriet� luogoNascita.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLuogoNascita(String value) {
        this.luogoNascita = value;
    }

    /**
     * Recupera il valore della propriet� codiceProvincia.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodiceProvincia() {
        return codiceProvincia;
    }

    /**
     * Imposta il valore della propriet� codiceProvincia.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodiceProvincia(String value) {
        this.codiceProvincia = value;
    }

    /**
     * Recupera il valore della propriet� dataUdienza.
     * 
     * @return
     *     possible object is
     *     {@link DATATYPE }
     *     
     */
    public DATATYPE getDataUdienza() {
        return dataUdienza;
    }

    /**
     * Imposta il valore della propriet� dataUdienza.
     * 
     * @param value
     *     allowed object is
     *     {@link DATATYPE }
     *     
     */
    public void setDataUdienza(DATATYPE value) {
        this.dataUdienza = value;
    }

    /**
     * Recupera il valore della propriet� nomeMagistratoRelatore.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomeMagistratoRelatore() {
        return nomeMagistratoRelatore;
    }

    /**
     * Imposta il valore della propriet� nomeMagistratoRelatore.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomeMagistratoRelatore(String value) {
        this.nomeMagistratoRelatore = value;
    }

    /**
     * Recupera il valore della propriet� cognomeMagistratoRelatore.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCognomeMagistratoRelatore() {
        return cognomeMagistratoRelatore;
    }

    /**
     * Imposta il valore della propriet� cognomeMagistratoRelatore.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCognomeMagistratoRelatore(String value) {
        this.cognomeMagistratoRelatore = value;
    }

    /**
     * Recupera il valore della propriet� etaPresuntaAnni.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEtaPresuntaAnni() {
        return etaPresuntaAnni;
    }

    /**
     * Imposta il valore della propriet� etaPresuntaAnni.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEtaPresuntaAnni(BigInteger value) {
        this.etaPresuntaAnni = value;
    }

    /**
     * Recupera il valore della propriet� etaPresuntaMesi.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEtaPresuntaMesi() {
        return etaPresuntaMesi;
    }

    /**
     * Imposta il valore della propriet� etaPresuntaMesi.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEtaPresuntaMesi(BigInteger value) {
        this.etaPresuntaMesi = value;
    }

    /**
     * Recupera il valore della propriet� sesso.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSesso() {
        return sesso;
    }

    /**
     * Imposta il valore della propriet� sesso.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSesso(String value) {
        this.sesso = value;
    }

}
