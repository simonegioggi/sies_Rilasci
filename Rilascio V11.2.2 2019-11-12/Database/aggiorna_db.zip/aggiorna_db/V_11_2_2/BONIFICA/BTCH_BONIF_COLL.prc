CREATE OR REPLACE PROCEDURE BTCH_BONIF_COLL is

  ERR_NUM            NUMBER;
  ERR_MSG            VARCHAR2(100);
  NUMERO_PROV_COMMIT NUMBER := 0;

  REC_CL integer;
  REC_COLLEGIO integer;

  CURSOR CUR_UDI IS
    select distinct  us.id_udienza_sige, us.col_id_collegio
      from udienza_sige us
     where us.col_id_collegio is not null;

BEGIN

  delete from collegio_magistrato a where a.cod_operatore_inserimento='BTCH_BONIF_COLL';

  FOR CUR_U IN CUR_UDI LOOP


      select count(*)
        into REC_CL
        from collegio_magistrato cl
       where cl.udi_id_udienza_sige = CUR_U.ID_UDIENZA_SIGE;

      select count(*)
        into REC_COLLEGIO
        from collegio_magistrato cl
       where cl.col_id_collegio = CUR_U.COL_ID_COLLEGIO;

    if rec_cl=0 and REC_COLLEGIO=3 then

        insert into collegio_magistrato
          select distinct y.col_id_collegio,
                          y.mag_cod_magistrato,
                          y.data_inserimento,
                          'BTCH_BONIF_COLL',
                          y.cod_ufficio_inserimento,
                          y.cod_ufficio_appartenenza,
                          CUR_U.id_udienza_sige
            from collegio_magistrato y
           where y.col_id_collegio = CUR_U.COL_ID_COLLEGIO;

        NUMERO_PROV_COMMIT:=NUMERO_PROV_COMMIT+1;

        IF NUMERO_PROV_COMMIT >= 100 THEN
          NUMERO_PROV_COMMIT := 0;
          COMMIT;
        END IF;
    end if;

  END LOOP;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ERR_NUM := SQLCODE;
    ERR_MSG := SUBSTR(SQLERRM, 1, 100);

END BTCH_BONIF_COLL;
/