begin
 BTCH_BONIF_COLL;
end;
/
