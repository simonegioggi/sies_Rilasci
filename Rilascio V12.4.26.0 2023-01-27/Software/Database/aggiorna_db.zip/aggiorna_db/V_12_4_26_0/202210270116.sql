CREATE OR REPLACE PROCEDURE Ricerca_Applicazione_Benefici
(codice_utente	  IN VARCHAR2,
 codice_ufficio	  IN VARCHAR2,
 anno_ini		  IN NUMBER,
 num_ini		  IN NUMBER,
 anno_fin		  IN NUMBER,
 num_fin		  IN NUMBER,
 data_del_reato	  IN VARCHAR2,
 anni_pr		  IN NUMBER,
 mesi_pr		  IN NUMBER,
 giorni_pr    	  IN NUMBER,
 data_pr		  IN VARCHAR2,
 pos_giu_agg	  IN NUMBER,
 cod_pos_giu	  IN VARCHAR2,
 anni_pena_comp	  IN NUMBER,
 mesi_pena_comp	  IN NUMBER,
 giorni_pena_comp IN NUMBER,
 --bvn 09 04 2014
 nazione in varchar2,
 id_rec			  OUT NUMBER
 )

IS
numVar NUMBER;
charVar VARCHAR2(5);

l_anno_ini NUMBER;
l_num_ini NUMBER;
l_anno_fin NUMBER;
l_num_fin NUMBER;
l_progr1 NUMBER;
l_progr2 NUMBER;
l_data_reato VARCHAR2(8);
l_cod_pos_giu VARCHAR2(2);
l_pos_giu_agg VARCHAR2(100);
l_anni_pr				NUMBER(4);
l_mesi_pr				NUMBER(4);
l_giorni_pr			NUMBER(4);
l_anni_comp				NUMBER(4);
l_mesi_comp				NUMBER(4);
l_giorni_comp			NUMBER(4);

l_data_pr DATE;
l_tot_giorni_pr NUMBER;

l_tot_giorni_calc NUMBER;

l_max_num NUMBER;
l_cont NUMBER;

l_num_anni_pena_res				NUMBER(4);
l_num_mesi_pena_res				NUMBER(4);
l_num_giorni_pena_res			NUMBER(4);

-- DF 09 04 2015
l_nazione                 VARCHAR2(300);

t_seq  		  	 	   	  	   	NUMBER;
t_id_fascicolo_siep            	NUMBER(38);
t_chiave_anno                   NUMBER(4);
t_chiave_progr                  NUMBER(38);
t_cognome						VARCHAR2(100 byte);
t_nome							VARCHAR2(100 byte);
t_luogo_nascita					VARCHAR2(500 byte);
t_data_nascita					DATE;
t_data_reato					DATE;
t_data_fine_pena				DATE;
t_num_anni_pena_res				NUMBER(4);
t_num_mesi_pena_res				NUMBER(4);
t_num_giorni_pena_res			NUMBER(4);
t_cod_posizione_giuridica		VARCHAR2(2 byte);
t_descr_posizione_giuridica		VARCHAR2(500 byte);

t_cod_stato_nascita		VARCHAR2(3 byte);
t_nazione             VARCHAR2(300);

l_time VARCHAR2(100);

CURSOR cur1 (v_cod_ufficio VARCHAR2, v_anno_ini IN NUMBER, v_num_ini IN NUMBER, v_anno_fin IN NUMBER,
	   		v_num_fin IN NUMBER, v_num1 IN NUMBER, v_num2 IN NUMBER,
			v_data_reato IN VARCHAR2, v_cod_pos_giu VARCHAR2, v_data_pr DATE, tot_giorni_pr NUMBER, v_pos_giu_agg VARCHAR2, v_nazione varchar2) IS


	SELECT DISTINCT A.ID_FASCICOLO_SIEP, a.CHIAVE_ANNO, a.CHIAVE_PROGR, C.COGNOME, C.NOME,
	   G.DESCRIZIONE, C.DATA_NASCITA, F.DATA_FINE, D.COD_POSIZIONE_GIURIDICA,
	   DECODE (F.DATA_FINE, NULL,
	   		  (((F.NUM_ANNI_ARRESTO+F.NUM_ANNI_RECLUSIONE)*360) + ((F.NUM_MESI_ARRESTO+F.NUM_MESI_RECLUSIONE)*30) + (F.NUM_GIORNI_ARRESTO + F.NUM_GIORNI_RECLUSIONE)),
			  NULL) tot_giorni, C.COD_STATO_NASCITA,  H.RV_MEANING NAZIONE -- DF 09 04 2015

	FROM FASCICOLO_SIEP A,
		 SOGGETTO C,
		 POSIZIONE_GIURIDICA D,
	     PENA_RESIDUA F,
		 COMUNE G,
     -- DF 09 04 2015
     CG_REF_CODES H
	WHERE
	A.CHIAVE_UFFICIO = v_cod_ufficio
	AND A.SOG_ID_SOGGETTO = C.ID_SOGGETTO AND C.COD_COMUNE_NASCITA = G.COD_COMUNE
	AND A.ID_FASCICOLO_SIEP = D.FAS_SIE_ID_FASCICOLO_SIEP
	AND A.ID_FASCICOLO_SIEP = F.FAS_SIE_ID_FASCICOLO_SIEP
  -- DF 09 04 2015
  AND C.NAZIONALITA = H.RV_LOW_VALUE
  AND (H.RV_DOMAIN = 'NAZIONE' OR (H.RV_DOMAIN='NAZIONALITA' AND UPPER(C.COD_OPERATORE_INSERIMENTO) LIKE 'RES%'))
   --bvn 09 04 2014
  and ((v_nazione = 'I' and c.cod_stato_nascita = '039') or (v_nazione = 'S' and c.cod_stato_nascita <> '039') or
       (v_nazione = '-'))
	AND
		(a.COD_STATO_FASCICOLO <> '01' AND a.COD_STATO_FASCICOLO <> '06')
			AND
			(
			((a.CHIAVE_ANNO = v_anno_ini AND a.CHIAVE_PROGR >= v_num_ini) AND (a.CHIAVE_ANNO = v_anno_ini AND a.CHIAVE_PROGR <= v_num1))
			OR
			((a.CHIAVE_ANNO = v_anno_fin AND a.CHIAVE_PROGR <= v_num_fin) AND (a.CHIAVE_ANNO = v_anno_fin AND a.CHIAVE_PROGR >= v_num2))
			OR
			(a.CHIAVE_ANNO > v_anno_ini AND a.CHIAVE_ANNO < v_anno_fin)
			)
	AND
	   EXISTS (SELECT 'X' FROM REATO B WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP AND
		-- REATI
		B.PROGR_CIRCOSTANZA = 1
			AND
			(
			 (B.DATA_FINE IS NOT NULL AND B.DATA_FINE <= TO_DATE(v_data_reato, 'ddmmyyyy')) OR
			 (B.DATA_FINE IS NULL AND B.DATA_INIZIO <= TO_DATE(v_data_reato, 'ddmmyyyy')) OR
			 (B.DATA_FINE IS NULL AND B.DATA_INIZIO IS NULL)
			)
		)
	AND
	-- Modificata Umberto 4/6/2010 D.DATA_INSERIMENTO = (SELECT MAX(DATA_INSERIMENTO) FROM POSIZIONE_GIURIDICA WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP)
	D.ID_POSIZIONE_GIURIDICA = (SELECT MAX(ID_POSIZIONE_GIURIDICA) FROM POSIZIONE_GIURIDICA WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP)
	AND (D.COD_POSIZIONE_GIURIDICA LIKE v_cod_pos_giu OR D.COD_POSIZIONE_GIURIDICA IN (SELECT RV_LOW_VALUE FROM CG_REF_CODES
		WHERE RV_DOMAIN = 'POSIZIONE_GIURIDICA_BENEFICI' AND RV_HIGH_VALUE = v_pos_giu_agg))
	AND
	F.ID_PENA_RESIDUA = (SELECT MAX(ID_PENA_RESIDUA) FROM PENA_RESIDUA WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP)
	AND F.FLAG_ERGASTOLO <> 'S'
	AND (
		(F.DATA_FINE IS NOT NULL AND (F.DATA_FINE <= v_data_pr AND F.DATA_FINE >= SYSDATE))
		OR (F.DATA_FINE IS NULL AND (((F.NUM_ANNI_ARRESTO+F.NUM_ANNI_RECLUSIONE)*360) + ((F.NUM_MESI_ARRESTO+F.NUM_MESI_RECLUSIONE)*30) +
		   				   			   F.NUM_GIORNI_ARRESTO + F.NUM_GIORNI_RECLUSIONE) <= tot_giorni_pr)
		);

CURSOR cur2 (v_cod_ufficio VARCHAR2, v_anno_ini IN NUMBER, v_num_ini IN NUMBER, v_anno_fin IN NUMBER,
	   		v_num_fin IN NUMBER, v_num1 IN NUMBER, v_num2 IN NUMBER,
			v_data_reato IN VARCHAR2, v_cod_pos_giu VARCHAR2, v_data_pr DATE, tot_giorni_pr NUMBER, v_pos_giu_agg VARCHAR2, v_nazione_1 varchar2) IS

	SELECT DISTINCT A.ID_FASCICOLO_SIEP, a.CHIAVE_ANNO, a.CHIAVE_PROGR, C.COGNOME, C.NOME,
	   G.DESCRIZIONE, C.DATA_NASCITA, F.DATA_FINE, D.COD_POSIZIONE_GIURIDICA,
	   (((F.NUM_ANNI_ARRESTO+F.NUM_ANNI_RECLUSIONE)*360) + ((F.NUM_MESI_ARRESTO+F.NUM_MESI_RECLUSIONE)*30) + (F.NUM_GIORNI_ARRESTO + F.NUM_GIORNI_RECLUSIONE)) tot_giorni,
	   C.COD_STATO_NASCITA,  H.RV_MEANING NAZIONE -- DF 09 04 2015

	FROM FASCICOLO_SIEP A, SOGGETTO C, POSIZIONE_GIURIDICA D,
	     PENA_COMPLESSIVA F, COMUNE G,
     -- DF 09 04 2015
     CG_REF_CODES H
	WHERE

	A.CHIAVE_UFFICIO = v_cod_ufficio
	AND A.SOG_ID_SOGGETTO = C.ID_SOGGETTO AND C.COD_COMUNE_NASCITA = G.COD_COMUNE
	AND A.ID_FASCICOLO_SIEP = D.FAS_SIE_ID_FASCICOLO_SIEP
	AND A.ID_FASCICOLO_SIEP = F.FAS_SIE_ID_FASCICOLO_SIEP
  -- DF 09 04 2015
  AND C.NAZIONALITA = H.RV_LOW_VALUE
  AND (H.RV_DOMAIN = 'NAZIONE' OR (H.RV_DOMAIN='NAZIONALITA' AND UPPER(C.COD_OPERATORE_INSERIMENTO) LIKE 'RES%'))
   --bvn 09 04 2014
  and ((v_nazione_1 = 'I' and c.cod_stato_nascita = '039') or (v_nazione_1 = 'S' and c.cod_stato_nascita <> '039') or
       (v_nazione_1 = '-'))
	AND

		-- FASCICOLO
		(a.COD_STATO_FASCICOLO <> '01' AND a.COD_STATO_FASCICOLO <> '06')

			AND
			(
			((a.CHIAVE_ANNO = v_anno_ini AND a.CHIAVE_PROGR >= v_num_ini) AND (a.CHIAVE_ANNO = v_anno_ini AND a.CHIAVE_PROGR <= v_num1))
			OR
			((a.CHIAVE_ANNO = v_anno_fin AND a.CHIAVE_PROGR <= v_num_fin) AND (a.CHIAVE_ANNO = v_anno_fin AND a.CHIAVE_PROGR >= v_num2))
			OR
			(a.CHIAVE_ANNO > v_anno_ini AND a.CHIAVE_ANNO < v_anno_fin)
			)

	AND
		-- REATI

	    EXISTS (SELECT 'X' FROM REATO B WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP AND

		B.PROGR_CIRCOSTANZA = 1
			AND
			(
			 (B.DATA_FINE IS NOT NULL AND B.DATA_FINE <= TO_DATE(v_data_reato, 'ddmmyyyy')) OR
			 (B.DATA_FINE IS NULL AND B.DATA_INIZIO <= TO_DATE(v_data_reato, 'ddmmyyyy')) OR
			 (B.DATA_FINE IS NULL AND B.DATA_INIZIO IS NULL)
			)

		)

	AND

	-- POSIZIONE GIURIDICA
		-- Modificata Umberto 4/6/2010 D.DATA_INSERIMENTO = (SELECT MAX(DATA_INSERIMENTO) FROM POSIZIONE_GIURIDICA WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP)
	D.ID_POSIZIONE_GIURIDICA = (SELECT MAX(ID_POSIZIONE_GIURIDICA) FROM POSIZIONE_GIURIDICA WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP)
	AND (D.COD_POSIZIONE_GIURIDICA LIKE v_cod_pos_giu OR D.COD_POSIZIONE_GIURIDICA IN (SELECT RV_LOW_VALUE FROM CG_REF_CODES
		WHERE RV_DOMAIN = 'POSIZIONE_GIURIDICA_BENEFICI' AND RV_HIGH_VALUE = v_pos_giu_agg))

	AND

	-- PENA COMPLESSIVA

	 (NOT EXISTS (SELECT 'x' FROM PENA_RESIDUA WHERE ID_FASCICOLO_SIEP = FAS_SIE_ID_FASCICOLO_SIEP)
	 	  AND
			(
			  (
			  			 ((F.NUM_ANNI_ARRESTO+F.NUM_ANNI_RECLUSIONE)*360) + ((F.NUM_MESI_ARRESTO+F.NUM_MESI_RECLUSIONE)*30) +
			  			  F.NUM_GIORNI_ARRESTO + F.NUM_GIORNI_RECLUSIONE
						  ) <= tot_giorni_pr

				OR

			  			 F.NUM_ANNI_ARRESTO+F.NUM_ANNI_RECLUSIONE+F.NUM_MESI_ARRESTO+F.NUM_MESI_RECLUSIONE+
			  			  F.NUM_GIORNI_ARRESTO + F.NUM_GIORNI_RECLUSIONE
						  IS NULL
				)

	  );


BEGIN

--   select to_char(sysdate, 'hh24.mi.ss') into l_time from dual;
--  dbms_output.put_line('l_time: '||l_time);

   DELETE FROM RISULTATO_RICERCA WHERE cod_utente = codice_utente;
   COMMIT;

   id_rec := 0;

   l_max_num := 999999;
   l_cont := 0;

   IF anno_ini IS NULL THEN
   	  l_anno_ini := 0;
   ELSE
   	  l_anno_ini := anno_ini;
   END IF;

   IF anno_fin IS NULL THEN
   	  l_anno_fin := 9999;
   ELSE
   	  l_anno_fin := anno_fin;
   END IF;

   IF num_ini IS NULL THEN
   	  l_num_ini := 0;
   ELSE
   	  l_num_ini := num_ini;
   END IF;

   IF num_fin IS NULL THEN
   	  l_num_fin := 0;
   ELSE
   	  l_num_fin := num_fin;
   END IF;

   IF l_anno_ini <> l_anno_fin THEN
   	  l_progr1 := l_max_num;
	  l_progr2 := 0;
   ELSE
   	  l_progr1 := l_num_fin;
	  l_progr2 := l_num_ini;
   END IF;

   IF data_del_reato IS NULL OR data_del_reato = '' THEN
   	  l_data_reato := '31129999';
   ELSE
   	  l_data_reato := data_del_reato;
   END IF;

   IF cod_pos_giu IS NULL OR cod_pos_giu = '-' THEN
   	  l_cod_pos_giu := '%';
   ELSE
   	  l_cod_pos_giu := cod_pos_giu;
   END IF;

   IF pos_giu_agg = 0 OR pos_giu_agg IS NULL THEN
      l_pos_giu_agg := 'nulla';
   END IF;
   IF pos_giu_agg = 1 THEN
   	  l_pos_giu_agg := 'DETENUTO';
   	  l_cod_pos_giu := 'xx';
   END IF;
   IF pos_giu_agg = 2 THEN
   	  l_pos_giu_agg := 'MISURA ALTERNATIVA';
   	  l_cod_pos_giu := 'xx';
   END IF;
   IF pos_giu_agg = 3 THEN
   	  l_pos_giu_agg := 'LIBERO';
   	  l_cod_pos_giu := 'xx';
   END IF;


	 IF anni_pr IS NULL THEN
	 	 l_anni_pr := 0;
	 ELSE
	 	 l_anni_pr := anni_pr;
	 END IF;

	 IF mesi_pr IS NULL THEN
	 	 l_mesi_pr := 0;
	 ELSE
	 	 l_mesi_pr := mesi_pr;
	 END IF;

	 IF giorni_pr IS NULL THEN
	 	 l_giorni_pr := 0;
	 ELSE
	 	 l_giorni_pr := giorni_pr;
	 END IF;

   IF l_anni_pr+l_mesi_pr+l_giorni_pr = 0 THEN
   	  SELECT TO_DATE('31129999', 'ddmmyyyy') INTO l_data_pr FROM dual;
	  l_tot_giorni_pr := l_max_num;
   ELSE
   	  SELECT ADD_MONTHS(SYSDATE, (l_anni_pr*12)+l_mesi_pr)+l_giorni_pr INTO l_data_pr FROM dual;
	  l_tot_giorni_pr := (l_anni_pr*360)+(l_mesi_pr*30)+l_giorni_pr;
   END IF;

	 IF anni_pena_comp IS NULL THEN
	 	 l_anni_comp := 0;
	 ELSE
	 	 l_anni_comp := anni_pena_comp;
	 END IF;

	 IF mesi_pena_comp IS NULL THEN
	 	 l_mesi_comp := 0;
	 ELSE
	 	 l_mesi_comp := mesi_pena_comp;
	 END IF;

	 IF giorni_pena_comp IS NULL THEN
	 	 l_giorni_comp := 0;
	 ELSE
	 	 l_giorni_comp := giorni_pena_comp;
	 END IF;

   IF l_anni_comp+l_mesi_comp+l_giorni_comp <> 0
      AND l_anni_pr+l_mesi_pr+l_giorni_pr = 0 THEN
	  l_tot_giorni_pr := (l_anni_comp*360)+(l_mesi_comp*30)+l_giorni_comp;
	  l_data_pr := NULL;
   END IF;

   
	dbms_output.put_line('cod_ufficio='||codice_ufficio);
	dbms_output.put_line('l_anno_ini='||l_anno_ini);
	dbms_output.put_line('l_num_ini='||l_num_ini);
	dbms_output.put_line('l_anno_fin='||l_anno_fin);
	dbms_output.put_line('l_num_fin='||l_num_fin);
	dbms_output.put_line('l_progr1='||l_progr1);
	dbms_output.put_line('l_progr2='||l_progr2);
	dbms_output.put_line('l_data_reato='||l_data_reato);
	dbms_output.put_line('l_cod_pos_giu='||l_cod_pos_giu);
	dbms_output.put_line('l_pos_giu_agg='||l_pos_giu_agg);
	dbms_output.put_line('l_data_pr='||l_data_pr);
	dbms_output.put_line('l_tot_giorni_pr='||l_tot_giorni_pr);

	dbms_output.put_line('nazione >'||nazione||'<');


    SELECT RIS_RIC_SEQ.NEXTVAL INTO t_seq FROM dual;

   
	dbms_output.put_line('l_anni_comp='||l_anni_comp);
	dbms_output.put_line('l_mesi_comp='||l_mesi_comp);
	dbms_output.put_line('l_giorni_comp='||l_giorni_comp);

	dbms_output.put_line('l_anni_pr='||l_anni_pr);
	dbms_output.put_line('l_mesi_pr='||l_mesi_pr);
	dbms_output.put_line('l_giorni_pr='||l_giorni_pr);
   
   
    IF l_anni_comp+l_mesi_comp+l_giorni_comp <> 0
      AND l_anni_pr+l_mesi_pr+l_giorni_pr = 0 THEN

--   	   select to_char(sysdate, 'hh24.mi.ss') into l_time from dual;
--   	   dbms_output.put_line('2_PRIMA_OPEN: '||l_time);
	dbms_output.put_line('PRIMO IF....');

	   OPEN cur2(codice_ufficio, l_anno_ini,l_num_ini,l_anno_fin,l_num_fin,l_progr1,l_progr2,l_data_reato, l_cod_pos_giu, l_data_pr, l_tot_giorni_pr, l_pos_giu_agg, nazione);

--   	   select to_char(sysdate, 'hh24.mi.ss') into l_time from dual;
--   	   dbms_output.put_line('2_DOPO_OPEN: '||l_time);

	   FETCH cur2 INTO t_id_fascicolo_siep,t_chiave_anno,t_chiave_progr,t_cognome,t_nome,t_luogo_nascita,t_data_nascita,t_data_fine_pena,t_cod_posizione_giuridica,l_tot_giorni_calc,t_cod_stato_nascita, l_nazione;

--	   dbms_output.put_line('inizio insert');

	   WHILE cur2%FOUND LOOP

	      	l_cont := l_cont + 1;

			l_num_anni_pena_res := NULL;
			l_num_mesi_pena_res	:= NULL;
			l_num_giorni_pena_res := NULL;

			IF l_tot_giorni_calc IS NOT NULL THEN

			   l_num_giorni_pena_res := l_tot_giorni_calc MOD 30;

			   l_num_mesi_pena_res := (l_tot_giorni_calc-l_num_giorni_pena_res)/30 MOD 12;

			   l_num_anni_pena_res := (l_tot_giorni_calc-l_num_giorni_pena_res-(l_num_mesi_pena_res*30)) / 360;

			END IF;

			SELECT RV_MEANING INTO t_descr_posizione_giuridica FROM CG_REF_CODES WHERE RV_DOMAIN = 'POSIZIONE_GIURIDICA' AND RV_LOW_VALUE = t_cod_posizione_giuridica;

			IF t_cod_stato_nascita <> '039' THEN
				-- Ticket#202210270116 - In caso di NAZIONE non valida su Soggetto, usciva dalla SP con "nessun elemento trovato"
				--                       Si gestisce qui questo caso particolare
				BEGIN
			   		SELECT UPPER(RV_MEANING) INTO t_luogo_nascita FROM CG_REF_CODES WHERE RV_DOMAIN = 'NAZIONE' AND RV_LOW_VALUE = t_cod_stato_nascita;
				EXCEPTION
				   WHEN NO_DATA_FOUND THEN
				      t_luogo_nascita := '-';
				END;
			    -- Ticket#202210270116 - FINE
			END IF;

			INSERT INTO RISULTATO_RICERCA (
			   ID_RICERCA, COD_UFFICIO, ID_FASCICOLO_SIEP,
			   CHIAVE_ANNO, CHIAVE_PROGR, COGNOME,
			   NOME, LUOGO_NASCITA, DATA_NASCITA,
			   DATA_REATO, DATA_FINE_PENA, NUM_ANNI_PENA_RES,
			   NUM_MESI_PENA_RES, NUM_GIORNI_PENA_RES, COD_POSIZIONE_GIURIDICA,
			   DESCR_POSIZIONE_GIURIDICA, COD_UTENTE, NAZIONALITA) -- DF 09 04 2015
			VALUES (t_seq, codice_ufficio, t_id_fascicolo_siep,
			    t_chiave_anno, t_chiave_progr, t_cognome,
			    t_nome, t_luogo_nascita, t_data_nascita,
			    NULL, t_data_fine_pena, l_num_anni_pena_res,
			    l_num_mesi_pena_res, l_num_giorni_pena_res,
				t_cod_posizione_giuridica, t_descr_posizione_giuridica,
				codice_utente, l_nazione); -- DF 09 04 2015


		  IF l_cont MOD 100 = 0 THEN
		   	COMMIT;
		  END IF;

		  FETCH cur2 INTO t_id_fascicolo_siep,t_chiave_anno,t_chiave_progr,
		  t_cognome,t_nome,t_luogo_nascita,t_data_nascita,t_data_fine_pena,t_cod_posizione_giuridica,l_tot_giorni_calc,t_cod_stato_nascita, t_nazione; -- df 09 04 2015

	   END LOOP;


	   CLOSE cur2;

   ELSE
	dbms_output.put_line('ELSE....');

--       select to_char(sysdate, 'hh24.mi.ss') into l_time from dual;
--   	   dbms_output.put_line('1_PRIMA_OPEN: '||l_time);

	   OPEN cur1(codice_ufficio, l_anno_ini,l_num_ini,l_anno_fin,l_num_fin,l_progr1,l_progr2,l_data_reato, l_cod_pos_giu, l_data_pr, l_tot_giorni_pr, l_pos_giu_agg, nazione);

--   	   select to_char(sysdate, 'hh24.mi.ss') into l_time from dual;
--   	   dbms_output.put_line('1_DOPO_OPEN: '||l_time);

	   FETCH cur1 INTO t_id_fascicolo_siep,t_chiave_anno,t_chiave_progr,t_cognome,t_nome,t_luogo_nascita,t_data_nascita,t_data_fine_pena,t_cod_posizione_giuridica,l_tot_giorni_calc,t_cod_stato_nascita, t_nazione; -- df 09 04 2015

--	   dbms_output.put_line('1_DOPO_FETCH: '||l_time);

--	   dbms_output.put_line('inizio insert');

	   WHILE cur1%FOUND LOOP

	      	l_cont := l_cont + 1;

			l_num_anni_pena_res := NULL;
			l_num_mesi_pena_res	:= NULL;
			l_num_giorni_pena_res := NULL;

			IF l_tot_giorni_calc IS NOT NULL THEN

			   l_num_giorni_pena_res := l_tot_giorni_calc MOD 30;

			   l_num_mesi_pena_res := (l_tot_giorni_calc-l_num_giorni_pena_res)/30 MOD 12;

			   l_num_anni_pena_res := (l_tot_giorni_calc-l_num_giorni_pena_res-(l_num_mesi_pena_res*30)) / 360;

			END IF;

			SELECT RV_MEANING INTO t_descr_posizione_giuridica FROM CG_REF_CODES WHERE RV_DOMAIN = 'POSIZIONE_GIURIDICA' AND RV_LOW_VALUE = t_cod_posizione_giuridica;

			IF t_cod_stato_nascita <> '039' THEN
				-- Ticket#202210270116 - In caso di NAZIONE non valida su Soggetto, usciva dalla SP con "nessun elemento trovato"
				--                       Si gestisce qui questo caso particolare
				BEGIN 
			   		SELECT UPPER(RV_MEANING) INTO t_luogo_nascita FROM CG_REF_CODES WHERE RV_DOMAIN = 'NAZIONE' AND RV_LOW_VALUE = t_cod_stato_nascita;
				EXCEPTION
				   WHEN NO_DATA_FOUND THEN
				      t_luogo_nascita := '-';
				END;
			    -- Ticket#202210270116 - FINE
			END IF;

			INSERT INTO RISULTATO_RICERCA (
			   ID_RICERCA, COD_UFFICIO, ID_FASCICOLO_SIEP,
			   CHIAVE_ANNO, CHIAVE_PROGR, COGNOME,
			   NOME, LUOGO_NASCITA, DATA_NASCITA,
			   DATA_REATO, DATA_FINE_PENA, NUM_ANNI_PENA_RES,
			   NUM_MESI_PENA_RES, NUM_GIORNI_PENA_RES, COD_POSIZIONE_GIURIDICA,
			   DESCR_POSIZIONE_GIURIDICA, COD_UTENTE, NAZIONALITA) -- df 09 04 2015
			VALUES (t_seq, codice_ufficio, t_id_fascicolo_siep,
			    t_chiave_anno, t_chiave_progr, t_cognome,
			    t_nome, t_luogo_nascita, t_data_nascita,
			    NULL, t_data_fine_pena, l_num_anni_pena_res,
			    l_num_mesi_pena_res, l_num_giorni_pena_res,
				t_cod_posizione_giuridica, t_descr_posizione_giuridica,
				codice_utente, t_nazione); -- df 09 04 2015

		  	 IF l_cont MOD 100 = 0 THEN
		  	 	COMMIT;
		  	 END IF;

		     FETCH cur1 INTO t_id_fascicolo_siep,t_chiave_anno,t_chiave_progr,
		                     t_cognome,t_nome,t_luogo_nascita,t_data_nascita,t_data_fine_pena,t_cod_posizione_giuridica,l_tot_giorni_calc,t_cod_stato_nascita, t_nazione;

	   END LOOP;


	   CLOSE cur1;

	END IF;

--   dbms_output.put_line('tot_fascicoli: ' || l_cont);

   IF l_cont = 0 THEN
	  RAISE NO_DATA_FOUND;
   ELSE
      id_rec := t_seq;
   END IF;

   COMMIT;

   dbms_output.put_line('RISULTATO: '||id_rec);

--   select to_char(sysdate, 'hh24.mi.ss') into l_time from dual;
--   dbms_output.put_line('l_time: '||l_time);

   EXCEPTION
     WHEN NO_DATA_FOUND THEN
	   ROLLBACK;
	   id_rec := 0;
       dbms_output.put_line('RISULTATO: '||id_rec);
     WHEN OTHERS THEN
	   DBMS_OUTPUT.PUT_LINE ('sqlerrm: ' || SQLERRM);
	   ROLLBACK;
	   id_rec := -1;
       dbms_output.put_line('RISULTATO: '||id_rec);


END Ricerca_Applicazione_Benefici;
/