--==============================================================================
-- Ticket 20200915015
-- Script di aggiornamento/reset del campo EVE_ID_EVENTO della tabella 
-- STATO_PROCEDIMENTO
--==============================================================================
UPDATE STATO_PROCEDIMENTO SET EVE_ID_EVENTO = NULL
where (STATO_PROCEDIMENTO.PROGRESSIVO
     , STATO_PROCEDIMENTO.FAS_SIE_ID_FASCICOLO_SIEP
     , STATO_PROCEDIMENTO.COD_STATO_PROCEDIMENTO
     , STATO_PROCEDIMENTO.EVE_ID_EVENTO
     , STATO_PROCEDIMENTO.DATA_INSERIMENTO
)
in (select STA_PROGRESSIVO,
           STA_FAS_SIE_ID_FASCICOLO_SIEP ,
           STA_COD_STATO_PROCEDIMENTO ,
           STA_EVE_ID_EVENTO,
           STA_DATA_INSERIMENTO
      from STATO_PROCEDIMENTO_APPO
   );