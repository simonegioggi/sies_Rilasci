CREATE OR REPLACE PACKAGE PULISCI_ALTRE_BDI
  IS
--
-- To modify this template, edit file PKGSPEC.TXT in TEMPLATE
-- directory of SQL Navigator
--
-- Purpose: Briefly explain the functionality of the package
--
-- MODIFICATION HISTORY
-- Person      Date    Comments
-- ---------   ------  ------------------------------------------
   -- Enter package declarations as shown below

   --variable_name   datatype;
    PROCEDURE Pulisci_Evento
     ( IdEvento IN NUMBER,
       EsitoPulisciEvento IN OUT VARCHAR2 );

    PROCEDURE pulisci_fascicolo
     ( IdFascicolo IN NUMBER,
       EsitoPulisciFascicolo IN OUT VARCHAR2);

    PROCEDURE pulisci_istruttoria_cum
     (p_IdIstrutoria            IN       NUMBER,
      p_EsitoPulisciIstruttoria IN OUT   VARCHAR2);

END; -- Package spec;
/
