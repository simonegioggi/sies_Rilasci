//
// Questo file � stato generato dall'architettura JavaTM per XML Binding (JAXB) Reference Implementation, v2.2.8-b130911.1802 
// Vedere <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Qualsiasi modifica a questo file andr� persa durante la ricompilazione dello schema di origine. 
// Generato il: 2020.02.10 alle 12:42:15 PM CET 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://it/eng/giustizia/avvocatura/ws/type/ricercaSoggettiConProcedimenti", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package it.eng.giustizia.avvocatura.ws.type.ricercaSoggettiConProcedimenti;
