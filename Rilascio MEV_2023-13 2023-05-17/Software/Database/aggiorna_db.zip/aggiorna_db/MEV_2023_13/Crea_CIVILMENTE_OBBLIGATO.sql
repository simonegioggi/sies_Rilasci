-- Create table
create table CIVILMENTE_OBBLIGATO
(
  id_civilmente_obbligato     NUMBER(38) not null,
  cod_tutore                  VARCHAR2(1),
  cod_persona                 VARCHAR2(1) not null,
  cod_fiscale                 VARCHAR2(16),
  cognome                     VARCHAR2(100),
  nome                        VARCHAR2(100),
  denominazione               VARCHAR2(200),
  data_nascita                DATE,
  cod_comune_nascita          VARCHAR2(6),
  cod_provincia_nascita       VARCHAR2(2),
  cod_stato_nascita           VARCHAR2(3),
  desc_comune_nascita_estero  VARCHAR2(200),
  sesso                       VARCHAR2(1),
  rag_sociale                 VARCHAR2(5),
  cod_provincia               VARCHAR2(2),
  ind_sede_legale             VARCHAR2(200),
  ind_sede_operativa          VARCHAR2(200),
  cod_operatore_inserimento   VARCHAR2(100),
  data_inserimento            DATE,
  cod_ufficio_inserimento     VARCHAR2(11),
  cod_operatore_aggiornamento VARCHAR2(100),
  data_aggiornamento          DATE,
  cod_ufficio_aggiornamento   VARCHAR2(11),
  cod_fiscale_rap             VARCHAR2(16),
  pec                         VARCHAR2(200),
  e_mail                      VARCHAR2(200),
  fas_sie_id_fascicolo_siep   NUMBER not null
)
tablespace SIESDIN
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes 
create index CIV_FAS_SIE_FAS_SIE_FK_I on CIVILMENTE_OBBLIGATO (FAS_SIE_ID_FASCICOLO_SIEP)
  tablespace SIESIND
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  )
  nologging;
-- Create/Recreate primary, unique and foreign key constraints 
alter table CIVILMENTE_OBBLIGATO
  add constraint ID_CIVIL_OBBL_PK primary key (ID_CIVILMENTE_OBBLIGATO)
  using index 
  tablespace SIESDIN
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter index ID_CIVIL_OBBL_PK nologging;