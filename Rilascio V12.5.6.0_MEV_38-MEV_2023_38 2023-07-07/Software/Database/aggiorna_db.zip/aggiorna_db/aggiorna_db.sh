#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV_2023_38/aggiorna_db.sql