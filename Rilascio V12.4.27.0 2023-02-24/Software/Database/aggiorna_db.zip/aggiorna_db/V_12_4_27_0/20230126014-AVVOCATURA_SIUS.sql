CREATE OR REPLACE PACKAGE BODY AVVOCATURA_SIUS IS

  CODI_UFFICIO UFFICIO.COD_UFFICIO%TYPE := NULL;
  ERR_MSG_OUT  VARCHAR2(600);
  ECCEZIONE EXCEPTION;
  G_DEBUGGING BOOLEAN := TRUE;
  --Data_Inizio_Proc DATE;

  PROCEDURE CERCA_UFFICIO(AVVO_SIUS_IN IN INP_AVV);

  PROCEDURE OUTPUT(AVVO_SIUS_IN IN INP_AVV,
                   P_TEXT       VARCHAR2,
                   DATA_INIZIO  in OUT DATE);

  PROCEDURE GESTISCI_ERRORE(ERR_MSG      IN VARCHAR2,
                            AVVO_SIUS_IN IN INP_AVV,
                            NOME_PROC    VARCHAR2);

  PROCEDURE CERCA_RESIDENZA(AVVO_SIUS_IN IN INP_AVV,
                            ID_FSC_SIUS  IN fascicolo_sius.id_fascicolo_sius%TYPE,
                            AR_SOGGETTO  IN OUT TY_SOGGETTO);

  PROCEDURE CERCA_ULTERIORI_ISTANZE(AVVO_SIUS_IN IN INP_AVV,
                                    AR_SIUS      IN OUT TY_FASCICOLO_SIUS);

  PROCEDURE CERCA_UDIENZA(AVVO_SIUS_IN IN INP_AVV,
                          ID_UDI       IN UDIENZA.ID_UDIENZA%TYPE,
                          ID_GP        IN GENERALE_PROCEDIMENTO.ID_GENERALE_PROCEDIMENTO%TYPE,
                          AR_SIUS      IN OUT TY_FASCICOLO_SIUS);

  PROCEDURE CERCA_FASCICOLO_SIEP(AVVO_SIUS_IN IN INP_AVV,
                                 ID_SIEP      IN FASCICOLO_SIEP.ID_FASCICOLO_SIEP%TYPE,
                                 AR_FASCICOLO IN OUT TY_FASCICOLO_SIEP);

  PROCEDURE CERCA_RIFERIMENTI_FASC_SIEP(AVVO_SIUS_IN     IN INP_AVV,
                                        ID_SIUS          IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                                        AR_RIF_FASC_SIEP OUT RC_RIFER_SIEP);

  PROCEDURE GESTISCI_ERRORE(ERR_MSG      IN VARCHAR2,
                            AVVO_SIUS_IN IN INP_AVV,
                            NOME_PROC    VARCHAR2) IS
  BEGIN
    DBMS_OUTPUT.PUT_LINE('*** " ' || ERR_MSG ||
                         ' " ERRORE NELLA PROCEDURA " ' || NOME_PROC ||
                         CHR(10) || ' ANNO_FAS: ' || AVVO_SIUS_IN.ANNO_FAS ||
                         CHR(10) || ' NUME_FAS: ' || AVVO_SIUS_IN.NUME_FAS ||
                         CHR(10) || ' TIPO_UFF: ' || AVVO_SIUS_IN.TIPO_UFF ||
                         CHR(10) || ' ID_DISTR: ' ||
                         AVVO_SIUS_IN.ID_DISTRETTO);
    ERR_MSG_OUT := ERR_MSG;
    --OUTPUT (ID_ANAG_CP, ID_PROVV_CP,'*** " ' || ERR_MSG ||' " ERRORE NELLA PROCEDURA CERCA_UFFICIO ');
  
  END;

  PROCEDURE CERCA_UFFICIO(AVVO_SIUS_IN IN INP_AVV) IS
  BEGIN
  
    SELECT /*+ optimizer_features_enable('12.1.0.2') */
     U.COD_UFFICIO
      INTO CODI_UFFICIO
      FROM UFFICIO U, COMUNE C
     WHERE U.COD_TIPO_UFFICIO = AVVO_SIUS_IN.TIPO_UFF
       AND U.COD_COMUNE = C.COD_COMUNE
          -- 20160817: SG
          --AND C.COD_COMUNE = AVVO_SIUS_IN.ID_DISTRETTO;
       AND U.COD_DISTRETTO = AVVO_SIUS_IN.ID_DISTRETTO;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_UFFICIO');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_RESIDENZA                          --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_RESIDENZA(AVVO_SIUS_IN IN INP_AVV,
                            ID_FSC_SIUS  IN fascicolo_sius.id_fascicolo_sius%TYPE,
                            AR_SOGGETTO  IN OUT TY_SOGGETTO) IS
  
    CURSOR C_RESID IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
      DISTINCT DESCR_STATO.RV_MEANING          DESCR_STATO,
               RESIDENZA.COD_PROVINCIA,
               COMUNE.DESCRIZIONE              DESCR_COMUNE,
               RESIDENZA.CAP,
               INDIRIZZO,
               DESC_COMUNE_ESTERO,
               COD_TIPO_RESIDENZA,
               DESCR_TIPO_RESIDENZA.RV_MEANING DESCR_TIPO_RESIDENZA,
               --RESIDENZA_FASCICOLO_SIUS.DATA_INIZIO_VALIDITA,
               --RESIDENZA_FASCICOLO_SIUS.DATA_FINE_VALIDITA,
               RESIDENZA.FLG_DOM_AVV,
               RESIDENZA.FLG_DOMICILIO_DIFENSORE
        FROM RESIDENZA,
             FASCICOLO_SIUS,
             RESIDENZA_FASCICOLO_SIUS,
             CG_REF_CODES             DESCR_STATO,
             CG_REF_CODES             DESCR_PROVINCIA,
             COMUNE,
             CG_REF_CODES             DESCR_TIPO_RESIDENZA
       WHERE (DESCR_STATO.RV_DOMAIN = 'NAZIONE' AND
             DESCR_STATO.RV_LOW_VALUE = RESIDENZA.COD_STATO)
         AND (DESCR_PROVINCIA.RV_DOMAIN = 'PROVINCIA' AND
             DESCR_PROVINCIA.RV_LOW_VALUE = RESIDENZA.COD_PROVINCIA)
         AND (COMUNE.COD_COMUNE = RESIDENZA.COD_COMUNE)
         AND (DESCR_TIPO_RESIDENZA.RV_DOMAIN = 'TIPO_RESIDENZA' AND
             DESCR_TIPO_RESIDENZA.RV_LOW_VALUE =
             RESIDENZA.COD_TIPO_RESIDENZA)
         AND (RESIDENZA.ID_RESIDENZA =
             RESIDENZA_FASCICOLO_SIUS.RES_ID_RESIDENZA)
         AND (FASCICOLO_SIUS.ID_FASCICOLO_SIUS =
             RESIDENZA_FASCICOLO_SIUS.FAS_SIU_ID_FASCICOLO_SIUS)
         AND (FASCICOLO_SIUS.ID_FASCICOLO_SIUS = ID_FSC_SIUS)
         AND (COD_TIPO_RESIDENZA IN ('R', 'D'))
         AND (RESIDENZA_FASCICOLO_SIUS.DATA_FINE_VALIDITA IS NULL);
  
    T_RESIDENZA TY_RESIDENZA := TY_RESIDENZA(NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL);
    R_RESIDENZA RC_RESIDENZA := RC_RESIDENZA();
    IND         NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_RESIDENZA_INIZIO',Data_Inizio_Proc);
    FOR C_R IN C_RESID LOOP
      T_RESIDENZA.TIPO_RESIDENZA     := C_R.DESCR_TIPO_RESIDENZA;
      T_RESIDENZA.ID_STATO           := NULL;
      T_RESIDENZA.DESC_STATO         := C_R.DESCR_STATO;
      T_RESIDENZA.ID_PROVINCIA       := C_R.COD_PROVINCIA;
      T_RESIDENZA.DESC_COMUNE        := C_R.DESCR_COMUNE;
      T_RESIDENZA.DESC_INDIRIZZO     := C_R.INDIRIZZO;
      T_RESIDENZA.DESC_COMUNE_ESTERO := C_R.DESC_COMUNE_ESTERO;
    
      IND := IND + 1;
      R_RESIDENZA.Extend;
      R_RESIDENZA(IND) := T_RESIDENZA;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_RESIDENZA_FINE',Data_Inizio_Proc);
    AR_SOGGETTO.RESIDENZE := R_RESIDENZA;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_RESIDENZA');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_ULTERIORI_ISTANZE                  --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_ULTERIORI_ISTANZE(AVVO_SIUS_IN IN INP_AVV,
                                    AR_SIUS      IN OUT TY_FASCICOLO_SIUS) IS
  
  BEGIN
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_ULTERIORI_ISTANZE_INIZIO',Data_Inizio_Proc);
  
    SELECT /*+ optimizer_features_enable('12.1.0.2') */
     DECODE(COUNT(ULTERIORE_ISTANZA.ID_ULTERIORE_ISTANZA), 0, 'N', 'S')
      INTO AR_SIUS.DESC_ULTER_ISTANZE
      FROM ULTERIORE_ISTANZA
     INNER JOIN CG_REF_CODES OGGETTO_PROCEDIMENTO
        ON OGGETTO_PROCEDIMENTO.RV_DOMAIN = 'OGGETTO_PROCEDIMENTO'
       AND OGGETTO_PROCEDIMENTO.RV_LOW_VALUE =
           ULTERIORE_ISTANZA.COD_OGGETTO_PROCEDIMENTO
     INNER JOIN CG_REF_CODES TIPO_ATTO
        ON TIPO_ATTO.RV_DOMAIN = 'TIPO_ATTO'
       AND TIPO_ATTO.RV_LOW_VALUE = ULTERIORE_ISTANZA.COD_TIPO_ATTO
     INNER JOIN CG_REF_CODES MITTENTE_ATTO
        ON MITTENTE_ATTO.RV_DOMAIN = 'MITTENTE_ATTO'
       AND MITTENTE_ATTO.RV_LOW_VALUE =
           ULTERIORE_ISTANZA.COD_TIPO_MITTENTE_ATTO
     INNER JOIN COMUNE SEDE_MITTENTE
        ON SEDE_MITTENTE.COD_COMUNE = ULTERIORE_ISTANZA.SEDE_MITTENTE
     WHERE FAS_SIU_ID_FASCICOLO_SIUS = AR_SIUS.ID_FASC_SIUS;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_ULTERIORI_ISTANZE_FINE',Data_Inizio_Proc);
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_ULTERIORI_ISTANZE');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_UDIENZA                            --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_UDIENZA(AVVO_SIUS_IN IN INP_AVV,
                          ID_UDI       IN UDIENZA.ID_UDIENZA%TYPE,
                          ID_GP        IN GENERALE_PROCEDIMENTO.ID_GENERALE_PROCEDIMENTO%TYPE,
                          AR_SIUS      IN OUT TY_FASCICOLO_SIUS) IS
  
  BEGIN
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_UDIENZA_INIZIO',Data_Inizio_Proc);
    SELECT /*+ optimizer_features_enable('12.1.0.2') */
    DISTINCT UDI.DATA_UDIENZA,
             GP.DATA_CAMERA_CONSIGLIO,
             UP.FLAG_RINVIATA FLAG_RINVIATA, --UP.FLAG_RINVIATA,
             (PRES.COGNOME || '  ' || PRES.NOME) AS DESC_PRES
      INTO AR_SIUS.UDIENZA.DATA_UDIENZA,
           AR_SIUS.UDIENZA.DATA_CAMERA_CONSIGLIO,
           AR_SIUS.UDIENZA.FLAG_RINVIATA,
           AR_SIUS.UDIENZA.DESC_PRESIDENTE
      FROM UDIENZA                UDI,
           MAGISTRATO             PRES,
           MAGISTRATO             GIU1,
           MAGISTRATO             GIU2,
           MAGISTRATO             PROC,
           ESPERTO                ESP1,
           ESPERTO                ESP2,
           ASSISTENTE_GIUDIZIARIO ASS,
           GENERALE_PROCEDIMENTO  GP,
           UDIENZA_PROCEDIMENTO   UP,
           -- Ticket#20210525019 � SIES 12.4.10.0 collegato a SIUS Avvocati ed al ticket 202105030111 - URGENTE
           -- estraggo data udienza <=> evento � validato
           EVENTO EV
     WHERE UDI.COD_GIUDICE_1 = GIU1.COD_MAGISTRATO(+)
       AND UDI.COD_GIUDICE_2 = GIU2.COD_MAGISTRATO(+)
       AND UDI.COD_PRESIDENTE = PRES.COD_MAGISTRATO(+)
       AND PRES.COD_UFFICIO_APPARTENENZA(+) = UDI.COD_UFFICIO_APPARTENENZA
       AND UDI.COD_PG = PROC.COD_MAGISTRATO(+)
       AND UDI.COD_ID_ASSISTENTE = ASS.ID_ASSISTENTE_GIUDIZIARIO(+)
       AND UDI.COD_ID_ESPERTO_1 = ESP1.ID_ESPERTO
       AND UDI.COD_ID_ESPERTO_2 = ESP2.ID_ESPERTO
       AND UDI.ID_UDIENZA = ID_UDI
       AND GP.ID_GENERALE_PROCEDIMENTO = ID_GP
       AND UDI.ID_UDIENZA = GP.UDI_ID_UDIENZA
       AND up.data_aggiornamento IS NULL
       AND UP.GEN_PRID_GENERALE_PROCEDIMENTO = gp.id_generale_procedimento
       AND UP.UDI_ID_UDIENZA = UDI.ID_UDIENZA
          -- Ticket#20210525019: aggiunte and condition
       AND EV.ID_EVENTO = UP.EVE_ID_EVENTO
       AND EV.FLAG_DOCUMENTO_REGISTRATO = 'S';
  
  EXCEPTION
    WHEN no_data_found THEN
      AR_SIUS.UDIENZA.DATA_UDIENZA          := NULL;
      AR_SIUS.UDIENZA.DATA_CAMERA_CONSIGLIO := NULL;
      AR_SIUS.UDIENZA.FLAG_RINVIATA         := NULL;
      AR_SIUS.UDIENZA.DESC_PRESIDENTE       := NULL;
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_UDIENZA');
      RAISE ECCEZIONE;
      --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_UDIENZA_FINE',Data_Inizio_Proc);
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_FASCICOLO_SIEP                     --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_FASCICOLO_SIEP(AVVO_SIUS_IN IN INP_AVV,
                                 ID_SIEP      IN FASCICOLO_SIEP.ID_FASCICOLO_SIEP%TYPE,
                                 AR_FASCICOLO IN OUT TY_FASCICOLO_SIEP) IS
  
  BEGIN
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASCICOLO_SIEP_1_INIZIO',Data_Inizio_Proc);
  
    BEGIN
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
      DISTINCT FASC.CHIAVE_ANNO,
               FASC.CHIAVE_PROGR,
               DECODE(FASC.Flag_Cumulante, 'S', '*CUMULO*'),
               DESCR_TIPO_UFF.RV_MEANING DESCR_TIPO_UFFICIO,
               DESCR_COM_UFF.DESCRIZIONE DESCR_COMUNE_UFFICIO,
               FASC.DATA_ISCRIZIONE,
               POS_GIU.RV_MEANING DESCR_POSIZIONE_GIURIDICA,
               SEN.ID_SENTENZA,
               SEN.ANNO_SENTENZA,
               SEN.NUMERO_SENTENZA,
               SEN.DATA_PROVVEDIMENTO,
               TIPO_AUTORITA_EMITTENTE.RV_MEANING DESCR_TIPO_AUTORITA_EMITTENTE
        INTO AR_FASCICOLO.CHIAVE_ANNO,
             AR_FASCICOLO.CHIAVE_PROG,
             AR_FASCICOLO.DESC_CUMULO,
             AR_FASCICOLO.DESC_TIPO_UFFICIO,
             AR_FASCICOLO.DESC_COMUNE_UFFICIO,
             AR_FASCICOLO.DATA_ISCRIZIONE,
             AR_FASCICOLO.DESC_POS_GIURIDICA,
             AR_FASCICOLO.SENTENZA.ID_SENTENZA,
             AR_FASCICOLO.SENTENZA.ANNO_SENTENZA,
             AR_FASCICOLO.SENTENZA.NUME_SENTENZA,
             AR_FASCICOLO.SENTENZA.DATA_PROVVEDIMENTO,
             AR_FASCICOLO.SENTENZA.DESC_AUTOR_EMIT
        FROM SENTENZA            SEN,
             CG_REF_CODES        TIPO_AUTORITA_EMITTENTE,
             COMUNE              LUOGO_EMITTENTE,
             POSIZIONE_GIURIDICA,
             CG_REF_CODES        POS_GIU,
             FASCICOLO_SIEP      FASC
        LEFT OUTER JOIN UFFICIO UFF
          ON (FASC.CHIAVE_UFFICIO = UFF.COD_UFFICIO)
        LEFT OUTER JOIN CG_REF_CODES DESCR_TIPO_UFF
          ON (UFF.COD_TIPO_UFFICIO = DESCR_TIPO_UFF.RV_LOW_VALUE AND
             DESCR_TIPO_UFF.RV_DOMAIN = 'TIPO_UFFICIO')
        LEFT OUTER JOIN COMUNE DESCR_COM_UFF
          ON (UFF.COD_COMUNE = DESCR_COM_UFF.COD_COMUNE)
        LEFT OUTER JOIN UFFICIO UFFUNIONE
          ON (FASC.COD_UFFICIO_UNIONE = UFFUNIONE.COD_UFFICIO)
        LEFT OUTER JOIN CG_REF_CODES DESCR_TIPO_UFFUNIONE
          ON (UFFUNIONE.COD_TIPO_UFFICIO =
             DESCR_TIPO_UFFUNIONE.RV_LOW_VALUE AND
             DESCR_TIPO_UFFUNIONE.RV_DOMAIN = 'TIPO_UFFICIO')
        LEFT OUTER JOIN COMUNE DESCR_COM_UFFUNIONE
          ON (UFFUNIONE.COD_COMUNE = DESCR_COM_UFFUNIONE.COD_COMUNE)
        LEFT OUTER JOIN CG_REF_CODES STATO_FASCICOLO
          ON (FASC.COD_STATO_FASCICOLO = STATO_FASCICOLO.RV_LOW_VALUE AND
             STATO_FASCICOLO.RV_DOMAIN = 'STATO_FASCICOLO')
        LEFT OUTER JOIN CG_REF_CODES MOTIVO_ARCHIVIAZIONE
          ON (FASC.COD_MOTIVO_ARCHIVIAZIONE =
             MOTIVO_ARCHIVIAZIONE.RV_LOW_VALUE AND
             MOTIVO_ARCHIVIAZIONE.RV_DOMAIN = 'MOTIVO_ARCHIVIAZIONE')
        LEFT OUTER JOIN CG_REF_CODES TIPO_POS_LIBERO
          ON (FASC.COD_TIPO_POS_LIBERO = TIPO_POS_LIBERO.RV_LOW_VALUE AND
             TIPO_POS_LIBERO.RV_DOMAIN = 'TIPO_POS_LIBERO')
        LEFT OUTER JOIN UFFICIO UFFINSERIMENTO
          ON (FASC.COD_UFFICIO_INSERIMENTO = UFFINSERIMENTO.COD_UFFICIO)
        LEFT OUTER JOIN CG_REF_CODES DESCR_TIPO_UFFINSERIMENTO
          ON (UFFINSERIMENTO.COD_TIPO_UFFICIO =
             DESCR_TIPO_UFFINSERIMENTO.RV_LOW_VALUE AND
             DESCR_TIPO_UFFINSERIMENTO.RV_DOMAIN = 'TIPO_UFFICIO')
        LEFT OUTER JOIN COMUNE DESCR_COM_UFFINSERIMENTO
          ON (UFFINSERIMENTO.COD_COMUNE =
             DESCR_COM_UFFINSERIMENTO.COD_COMUNE)
        LEFT OUTER JOIN V_SOGGETTO_ETA VSE
          ON (FASC.ID_FASCICOLO_SIEP = VSE.FAS_SIE_ID_FASCICOLO_SIEP)
       WHERE FASC.ID_FASCICOLO_SIEP IS NOT NULL
         AND ID_FASCICOLO_SIEP = ID_SIEP
         AND SEN.ID_SENTENZA = FASC.SEN_ID_SENTENZA
         AND TIPO_AUTORITA_EMITTENTE.RV_DOMAIN = 'TIPO_UFFICIO'
         AND TIPO_AUTORITA_EMITTENTE.RV_LOW_VALUE =
             SEN.COD_TIPO_AUTORITA_EMITTENTE
         AND LUOGO_EMITTENTE.COD_COMUNE = SEN.COD_LUOGO_EMITTENTE
         AND POS_GIU.RV_DOMAIN = 'POSIZIONE_GIURIDICA'
         AND POS_GIU.RV_LOW_VALUE =
             POSIZIONE_GIURIDICA.COD_POSIZIONE_GIURIDICA
         AND POSIZIONE_GIURIDICA.DATA_INSERIMENTO =
             (SELECT MAX(DATA_INSERIMENTO)
                FROM POSIZIONE_GIURIDICA
               WHERE FAS_SIE_ID_FASCICOLO_SIEP = ID_SIEP);
    
    EXCEPTION
      WHEN no_data_found THEN
        NULL;
    END;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASCICOLO_SIEP_1_FINE',Data_Inizio_Proc);
  
    BEGIN
      ----PENA RESIDUA
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
      DISTINCT DATA_INIZIO,
               DATA_FINE,
               NULL,
               FLAG_ERGASTOLO,
               NUM_ANNI_ISOLAMENTO_DIURNO,
               NUM_MESI_ISOLAMENTO_DIURNO,
               NUM_GIORNI_ISOLAMENTO_DIURNO,
               NUM_ANNI_RECLUSIONE,
               NUM_MESI_RECLUSIONE,
               NUM_GIORNI_RECLUSIONE,
               NUM_ANNI_ARRESTO,
               NUM_MESI_ARRESTO,
               NUM_GIORNI_ARRESTO,
               IMPORTO_MULTA,
               IMPORTO_AMMENDA,
               NULL
        INTO AR_FASCICOLO.PENA_RESIDUA.DATA_INIZIO_PENA,
             AR_FASCICOLO.PENA_RESIDUA.DATA_FINE_PENA,
             AR_FASCICOLO.PENA_RESIDUA.NUME_SANZ_SOST_RES,
             AR_FASCICOLO.PENA_RESIDUA.FLAG_ERGASTOLO,
             AR_FASCICOLO.PENA_RESIDUA.ANNI_ISOL_DIURNO,
             AR_FASCICOLO.PENA_RESIDUA.MESI_ISOL_DIURNO,
             AR_FASCICOLO.PENA_RESIDUA.GIOR_ISOL_DIURNO,
             AR_FASCICOLO.PENA_RESIDUA.ANNI_RECLUSIONE,
             AR_FASCICOLO.PENA_RESIDUA.MESI_RECLUSIONE,
             AR_FASCICOLO.PENA_RESIDUA.GIOR_RECLUSIONE,
             AR_FASCICOLO.PENA_RESIDUA.ANNI_ARRESTO,
             AR_FASCICOLO.PENA_RESIDUA.MESI_ARRESTO,
             AR_FASCICOLO.PENA_RESIDUA.GIOR_ARRESTO,
             AR_FASCICOLO.PENA_RESIDUA.IMPO_MULTA,
             AR_FASCICOLO.PENA_RESIDUA.IMPO_AMMENDA,
             AR_FASCICOLO.PENA_RESIDUA.DESC_PENA_DETENTIVA
        FROM PENA_RESIDUA PR
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = ID_SIEP
         AND FLAG_VALIDATO = 'S'
         AND PR.Data_Inserimento =
             (SELECT MAX(P_R.Data_Inserimento)
                FROM PENA_RESIDUA P_R
               WHERE P_R.FAS_SIE_ID_FASCICOLO_SIEP =
                     PR.FAS_SIE_ID_FASCICOLO_SIEP);
    
    EXCEPTION
      WHEN no_data_found THEN
        NULL;
    END;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASCICOLO_SIEP_2_FINE',Data_Inizio_Proc);
  
    BEGIN
      ----PENA COMPLESSIVA
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
      DISTINCT DATA_INIZIO,
               DATA_FINE,
               NULL,
               NULL,
               NUM_ANNI_ISOLAMENTO_DIURNO,
               NUM_MESI_ISOLAMENTO_DIURNO,
               NUM_GIORNI_ISOLAMENTO_DIURNO,
               NUM_ANNI_RECLUSIONE,
               NUM_MESI_RECLUSIONE,
               NUM_GIORNI_RECLUSIONE,
               NUM_ANNI_ARRESTO,
               NUM_MESI_ARRESTO,
               NUM_GIORNI_ARRESTO,
               IMPORTO_MULTA,
               IMPORTO_AMMENDA,
               PENA_DETENTIVA.RV_MEANING DESCR_PENA_DETENTIVA
        INTO AR_FASCICOLO.PENA_COMPLESSIVA.DATA_INIZIO_PENA,
             AR_FASCICOLO.PENA_COMPLESSIVA.DATA_FINE_PENA,
             AR_FASCICOLO.PENA_COMPLESSIVA.NUME_SANZ_SOST_RES,
             AR_FASCICOLO.PENA_COMPLESSIVA.FLAG_ERGASTOLO,
             AR_FASCICOLO.PENA_COMPLESSIVA.ANNI_ISOL_DIURNO,
             AR_FASCICOLO.PENA_COMPLESSIVA.MESI_ISOL_DIURNO,
             AR_FASCICOLO.PENA_COMPLESSIVA.GIOR_ISOL_DIURNO,
             AR_FASCICOLO.PENA_COMPLESSIVA.ANNI_RECLUSIONE,
             AR_FASCICOLO.PENA_COMPLESSIVA.MESI_RECLUSIONE,
             AR_FASCICOLO.PENA_COMPLESSIVA.GIOR_RECLUSIONE,
             AR_FASCICOLO.PENA_COMPLESSIVA.ANNI_ARRESTO,
             AR_FASCICOLO.PENA_COMPLESSIVA.MESI_ARRESTO,
             AR_FASCICOLO.PENA_COMPLESSIVA.GIOR_ARRESTO,
             AR_FASCICOLO.PENA_COMPLESSIVA.IMPO_MULTA,
             AR_FASCICOLO.PENA_COMPLESSIVA.IMPO_AMMENDA,
             AR_FASCICOLO.PENA_COMPLESSIVA.DESC_PENA_DETENTIVA
        FROM PENA_COMPLESSIVA PC,
             CG_REF_CODES     PENA_DETENTIVA,
             CG_REF_CODES     TIPO_RITO
       WHERE (PENA_DETENTIVA.RV_DOMAIN = 'TIPO_PENA_DETENTIVA' AND
             PC.COD_TIPO_PENA_DETENTIVA = PENA_DETENTIVA.RV_LOW_VALUE)
         AND (TIPO_RITO.RV_DOMAIN = 'TIPO_RITO' AND
             PC.COD_TIPO_RITO = TIPO_RITO.RV_LOW_VALUE)
         AND FAS_SIE_ID_FASCICOLO_SIEP = ID_SIEP
         AND PC.DATA_INSERIMENTO =
             (SELECT MAX(P_C.DATA_INSERIMENTO)
                FROM PENA_COMPLESSIVA P_C
               WHERE P_C.FAS_SIE_ID_FASCICOLO_SIEP =
                     PC.FAS_SIE_ID_FASCICOLO_SIEP);
    EXCEPTION
      WHEN no_data_found THEN
        NULL;
    END;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASCICOLO_SIEP_3_FINE',Data_Inizio_Proc);
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_FASCICOLO_SIEP');
      RAISE ECCEZIONE;
    
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_OGGETTO                            --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_OGGETTO(AVVO_SIUS_IN  IN INP_AVV,
                          G_P           GENERALE_PROCEDIMENTO.ID_GENERALE_PROCEDIMENTO%TYPE,
                          T_OGGETTO_OUT IN OUT rc_oggetto) IS
  
    CURSOR C_OGGETTO IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       TEN.NOTE NOTE, OGGETTO_TENORE.RV_MEANING DESC_OGGETTO_TENORE
        FROM TENORE                TEN,
             GENERALE_PROCEDIMENTO GP,
             CG_REF_CODES          OGGETTO_TENORE,
             CG_REF_CODES          DETTAGLIO_OGGETTO,
             CG_REF_CODES          ESITO,
             UFFICIO               UFF,
             COMUNE                DESCR_COM_UFF
       WHERE (TEN.GEN_PRID_GENERALE_PROCEDIMENTO =
             GP.ID_GENERALE_PROCEDIMENTO)
         AND (OGGETTO_TENORE.RV_LOW_VALUE = COD_OGGETTO_TENORE)
         AND (OGGETTO_TENORE.RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO')
         AND (DETTAGLIO_OGGETTO.RV_LOW_VALUE = COD_DETTAGLIO_OGGETTO)
         AND (DETTAGLIO_OGGETTO.RV_DOMAIN = 'DETTAGLIO_MOTIVO')
         AND (UFF.COD_COMUNE = DESCR_COM_UFF.COD_COMUNE AND
             TEN.COD_UFFICIO_INSERIMENTO = UFF.COD_UFFICIO)
         AND (ESITO.RV_LOW_VALUE = COD_ESITO_TENORE)
         AND (ESITO.RV_DOMAIN = 'ESITO_PROVVEDIMENTO')
         AND DATA_FINE IS NULL
         AND GEN_PRID_GENERALE_PROCEDIMENTO = G_P
       ORDER BY COD_ESITO_TENORE DESC;
  
    T_OGGETTO TY_OGGETTO := TY_OGGETTO(NULL, NULL);
    R_OGGETTO RC_OGGETTO := RC_OGGETTO();
    IND       NUMBER;
  
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_OGGETTO_INIZIO',Data_Inizio_Proc);
  
    FOR C_O IN C_OGGETTO LOOP
      T_OGGETTO.DESC_OGGETTO := C_O.DESC_OGGETTO_TENORE;
      T_OGGETTO.NOTE         := C_O.NOTE;
    
      IND := IND + 1;
      R_OGGETTO.Extend;
      R_OGGETTO(IND) := T_OGGETTO;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_OGGETTO_FINE',Data_Inizio_Proc);
  
    T_OGGETTO_OUT := R_OGGETTO;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_OGGETTO');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_OGGETTO_STRALCIATO                 --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_OGGETTO_STRALCIATO(AVVO_SIUS_IN    IN INP_AVV,
                                     ID_FAS_SIUS     IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                                     T_OGGETTO_S_OUT IN OUT rc_oggetto) IS
  
    CURSOR C_OGGETTO IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       TEN.NOTE NOTE, OGGETTO_TENORE.RV_MEANING DESC_OGGETTO_TENORE
        FROM TENORE                TEN,
             GENERALE_PROCEDIMENTO GP,
             CG_REF_CODES          OGGETTO_TENORE,
             CG_REF_CODES          ESITO,
             UFFICIO               UFF,
             COMUNE                DESCR_COM_UFF,
             CG_REF_CODES          PESO_TENORE,
             CG_REF_CODES          DETTAGLIO_OGGETTO
       WHERE (TEN.GEN_PRID_GENERALE_PROCEDIMENTO =
             GP.ID_GENERALE_PROCEDIMENTO)
         AND (OGGETTO_TENORE.RV_LOW_VALUE = COD_OGGETTO_TENORE)
         AND (OGGETTO_TENORE.RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO')
         AND (DETTAGLIO_OGGETTO.RV_LOW_VALUE = COD_DETTAGLIO_OGGETTO)
         AND (DETTAGLIO_OGGETTO.RV_DOMAIN = 'DETTAGLIO_MOTIVO')
         AND (UFF.COD_COMUNE = DESCR_COM_UFF.COD_COMUNE AND
             TEN.COD_UFFICIO_INSERIMENTO = UFF.COD_UFFICIO)
         AND (ESITO.RV_LOW_VALUE = COD_ESITO_TENORE)
         AND (ESITO.RV_DOMAIN = 'ESITO_PROVVEDIMENTO')
         AND (PESO_TENORE.RV_DOMAIN = 'PESO_ESITO_TENORE' AND
             PESO_TENORE.RV_LOW_VALUE = COD_ESITO_TENORE)
         AND GEN_PRID_GENERALE_PROCEDIMENTO = ID_GENERALE_PROCEDIMENTO
         AND DATA_FINE IS NOT NULL
         AND COD_ESITO_TENORE = '0604'
         AND FAS_SIU_ID_FASCICOLO_SIUS = ID_FAS_SIUS
       ORDER BY PESO_TENORE.RV_HIGH_VALUE, TEN.COD_OGGETTO_TENORE;
  
    T_OGGETTO TY_OGGETTO := TY_OGGETTO(NULL, NULL);
    R_OGGETTO RC_OGGETTO := RC_OGGETTO();
    IND       NUMBER;
  
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_OGGETTO_STRALCIATO_INIZIO',Data_Inizio_Proc);
  
    FOR C_O IN C_OGGETTO LOOP
      T_OGGETTO.DESC_OGGETTO := C_O.DESC_OGGETTO_TENORE;
      T_OGGETTO.NOTE         := C_O.NOTE;
    
      IND := IND + 1;
      R_OGGETTO.Extend;
      R_OGGETTO(IND) := T_OGGETTO;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_OGGETTO_STRALCIATO_FINE',Data_Inizio_Proc);
  
    T_OGGETTO_S_OUT := R_OGGETTO;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_OGGETTO_STRALCIATO');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_OGGETTO_STRALCIATO                 --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_NOTE(AVVO_SIUS_IN IN INP_AVV,
                       AR_SIUS      IN OUT TY_FASCICOLO_SIUS,
                       ID_GP        GENERALE_PROCEDIMENTO.ID_GENERALE_PROCEDIMENTO%TYPE) IS
  
    CURSOR C_NOTE IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       trunc(DATA) DT_NOTE, DESCRIZIONE
        FROM NOTE
       WHERE FAS_SIU_ID_FASCICOLO_SIUS = AR_SIUS.ID_FASC_SIUS
      UNION
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       GP.DATA_ANNOTAZIONE, GP.ANNOTAZIONE
        FROM generale_procedimento GP
       WHERE GP.ID_GENERALE_PROCEDIMENTO = ID_GP
       ORDER BY 1;
  
    T_NOTE TY_LISTA_NOTE := TY_LISTA_NOTE(NULL, NULL);
    R_NOTE RC_LISTA_NOTE := RC_LISTA_NOTE();
    IND    NUMBER;
  
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_NOTE_INIZIO',Data_Inizio_Proc);
  
    FOR C_N IN C_NOTE LOOP
      T_NOTE.DATA_NOTE  := C_N.DT_NOTE;
      T_NOTE.DESCR_NOTE := C_N.DESCRIZIONE;
    
      IND := IND + 1;
      R_NOTE.Extend;
      R_NOTE(IND) := T_NOTE;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_NOTE_FINE',Data_Inizio_Proc);
  
    AR_SIUS.NOTE := R_NOTE;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300), AVVO_SIUS_IN, 'CERCA_NOTE');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_RIFERIMENTI_FASC_SIEP                          --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_RIFERIMENTI_FASC_SIEP(AVVO_SIUS_IN     IN INP_AVV,
                                        ID_SIUS          IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                                        AR_RIF_FASC_SIEP OUT RC_RIFER_SIEP) IS
  
    CURSOR C_RFS IS
    
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       RFS.ID_RIFERIMENTO_FASCICOLO_SIEP,
       RFS.FLAG_MS_SN,
       ANNO_FASCICOLO_SIEP,
       PROGR_FASCICOLO_SIEP,
       DESCR_TIPO_UFF.RV_MEANING ||
       decode(DESCR_COM_UFF.DESCRIZIONE,
              NULL,
              NULL,
              ' di ' || DESCR_COM_UFF.DESCRIZIONE) DESCR_COMUNE_UFFICIO,
       DATA_PROVVEDIMENTO,
       DESCR_TIPO_PROVV.RV_MEANING DESCR_TIPO_PROVVEDIMENTO,
       DESCR_AUTORITA_EMIT.RV_MEANING DESCR_AUTORITA_EMITTENTE,
       DESCR_LUOGO_EMIT.DESCRIZIONE DESCR_LUOGO_EMITTENTE,
       DATA_IRREVOCABILITA,
       ANNO_PROVVEDIMENTO,
       NUMERO_PROVVEDIMENTO
        FROM RIFERIMENTO_FASCICOLO_SIEP RFS,
             CG_REF_CODES               DESCR_TIPO_UFF,
             COMUNE                     DESCR_COM_UFF,
             UFFICIO                    UFF,
             CG_REF_CODES               DESCR_TIPO_PROVV,
             COMUNE                     DESCR_LUOGO_EMIT,
             CG_REF_CODES               DESCR_AUTORITA_EMIT
       WHERE DESCR_TIPO_UFF.RV_DOMAIN = 'TIPO_UFFICIO'
         AND NVL(UFF.COD_TIPO_UFFICIO, '-') = DESCR_TIPO_UFF.RV_LOW_VALUE
         AND UFF.COD_COMUNE = DESCR_COM_UFF.COD_COMUNE
         AND RFS.COD_UFF_FASCICOLO_SIEP = UFF.COD_UFFICIO
         AND DESCR_TIPO_PROVV.RV_DOMAIN = 'TIPO_PROVVEDIMENTO'
         AND RFS.COD_TIPO_PROVVEDIMENTO = DESCR_TIPO_PROVV.RV_LOW_VALUE
         AND DESCR_AUTORITA_EMIT.RV_DOMAIN = 'TIPO_UFFICIO'
         AND RFS.COD_TIPO_AUTORITA_EMITTENTE =
             DESCR_AUTORITA_EMIT.RV_LOW_VALUE
         AND RFS.COD_LUOGO_EMITTENTE = DESCR_LUOGO_EMIT.COD_COMUNE
         AND RFS.FAS_SIU_ID_FASCICOLO_SIUS = ID_SIUS;
  
    T_RIFER_SIEP TY_RIFER_SIEP := TY_RIFER_SIEP(NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL);
    R_RIFER_SIEP RC_RIFER_SIEP := RC_RIFER_SIEP();
    IND          NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_RIFERIMENTI_FASC_SIEP_INIZIO',Data_Inizio_Proc);
  
    FOR C_R IN C_RFS LOOP
    
      T_RIFER_SIEP.ID_RIF_FASC_SIEP     := C_R.ID_RIFERIMENTO_FASCICOLO_SIEP;
      T_RIFER_SIEP.FLAG_MS              := C_R.FLAG_MS_SN;
      T_RIFER_SIEP.CHIAVE_ANNO          := C_R.ANNO_FASCICOLO_SIEP;
      T_RIFER_SIEP.CHIAVE_PROG          := C_R.PROGR_FASCICOLO_SIEP;
      T_RIFER_SIEP.DESC_TIPO_UFFICIO    := C_R.DESCR_COMUNE_UFFICIO;
      T_RIFER_SIEP.DATA_PROVVEDIMENTO   := C_R.DATA_PROVVEDIMENTO;
      T_RIFER_SIEP.DESC_TIPO_PROVV      := C_R.DESCR_TIPO_PROVVEDIMENTO;
      T_RIFER_SIEP.DESC_TIPO_AUTOR_EMIT := C_R.DESCR_AUTORITA_EMITTENTE;
      T_RIFER_SIEP.DESC_LUOGO_AUT_EMIT  := C_R.DESCR_LUOGO_EMITTENTE;
      T_RIFER_SIEP.DATA_IRREV           := C_R.DATA_IRREVOCABILITA;
      T_RIFER_SIEP.ANNO_PROV            := C_R.ANNO_PROVVEDIMENTO;
      T_RIFER_SIEP.NUME_PROV            := C_R.NUMERO_PROVVEDIMENTO;
    
      IND := IND + 1;
      R_RIFER_SIEP.Extend;
      R_RIFER_SIEP(IND) := T_RIFER_SIEP;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_RIFERIMENTI_FASC_SIEP_INIZIO',Data_Inizio_Proc);
  
    AR_RIF_FASC_SIEP := R_RIFER_SIEP;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_RIFERIMENTI_FASC_SIEP');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_AVVOCATI                           --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_AVVOCATI(AVVO_SIUS_IN IN INP_AVV,
                           ID_SIUS      IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                           AR_AVVOCATI  OUT RC_AVVOCATO) IS
  
    CURSOR C_AVV IS
    
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       COGNOME,
       NOME,
       FORO,
       FLAG_VISUALIZZA,
       FLAG_CANCELLATO,
       AVVTIPODESC.RV_MEANING DESCRTIPO,
       AVVOCATO.COD_FISCALE
        FROM AVVOCATO,
             AVVOCATO_FASCICOLO_SIUS,
             CG_REF_CODES            AVVTIPODESC,
             CG_REF_CODES            AVVTIPODESCMOTIVO,
             CG_REF_CODES            AVVTIPODESCAUTORITA,
             CG_REF_CODES            AVVTIPODESCAUTORITADIF,
             COMUNE                  COMNA,
             COMUNE                  COMRES,
             COMUNE                  COMSEDE,
             COMUNE                  COMSEDEDIF
       WHERE AVVOCATO.ID_AVVOCATO = AVVOCATO_FASCICOLO_SIUS.AVV_ID_AVVOCATO
         AND AVVTIPODESC.RV_LOW_VALUE =
             AVVOCATO_FASCICOLO_SIUS.COD_TIPO_AVVOCATO
         AND AVVTIPODESC.RV_DOMAIN = 'TIPO_AVVOCATO'
         AND AVVTIPODESCMOTIVO.RV_LOW_VALUE =
             AVVOCATO_FASCICOLO_SIUS.COD_MOTIVO_DESIGNAZIONE
         AND AVVTIPODESCMOTIVO.RV_DOMAIN = 'MOTIVO_DESIGNAZIONE'
         AND AVVTIPODESCAUTORITA.RV_LOW_VALUE =
             AVVOCATO_FASCICOLO_SIUS.COD_TIPO_AUTORITA
         AND AVVTIPODESCAUTORITA.RV_DOMAIN = 'TIPO_AUTORITA'
         AND AVVTIPODESCAUTORITADIF.RV_LOW_VALUE =
             AVVOCATO_FASCICOLO_SIUS.COD_TIPO_AUTORITA_DIF
         AND AVVTIPODESCAUTORITADIF.RV_DOMAIN = 'TIPO_AUTORITA'
         AND AVVOCATO.COD_LUOGO_NASCITA = COMNA.COD_COMUNE
         AND AVVOCATO.COD_COMUNE_RESIDENZA = COMRES.COD_COMUNE
         AND AVVOCATO_FASCICOLO_SIUS.SEDE_TIPO_AUTORITA =
             COMSEDE.COD_COMUNE
         AND AVVOCATO_FASCICOLO_SIUS.SEDE_TIPO_AUTORITA_DIF =
             COMSEDEDIF.COD_COMUNE
         AND DATA_FINE_VALIDITA IS NULL
         AND FAS_SIU_ID_FASCICOLO_SIUS = ID_SIUS
       ORDER BY ID_AVVOCATO ASC;
  
    T_AVVOCATO TY_AVVOCATO := TY_AVVOCATO(NULL, NULL, NULL, NULL, NULL);
    R_AVVOCATO RC_AVVOCATO := RC_AVVOCATO();
    IND        NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_AVVOCATI_INIZIO',Data_Inizio_Proc);
  
    FOR C_A IN C_AVV LOOP
    
      T_AVVOCATO.DESC_FORO   := C_A.FORO;
      T_AVVOCATO.COGNOME     := C_A.Cognome;
      T_AVVOCATO.NOME        := C_A.NOME;
      T_AVVOCATO.DESC_TIPO   := C_A.DESCRTIPO;
      T_AVVOCATO.COD_FISCALE := C_A.COD_FISCALE;
    
      IND := IND + 1;
      R_AVVOCATO.Extend;
      R_AVVOCATO(IND) := T_AVVOCATO;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_AVVOCATI_FINE',Data_Inizio_Proc);
  
    AR_AVVOCATI := R_AVVOCATO;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_AVVOCATI');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_MOVIMENTI_UDIENZA                  --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_MOVIMENTI_UDIENZA(AVVO_SIUS_IN IN INP_AVV,
                                    ID_GP        IN GENERALE_PROCEDIMENTO.ID_GENERALE_PROCEDIMENTO%TYPE,
                                    AR_UDIENZA   OUT RC_UDIENZA) IS
  
    CURSOR C_GEN_PROC IS
    
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       DATA_UDIENZA,
       CASE
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'F' THEN
          'FISSAZIONE'
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'P' THEN
          'PREFISSAZIONE'
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'M' AND
              UDIENZA_PROCEDIMENTO.EVE_ID_EVENTO IS NOT NULL THEN
          'FISSAZIONE E POI MODIFICA'
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'M' AND
              UDIENZA_PROCEDIMENTO.EVE_ID_EVENTO IS NULL THEN
          'PREFISSAZIONE E POI MODIFICA'
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'A' THEN
          'ANNULLAMENTO'
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'R' THEN
          'RINVIO'
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'S' THEN
          'FISSAZIONE A SEGUITO RINVIO'
         WHEN UDIENZA_PROCEDIMENTO.FLAG_RINVIATA = 'N' THEN
          'NUOVO RUOLO'
       END FLAG_RINV,
       --decode(UDIENZA_PROCEDIMENTO.FLAG_RINVIATA,'F','FISSAZIONE','P','PREFISSATA') FLAG_RINV,
       --UDIENZA_PROCEDIMENTO.FLAG_RINVIATA FLAG_RINV,
       UDIENZA_PROCEDIMENTO.DATA_INSERIMENTO,
       UDIENZA_PROCEDIMENTO.Data_Aggiornamento
        FROM UDIENZA_PROCEDIMENTO
       INNER JOIN UDIENZA
          ON ID_UDIENZA = UDI_ID_UDIENZA
      -- Ticket#20210525019 � SIES 12.4.10.0 collegato a SIUS Avvocati ed al ticket 202105030111 - URGENTE
      -- aggiunta inner join l'evento di fissazione udienza deve essere validato
       INNER JOIN EVENTO
          ON ID_EVENTO = UDIENZA_PROCEDIMENTO.EVE_ID_EVENTO
         AND FLAG_DOCUMENTO_REGISTRATO = 'S'
       WHERE GEN_PRID_GENERALE_PROCEDIMENTO = ID_GP
       ORDER BY DATA_INSERIMENTO ASC;
  
    T_UDIENZA TY_UDIENZA := TY_UDIENZA(NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL);
    R_UDIENZA RC_UDIENZA := RC_UDIENZA();
    IND       NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_UDIENZA_INIZIO',Data_Inizio_Proc);
  
    FOR C_GP IN C_GEN_PROC LOOP
    
      T_UDIENZA.DATA_UDIENZA         := C_GP.DATA_UDIENZA;
      T_UDIENZA.DESC_TIPO_OPERAZIONE := C_GP.FLAG_RINV;
      T_UDIENZA.DATA_INSERIMENTO     := C_GP.DATA_INSERIMENTO;
      T_UDIENZA.DATA_MODIFICA        := C_GP.DATA_AGGIORNAMENTO;
    
      IND := IND + 1;
      R_UDIENZA.Extend;
      R_UDIENZA(IND) := T_UDIENZA;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_UDIENZA_FINE',Data_Inizio_Proc);
  
    AR_UDIENZA := R_UDIENZA;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_AVVOCATI');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_OPPOS_IMPUGN                       --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_OPPOS_IMPUGN(AVVO_SIUS_IN IN INP_AVV,
                               ID_SIUS      IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                               T_PROVVE     IN OUT TY_PROVVEDIMENTI) IS
  
    CURSOR C_IMPUGNAZIONI IS
    
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       decode(COD_TIPO_IMPUGNAZIONE, '04', 'O', 'I') Tipo_Imp,
       TIPO_IMPUGNAZIONE.RV_MEANING DESCR_TIPO_IMPUGNAZIONE,
       IMP.DATA_RICORSO
        FROM IMPUGNAZIONE IMP
        JOIN CG_REF_CODES TIPO_IMPUGNAZIONE
          ON (TIPO_IMPUGNAZIONE.RV_DOMAIN = 'TIPO_RICORSO' AND
             TIPO_IMPUGNAZIONE.RV_LOW_VALUE = IMP.COD_TIPO_IMPUGNAZIONE),
       EVENTO EVE, DEPOSITO_ORDINANZA_PC DOP
       WHERE EVE.ID_EVENTO = DOP.ID_EVENTO_GENERATO
         AND DOP.ID_DEPOSITO_ORDINANZA_PC =
             IMP.DEP_OPID_DEPOSITO_ORDINANZA_PC
         AND COD_TIPO_IMPUGNAZIONE in ('01', '02', '03', '04')
         AND eve.fas_siu_id_fascicolo_sius = ID_SIUS
       ORDER BY IMP.DATA_INSERIMENTO;
  
    T_IMPUGNAZIONI TY_IMPUGNAZIONI := TY_IMPUGNAZIONI(NULL, NULL, NULL);
    R_IMPUGNAZIONI RC_IMPUGNAZIONI := RC_IMPUGNAZIONI();
    IND            NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_OPPOS_IMPUGN_INIZIO',Data_Inizio_Proc);
  
    FOR C_I IN C_IMPUGNAZIONI LOOP
    
      T_IMPUGNAZIONI.FLAG_IO                := C_I.TIPO_IMP;
      T_IMPUGNAZIONI.DESC_TIPO_IMPUGNAZIONI := C_I.DESCR_TIPO_IMPUGNAZIONE;
      T_IMPUGNAZIONI.DATA_RISCORSO          := C_I.DATA_RICORSO;
    
      IND := IND + 1;
      R_IMPUGNAZIONI.Extend;
      R_IMPUGNAZIONI(IND) := T_IMPUGNAZIONI;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_OPPOS_IMPUGN_FINE',Data_Inizio_Proc);
  
    IF IND > 0 THEN
      T_PROVVE.ALTRE_INFO := T_PROVVE.ALTRE_INFO || ' - RICORSI';
    END IF;
  
    T_PROVVE.LISTA_OPPOS_IMP := R_IMPUGNAZIONI;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_OPPOS_IMPUGN');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_PROVVEDIMENTI                      --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_PROVVEDIMENTI(AVVO_SIUS_IN     IN INP_AVV,
                                ID_SIUS          IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                                AR_PROVVEDIMENTI IN OUT RC_PROVVEDIMENTI) IS
  
    CURSOR C_PROVVE IS
    
      select *
        from (
              
              SELECT /*+ optimizer_features_enable('12.1.0.2') */
               EVENTO.ID_EVENTO,
                CODTIPPRO.RV_MEANING DESC_TIPO_PRO,
                CODTIPPRO.RV_LOW_VALUE COD_TIPO_PRO,
                CODMOV.RV_MEANING DESC_MOV,
                EVENTO.DATA_EMISSIONE,
                CODESI.RV_MEANING DESC_ESI,
                CASE
                  WHEN do.data_deposito IS NOT NULL THEN
                   do.data_deposito
                  WHEN dd.data_deposito IS NOT NULL THEN
                   dd.data_deposito
                  WHEN ds.data_deposito is NOT NULL THEN
                   ds.data_deposito
                  ELSE
                   NULL
                END Data_Deposito,
                --DECODE(FLAG_DOCUMENTO_REGISTRATO, 'S', 'VALIDATO', 'A', 'ANNULLATO') PROVV_VALIDATO,
                FLAG_DOCUMENTO_REGISTRATO PROVV_VALIDATO,
                CASE
                  WHEN (SELECT COUNT(*)
                          FROM DOCUMENTO_ALLEGATO A
                         WHERE A.FLAG_DOCUMENTO_REGISTRATO = 'S'
                           AND A.EVE_ID_EVENTO = EVENTO.ID_EVENTO) > 0 AND
                       FLAG_DOCUMENTO_REGISTRATO = 'S' THEN
                   'SI'
                  ELSE
                   'NO'
                END DEPOSITO_VALIDATO,
                CASE
                  WHEN (SELECT count(ID_DOCUMENTO_ALLEGATO)
                          FROM DOCUMENTO_ALLEGATO
                          join CG_REF_CODES CODTIPDOC
                            on (DOCUMENTO_ALLEGATO.COD_TIPO_DOCUMENTO =
                               CODTIPDOC.RV_LOW_VALUE and
                               CODTIPDOC.RV_DOMAIN = 'TIPO_DOCUMENTO_ALLEGATO')
                          left outer join CG_REF_CODES CODMOTIVNONINVIO
                            ON (CODMOTIVNONINVIO.RV_LOW_VALUE =
                               DOCUMENTO_ALLEGATO.CODI_MOTIVAZIONE_NON_INVIO and
                               CODMOTIVNONINVIO.RV_DOMAIN =
                               'MOTIVAZIONE_NON_INVIO_FC')
                         WHERE EVE_ID_EVENTO = EVENTO.ID_EVENTO
                           AND COD_TIPO_DOCUMENTO = '06'
                           AND DATA_ANNULLAMENTO IS NULL) > 0 THEN
                   'Emesso Foglio Complementare'
                END FC,
                EVENTO.EVE_ID_EVENTO_REVOCA,
                -- @emma11012018 inizio MEV per recupero il motivo annullamento PER FLAG_DOCUMENTO_REGISTRATO = 'A'
                CASE
                  WHEN (SELECT A.DESCR
                          FROM CAMPO_NOTA A, EVENTO E
                         WHERE E.FLAG_DOCUMENTO_REGISTRATO = 'A'
                           AND A.EVE_ID_EVENTO = E.ID_EVENTO
                           and E.ID_EVENTO = EVENTO.ID_EVENTO) IS NULL THEN
                   ''
                  ELSE
                   ' - Motivo Annullamento: ' ||
                   (SELECT A.DESCR
                      FROM CAMPO_NOTA A, EVENTO E
                     WHERE E.FLAG_DOCUMENTO_REGISTRATO = 'A'
                       AND A.EVE_ID_EVENTO = E.ID_EVENTO
                       and E.ID_EVENTO = EVENTO.ID_EVENTO)
                END MOTIVO_ANNULLAMENTO,
                -- @emma11012018 fine MEV per recupero il motivo annullamento PER FLAG_DOCUMENTO_REGISTRATO = 'A'
                -- @emma09072018 (MEV AVVOCATOURA POST COLLAUDO DELLA 11.1.2)  inserisco in estrazione anche il COD_ESITO
                CODESI.RV_LOW_VALUE COD_ESITO
                FROM EVENTO
                LEFT OUTER JOIN DEPOSITO_ORDINANZA_PC DO
                  ON (DO.ID_EVENTO_GENERATO = EVENTO.ID_EVENTO)
                LEFT OUTER JOIN DEPOSITO_DECRETO DD
                  ON (DD.ID_EVENTO_GENERATO = EVENTO.ID_EVENTO)
                LEFT OUTER JOIN DEPOSITO_SENTENZA DS
                  ON (DS.ID_EVENTO_GENERATO = EVENTO.ID_EVENTO), CG_REF_CODES
               CODESI, CG_REF_CODES CODMOV, UFFICIO UFF_EMI,
               CG_REF_CODES UFF_TIPO_EMI, CG_REF_CODES CODTIPPRO,
               CG_REF_CODES CODEVE, COMUNE LUOEMI, COMUNE LUODES,
               CG_REF_CODES UFF_TIPO_DES
               WHERE EVENTO.COD_TIPO_EVENTO = CODEVE.RV_LOW_VALUE
                 AND CODEVE.RV_DOMAIN = 'TIPO_EVENTO'
                 AND EVENTO.COD_TIPO_PROVVEDIMENTO = CODTIPPRO.RV_LOW_VALUE
                 AND CODTIPPRO.RV_DOMAIN = 'TIPO_PROVVEDIMENTO'
                 AND ((NVL(EVENTO.COD_MOTIVO, '-') = CODMOV.RV_LOW_VALUE AND
                     CODMOV.RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO') OR
                     (EVENTO.COD_MOTIVO = CODMOV.RV_LOW_VALUE AND
                     CODMOV.RV_DOMAIN = 'OGGETTO_PROCEDIMENTO'))
                 AND EVENTO.COD_ESITO = CODESI.RV_LOW_VALUE
                 AND CODESI.RV_DOMAIN = 'ESITO_PROVVEDIMENTO'
                 AND EVENTO.COD_LUOGO_EMITTENTE = LUOEMI.COD_COMUNE
                 AND EVENTO.COD_LUOGO_DESTINATARIO = LUODES.COD_COMUNE
                 AND UFF_EMI.COD_UFFICIO = COD_UFFICIO_EMITTENTE
                 AND UFF_TIPO_EMI.RV_DOMAIN = 'TIPO_UFFICIO'
                 AND UFF_TIPO_EMI.RV_LOW_VALUE = UFF_EMI.COD_TIPO_UFFICIO
                 AND UFF_TIPO_DES.RV_LOW_VALUE =
                     EVENTO.COD_TIPO_UFFICIO_DESTINATARIO
                 AND UFF_TIPO_DES.RV_DOMAIN = 'TIPO_UFFICIO'
                 AND FAS_SIU_ID_FASCICOLO_SIUS = ID_SIUS
                 AND COD_TIPO_EVENTO = '01'
               ORDER BY DATA_EMISSIONE          DESC,
                         EVENTO.DATA_INSERIMENTO DESC,
                         ID_EVENTO               DESC
              -- @emma09072018 (MEV AVVOCATOURA POST COLLAUDO DELLA 11.1.2) :
              -- occorre estrarre solo i provvedimenti con il deposito validato, a meno dei decreti di fissazione udienza
              )
       WHERE (DEPOSITO_VALIDATO = 'SI' OR
             (DEPOSITO_VALIDATO = 'NO' AND COD_ESITO = '0601'))
            -- Ticket#202105030111 - SIUS-avvocati fissazione dell'udienza
            -- il provvedimento deve essere VALIDATO!!!
         AND PROVV_VALIDATO = 'S';
  
    T_PROVVE TY_PROVVEDIMENTI := TY_PROVVEDIMENTI(NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  NULL);
    R_PROVVE RC_PROVVEDIMENTI := RC_PROVVEDIMENTI();
    IND      NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_PROVVEDIMENTI_INIZIO',Data_Inizio_Proc);
  
    FOR C_P IN C_PROVVE LOOP
    
      T_PROVVE.ID_EVENTO              := C_P.ID_EVENTO;
      T_PROVVE.DATA_EMISSIONE         := C_P.DATA_EMISSIONE;
      T_PROVVE.DESC_TIPO_PROVV        := C_P.DESC_TIPO_PRO;
      T_PROVVE.DESC_MOTIVO            := C_P.DESC_MOV;
      T_PROVVE.DESC_ESITO             := C_P.DESC_ESI;
      T_PROVVE.DATA_DEPOSITO          := C_P.DATA_DEPOSITO;
      T_PROVVE.ID_TIPO_PROVV          := C_P.COD_TIPO_PRO;
      T_PROVVE.ID_EVENTO_REVOCA       := C_P.EVE_ID_EVENTO_REVOCA;
      T_PROVVE.FLAG_DOC_REGISTRATO    := C_P.PROVV_VALIDATO;
      T_PROVVE.FLAG_DEPOSITO_VALIDATO := C_P.DEPOSITO_VALIDATO;
      -- @emma11012018 aggiungo il valore c_p.motivo_annullamento
      T_PROVVE.ALTRE_INFO := C_P.FC || c_p.motivo_annullamento;
    
      --LISTA_OPPOSIZIONI_IMPUGNAZIONI
    
      CERCA_OPPOS_IMPUGN(AVVO_SIUS_IN, ID_SIUS, T_PROVVE);
    
      IND := IND + 1;
      R_PROVVE.Extend;
      R_PROVVE(IND) := T_PROVVE;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_PROVVEDIMENTI_FINE',Data_Inizio_Proc);
  
    AR_PROVVEDIMENTI := R_PROVVE;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_PROVVEDIMENTI');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_ALTRI_ATTII                        --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_ALTRI_ATTI(AVVO_SIUS_IN  IN INP_AVV,
                             ID_SIUS       IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                             AR_ALTRI_ATTI IN OUT RC_PROVVEDIMENTI) IS
  
    CURSOR C_ALTRI_ATTI IS
    
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       ID_EVENTO,
       DATA_EMISSIONE,
       CODMOV.RV_ABBREVIATION COD_ABBR,
       CODMOV.RV_MEANING      COD_MOV,
       CODESI.RV_MEANING      COD_ESI
        FROM EVENTO,
             cg_ref_codes CODESI,
             cg_ref_codes CODMOV,
             UFFICIO      UFF_EMI,
             CG_REF_CODES UFF_TIPO_EMI,
             CG_REF_CODES CODTIPPRO,
             CG_REF_CODES CODEVE,
             COMUNE       LUOEMI,
             COMUNE       LUODES,
             CG_REF_CODES UFF_TIPO_DES
       WHERE EVENTO.COD_TIPO_EVENTO = CODEVE.RV_LOW_VALUE
         AND CODEVE.RV_DOMAIN = 'TIPO_EVENTO'
         AND EVENTO.COD_TIPO_EVENTO != '01'
         AND EVENTO.COD_TIPO_EVENTO != '05'
         AND EVENTO.COD_TIPO_PROVVEDIMENTO = CODTIPPRO.RV_LOW_VALUE
         AND CODTIPPRO.RV_DOMAIN = 'TIPO_PROVVEDIMENTO'
         AND EVENTO.COD_MOTIVO = CODMOV.RV_LOW_VALUE
         AND CODMOV.RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO'
         AND EVENTO.COD_ESITO = CODESI.RV_LOW_VALUE
         AND CODESI.RV_DOMAIN = 'ESITO_PROVVEDIMENTO'
         AND EVENTO.COD_LUOGO_EMITTENTE = LUOEMI.COD_COMUNE
         AND EVENTO.COD_LUOGO_DESTINATARIO = LUODES.COD_COMUNE
         AND UFF_EMI.COD_UFFICIO = COD_UFFICIO_EMITTENTE
         AND UFF_TIPO_EMI.RV_DOMAIN = 'TIPO_UFFICIO'
         AND UFF_TIPO_EMI.RV_LOW_VALUE = UFF_EMI.COD_TIPO_UFFICIO
         AND UFF_TIPO_DES.RV_LOW_VALUE =
             EVENTO.COD_TIPO_UFFICIO_DESTINATARIO
         AND UFF_TIPO_DES.RV_DOMAIN = 'TIPO_UFFICIO'
         AND EVENTO.COD_TIPO_EVENTO != '01'
         AND EVENTO.COD_TIPO_EVENTO != '05'
         AND FAS_SIU_ID_FASCICOLO_SIUS = ID_SIUS
       ORDER BY DATA_EMISSIONE DESC;
  
    T_ALTRI_ATTI TY_PROVVEDIMENTI := TY_PROVVEDIMENTI(NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL);
    R_ALTRI_ATTI RC_PROVVEDIMENTI := RC_PROVVEDIMENTI();
    IND          NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_ALTRI_ATTI_INIZIO',Data_Inizio_Proc);
  
    FOR C_AA IN C_ALTRI_ATTI LOOP
    
      T_ALTRI_ATTI.ID_EVENTO       := C_AA.ID_EVENTO;
      T_ALTRI_ATTI.DATA_EMISSIONE  := C_AA.DATA_EMISSIONE;
      T_ALTRI_ATTI.DESC_TIPO_PROVV := C_AA.COD_ABBR;
      T_ALTRI_ATTI.DESC_MOTIVO     := C_AA.COD_MOV;
      T_ALTRI_ATTI.DESC_ESITO      := C_AA.COD_ESI;
    
      IND := IND + 1;
      R_ALTRI_ATTI.Extend;
      R_ALTRI_ATTI(IND) := T_ALTRI_ATTI;
    
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_ALTRI_ATTI_FINE',Data_Inizio_Proc);
  
    AR_ALTRI_ATTI := R_ALTRI_ATTI;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_ALTRI_ATTII');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_ALTRI_ATTII                        --
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_RIC_ISTR(AVVO_SIUS_IN IN INP_AVV,
                           ID_SIUS      IN FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE,
                           AR_RIC_ISTR  IN OUT RC_RICH_ISTR) IS
  
    CURSOR C_RIC_ISTR IS
    
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       CODMOV.RV_MEANING             MOTIVO_EVE,
       N.DATA_INVIO                  DATA_RICHIESTA,
       N.DATA_AVVENUTA_NOTIFICA      DATA_RESTITUZIONE,
       N.UFF_COD_UFFICIO             UFF_COD_UFFICIO,
       N.CSS_ID_CSSA                 CSS_ID_CSSA,
       N.AUT_EST_ID_AUTORITA_ESTERNA AUT_EST
        FROM NOTIFICA     N,
             CG_REF_CODES COD_NOT,
             CG_REF_CODES COD_ESI,
             EVENTO       E,
             CG_REF_CODES CODMOV
       WHERE E.ID_EVENTO = N.EVE_ID_EVENTO
         AND COD_NOT.RV_DOMAIN = 'TIPO_NOTIFICA'
         AND COD_NOT.RV_LOW_VALUE = N.COD_TIPO_NOTIFICA
         AND COD_ESI.RV_DOMAIN = 'ESITO_NOTIFICA'
         AND COD_ESI.RV_LOW_VALUE = N.COD_ESITO
         AND E.COD_MOTIVO = CODMOV.RV_LOW_VALUE
         AND CODMOV.RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO'
         AND E.FAS_SIU_ID_FASCICOLO_SIUS = ID_SIUS
         AND E.COD_TIPO_EVENTO = '05'
       ORDER BY DATA_INVIO DESC;
  
    T_RICH_ISTR TY_RICH_ISTR := TY_RICH_ISTR(NULL, NULL, NULL, NULL);
    R_RICH_ISTR RC_RICH_ISTR := RC_RICH_ISTR();
  
    IND NUMBER;
  BEGIN
  
    IND := 0;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_RIC_ISTR_INIZIO',Data_Inizio_Proc);
  
    FOR C_RI IN C_RIC_ISTR LOOP
    
      T_RICH_ISTR.DESC_NOTIFICA          := C_RI.MOTIVO_EVE;
      T_RICH_ISTR.DATA_INVIO             := C_RI.DATA_RICHIESTA;
      T_RICH_ISTR.DATA_AVVENUTA_NOTIFICA := C_RI.DATA_RESTITUZIONE;
    
      IF C_RI.AUT_EST IS NOT NULL THEN
        BEGIN
          SELECT /*+ optimizer_features_enable('12.1.0.2') */
           COD.RV_MEANING || ' DI ' || COM.DESCRIZIONE DESC_AUT
            INTO T_RICH_ISTR.DESC_DESTINATARIO
            FROM AUTORITA_ESTERNA AUT, CG_REF_CODES COD, COMUNE COM
           WHERE COD.RV_DOMAIN = 'TIPO_AUTORITA'
             AND COD.RV_LOW_VALUE = COD_TIPO_AUTORITA
             AND COM.COD_COMUNE = COD_SEDE
             AND ID_AUTORITA_ESTERNA = C_RI.AUT_EST
          UNION
          SELECT /*+ optimizer_features_enable('12.1.0.2') */
           COD.RV_MEANING || ' DI ' || SEDE.RV_MEANING DESC_AUT
            FROM AUTORITA_ESTERNA AUT, CG_REF_CODES COD, CG_REF_CODES SEDE
           WHERE COD.RV_DOMAIN = 'TIPO_AUTORITA'
             AND COD.RV_LOW_VALUE = COD_TIPO_AUTORITA
             AND SEDE.RV_DOMAIN = 'NAZIONE'
             AND SEDE.RV_LOW_VALUE = COD_SEDE
             AND ID_AUTORITA_ESTERNA = C_RI.AUT_EST;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            T_RICH_ISTR.DESC_DESTINATARIO := NULL;
        END;
      END IF;
      IF T_RICH_ISTR.DESC_DESTINATARIO IS NULL THEN
        IF C_RI.CSS_ID_CSSA IS NOT NULL THEN
          BEGIN
            SELECT TIPO || ' - ' || INDIRIZZO || ' - ' || COMUNE
              INTO T_RICH_ISTR.DESC_DESTINATARIO
              FROM CSSA
             WHERE ID_CSSA = C_RI.CSS_ID_CSSA;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              T_RICH_ISTR.DESC_DESTINATARIO := NULL;
          END;
        END IF;
      END IF;
      IF T_RICH_ISTR.DESC_DESTINATARIO IS NULL THEN
        IF C_RI.UFF_COD_UFFICIO IS NOT NULL THEN
          BEGIN
            SELECT /*+ optimizer_features_enable('12.1.0.2') */
             DESC_TIPO_UFFICIO.RV_MEANING || ' DI ' ||
             DESC_PROVINCIA.RV_MEANING DESC_TIPO_UFFICIO
              INTO T_RICH_ISTR.DESC_DESTINATARIO
              FROM UFFICIO      UFF,
                   COMUNE       COM,
                   CG_REF_CODES DESC_PROVINCIA,
                   CG_REF_CODES DESC_TIPO_UFFICIO
             WHERE (UFF.COD_UFFICIO = C_RI.UFF_COD_UFFICIO)
               AND (COM.COD_COMUNE = UFF.COD_COMUNE)
               AND (DESC_PROVINCIA.RV_DOMAIN = 'PROVINCIA' AND
                   UFF.COD_PROVINCIA = DESC_PROVINCIA.RV_LOW_VALUE)
               AND (DESC_TIPO_UFFICIO.RV_DOMAIN = 'TIPO_UFFICIO' AND
                   UFF.COD_TIPO_UFFICIO = DESC_TIPO_UFFICIO.RV_LOW_VALUE);
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              T_RICH_ISTR.DESC_DESTINATARIO := NULL;
          END;
        END IF;
      END IF;
    
      IND := IND + 1;
      R_RICH_ISTR.Extend;
      R_RICH_ISTR(IND) := T_RICH_ISTR;
      T_RICH_ISTR := TY_RICH_ISTR(NULL, NULL, NULL, NULL);
    END LOOP;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_RIC_ISTR_FINE',Data_Inizio_Proc);
  
    AR_RIC_ISTR := R_RICH_ISTR;
  
  EXCEPTION
    WHEN OTHERS THEN
      GESTISCI_ERRORE(SUBSTR(SQLERRM, 1, 300),
                      AVVO_SIUS_IN,
                      'CERCA_RIC_ISTR');
      RAISE ECCEZIONE;
  END;

  --///////////////**********************************************//////////////
  --                      PROCEDURE CERCA_FASIUS_PER_ESTREMI
  --///////////////**********************************************//////////////

  PROCEDURE CERCA_FASIUS_PER_ESTREMI(AVVO_SIUS_IN         IN INP_AVV,
                                     T_FASCICOLO_SIUS_OUT OUT TY_FASCICOLO_SIUS,
                                     T_RIF_FASC_SIEP_OUT  OUT RC_RIFER_SIEP,
                                     T_AVVOCATI_OUT       OUT RC_AVVOCATO,
                                     T_UDIENZA_OUT        OUT RC_UDIENZA,
                                     T_PROVVEDIMENTI_OUT  OUT RC_PROVVEDIMENTI,
                                     T_ALTRI_ATTI_OUT     OUT RC_PROVVEDIMENTI,
                                     T_RIC_ISTR_OUT       OUT RC_RICH_ISTR,
                                     T_SOGGETTO           OUT TY_SOGGETTO,
                                     T_FASCICOLO_SIEP     OUT TY_FASCICOLO_SIEP,
                                     T_ATTO               OUT TY_ATTO,
                                     T_OGGETTO            OUT RC_OGGETTO,
                                     T_OGGETTO_STRALCIATO OUT RC_OGGETTO,
                                     ERR                  OUT VARCHAR2,
                                     DESC_ERRORE          OUT VARCHAR2) IS
  
    CURSOR C_FSIUS IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
      DISTINCT GP.ID_GENERALE_PROCEDIMENTO,
               FASC.ID_FASCICOLO_SIUS ID_FASCICOLO_SIUS,
               FASC.FAS_SIE_ID_FASCICOLO_SIEP ID_FASCICOLO_SIEP,
               FASC.CHIAVE_ANNO CHIAVE_ANNO,
               FASC.DATA_ISCRIZIONE DATA_ISCRIZIONE,
               FASC.CHIAVE_PROGR CHIAVE_PROGR,
               SOGG.ID_SOGGETTO ID_SOGGETTO,
               SOGG.COGNOME COGNOME,
               SOGG.NOME NOME,
               to_char(SOGG.DATA_NASCITA, 'dd/mm/yyyy') DATA_NASCITA,
               decode(DESCR_COM_NASCITA.DESCRIZIONE,
                      NULL,
                      DESC_COMUNE_NASCITA_ESTERO,
                      DESCR_COM_NASCITA.DESCRIZIONE) DESCR_COMUNE_NASCITA,
               SOGG.COD_PROVINCIA_NASCITA,
               NAZIONE.RV_MEANING NAZIONE_NASCITA,
               SOGG.COD_FISCALE,
               SOGG.COD_AFIS,
               SOGG.ANNO_NASCITA,
               SOGG.MESE_NASCITA,
               ETA_PRESUNTA_ANNI,
               ETA_PRESUNTA_MESI,
               DATA_NASCITA_PRESUNTA,
               SOGG.PATERNITA,
               SOGG.COGNOME_MADRE,
               SOGG.NOME_MADRE,
               SOGG.SESSO,
               SOGG.NOTE,
               FLAG_PRESENZA_FASCICOLO,
               --soggetto
               DESCR_OGGETTO_PROCEDIMENTO.RV_MEANING CONTENUTO,
               POS_GIURIDICA.RV_MEANING              DESCR_POS_GIURIDICA,
               DESCR_COM_UFF.DESCRIZIONE             DESCR_COMUNE_UFFICIO,
               GP.COD_POSIZIONE_GIURIDICA,
               GP.COD_OGGETTO_PROCEDIMENTO,
               --NVL(GP.COD_AUTORITA_DELEGATA, '-') COD_AUTORITA_DELEGATA,
               NVL(GP.DESCR_MITTENTE, '-') DESCR_MITTENTE,
               GP.DATA_FINE_PENA,
               id.descrizione,
               isd.rv_meaning || ' DI ' || id.descrizione IST_DET_ID_ISTITUTO_DETENZIONE,
               --                LD.IST_DET_ID_ISTITUTO_DETENZIONE,
               LD.NOTE                    NOTE_DETENZIONE,
               LD.DATA_INIZIO_DETENZIONE,
               LD.DATA_FINE_DETENZIONE,
               LD.ALTRO_LUOGO,
               TIPO_ATTO.RV_MEANING       DESCR_TIPO_ATTO,
               GP.DATA_RICHIESTA,
               GP.DATA_ARRIVO_CANCELLERIA,
               MITTENTE_ATTO.RV_MEANING   DESCR_TIPO_MITTENTE,
               DESCR_COM_MIT.DESCRIZIONE  DESCR_SEDE_MITTENTE,
               GP.DATA_DEFINIZIONE,
               GP.TIPO_DEFINIZIONE,
               GP.DESCR_DEFINIZIONE,
               --OGGETTO_TENORE.RV_MEANING DESC_OGGETTO,
               M.COGNOME COGNOME_MAG,
               M.NOME NOME_MAG,
               NVL(UD.DATA_UDIENZA, GP.DATA_CAMERA_CONSIGLIO) DATA_UDIENZA,
               ud.id_udienza ID_UD,
               DECODE(UP.FLAG_RINVIATA, 'P', 'PREFISSATA') FLAG_RINVIATA,
               -- STATO_FASCICOLO.RV_MEANING DESCR_STATO_FASCICOLO,
			   -- Ticket#20230126014 - Correzione su SIES per SIUS-Avvocati
			   -- Aggiunto controllo sulla gestione del decreto di fissazione udienza validato e depositato.
               case
                 when (select count(e.cod_esito)
                         from evento e, documento_allegato a
                        where e.fas_siu_id_fascicolo_sius =
                              FASC.ID_FASCICOLO_SIUS
                          and a.eve_id_evento = e.id_evento
                          and e.flag_documento_registrato = 'S'
                          and a.flag_documento_registrato = 'S') <= 1 then
				  -- Ticket#202105030112 - SIUS-avvocati
				  -- aggiunto controllo poiche' Emesso Provvedimento si deve vedere <=>
				  -- il decreto o l'ordinanza sono depositate ed il deposito sia validato
                  CASE
                    WHEN (select e.cod_esito
                            from evento e, documento_allegato a
                           where e.fas_siu_id_fascicolo_sius =
                                 FASC.ID_FASCICOLO_SIUS
                             and a.eve_id_evento = e.id_evento
                                --and e.cod_magistrato is not null
                             and e.flag_documento_registrato = 'S'
                             and a.flag_documento_registrato = 'S') is null THEN
                     'Iscritto'
                    WHEN (select e.cod_esito
                            from evento e, documento_allegato a
                           where e.fas_siu_id_fascicolo_sius =
                                 FASC.ID_FASCICOLO_SIUS
                             and a.eve_id_evento = e.id_evento
                                --and e.cod_magistrato is not null
                             and e.flag_documento_registrato = 'S'
                             and a.flag_documento_registrato = 'S') = '0601' THEN
                     'Iscritto'
                    ELSE
                     STATO_FASCICOLO.RV_MEANING
                  END
				  -- FINE Ticket#202105030112
                 else
                  STATO_FASCICOLO.RV_MEANING
               END DESCR_STATO_FASCICOLO,
               -- FINE Ticket#20230126014
               TIPO_REGISTRO.RV_MEANING DESCR_TIPO_REGISTRO,
               --eliminata condizione successiva 14 03 2017
               --P.DESC_POSIZIONE_MATERIALE,
               --fine eliminata condizione successiva 14 03 2017
               GP.ANNO_S1,
               GP.PROGR_S1,
               fasc.fas_siu_id_fascicolo_sius,
               FASC.ID_FASCICOLO_SIUS_ORIGINE
        FROM SOGGETTO SOGG, GENERALE_PROCEDIMENTO GP
        LEFT OUTER JOIN UDIENZA_PROCEDIMENTO UP
          ON (UP.GEN_PRID_GENERALE_PROCEDIMENTO =
             GP.ID_GENERALE_PROCEDIMENTO)
        LEFT OUTER JOIN UDIENZA UD
          ON (UD.ID_UDIENZA = GP.UDI_ID_UDIENZA), TENORE TEN, CG_REF_CODES
       DESCR_OGGETTO_PROCEDIMENTO, CG_REF_CODES POS_GIURIDICA,
       CG_REF_CODES NAZIONE, UFFICIO UFF, CG_REF_CODES
       STATO_FASCICOLO, COMUNE DESCR_COM_UFF, COMUNE
       DESCR_COM_NASCITA, CG_REF_CODES TIPO_ATTO, CG_REF_CODES
       MITTENTE_ATTO,
      --CG_REF_CODES OGGETTO_TENORE,
       CG_REF_CODES TIPO_REGISTRO, COMUNE DESCR_COM_MIT,
       MAGISTRATO_RELATORE MAG, MAGISTRATO M, AVVOCATO AVV,
       AVVOCATO_FASCICOLO_SIUS AVV_FAS, FASCICOLO_SIUS FASC
        LEFT OUTER JOIN V_SOGSIUS_ETA VSE
          ON (FASC.ID_FASCICOLO_SIUS = VSE.ID_FASCICOLO_SIUS)
        LEFT OUTER JOIN LUOGO_DETENZIONE LD
          ON (FASC.ID_FASCICOLO_SIUS = LD.FAS_SIU_ID_FASCICOLO_SIUS)
        LEFT OUTER JOIN istituto_detenzione ID
          ON (ld.ist_det_id_istituto_detenzione = ID.ID_ISTITUTO_DETENZIONE)
        LEFT OUTER JOIN cg_ref_codes ISD
          ON (ISD.RV_LOW_VALUE = ID.COD_TIPO_ISTITUTO AND
             isd.rv_domain = 'TIPO_ISTITUTO')
      --eliminata 6 condizione successiva 14 03 2017
      /*LEFT OUTER JOIN POSIZIONE_MATERIALE_FASC_SIUS PFF
        ON (fasc.id_fascicolo_sius=pff.fas_sius_id_fascicolo_sius),
        POSIZIONE_MATERIALE_FASC_SIUS PF
      JOIN POSIZIONE_MATERIALE P
        ON P.COD_UFFICIO = PF.COD_UFFICIO
       AND P.COD_POSIZIONE_MATERIALE = PF.COD_POSIZIONE_MATERIALE*/
      --fine eliminate 6 condizione successiva 14 03 2017
       WHERE FASC.SOG_ID_SOGGETTO = SOGG.ID_SOGGETTO
         AND FASC.ID_FASCICOLO_SIUS = GP.FAS_SIU_ID_FASCICOLO_SIUS
         AND DESCR_OGGETTO_PROCEDIMENTO.RV_DOMAIN = 'OGGETTO_PROCEDIMENTO'
         AND GP.COD_OGGETTO_PROCEDIMENTO =
             DESCR_OGGETTO_PROCEDIMENTO.RV_LOW_VALUE
         AND POS_GIURIDICA.RV_DOMAIN = 'POSIZIONE_GIURIDICA'
         AND (NVL(GP.COD_POSIZIONE_GIURIDICA, '-') =
             POS_GIURIDICA.RV_LOW_VALUE)
         AND UFF.COD_UFFICIO = FASC.CHIAVE_UFFICIO
         AND UFF.COD_COMUNE = DESCR_COM_UFF.COD_COMUNE
         AND SOGG.COD_COMUNE_NASCITA = DESCR_COM_NASCITA.COD_COMUNE
         AND FASC.ID_FASCICOLO_SIUS = VSE.ID_FASCICOLO_SIUS
         AND CHIAVE_PROGR = AVVO_SIUS_IN.NUME_FAS
         AND CHIAVE_ANNO = AVVO_SIUS_IN.ANNO_FAS
            -- MEV_20: il campo "COD_UFFICIO" arriva dal WS
            -- CB INIZIO 19/02/2020
         AND UFF.COD_UFFICIO IN
             (case when AVVO_SIUS_IN.COD_UFF IS NULL then
              (SELECT U.COD_UFFICIO
                 FROM UFFICIO U, COMUNE C
                WHERE U.COD_TIPO_UFFICIO = AVVO_SIUS_IN.TIPO_UFF
                  AND U.COD_COMUNE = C.COD_COMUNE
                  AND U.COD_DISTRETTO = AVVO_SIUS_IN.ID_DISTRETTO)
              else(AVVO_SIUS_IN.COD_UFF) end)
            -- CB FINE 19/02/2020
            
            /*AND uff.cod_ufficio IN (SELECT U.COD_UFFICIO
             FROM UFFICIO U, COMUNE C
            WHERE U.COD_TIPO_UFFICIO = AVVO_SIUS_IN.TIPO_UFF
              AND U.COD_COMUNE = C.COD_COMUNE
              AND U.COD_DISTRETTO = AVVO_SIUS_IN.ID_DISTRETTO)*/
            -- MEV_20: il campo "COD_UFFICIO" arriva dal WS
         AND ((NVL(VSE.ETA_ORA, 18) >= 18) OR
             -- CB INIZIO 19/02/2020
             FASC.COD_UFFICIO_INSERIMENTO IN
             (case when AVVO_SIUS_IN.COD_UFF IS NULL then
               (SELECT U.COD_UFFICIO
                  FROM UFFICIO U, COMUNE C
                 WHERE U.COD_TIPO_UFFICIO = AVVO_SIUS_IN.TIPO_UFF
                   AND U.COD_COMUNE = C.COD_COMUNE
                   AND U.COD_DISTRETTO = AVVO_SIUS_IN.ID_DISTRETTO)
               else(AVVO_SIUS_IN.COD_UFF) end)
             -- CB FINE 19/02/2020
             )
            /*(FASC.COD_UFFICIO_INSERIMENTO =  IN (SELECT U.COD_UFFICIO
             FROM UFFICIO U, COMUNE C
            WHERE U.COD_TIPO_UFFICIO = AVVO_SIUS_IN.TIPO_UFF
              AND U.COD_COMUNE = C.COD_COMUNE
              AND U.COD_DISTRETTO = AVVO_SIUS_IN.ID_DISTRETTO)))*/
         AND NAZIONE.RV_DOMAIN = 'NAZIONE'
         AND NAZIONE.RV_LOW_VALUE = SOGG.COD_STATO_NASCITA
         AND NVL(LD.DATA_INSERIMENTO, TO_DATE('01/01/1900', 'dd/mm/yyyy')) =
             NVL((SELECT MAX(DATA_INSERIMENTO)
                   FROM LUOGO_DETENZIONE
                  WHERE FAS_SIU_ID_FASCICOLO_SIUS = FASC.ID_FASCICOLO_SIUS),
                 TO_DATE('01/01/1900', 'dd/mm/yyyy'))
         AND (TIPO_ATTO.RV_DOMAIN = 'TIPO_ATTO' AND
             NVL(GP.COD_TIPO_ATTO, '-') = TIPO_ATTO.RV_LOW_VALUE)
         AND (MITTENTE_ATTO.RV_DOMAIN = 'MITTENTE_ATTO' AND
             NVL(GP.COD_TIPO_MITTENTE_ATTO, '-') =
             MITTENTE_ATTO.RV_LOW_VALUE)
         AND (GP.COD_SEDE_MITTENTE = DESCR_COM_MIT.COD_COMUNE)
         AND (TEN.GEN_PRID_GENERALE_PROCEDIMENTO =
             GP.ID_GENERALE_PROCEDIMENTO)
            /*AND (OGGETTO_TENORE.RV_LOW_VALUE = TEN.COD_OGGETTO_TENORE)
            AND (OGGETTO_TENORE.RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO')*/
         AND MAG.FAS_SIU_ID_FASCICOLO_SIUS = FASC.ID_FASCICOLO_SIUS
         AND MAG.DATA_FINE IS NULL
         AND M.COD_MAGISTRATO = MAG.MAG_COD_MAGISTRATO
         AND M.DATA_FINE_VALIDITA IS NULL
         AND AVV.ID_AVVOCATO = AVV_FAS.AVV_ID_AVVOCATO
         AND FASC.ID_FASCICOLO_SIUS = AVV_FAS.FAS_SIU_ID_FASCICOLO_SIUS
         AND AVV_FAS.DATA_FINE_VALIDITA IS NULL
         AND AVV.COD_FISCALE = UPPER(AVVO_SIUS_IN.CF_AVV)
         AND (STATO_FASCICOLO.RV_DOMAIN = 'STATO_FASCICOLO' AND
             NVL(STATO_FASCICOLO.RV_LOW_VALUE, '-') =
             FASC.COD_STATO_FASCICOLO)
         AND (TIPO_REGISTRO.RV_DOMAIN = 'TIPO_REGISTRO' AND
             NVL(GP.COD_TIPO_REGISTRO, '-') = TIPO_REGISTRO.RV_LOW_VALUE);
    --eliminata condizione successiva 14 03 2017
    --AND PF.DATA_FINE IS NULL;
    --fine eliminata condizione successiva 14 03 2017
  
    CURSOR C_FASC_U(FAS_SIUS fascicolo_sius.id_fascicolo_sius%TYPE) IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       FASC.CHIAVE_ANNO || '/' || FASC.CHIAVE_PROGR || ' ' ||
       DESCR_TIPO_UFF.RV_LOW_VALUE || ' ' || DESCR_COM_UFF.DESCRIZIONE UFF_UNI
        FROM FASCICOLO_SIUS FASC,
             CG_REF_CODES   DESCR_TIPO_UFF,
             COMUNE         DESCR_COM_UFF,
             UFFICIO        UFF
       WHERE (DESCR_TIPO_UFF.RV_DOMAIN = 'TIPO_UFFICIO' AND
             NVL(UFF.COD_TIPO_UFFICIO, '-') = DESCR_TIPO_UFF.RV_LOW_VALUE)
         AND (UFF.COD_COMUNE = DESCR_COM_UFF.COD_COMUNE AND
             FASC.CHIAVE_UFFICIO = UFF.COD_UFFICIO)
         AND FASC.ID_FASCICOLO_SIUS = FAS_SIUS;
  
    CURSOR C_FASC_UNIFICATO(FAS_SIUS fascicolo_sius.id_fascicolo_sius%TYPE) IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       FASC.CHIAVE_ANNO || '/' || FASC.CHIAVE_PROGR UFF_UNI
        FROM FASCICOLO_SIUS FASC
       WHERE FASC.FAS_SIU_ID_FASCICOLO_SIUS = FAS_SIUS;
  
    CURSOR C_FASC_COLL(FAS_SIUS fascicolo_sius.id_fascicolo_sius%TYPE) IS
      SELECT /*+ optimizer_features_enable('12.1.0.2') */
       FASC.CHIAVE_ANNO || '/' || FASC.CHIAVE_PROGR || ' ' ||
       DESCR_TIPO_UFF.RV_LOW_VALUE || ' ' || DESCR_COM_UFF.DESCRIZIONE UFF_UNI
        FROM FASCICOLO_SIUS FASC,
             CG_REF_CODES   DESCR_TIPO_UFF,
             COMUNE         DESCR_COM_UFF,
             UFFICIO        UFF
       WHERE (DESCR_TIPO_UFF.RV_DOMAIN = 'TIPO_UFFICIO' AND
             NVL(UFF.COD_TIPO_UFFICIO, '-') = DESCR_TIPO_UFF.RV_LOW_VALUE)
         AND (UFF.COD_COMUNE = DESCR_COM_UFF.COD_COMUNE AND
             FASC.CHIAVE_UFFICIO = UFF.COD_UFFICIO)
         AND FASC.ID_FASCICOLO_SIUS_ORIGINE = FAS_SIUS;
  
    --type complessi
    T_FASCICOLO_SIUS TY_FASCICOLO_SIUS;
  
    R_RIF_FASCICOLO_SIEP RC_RIFER_SIEP;
    R_AVVOCATI           RC_AVVOCATO;
    R_M_UDIENZA          RC_UDIENZA;
    R_PROVVEDIMENTI      RC_PROVVEDIMENTI;
    R_ALTRI_ATTI         RC_PROVVEDIMENTI;
    R_RICH_ISTR          RC_RICH_ISTR;
  
    APPO_GP GENERALE_PROCEDIMENTO.ID_GENERALE_PROCEDIMENTO%TYPE;
  
  BEGIN
    T_FASCICOLO_SIUS := TY_FASCICOLO_SIUS(NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL,
                                          NULL);
  
    --Inserita la IN nella query generica per gestire gli Uffici di Sorveglianza: 02/09/2016
    --CERCA_UFFICIO(AVVO_SIUS_IN);
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_INZIZIO',Data_Inizio_Proc);
  
    FOR C_F IN C_FSIUS LOOP
    
      APPO_GP := C_F.ID_GENERALE_PROCEDIMENTO;
    
      T_FASCICOLO_SIUS.ID_FASC_SIUS    := C_F.ID_FASCICOLO_SIUS;
      T_FASCICOLO_SIUS.CHIAVE_PROG     := C_F.CHIAVE_PROGR;
      T_FASCICOLO_SIUS.CHIAVE_ANNO     := C_F.CHIAVE_ANNO;
      T_FASCICOLO_SIUS.DATA_ISCRIZIONE := C_F.DATA_ISCRIZIONE;
      --impostata a null condizione successiva 14 03 2017
      T_FASCICOLO_SIUS.DESC_POS_MATER := null; --C_F.DESC_POSIZIONE_MATERIALE;
      --fine impostata a null condizione successiva 14 03 2017
      T_FASCICOLO_SIUS.DESC_STATO_FASCICOLO := C_F.DESCR_STATO_FASCICOLO;
    
      /*PER gli UNIFICANTI
      se fas_siu_id_fascicolo_sius IS NOT NULL allora alla QUERY unificanti devo passare fas_siu_id_fascicolo_sius        */
    
      IF C_F.FAS_SIU_ID_FASCICOLO_SIUS IS NOT NULL THEN
        --Data_Inizio_Proc:=systimestamp;
        --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_1_INZIZIO',Data_Inizio_Proc);
        FOR C_UNIFICANTE IN C_FASC_U(C_F.FAS_SIU_ID_FASCICOLO_SIUS) LOOP
          T_FASCICOLO_SIUS.DESC_FASC_UNIFICANTE := T_FASCICOLO_SIUS.DESC_FASC_UNIFICANTE ||
                                                   C_UNIFICANTE.UFF_UNI || ';';
        END LOOP;
        --Data_Inizio_Proc:=systimestamp;
        --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_2_INZIZIO',Data_Inizio_Proc);
        T_FASCICOLO_SIUS.DESC_FASC_UNIFICANTE := substr(T_FASCICOLO_SIUS.DESC_FASC_UNIFICANTE,
                                                        1,
                                                        length(T_FASCICOLO_SIUS.DESC_FASC_UNIFICANTE) - 1);
      END IF;
    
      T_FASCICOLO_SIUS.DATA_DEFINIZIONE    := C_F.DATA_DEFINIZIONE;
      T_FASCICOLO_SIUS.DESC_DEFINIZIONE    := C_F.DESCR_DEFINIZIONE;
      T_FASCICOLO_SIUS.TIPO_DEFINZIONE     := C_F.TIPO_DEFINIZIONE;
      T_FASCICOLO_SIUS.DESCR_TIPO_REGISTRO := C_F.DESCR_TIPO_REGISTRO;
      T_FASCICOLO_SIUS.CHIAVE_ANNO_S1      := C_F.ANNO_S1;
      T_FASCICOLO_SIUS.CHIAVE_PROG_S1      := C_F.PROGR_S1;
    
      /*PER gli UNIFICATI alla QUERY unificati devo passare id_fascicolo_sius*/
      --Data_Inizio_Proc:=systimestamp;
      --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_3_INZIZIO',Data_Inizio_Proc);
      FOR C_UNIFICATO IN C_FASC_UNIFICATO(C_F.ID_FASCICOLO_SIUS) LOOP
        T_FASCICOLO_SIUS.DESC_FASC_UNIFICATI := T_FASCICOLO_SIUS.DESC_FASC_UNIFICATI ||
                                                C_UNIFICATO.UFF_UNI || ';';
      END LOOP;
      --Data_Inizio_Proc:=systimestamp;
      --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_4_INZIZIO',Data_Inizio_Proc);
      T_FASCICOLO_SIUS.DESC_FASC_UNIFICATI := substr(T_FASCICOLO_SIUS.DESC_FASC_UNIFICATI,
                                                     1,
                                                     length(T_FASCICOLO_SIUS.DESC_FASC_UNIFICATI) - 1);
      /*PER i COLLEGATI
      se id_fascicolo_sius_origine IS NULL allora alla QUERY collegati devo passare id_fascicolo_sius
      se id_fascicolo_sius_origine IS NOT NULL allora alla QUERY unificanti devo passare id_fascicolo_sius_origine
       2005/315 */
      ------ IF C_F.ID_FASCICOLO_SIUS_ORIGINE IS NULL THEN
      --Data_Inizio_Proc:=systimestamp;
      --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_5_INZIZIO',Data_Inizio_Proc);
      FOR C_F_COLL IN C_FASC_COLL(C_F.ID_FASCICOLO_SIUS) LOOP
        -- Proc. Collegati
        T_FASCICOLO_SIUS.DESC_FASC_COLLEGATI := T_FASCICOLO_SIUS.DESC_FASC_COLLEGATI ||
                                                C_F_COLL.UFF_UNI || ';';
      END LOOP;
      --Data_Inizio_Proc:=systimestamp;
      --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_6_INZIZIO',Data_Inizio_Proc);
      T_FASCICOLO_SIUS.DESC_FASC_COLLEGATI := substr(T_FASCICOLO_SIUS.DESC_FASC_COLLEGATI,
                                                     1,
                                                     length(T_FASCICOLO_SIUS.DESC_FASC_COLLEGATI) - 1);
      /*ELSE
         FOR C_UNIFICANTE IN C_FASC_U(C_F.ID_FASCICOLO_SIUS_ORIGINE) LOOP--verificare
            T_FASCICOLO_SIUS.DESC_FASC_COLLEGATI:=T_FASCICOLO_SIUS.DESC_FASC_COLLEGATI||C_UNIFICANTE.UFF_UNI||';';
         END LOOP;
      END IF; */
    
      IF C_F.ID_FASCICOLO_SIUS_ORIGINE IS NOT NULL THEN
        --DESC_FASCICOLO_PADRE = collegato al proc
        --Data_Inizio_Proc:=systimestamp;
        --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_7_INZIZIO',Data_Inizio_Proc);
        FOR C_UNIFICANTE IN C_FASC_U(C_F.ID_FASCICOLO_SIUS_ORIGINE) LOOP
          T_FASCICOLO_SIUS.DESC_FASCICOLO_PADRE := T_FASCICOLO_SIUS.DESC_FASCICOLO_PADRE ||
                                                   C_UNIFICANTE.UFF_UNI || ';';
        END LOOP;
        --Data_Inizio_Proc:=systimestamp;
        --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_8_INZIZIO',Data_Inizio_Proc);
        T_FASCICOLO_SIUS.DESC_FASCICOLO_PADRE := substr(T_FASCICOLO_SIUS.DESC_FASCICOLO_PADRE,
                                                        1,
                                                        length(T_FASCICOLO_SIUS.DESC_FASCICOLO_PADRE) - 1);
      END IF;
    
      T_FASCICOLO_SIUS.UDIENZA := TY_UDIENZA(NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL,
                                             NULL);
      CERCA_UDIENZA(AVVO_SIUS_IN, C_F.ID_UD, APPO_GP, T_FASCICOLO_SIUS);
    
      T_SOGGETTO := TY_SOGGETTO(NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL);
      --DATI SOGGETTO
      T_SOGGETTO.COGNOME := C_F.COGNOME;
      T_SOGGETTO.NOME    := C_F.NOME;
      IF C_F.DATA_NASCITA IS NOT NULL THEN
        T_SOGGETTO.ANNO_NASCITA   := substr(C_F.DATA_NASCITA, 7, 4);
        T_SOGGETTO.MESE_NASCITA   := substr(C_F.DATA_NASCITA, 4, 2);
        T_SOGGETTO.GIORNO_NASCITA := substr(C_F.DATA_NASCITA, 1, 2);
      END IF;
      T_SOGGETTO.DESC_COMUNE              := C_F.DESCR_COMUNE_NASCITA;
      T_SOGGETTO.DESC_STATO_NASCITA       := C_F.NAZIONE_NASCITA;
      T_SOGGETTO.DESC_PATENITA            := C_F.PATERNITA;
      T_SOGGETTO.DESC_COGNOME_MADRE       := C_F.COGNOME_MADRE;
      T_SOGGETTO.DESC_POSIZIONE_GIURIDICA := C_F.DESCR_POS_GIURIDICA;
      T_SOGGETTO.DATA_FINE_PENA           := C_F.DATA_FINE_PENA;
      T_SOGGETTO.DESC_LUOGO_DETENZIONE    := C_F.IST_DET_ID_ISTITUTO_DETENZIONE;
      T_SOGGETTO.ID_PROVINCIA             := C_F.COD_PROVINCIA_NASCITA;
      T_SOGGETTO.ID_SOGGETTO              := C_F.ID_SOGGETTO;
    
      T_SOGGETTO.RESIDENZE := RC_RESIDENZA();
      CERCA_RESIDENZA(AVVO_SIUS_IN,
                      T_FASCICOLO_SIUS.ID_FASC_SIUS,
                      T_SOGGETTO);
      --FINE DATI SOGGETTO
    
      --DATI ATTO
      T_ATTO                         := TY_ATTO(NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL);
      T_ATTO.DATA_RICHIESTA          := C_F.DATA_RICHIESTA;
      T_ATTO.DESC_TIPO_ATTO          := C_F.DESCR_TIPO_ATTO;
      T_ATTO.DATA_ARRIVO_CANCELLERIA := C_F.DATA_ARRIVO_CANCELLERIA;
      T_ATTO.DESCR_TIPO_MITTENTE     := C_F.DESCR_TIPO_MITTENTE;
      T_ATTO.DESC_SEDE_MITTENTE      := C_F.DESCR_SEDE_MITTENTE;
      T_ATTO.DESC_MITTENTE           := C_F.DESCR_MITTENTE;
      --FINE DATI ATTO
    
      T_FASCICOLO_SIEP                  := TY_FASCICOLO_SIEP(NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL,
                                                             NULL);
      T_FASCICOLO_SIEP.SENTENZA         := TY_SENTENZA(NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL);
      T_FASCICOLO_SIEP.PENA_RESIDUA     := TY_PENA(NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL);
      T_FASCICOLO_SIEP.PENA_COMPLESSIVA := TY_PENA(NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL,
                                                   NULL);
    
      CERCA_FASCICOLO_SIEP(AVVO_SIUS_IN,
                           C_F.ID_FASCICOLO_SIEP,
                           T_FASCICOLO_SIEP);
    
      T_FASCICOLO_SIUS.DESC_CONTENUTO := C_F.CONTENUTO;
    
      T_OGGETTO            := RC_OGGETTO();
      T_OGGETTO_STRALCIATO := RC_OGGETTO();
    
      CERCA_OGGETTO(AVVO_SIUS_IN, APPO_GP, T_OGGETTO);
      CERCA_OGGETTO_STRALCIATO(AVVO_SIUS_IN,
                               T_FASCICOLO_SIUS.ID_FASC_SIUS,
                               T_OGGETTO_STRALCIATO);
    
      T_FASCICOLO_SIUS.MAGISTRATO             := TY_MAGISTRATO(NULL, NULL);
      T_FASCICOLO_SIUS.MAGISTRATO.COGNOME_MAG := C_F.COGNOME_MAG;
      T_FASCICOLO_SIUS.MAGISTRATO.NOME_MAG    := C_F.NOME_MAG;
      --Data_Inizio_Proc:=systimestamp;
      --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_9_INZIZIO',Data_Inizio_Proc);
    
      BEGIN
        SELECT /*+ optimizer_features_enable('12.1.0.2') */
         CA.DESC_CANCELLERIA_ASSEGNATARIA
          INTO T_FASCICOLO_SIUS.DESC_CANCEL
          FROM CANC_ASS_FASC_SIUS CF
          JOIN CANCELLERIA_ASSEGNATARIA CA
            ON CA.COD_UFFICIO = CF.COD_UFFICIO
           AND CA.COD_CANCELLERIA_ASSEGNATARIA =
               CF.COD_CANCELLERIA_ASSEGNATARIA
         WHERE FAS_SIUS_ID_FASCICOLO_SIUS = C_F.ID_FASCICOLO_SIUS
           AND DATA_FINE IS NULL;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          T_FASCICOLO_SIUS.DESC_CANCEL := NULL;
      END;
      --Data_Inizio_Proc:=systimestamp;
      --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_10_INZIZIO',Data_Inizio_Proc);
    
      T_FASCICOLO_SIUS.DESC_ANNOT_PROCED := C_F.NOTE;
    
      --ALTRE NOTE
      T_FASCICOLO_SIUS.NOTE := RC_LISTA_NOTE();
      CERCA_NOTE(AVVO_SIUS_IN, T_FASCICOLO_SIUS, APPO_GP);
    
      CERCA_ULTERIORI_ISTANZE(AVVO_SIUS_IN, T_FASCICOLO_SIUS);
      --FINE FASCICOLO SIUS
    
    END LOOP;
  
    T_FASCICOLO_SIUS_OUT := T_FASCICOLO_SIUS;
    --Data_Inizio_Proc:=systimestamp;
    --OUTPUT(AVVO_SIUS_IN, 'CERCA_FASIUS_PER_ESTREMI_11_INZIZIO',Data_Inizio_Proc);
  
    IF T_FASCICOLO_SIUS.ID_FASC_SIUS IS NOT NULL THEN
      --RIFERIMENTI FASCICOLO SIEP
      CERCA_RIFERIMENTI_FASC_SIEP(AVVO_SIUS_IN,
                                  T_FASCICOLO_SIUS_OUT.ID_FASC_SIUS,
                                  R_RIF_FASCICOLO_SIEP);
    
      T_RIF_FASC_SIEP_OUT := R_RIF_FASCICOLO_SIEP;
    
      --LISTA AVVOCATI
    
      CERCA_AVVOCATI(AVVO_SIUS_IN,
                     T_FASCICOLO_SIUS_OUT.ID_FASC_SIUS,
                     R_AVVOCATI);
    
      T_AVVOCATI_OUT := R_AVVOCATI;
    
      --MOVIMENTI UDIENZA
      CERCA_MOVIMENTI_UDIENZA(AVVO_SIUS_IN, APPO_GP, R_M_UDIENZA);
    
      T_UDIENZA_OUT := R_M_UDIENZA;
    
      --ELENCO PROVVEDIMENTI
      CERCA_PROVVEDIMENTI(AVVO_SIUS_IN,
                          T_FASCICOLO_SIUS_OUT.ID_FASC_SIUS,
                          R_PROVVEDIMENTI);
    
      T_PROVVEDIMENTI_OUT := R_PROVVEDIMENTI;
    
      --ELENCO ATTI
      CERCA_ALTRI_ATTI(AVVO_SIUS_IN,
                       T_FASCICOLO_SIUS_OUT.ID_FASC_SIUS,
                       R_ALTRI_ATTI);
    
      T_ALTRI_ATTI_OUT := R_ALTRI_ATTI;
    
      --ELENCO ISTRUTTORIE
    
      CERCA_RIC_ISTR(AVVO_SIUS_IN,
                     T_FASCICOLO_SIUS_OUT.ID_FASC_SIUS,
                     R_RICH_ISTR);
    
      T_RIC_ISTR_OUT := R_RICH_ISTR;
    END IF;
  
    IF T_FASCICOLO_SIUS.ID_FASC_SIUS IS NULL THEN
      DESC_ERRORE := 'NON TROVATO';
      Err         := 'NF';
    ELSE
      Err := 'OK';
    END IF;
  
  EXCEPTION
    WHEN Eccezione THEN
      Err         := 'KO';
      DESC_ERRORE := ERR_MSG_OUT;
    
  END CERCA_FASIUS_PER_ESTREMI;

  PROCEDURE OUTPUT(AVVO_SIUS_IN IN INP_AVV,
                   P_TEXT       VARCHAR2,
                   Data_Inizio  IN OUT DATE) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
    Data_Char VARCHAR2(100);
  BEGIN
    IF G_DEBUGGING THEN
      Data_Char := to_char(systimestamp, 'dd/mm/yyyy hh24:mi:ss:ff');
    
      INSERT INTO log_attivita
      VALUES
        (P_TEXT,
         Data_Char,
         NULL,
         'AVVOCATI',
         AVVO_SIUS_IN.ANNO_FAS || '/' || AVVO_SIUS_IN.NUME_FAS);
      /*INSERT INTO CP_CG_DEBUG_MESSAGES (ID_ANAG_CP, ID_PROVV_CP, CP_CG_DTTM, TEXT)
      VALUES (PROG_ANAG_CP, PROG_PROVV_CP , SYSDATE, P_TEXT);*/
      COMMIT;
      NULL;
    END IF;
  END;

BEGIN
  -- Initialization
  NULL;
END AVVOCATURA_SIUS;
/