update stato_procedimento sp
   set sp.cod_stato_procedimento = '0109'
 where sp.cod_stato_procedimento = '0000';