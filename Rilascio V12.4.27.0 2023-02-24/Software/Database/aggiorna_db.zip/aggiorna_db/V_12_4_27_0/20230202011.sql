-- ========================================================================
-- Aggiorna la funzione presente nel menu a tendina del dettaglio 
-- per agganciare la stessa funzione dell'icone dal menu di accesso rapido
-- ========================================================================
UPDATE RELAZIONE_FUNZIONE
SET FUN_ID_FUNZIONE_FIGLIA = 90110749
WHERE FUN_ID_FUNZIONE = 90010012 AND FUN_ID_FUNZIONE_FIGLIA = 90110650;