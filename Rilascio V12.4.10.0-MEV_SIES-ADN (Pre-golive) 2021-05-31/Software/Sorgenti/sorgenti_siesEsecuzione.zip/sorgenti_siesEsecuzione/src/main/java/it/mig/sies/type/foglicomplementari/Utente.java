
package it.mig.sies.type.foglicomplementari;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java per anonymous complex type.
 * 
 * <p>Il seguente frammento di schema specifica il contenuto previsto contenuto in questa classe.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://it/mig/sies/type/fogliComplementari}Ufficio"/>
 *         &lt;element name="Username">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Cognome">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="35"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Nome">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="35"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ipServer" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UserAdn">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="128"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "ufficio",
    "username",
    "cognome",
    "nome",
    "ipServer",
    "userAdn"
})
@XmlRootElement(name = "Utente")
public class Utente {

    @XmlElement(name = "Ufficio", required = true)
    protected Ufficio ufficio;
    @XmlElement(name = "Username", required = true)
    protected String username;
    @XmlElement(name = "Cognome", required = true)
    protected String cognome;
    @XmlElement(name = "Nome", required = true)
    protected String nome;
    @XmlElement(required = true, nillable = true)
    protected String ipServer;
    @XmlElement(name = "UserAdn", required = true)
    protected String userAdn;

    /**
     * Recupera il valore della propriet� ufficio.
     * 
     * @return
     *     possible object is
     *     {@link Ufficio }
     *     
     */
    public Ufficio getUfficio() {
        return ufficio;
    }

    /**
     * Imposta il valore della propriet� ufficio.
     * 
     * @param value
     *     allowed object is
     *     {@link Ufficio }
     *     
     */
    public void setUfficio(Ufficio value) {
        this.ufficio = value;
    }

    /**
     * Recupera il valore della propriet� username.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsername() {
        return username;
    }

    /**
     * Imposta il valore della propriet� username.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsername(String value) {
        this.username = value;
    }

    /**
     * Recupera il valore della propriet� cognome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCognome() {
        return cognome;
    }

    /**
     * Imposta il valore della propriet� cognome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCognome(String value) {
        this.cognome = value;
    }

    /**
     * Recupera il valore della propriet� nome.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNome() {
        return nome;
    }

    /**
     * Imposta il valore della propriet� nome.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNome(String value) {
        this.nome = value;
    }

    /**
     * Recupera il valore della propriet� ipServer.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIpServer() {
        return ipServer;
    }

    /**
     * Imposta il valore della propriet� ipServer.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIpServer(String value) {
        this.ipServer = value;
    }

    /**
     * Recupera il valore della propriet� userAdn.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserAdn() {
        return userAdn;
    }

    /**
     * Imposta il valore della propriet� userAdn.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserAdn(String value) {
        this.userAdn = value;
    }

}
