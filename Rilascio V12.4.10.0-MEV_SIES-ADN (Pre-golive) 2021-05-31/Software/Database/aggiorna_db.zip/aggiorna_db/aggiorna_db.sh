#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV_SIES-ADN_Pre-golive/aggiorna_db.sql