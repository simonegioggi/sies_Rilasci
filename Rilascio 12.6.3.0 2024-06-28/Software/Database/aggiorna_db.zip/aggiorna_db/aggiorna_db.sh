#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/V_12_6_3_0/aggiorna_db.sql