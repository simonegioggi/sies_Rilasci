#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/V_12_8_3_0/aggiorna_db.sql