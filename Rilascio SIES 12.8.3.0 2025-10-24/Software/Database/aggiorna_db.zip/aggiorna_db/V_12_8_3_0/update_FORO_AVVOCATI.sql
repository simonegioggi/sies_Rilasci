update cg_ref_codes c
   set c.rv_alt2_value = '110009'
 where c.rv_domain = 'FORO_AVVOCATI'
   and c.rv_low_value = 'TRANI'
   and c.rv_alt2_value = '072045';
update cg_ref_codes c
   set c.rv_alt2_value = '109006'
 where c.rv_domain = 'FORO_AVVOCATI'
   and c.rv_low_value = 'FERMO'
   and c.rv_alt2_value = '044019';