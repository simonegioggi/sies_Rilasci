-- primo merge su EVENTO
merge into evento e
using (SELECT EV.Data_Inserimento,
              ev.id_evento,
              ev.cod_ufficio_inserimento,
              ev.cod_operatore_inserimento
         FROM EVENTO EV, FASCICOLO_SIEP, COMUNE, UFFICIO, PENA_RESIDUA pr
        WHERE 1 = 1
          AND PR.COD_OPERATORE_INSERIMENTO IS NULL
          AND PR.COD_UFFICIO_INSERIMENTO IS NULL
          AND PR.EVE_ID_EVENTO = EV.ID_EVENTO
          AND EV.COD_MOTIVO IN ('0019', '0356')
          AND EV.COD_TIPO_PROVVEDIMENTO = '25'
          and ev.data_aggiornamento is null
          AND EV.FAS_SIE_ID_FASCICOLO_SIEP =
              FASCICOLO_SIEP.ID_FASCICOLO_SIEP
          AND EV.FLAG_DOCUMENTO_REGISTRATO = 'S'
          AND FASCICOLO_SIEP.CHIAVE_UFFICIO = UFFICIO.COD_UFFICIO
          AND COMUNE.cod_comune = UFFICIO.cod_comune) t2
on (e.ID_evento = t2.ID_Evento)
when matched then
  update
     set e.data_aggiornamento          = t2.Data_Inserimento,
         e.cod_ufficio_aggiornamento   = nvl(e.cod_ufficio_aggiornamento,
                                             t2.cod_ufficio_inserimento),
         e.cod_operatore_aggiornamento = nvl(e.cod_operatore_aggiornamento,
                                             t2.cod_operatore_inserimento);
-- secondo merge su PENA_RESIDUA
merge into PENA_RESIDUA PRU
using (SELECT EV.COD_OPERATORE_INSERIMENTO,
              EV.COD_UFFICIO_INSERIMENTO,
              PR.ID_PENA_RESIDUA
         FROM PENA_RESIDUA PR, EVENTO EV, FASCICOLO_SIEP, COMUNE, UFFICIO
        WHERE 1 = 1
          AND PR.COD_OPERATORE_INSERIMENTO IS NULL
          AND PR.COD_UFFICIO_INSERIMENTO IS NULL
          AND PR.EVE_ID_EVENTO = EV.ID_EVENTO
          AND EV.COD_MOTIVO IN ('0019', '0356')
          AND EV.COD_TIPO_PROVVEDIMENTO = '25'
          AND EV.FAS_SIE_ID_FASCICOLO_SIEP =
              FASCICOLO_SIEP.ID_FASCICOLO_SIEP
          AND EV.FLAG_DOCUMENTO_REGISTRATO = 'S'
          AND FASCICOLO_SIEP.CHIAVE_UFFICIO = UFFICIO.COD_UFFICIO
          AND COMUNE.cod_comune = UFFICIO.cod_comune) t2
on (PRU.ID_PENA_RESIDUA = t2.ID_PENA_RESIDUA)
when matched then
  update
     set PRU.COD_OPERATORE_INSERIMENTO = t2.COD_OPERATORE_INSERIMENTO,
         PRU.COD_UFFICIO_INSERIMENTO   = t2.COD_UFFICIO_INSERIMENTO;