create or replace force view v_soggetto_maggiorenne_new as
select distinct
       TB_SOGGETTI.ID_SOGGETTO id_soggetto,
       null data_maggiorenne,
       (case
         -- Recupero i dati preferenzialmente dalla vista principale V_SOGGETTO_MAGGIORENNE
         when TB_SOGGETTI.ETA_SOGGETTO_ORA is not null then
          TB_SOGGETTI.ETA_SOGGETTO_ORA
         when TB_SOGGETTI.ETA_PRESUNTA_ORA is not null then
          TB_SOGGETTI.ETA_PRESUNTA_ORA
         -- In assenza se il soggetto � un soggetto SIEP provo a recuperare i dati dai reati
         when TB_SOGGETTI_SIES.ETA_PRESUNTA_ORA is not null then
          TB_SOGGETTI_SIES.ETA_PRESUNTA_ORA
         -- Se invece � un soggetto SIGE provo a recuperare i dati dal soggetto SIEP collegato
         -- al fascicoli SIGE tramite la FAS_SIGE_SENTENZA
         -- Preferibilmente dalla tabella SOGGETTO del fascicolo SIEP
         when TB_SOGGETTI_SIGE.ETA_SOGGETTO_ORA_SIEP is not null then
          TB_SOGGETTI_SIGE.ETA_SOGGETTO_ORA_SIEP
         -- in assenza sempre dai reati
         when TB_SOGGETTI_SIGE.ETA_PRESUNTA_ORA is not null then
          TB_SOGGETTI_SIGE.ETA_PRESUNTA_ORA
         else  trunc(((nvl(TB_SOGGETTI.eta_presunta_anni,0) * 12) + nvl(TB_SOGGETTI.eta_presunta_mesi,0)) /12)
       end) as eta_soggetto_ora,
       null eta_presunta_anni,
       null eta_presunta_mesi,
       TB_SOGGETTI.data_nascita_presunta,
       TB_SOGGETTI.data_reato_sius
FROM (select null "ID_FASCICOLO_SIEP",
          null "NUM_REATI",
          null "PRIMO_REATO",
          null "ULTIMO_REATO",
          sm.id_soggetto ID_SOGGETTO,
          sm."DATA_MAGGIORENNE",
          sm."ETA_SOGGETTO_ORA",
          sm."DATA_NASCITA_PRESUNTA",
          sm."ETA_PRESUNTA_ANNI",
          sm."ETA_PRESUNTA_MESI",
          trunc(MONTHS_BETWEEN(sysdate, ADD_MONTHS(ADD_MONTHS(sm.data_reato_sius, - nvl(sm.eta_presunta_anni,0) * 12), -nvl(sm.eta_presunta_mesi,0) ) ) / 12)
                 ETA_PRESUNTA_ORA,
          sm.data_reato_sius
     from V_SOGGETTO_MAGGIORENNE sm
) TB_SOGGETTI
, (select fs."ID_FASCICOLO_SIEP",
          rf."NUM_REATI",
          rf."PRIMO_REATO",
          rf."ULTIMO_REATO",
          fs.sog_id_soggetto ID_SOGGETTO,
          sm."DATA_MAGGIORENNE",
          sm."ETA_SOGGETTO_ORA",
          sm."DATA_NASCITA_PRESUNTA",
          sm."ETA_PRESUNTA_ANNI",
          sm."ETA_PRESUNTA_MESI",
          nvl(trunc(MONTHS_BETWEEN(sysdate, ADD_MONTHS(ADD_MONTHS(sm.data_reato_sius, - nvl(sm.eta_presunta_anni,0) * 12), -nvl(sm.eta_presunta_mesi,0) ) ) / 12),
              trunc(MONTHS_BETWEEN(sysdate, ADD_MONTHS(ADD_MONTHS(rf.primo_reato, - nvl(sm.eta_presunta_anni,0) * 12), -nvl(sm.eta_presunta_mesi,0) ) ) / 12))
              ETA_PRESUNTA_ORA,
          sm.data_reato_sius
     from FASCICOLO_SIEP         fs,
          V_REATI_FASCICOLO      rf,
          V_SOGGETTO_MAGGIORENNE sm
    where fs.id_fascicolo_siep = rf.fas_sie_id_fascicolo_siep
      and fs.sog_id_soggetto = sm.id_soggetto
) TB_SOGGETTI_SIES
, ( select fs."ID_FASCICOLO_SIEP",
           rf."NUM_REATI",
           rf."PRIMO_REATO",
           rf."ULTIMO_REATO",
           a.sog_id_soggetto ID_SOGGETTO,
           sm."DATA_MAGGIORENNE",
           sm."ETA_SOGGETTO_ORA" ETA_SOGGETTO_ORA_SIGE,
           smSIEP."ETA_SOGGETTO_ORA" ETA_SOGGETTO_ORA_SIEP,
           sm."DATA_NASCITA_PRESUNTA",
           sm."ETA_PRESUNTA_ANNI",
           sm."ETA_PRESUNTA_MESI",
           fs.ID_FASCICOLO_SIEP,
           nvl(trunc(MONTHS_BETWEEN(sysdate, ADD_MONTHS(ADD_MONTHS(sm.data_reato_sius, - nvl(sm.eta_presunta_anni,0) * 12), -nvl(sm.eta_presunta_mesi,0) ) ) / 12),
               trunc(MONTHS_BETWEEN(sysdate, ADD_MONTHS(ADD_MONTHS(rf.primo_reato, - nvl(sm.eta_presunta_anni,0) * 12), -nvl(sm.eta_presunta_mesi,0) ) ) / 12))
           ETA_PRESUNTA_ORA,
           sm.data_reato_sius
      from FASCICOLO_SIEP         fs,
           V_REATI_FASCICOLO      rf,
           V_SOGGETTO_MAGGIORENNE sm,
           V_SOGGETTO_MAGGIORENNE smSIEP,
           fascicolo_sige a,
           fas_sige_sentenza b
     where fs.id_fascicolo_siep = rf.fas_sie_id_fascicolo_siep
       and a.sog_id_soggetto = sm.id_soggetto
       and fs.sog_id_soggetto = smSIEP.id_soggetto
       and b.fas_id_fascicolo_sige = a.id_fascicolo_sige
       and fs.id_fascicolo_siep = b.fas_sie_id_fascicolo_siep
) TB_SOGGETTI_SIGE
WHERE 1=1
AND TB_SOGGETTI.ID_SOGGETTO = TB_SOGGETTI_SIES.ID_SOGGETTO(+)
AND TB_SOGGETTI.ID_SOGGETTO = TB_SOGGETTI_SIGE.ID_SOGGETTO(+);
/