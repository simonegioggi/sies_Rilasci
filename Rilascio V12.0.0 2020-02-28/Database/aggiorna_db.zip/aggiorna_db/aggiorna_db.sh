#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/V_12/aggiorna_db.sql