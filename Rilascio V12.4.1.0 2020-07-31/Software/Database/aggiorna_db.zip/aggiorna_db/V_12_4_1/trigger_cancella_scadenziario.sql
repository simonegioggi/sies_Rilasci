CREATE OR REPLACE TRIGGER CANCELLA_SCADENZARIO
AFTER UPDATE
ON EVENTO
REFERENCING NEW AS RIGA_CORR OLD AS RIGA_OLD
FOR EACH ROW
WHEN (
RIGA_CORR.FLAG_DOCUMENTO_REGISTRATO = 'S' and
RIGA_CORR.FAS_SIE_ID_FASCICOLO_SIEP is not null and
RIGA_CORR.FAS_SIU_ID_FASCICOLO_SIUS is null
      )
DECLARE
eve_cancella_scad   NUMBER;
BEGIN
   eve_cancella_scad := 0;
   SELECT count(*)
     INTO eve_cancella_scad
     FROM W_EVE_DEL_SCAD
    WHERE cod_motivo    = :RIGA_CORR.COD_MOTIVO
	  AND cod_tipo_scad = '01' ;
   IF eve_cancella_scad > 0 THEN
      BEGIN
  	    DELETE FROM SCADENZARIO_SIEP
	     WHERE	cod_tipo_scadenzario      = '01'
	       AND  EVE_ID_EVENTO <> :RIGA_CORR.EVE_ID_EVENTO --Aggiunto DF [Ticket#20200723012]
	       AND	fas_sie_id_fascicolo_siep = :RIGA_CORR.FAS_SIE_ID_FASCICOLO_SIEP;
      END;
   END IF;
   -- Aggiunto 08.11.2010 per gestione Scadenzario tipo '03' (Ordine di esecuzione)
   eve_cancella_scad := 0;
   SELECT count(*)
     INTO eve_cancella_scad
     FROM W_EVE_DEL_SCAD
    WHERE cod_motivo    = :RIGA_CORR.COD_MOTIVO
	  AND cod_tipo_scad = '03' ;
   IF eve_cancella_scad > 0 THEN
      BEGIN
  	    DELETE FROM SCADENZARIO_SIEP
	     WHERE	cod_tipo_scadenzario      = '03'
	       AND	fas_sie_id_fascicolo_siep = :RIGA_CORR.FAS_SIE_ID_FASCICOLO_SIEP;
      END;
   END IF;
   -- Termini Ottemperanza Obblighi
   SELECT count(*)
     INTO eve_cancella_scad
     FROM W_EVE_DEL_SCAD
    WHERE cod_motivo    = :RIGA_CORR.COD_MOTIVO
	  AND cod_tipo_scad = '16' ;
   IF eve_cancella_scad > 0 THEN
      BEGIN
  	    DELETE FROM SCADENZARIO_SIEP
	     WHERE	cod_tipo_scadenzario      = '16'
	       AND	fas_sie_id_fascicolo_siep = :RIGA_CORR.FAS_SIE_ID_FASCICOLO_SIEP;
      END;
   END IF;
   -- Termini Sospensione Condizionale
   SELECT count(*)
     INTO eve_cancella_scad
     FROM W_EVE_DEL_SCAD
    WHERE cod_motivo    = :RIGA_CORR.COD_MOTIVO
	  AND cod_tipo_scad = '17' ;
   IF eve_cancella_scad > 0 THEN
      BEGIN
  	    DELETE FROM SCADENZARIO_SIEP
	     WHERE	cod_tipo_scadenzario      = '17'
	       AND	fas_sie_id_fascicolo_siep = :RIGA_CORR.FAS_SIE_ID_FASCICOLO_SIEP;
      END;
   END IF;
EXCEPTION
  WHEN OTHERS THEN
       RAISE;
END;
/