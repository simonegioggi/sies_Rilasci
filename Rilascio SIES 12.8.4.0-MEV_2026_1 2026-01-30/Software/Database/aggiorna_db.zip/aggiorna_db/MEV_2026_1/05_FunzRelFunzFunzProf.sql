-- FUNZIONE
insert into FUNZIONE values (36160027,'Ricerca Fine Pena Procedimenti Pendenti per Excel','R','siap.sius.scadenzario.action.RicercaFinePenaProcedimentiPendentiExcel');
insert into FUNZIONE values (36160028,'Ricerca Fine Pena Procedimenti Pendenti per Excel','R','siap.sius.scadenzario.action.ActRicercaFinePenaProcedimentiPendentiExcel');
insert into FUNZIONE values (36160029,'Ricerca Fine Pena Procedimenti Pendenti','R','siap.sius.scadenzario.action.ActRicercaFinePenaProcedimentiPendenti');
insert into FUNZIONE values (36160030,'Load Ricerca Fine Pena Procedimenti Pendenti','R','siap.sius.scadenzario.action.ActLoadRicercaFinePenaProcedimentiPendenti');
-- RELAZIONE_FUNZIONE
insert into RELAZIONE_FUNZIONE values (10509,36160030,'ME','Ricerca Fine Pena Procedimenti Pendenti',2,null);
-- FUNZIONE_PROFILO
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160027, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160028, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160029, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 14, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 24, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 31, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 32, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 41, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 42, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 51, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into FUNZIONE_PROFILO values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 36160030, 52, 'MEV_2026-1', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');