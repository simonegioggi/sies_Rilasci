CREATE OR REPLACE PROCEDURE bonifica_soggetto_presentante(data_versione IN VARCHAR2) IS

NUM_RECORD_AGGIORNATI NUMBER := 0;

BEGIN

	UPDATE impugnazione_sige s
	   SET soggetto_impugnante = DECODE(s.soggetto_impugnante,
										'01','05',
										'02','01',
										'03','02',
										'04','03',
										'05','06',
										s.soggetto_impugnante)
	 WHERE to_date(to_char(s.DATA_AGGIORNAMENTO, 'dd/mm/yyyy'),
                      'dd/mm/yyyy') >= to_date(data_versione, 'dd/mm/yyyy') AND 
                  to_date(to_char(s.DATA_AGGIORNAMENTO, 'dd/mm/yyyy'),
                     ' dd/mm/yyyy') <= sysdate;

    NUM_RECORD_AGGIORNATI:= SQL%ROWCOUNT;
    
    dbms_output.put_line('======================================================================');
    dbms_output.put_line('DATA AGGIORNAMENTO --> ' || data_versione );
    dbms_output.put_line('NUMERO RECORD AGGIORNATI --> ' || NUM_RECORD_AGGIORNATI );
    dbms_output.put_line('======================================================================');
EXCEPTION
	WHEN OTHERS THEN
		dbms_output.put_line('=============================================================================');
		dbms_output.put_line('ERRORE GENERICO (bonifica_soggetto_presentante) --> ' || TO_CHAR(SQLCODE) ||  '-- ' || SQLERRM);
		dbms_output.put_line('=============================================================================');
	
END bonifica_soggetto_presentante;
/
