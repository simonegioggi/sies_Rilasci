INSERT INTO cg_ref_codes
 SELECT 'SOGGETTO_IMPUGNANTE_SIGE', 
            t.rv_low_value, 
            t.rv_high_value, 
            t.rv_abbreviation, 
            t.rv_meaning, 
            t.rv_alt2_value, 
            t.rv_alt3_value, 
            t.rv_alt4_value, 
            t.rv_alt5_value
 FROM CG_REF_CODES t WHERE t.rv_domain = 'SOGGETTO_IMPUGNANTE' 
                 AND t.rv_meaning IN (  'Difensore',
                                        'Soggetto',
                                        'Procura Repubblica Presso il Tribunale',
                                        'Procura Generale Presso Corte D''Appello',
                                        'Procura della Repubblica Presso il Tribunale per i Minorenni'
                                        ); 

insert into CG_REF_CODES (RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING, RV_ALT2_VALUE, RV_ALT3_VALUE, RV_ALT4_VALUE, RV_ALT5_VALUE)
values ('SOGGETTO_IMPUGNANTE_SIGE', '-', null, null, '-', null, null, null, null);