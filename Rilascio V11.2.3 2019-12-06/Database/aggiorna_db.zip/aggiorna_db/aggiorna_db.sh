#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/V_11_2_3/aggiorna_db.sql