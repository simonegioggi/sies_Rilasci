prompt
prompt Creating table UTENZA_ADN
prompt =========================
prompt
@@utenza_adn.tab
prompt
prompt Creating table ASSOC_UTENTE_SIES_ADN
prompt ===================================
prompt
@@assoc_utente_sies_adn.tab
prompt
prompt Creating sequence ASSOC_UTENTE_SIES_ADN_SEQ
prompt ==========================================
prompt
@@assoc_utente_sies_adn_seq.seq
prompt
prompt Creating sequence UTENZA_ADN_SEQ
prompt ================================
prompt
@@utenza_adn_seq.seq