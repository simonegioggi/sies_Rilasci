#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV_2024_092/aggiorna_db/aggiorna_db.sql