#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV_2025_48/aggiorna_db.sql