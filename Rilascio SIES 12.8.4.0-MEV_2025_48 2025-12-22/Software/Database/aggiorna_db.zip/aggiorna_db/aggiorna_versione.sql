update template x  set x.nome_template = substr(x.nome_template,  1,  length(x.nome_template) - 3) || 'rtf' where x.id_template in
(select t.id_template  from template t  where substr(t.nome_template, length(t.nome_template) - 2, 3) = 'RTF');
DELETE FROM versione WHERE cod_versione='12.8.4.0-MEV_2025_48';
INSERT INTO versione (COD_VERSIONE, DATA, DESCRIZIONE) VALUES ('12.8.4.0-MEV_2025_48', to_date(to_char(SYSDATE, 'dd/MM/yyyy'), 'dd/MM/yyyy'), 'Patch per rilascio MEV 2025_48');