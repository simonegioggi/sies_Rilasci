-- ==========================================================================
-- Aggiunto campo FLAG_APP_PROVVISORIA per gestone richieste benefici al PM
-- ==========================================================================
ALTER TABLE COMPUTI_CUMULO ADD FLAG_APP_PROVVISORIA VARCHAR2(1) NULL;
COMMENT ON COLUMN COMPUTI_CUMULO.FLAG_APP_PROVVISORIA IS 'A=Anticipazione, R=senza anticipazione';