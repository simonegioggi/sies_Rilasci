-- Per accesso dalla lista provvedimenti del PM
INSERT INTO DETTAGLIO_PROVVEDIMENTO
  (COD_TIPO_EVENTO,
   COD_TIPO_PROVVEDIMENTO,
   COD_MOTIVO,
   ACTION_DETTAGLIO,
   NOTE,
   ACTION_UPLOAD)
VALUES
  ('01',
   '25',
   '0736',
   'siap.siep.archiviazione.action.ActLoadDettaglioPassaggioClasse',
   'Definizione Procedimento -> Passaggio Classe -> Scelta Passaggio di Classe',
   'siap.siep.archiviazione.action.ActUploadPassaggioClasse');

UPDATE DETTAGLIO_PROVVEDIMENTO d
   SET ACTION_UPLOAD = 'siap.siep.ordineesecuzione.action.ActUploadL78del2013'
 WHERE COD_TIPO_EVENTO = '01'
   AND COD_TIPO_PROVVEDIMENTO = '06'
   AND COD_MOTIVO = '1024';