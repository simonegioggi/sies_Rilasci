-- =====================================================================
--  Script per impostare a S il FLAG_VISTO dei messaggi estratti
--  dalla funzione "Istruttorie/Richieste - Riscontro Trasmissioni/Solleciti"
--  che sono stati correttamente presi in carico per l'annotazione 
--  esito e sono quindi puntati da 
--  ANNOTAZIONE_ESITO_TRASMISSIONE.MES_ID_MESSAGGIO_ESITO
--  a sua volta collegato all'evento di annotazione validato
-- =====================================================================
UPDATE MESSAGGIO m
   SET m.FLAG_VISTO = 'S'
 WHERE 1 = 1
   AND m.COD_TIPO_OPERAZIONE IN ('00067', '00079', '00080')
   AND m.FLAG_VISTO = 'N'
   AND EXISTS
 (SELECT 1
          FROM ANNOTAZIONE_ESITO_TRASMISSIONE a, EVENTO e
         WHERE a.EVE_ID_EVENTO = e.ID_EVENTO
           AND e.FLAG_DOCUMENTO_REGISTRATO = 'S'
           AND a.MES_ID_MESSAGGIO_ESITO = m.ID_MESSAGGIO);