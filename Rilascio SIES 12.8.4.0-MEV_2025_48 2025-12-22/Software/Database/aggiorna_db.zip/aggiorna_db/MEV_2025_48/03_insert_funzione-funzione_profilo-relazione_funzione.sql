-- ======================================================================================
-- Funzioni per intervento 
-- 2.14.Prevedere la funzione trasmissione atti per competenza in fase di istruttoria
-- ======================================================================================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080076, 'Load Trasferisci Istruttoria Cumulo', 'C', 'siap.siep.istruttoriacumulo.action.ActLoadTrasferisciIstruttoria');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080076, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080076, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080076, 50, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080076, 30, 'S');

INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080077, 'Ricerca Fasc Per Trasferisci Istruttoria Cumulo', 'R', 'siap.siep.istruttoriacumulo.action.ActRicercaFascPerTrasferisciIstruttoria');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080077, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080077, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080077, 50, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080077, 30, 'S');

INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080078, 'Trasferimento Istruttoria Cumulo', 'I', 'siap.siep.istruttoriacumulo.action.ActTrasferisciIstruttoria');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080078, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080078, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080078, 50, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080078, 30, 'S');

INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080079, 'Carica il dettaglio Istruttoria Trasferita', 'R', 'siap.siep.istruttoriacumulo.action.ActLoadIstruttoriaDopoTrasferimento');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080079, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080079, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080079, 50, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080079, 30, 'S');

-- ======================================================================================
-- Funzioni per intervento 2.15
-- Action dal tasto "x" per marcare il messaggio come VISTO
-- ======================================================================================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080084, 'Marca messaggio Visto', 'M', 'siap.jms.messaggio.action.ActMarcaMessaggio');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080084, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080084, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080084, 50, 'S');

---------------------------------------------------------------------------------------------------
insert into funzione values (32170016, 'Load Ricerca Data Scadenza Procedimenti Esecuzione M.A.', 'R', 'siap.sius.esecuzionemisuraalternativa.action.ActLoadRicercaDataScadenzaProcedimentiEsecuzioneMA');
insert into funzione values (32170017, 'Ricerca Data Scadenza Procedimenti Esecuzione M.A.', 'R', 'siap.sius.esecuzionemisuraalternativa.action.ActRicercaDataScadenzaProcEsecMA');
insert into funzione values (32170018, 'Ricerca Data Scadenza Procedimenti Esecuzione M.A. in Excel', 'R', 'siap.sius.esecuzionemisuraalternativa.action.ActRicercaDataScadenzaProcEsecMAExcel');

insert into relazione_funzione values (32170000, 32170016, 'ME', 'Ricerca Data Scadenza Procedimenti Esecuzione M.A.', 3, null);

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170016, 24, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170016, 32, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170016, 42, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170016, 52, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 14, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 24, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 31, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 32, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 41, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 42, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 51, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170017, 52, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 14, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 24, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 31, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 32, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 41, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 42, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 51, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 32170018, 52, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
---------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------
insert into funzione values (90111955, 'Load Inserimento Def. Proc. - Passaggio Classe', 'I', 'siap.siep.archiviazione.action.ActLoadInserisciPassaggioClasse');
insert into funzione values (90111956, 'Dettaglio Inserimento Def. Proc. - Passaggio Classe', 'D', 'siap.siep.archiviazione.action.ActLoadDettaglioPassaggioClasse');
insert into funzione values (90111957, 'Inserimento Def. Proc. - Passaggio Classe', 'I', 'siap.siep.archiviazione.action.ActInserisciPassaggioClasse');
insert into funzione values (90111958, 'Stampa Def. Proc. - Passaggio Classe', 'S', 'siap.siep.archiviazione.action.ActStampaPassaggioClasse');
insert into funzione values (90111959, 'Upload Def. Proc. - Passaggio Classe', 'M', 'siap.siep.archiviazione.action.ActUploadPassaggioClasse');
insert into funzione values (90111960, 'Load Def. Proc. - Scelta Passaggio Classe', 'L', 'siap.siep.archiviazione.action.ActLoadSceltaPassaggioClasse');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111955, 4,  'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111955, 40, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111955, 50, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111956, 4,  'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111956, 40, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111956, 50, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111957, 4,  'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111957, 40, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111957, 50, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111958, 4,  'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111958, 40, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111958, 50, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111959, 4,  'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111959, 40, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111959, 50, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');

insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111960, 4,  'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111960, 40, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
insert into funzione_profilo values (to_date(sysdate-1, 'dd/MM/yyyy'), null, 90111960, 50, 'MEV_2025-48', to_date(sysdate-1, 'dd/MM/yyyy'), '', null, 'S');
---------------------------------------------------------------------------------------------------

-- ======================================================================================
-- Funzioni per intervento 
-- Gestione Richieste Benefici al GE 
-- Da creare 4 action
-- 21080394 - siap.siep.modulocumulo.action.ActRicercaRichBenGE [caricamento lista provvedimenti]
--  >> ElencoRichiesteAlGEBeneficiCumulo.jsp
-- 21080395 - siap.siep.modulocumulo.action.ActDettaglioRichBenGECumulo (dettaglio)
--  >> DettaglioRichiesteAlGEBeneficiCumulo.jsp
-- 21080396 - siap.siep.modulocumulo.action.ActLoadInserisciRichBenGECumulo
--  >> LoadInserisciRichiesteAlGEBeneficiCumulo.jsp
-- 21080397 - siap.siep.modulocumulo.action.ActInserisciRichBenGECumulo (inserimento/modifica/cancellazione)
--
-- ======================================================================================
-- MEV_2025-48 - ALTRO – Benefici con anticipazione effetti
-- ============================
-- Ricerca
-- ============================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080394, 'Ricerca Richieste Benefici al GE Amn/Ind/Dep/Inc', 'R', 'siap.siep.modulocumulo.action.ActRicercaRichBenGE');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080394, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080394, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080394, 50, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080394, 30, 'S');

-- ============================
-- Dettaglio
-- ============================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080395, 'Dettaglio Richiesta al GE', 'D', 'siap.siep.modulocumulo.action.ActDettaglioRichBenGECumulo');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080395, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080395, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080395, 50, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080395, 30, 'S');

-- ============================
-- Load Inserimento e Modifica
-- ============================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080396, 'Load Inserimento e Modifica Richiesta al GE', 'I', 'siap.siep.modulocumulo.action.ActLoadInserisciRichBenGECumulo');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080396, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080396, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080396, 50, 'S');

-- ============================
-- Inserimento/Modifica/Cancellazione
-- ============================
INSERT INTO FUNZIONE
(ID_FUNZIONE, DESCRIZIONE, COD_TIPO_FUNZIONE, AZIONE_CONTESTO_JAVA)
VALUES(21080397, 'Inserimento, Modifica e Cancellazione Richiesta al GE', 'I', 'siap.siep.modulocumulo.action.ActInserisciRichBenGECumulo');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080397, 4, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080397, 40, 'S');

INSERT INTO FUNZIONE_PROFILO
(DATA_INIZIO_VALIDITA, DATA_FINE_VALIDITA, FUN_ID_FUNZIONE, PRF_COD_PROFILO, FLAG_ATTIVO)
VALUES(TIMESTAMP '2025-10-01 00:00:00.000000', NULL, 21080397, 50, 'S');