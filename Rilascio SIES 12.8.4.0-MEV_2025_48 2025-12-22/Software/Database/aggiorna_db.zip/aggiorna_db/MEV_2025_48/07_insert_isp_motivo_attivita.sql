INSERT INTO ISP_MOTIVO_ATTIVITA
(COD_MOTIVO, DESCRIZIONE_MOTIVO, COD_ATTIVITA, PROGR)
VALUES('0736', 'Archiviazione fascicolo con contestuale iscrizione in altra classe di appartenenza', '47', '011');