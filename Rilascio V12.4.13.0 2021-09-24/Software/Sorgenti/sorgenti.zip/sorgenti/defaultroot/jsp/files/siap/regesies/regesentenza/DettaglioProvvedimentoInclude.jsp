<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="f3b.web.IWebConstants"%>
<%@ page import="f3b.util.DateUtils"%>
<%@ page import="f3b.util.StringUtils"%>
<%@ page import="f3b.util.Utils"%>
<%@ page import="java.util.Iterator" %>
<%@ page import="java.util.Vector" %>

<%@ page import="siap.sico.security.action.ICostantiSecurity" %>
<%@ page import="siap.regesies.regesentenza.model.RegeSentenzaModel"%>
<%@ page import="siap.regesies.regesentenza.action.ICostantiRegeSentenza"%>

<jsp:useBean id="provvedimentoRege"  scope="session" class="siap.regesies.regesentenza.model.ProvvedimentoModel"/>
<%
String isVALIGN = "top";
String isBorder = "0";
String lWidth = "96%";
String largh = "8%";
String resto = "92%";
%>

<html>
<%RegeSentenzaModel lSentenza = provvedimentoRege.getRegeSentenza(); %>

<table>
  <tr>
    <td class="LBGISI" width=<%=largh%> valign="middle">
   <% if(lSentenza.getCodTipoProvvedimento().equals("01")){%>
      <font class="campo">Sentenza ReGe</font>
    <%}else{%>
       <font class="campo">Decreto ReGe</font>
    <%}%>
 	</td>
 		<%-- MEV NUOVA INFRASTRUTTURA: refactoring --%>
 		<%--<td width=< % =resto%>></td></tr><><tr> --%>
	<td>
	<table width="100%"><tr><td class="L" colspan=2>
        <font class="label">N. </font>
        <a class="cliccabile" title="Dettaglio Provvedimento" href="<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>=siap.regesies.regesentenza.action.ActDettaglioProvvedimento&<%=ICostantiRegeSentenza.CAMPO_ID_FILE%>=<%=provvedimentoRege.getRegeSoggetto().getIdFile()%>">
          <%=lSentenza.getAnnoSentenza()%>/<%=lSentenza.getNumeroSentenza()%>
        </a>&nbsp;
       <font  class="label" > del </font>
            <font class="campo"><%=StringUtils.toStringJSP(DateUtils.getDateToString(lSentenza.getDataProvvedimento(),"dd-MM-yyyy"))%></font>&nbsp;
   <font class="label" > emessa da </font>
         <font class="campo"><%=StringUtils.toStringJSP(lSentenza.getDescrTipoAutoritaEmittente())%> </font><font class="label"> di </font><font class="campo"><%=StringUtils.toStringJSP(lSentenza.getDescrLuogoEmittente())%></font>&nbsp;
    </td></tr>
 <tr>
   <td class="L" colspan=2>
    <font class="label">Data Arrivo Atto</font>
       <font class="campo"><%=StringUtils.toStringJSP(DateUtils.getDateToString(lSentenza.getDataArrivoAtto(),"dd-MM-yyyy"),"-")%></font>&nbsp;

      <font class="label">Data Iscrizione</font>
               <font class="campo"><%=StringUtils.toStringJSP(DateUtils.getDateToString(lSentenza.getDataIscrizione(),"dd-MM-yyyy"),"-")%></font>&nbsp;

      <font class="label">Data Irrevocabilit�</font>
         <font class="campo"><%=StringUtils.toStringJSP(DateUtils.getDateToString(lSentenza.getDataIrrevocabilita(),"dd-MM-yyyy"))%></font>&nbsp;
      <font class="label">Note</font>
        <font class="campo"><%=StringUtils.toStringJSP(lSentenza.getNote())%></font>&nbsp;
      </td>
    </tr>
   </table>
  </td>
  </tr>
</table>
  <br>
</html>