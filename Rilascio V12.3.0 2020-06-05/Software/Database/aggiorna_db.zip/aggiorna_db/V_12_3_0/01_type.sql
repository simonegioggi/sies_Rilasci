DROP TYPE INP_AVV;
prompt
prompt Creating type INP_AVV
prompt =====================
prompt
CREATE OR REPLACE TYPE INP_AVV AS OBJECT
(
  ANNO_FAS          NUMBER(4),
  NUME_FAS          NUMBER,
  TIPO_UFF          VARCHAR2(10),
  ID_DISTRETTO      VARCHAR2(11),
  CF_AVV            VARCHAR2(16),
  COD_UFF           VARCHAR2(11)
)
/
