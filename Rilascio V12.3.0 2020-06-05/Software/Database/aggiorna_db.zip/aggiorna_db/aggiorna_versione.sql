update template x  set x.nome_template = substr(x.nome_template,  1,  length(x.nome_template) - 3) || 'rtf' where x.id_template in
(select t.id_template  from template t  where substr(t.nome_template, length(t.nome_template) - 2, 3) = 'RTF');
DELETE FROM versione WHERE cod_versione='12.1.0';
INSERT INTO versione (COD_VERSIONE, DATA, DESCRIZIONE) VALUES ('12.1.0',to_date(to_char(SYSDATE-2,'dd/MM/yyyy'),'dd/MM/yyyy'),'RELEASE 12.1.0 PER MEV 019_020');
DELETE FROM versione WHERE cod_versione='12.2.0';
INSERT INTO versione (COD_VERSIONE, DATA, DESCRIZIONE) VALUES ('12.2.0',to_date(to_char(SYSDATE-1,'dd/MM/yyyy'),'dd/MM/yyyy'),'RELEASE 12.2.0 PER PATCH_04_2020');
DELETE FROM versione WHERE cod_versione='12.3.0';
INSERT INTO versione (COD_VERSIONE, DATA, DESCRIZIONE) VALUES ('12.3.0',to_date(to_char(SYSDATE,'dd/MM/yyyy'),'dd/MM/yyyy'), 'RELEASE 12.3.0 PER PATCH_05_2020');