#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV_2023_33_STEP_1/aggiorna_db.sql