-------------------------------------------------------------------------------
-- Scopo ..: Creazione degli oggetti del database del sistema informativo
-- Note ...: eseguire da SQLPLUS /NOLOG
--
-- MEV_2023_33_STEP_1
-------------------------------------------------------------------------------

WHENEVER SQLERROR CONTINUE
WHENEVER OSERROR CONTINUE

PROMPT Procedura di installazione versione MEV_2023_33_STEP_1 di SIES
PROMPT
PROMPT Se non si intende procedere chiudere SQL*Plus premendo adesso CTRL+C
PAUSE oppure premere INVIO...

ACCEPT dbsid PROMPT 'Inserire il SID dell''istanza Oracle (esempio SIES) ... : ';
ACCEPT siesuser PROMPT 'Inserire il nome dello schema SIES ... : ';
ACCEPT pwd_sies PROMPT 'Inserire la password dello schema SIES ... : ';

PROMPT
PROMPT Per generare il file di log ed il percorso dei datafile in modo opportuno
PROMPT occorre indicare un nome mnemonico per questa installazione.
PROMPT Valore di default: &dbsid
PROMPT
ACCEPT nomeinstallazione PROMPT 'Inserire il nome di questa installazione : ' DEFAULT &dbsid

DEFINE logpath=log
HOST mkdir -p &logpath

PROMPT
PROMPT Inserimento dati completato
PAUSE Premere INVIO per continuare...
PROMPT
SPOOL &logpath/&nomeinstallazione..log

PROMPT
PROMPT ==============================================================================
PROMPT Riassunto dei dati immessi per questa installazione
PROMPT Nome ....................: &nomeinstallazione
PROMPT ==============================================================================
PROMPT SID Oracle ..............: &dbsid
PROMPT Utente_SIES..............: &siesuser
PROMPT Password_SIES............: &pwd_sies
PROMPT ==============================================================================
!echo '=============================================================================='
!echo '***** DATA INIZIO PROCEDURA:' `date +%d/%m/%Y_%r`
!echo '=============================================================================='
PROMPT
PROMPT Se non si intende procedere chiudere adesso SQL*Plus premendo CTRL+C
PAUSE altrimenti premere INVIO per continuare...

!cd $ORACLE_HOME/bin

CONNECT &siesuser/&pwd_sies@&dbsid

SET TERMOUT ON;
PROMPT 
PROMPT ===================================================
PROMPT  LANCIO AGGIORNAMENTO DATI MEV_2023_33_STEP_1 ...
PROMPT ===================================================
PROMPT
SET TERMOUT OFF;

SET TERMOUT ON;
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 01...
PROMPT ===================================================
PROMPT
@MEV_2023_33/01_CREATE_TABLE_INVOCAZIONE.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 02...
PROMPT ===================================================
PROMPT
@MEV_2023_33/02_CREATE_TABLE_BOLLETTINO_BATCH_PAGOPA.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 03...
PROMPT ===================================================
PROMPT
@MEV_2023_33/03_Create_Table_ERRORI_SIES_PAGOPA.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 04...
PROMPT ===================================================
PROMPT
@MEV_2023_33/04_ALTER_TABLE_RINNOVO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 05...
PROMPT ===================================================
PROMPT
@MEV_2023_33/05_Alter_table_RINNOVO_X_Solleciti.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 06...
PROMPT ===================================================
PROMPT
@MEV_2023_33/06_AlterTable_BATCH_PAGOPA.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 07...
PROMPT ===================================================
PROMPT
@MEV_2023_33/07_Aggiorna_FUNZIONE.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 08...
PROMPT ===================================================
PROMPT
@MEV_2023_33/08_Aggiorna_FUNZIONE_PROFILO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 09...
PROMPT ===================================================
PROMPT
@MEV_2023_33/09_Aggiorna_RELAZIONE_FUNZIONE.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 10...
PROMPT ===================================================
PROMPT
@MEV_2023_33/10_Insert_Funzioni_Comma5.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 11...
PROMPT ===================================================
PROMPT
@MEV_2023_33/11_Insert_Funzioni_Nota_Trasmissione_Bollettini.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 12...
PROMPT ===================================================
PROMPT
@MEV_2023_33/12_Insert_Funzioni_Rinnovazioni.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 13...
PROMPT ===================================================
PROMPT
@MEV_2023_33/13_Insert_Funzioni_Rinnovo.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 14...
PROMPT ===================================================
PROMPT
@MEV_2023_33/14_Insert_Funzioni_Scadenzario.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 15...
PROMPT ===================================================
PROMPT
@MEV_2023_33/15_Insert_Funzioni_Solleciti.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 16...
PROMPT ===================================================
PROMPT
@MEV_2023_33/16_Insert_STATO_PROCEDIMENTO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 17...
PROMPT ===================================================
PROMPT
@MEV_2023_33/17_Insert_CG_MOTIVO_ARCHIVIAZIONE_DefinizioneProcedimento.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 18...
PROMPT ===================================================
PROMPT
@MEV_2023_33/18_Insert_CG_REF_CODES_SIEP.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 19...
PROMPT ===================================================
PROMPT
@MEV_2023_33/19_Insert_CG_REF_CODES_SIGE.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 20...
PROMPT ===================================================
PROMPT
@MEV_2023_33/20_Insert_CG_REF_CODES_Solleciti.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 21...
PROMPT ===================================================
PROMPT
@MEV_2023_33/21_Insert_DETTAGLIO_PROVVEDIMENTO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 22...
PROMPT ===================================================
PROMPT
@MEV_2023_33/22_Insert_DETTAGLIO_PROVVEDIMENTO_nota_trasmissione.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 23...
PROMPT ===================================================
PROMPT
@MEV_2023_33/23_Insert_Funzioni_di_Ricerca_Stato_Pagamenti.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 24...
PROMPT ===================================================
PROMPT
@MEV_2023_33/24_Insert_Funzioni_Gestione_Batch.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 25...
PROMPT ===================================================
PROMPT
@MEV_2023_33/25_Insert_isp_oggetto_esito.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 26...
PROMPT ===================================================
PROMPT
@MEV_2023_33/26_Insert_TEMPLATE_SIEP.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 27...
PROMPT ===================================================
PROMPT
@MEV_2023_33/27_Insert_TEMPLATE_SIUS.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 28...
PROMPT ===================================================
PROMPT
@MEV_2023_33/28_InsertFunzioniCruscotto.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 29...
PROMPT ===================================================
PROMPT
@MEV_2023_33/29_Insert_ModalitaPagamentoMenu.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 30...
PROMPT ===================================================
PROMPT
@MEV_2023_33/30_Insert_pene_sostitutive_brevi.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 31...
PROMPT ===================================================
PROMPT
@MEV_2023_33/31_AGGIORNA_TEMPLATE_OI.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 32...
PROMPT ===================================================
PROMPT
@MEV_2023_33/32_Aggiornamento_cg_ref_codes_SIUS.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 33...
PROMPT ===================================================
PROMPT
@MEV_2023_33/33_Aggiornamento_cg_ref_codes_SIUS-U125.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 34...
PROMPT ===================================================
PROMPT
@MEV_2023_33/34_AGGIORNA_POSIZIONI_GIURIDICHE.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 35...
PROMPT ===================================================
PROMPT
@MEV_2023_33/35_UPDATE_CG_REF_CODE_VVR.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 36...
PROMPT ===================================================
PROMPT
@MEV_2023_33/36_deleteScadenzario.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 37...
PROMPT ===================================================
PROMPT
@MEV_2023_33/37_Insert_PesoEsitoTenore.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO 38...
PROMPT ===================================================
PROMPT
@MEV_2023_33/38_Insert_TipoRegistro.sql
SET TERMOUT OFF;

SET TERMOUT ON;
COMMIT;

PROMPT 
PROMPT ===================================================
PROMPT  LANCIO AGGIORNAMENTO VERSIONE...
PROMPT ===================================================
PROMPT
SET TERMOUT OFF;
@aggiorna_versione.sql

SET TERMOUT ON;
COMMIT;

PROMPT
PROMPT ==============================================================================
PROMPT *******          ******** | Operazioni completate | *******           ********
PROMPT ==============================================================================
PROMPT Le operazioni sono state registrate sul file
PROMPT &logpath/creazione_&nomeinstallazione..log
PROMPT ==============================================================================
!echo '=============================================================================='
!echo '***** DATA FINE PROCEDURA:' `date +%d/%m/%Y_%r`
!echo '=============================================================================='
PROMPT

DISCONNECT

SPOOL off

PAUSE Premere INVIO per concludere...
EXIT