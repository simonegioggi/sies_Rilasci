INSERT INTO CG_REF_CODES
VALUES('STATO_PROCEDIMENTO', '0363', NULL, 'In esecuzione', 'Emesso Avviso Pagamento Rate successive alla prima', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
VALUES('STATO_PROCEDIMENTO', '0364', NULL, 'In esecuzione', 'Emesso Provvedimento Rideterminazione Pena Pecuniaria Sostitutiva', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
VALUES('STATO_PROCEDIMENTO', '0365', NULL, 'In esecuzione', 'Emesso Provvedimento Avviso Mancato Pagamento', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
VALUES('STATO_PROCEDIMENTO', '0366', NULL, 'In esecuzione', 'Emesso Provvedimento Avvenuto pagamento pena pecuniaria', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
VALUES('STATO_PROCEDIMENTO', '0367', NULL, 'In esecuzione', 'Trasmessi Atti a Magistrato di Sorveglianza per Conversione Pena Pecuniaria Sostitutiva', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES
VALUES('STATO_PROCEDIMENTO', '0368', NULL, 'Definito', 'Archiviazione a seguito Provvedimento Avvenuto Pagamento Pena Pecuniaria', NULL, NULL, NULL, NULL);