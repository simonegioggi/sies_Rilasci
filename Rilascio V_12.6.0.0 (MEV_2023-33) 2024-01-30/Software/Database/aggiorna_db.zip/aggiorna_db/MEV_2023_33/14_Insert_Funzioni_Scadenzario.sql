-- ==============================================================================
-- Caricamento griglia scadenzari
-- ==============================================================================
INSERT INTO FUNZIONE VALUES (15010091, 'Load Griglia Scadenzari Pene Pecuniarie', 'R', 'siap.siep.sanzionesostitutiva.action.ActGrigliaScadenzari');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010091, 4, NULL, NULL, NULL, NULL, 'S');
--INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 15010091, 30, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010091, 40, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010091, 50, NULL, NULL, NULL, NULL, 'S');

-- ==============================================================================
-- Load Ricerca Scadenzari
-- ==============================================================================
INSERT INTO FUNZIONE VALUES (15010128, 'Load Ricerca Scadenzari Pene Pecuniarie', 'R', 'siap.siep.scadenzario.action.ActLoadRicercaScadenzarioStatoPagamentiPP');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010128, 4, NULL, NULL, NULL, NULL, 'S');
--INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 15010128, 30, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010128, 40, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010128, 50, NULL, NULL, NULL, NULL, 'S');

-- ==============================================================================
-- Ricerca Scadenzari
-- ==============================================================================
INSERT INTO FUNZIONE VALUES (15010129, 'Ricerca Scadenzari Pene Pecuniarie', 'R', 'siap.siep.scadenzario.action.ActRicercaScadenzarioStatoPagamentiPP');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010129, 4, NULL, NULL, NULL, NULL, 'S');
--INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 15010129, 30, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010129, 40, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES (TIMESTAMP '2023-01-01 00:00:00.000000', NULL, 15010129, 50, NULL, NULL, NULL, NULL, 'S');