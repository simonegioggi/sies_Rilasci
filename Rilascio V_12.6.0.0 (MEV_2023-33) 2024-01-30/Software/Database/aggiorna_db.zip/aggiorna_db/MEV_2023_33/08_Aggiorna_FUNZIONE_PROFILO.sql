-- FUNZIONE_PROFILO:
-- AVVISO BATCH PAGOPA
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 24020165, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 24020165, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 24020165, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 24020165, 50, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 24020165, 99, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 24020165, 90, null, null, null, null, 'S');

-- RIDETERMINAZIONE P.P.
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010007, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010007, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010007, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010007, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010008, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010008, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010008, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010008, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010009, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010009, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010009, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010009, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010010, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010010, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010010, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010010, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010011, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010011, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010011, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010011, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010012, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010012, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010012, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010012, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010013, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010013, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010013, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010013, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010014, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010014, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010014, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010014, 50, null, null, null, null, 'S');

-- AVVISO MANCATO PAGAMENTO
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010016, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010016, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010016, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010016, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010017, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010017, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010017, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010017, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010018, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010018, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010018, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010018, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010019, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010019, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010019, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010019, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010020, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010020, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010020, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010020, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010021, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010021, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010021, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010021, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010022, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010022, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010022, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010022, 50, null, null, null, null, 'S');

-- PROVVEDIMENTO ESTINZIONE PENA PECUNIARIA
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010024, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010024, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010024, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010024, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010025, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010025, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010025, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010025, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010026, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010026, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010026, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010026, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010027, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010027, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010027, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010027, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010028, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010028, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010028, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010028, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010029, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010029, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010029, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010029, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010030, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010030, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010030, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010030, 50, null, null, null, null, 'S');

-- TRASMISSIONE ATTI CONVERSIONE
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010031, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010031, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010031, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010031, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010032, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010032, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010032, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010032, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010033, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010033, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010033, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010033, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010034, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010034, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010034, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010034, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010035, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010035, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010035, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010035, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010036, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010036, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010036, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010036, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010037, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010037, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010037, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010037, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010038, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010038, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010038, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010038, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010039, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010039, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010039, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010039, 50, null, null, null, null, 'S');

-- DEFINIZIONE PROCEDIMENTO PENA PECUNIARIA
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010040, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010040, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010040, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010040, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010041, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010041, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010041, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010041, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010042, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010042, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010042, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010042, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010043, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010043, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010043, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010043, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010044, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010044, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010044, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010044, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010045, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010045, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010045, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010045, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010046, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010046, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010046, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010046, 50, null, null, null, null, 'S');

-- Gestione Pene Sostitutive Brevi
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010070, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010070, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010070, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010070, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010071, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010071, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010071, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010071, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010072, 4, null, null, null, null, 'S');
-- insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010072, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010072, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010072, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010073, 4, null, null, null, null, 'S');
-- insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010073, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010073, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010073, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010074, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010074, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010074, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010074, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010075, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010075, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010075, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010075, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010076, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010076, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010076, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010076, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010077, 4, null, null, null, null, 'S');
-- insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010077, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010077, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010077, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010078, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010078, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010078, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010078, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010079, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010079, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010079, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010079, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010082, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010082, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010082, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010082, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010083, 4, null, null, null, null, 'S');
/* insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010083, 30, null, null, null, null, 'S'); */
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010083, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values (trunc(sysdate), null, 15010083, 50, null, null, null, null, 'S');

-- LEGENDA: loadInserisci, Inserisci, loadModifica, Modifica, Upload e Stampa NON per il profilo 30 (solo Dettaglio, Griglie, Ricerche)
/*
4	SUPERUTENTE PER L'ESECUZIONE	
	14	SUPERUTENTE PER IL TRIBUNALE DI SORVEGLIANZA	
	15	SUPERUTENTE PER L'UFFICIO di ESECUZIONE PENALE ESTERNA	
	16	SUPERUTENTE PER UFFICIO GIUDICE ESECUZIONE	
	24	SUPERUTENTE PER L'UFFICIO DI SORVEGLIANZA	
30	LETTURA PER L'ESECUZIONE	
	31	LETTURA PER IL TRIBUNALE DI SORVEGLIANZA	
	32	LETTURA PER L'UFFICIO DI SORVEGLIANZA	
	33	LETTURA PER L'UFFICIO DI ESECUZIONE PENALE ESTERNA	
	36	LETTURA PER UFFICIO GIUDICE ESECUZIONE	
40	LETTURA/SCRITTURA PER L'ESECUZIONE	
	41	LETTURA/SCRITTURA PER IL TRIBUNALE di SORVEGLIANZA	
	42	LETTURA/SCRITTURA PER L'UFFICIO di SORVEGLIANZA	
	43	LETTURA/SCRITTURA PER L'UFFICIO di ESECUZIONE PENALE EST.	
	46	LETTURA/SCRITTURA PER UFFICIO GIUDICE ESECUZIONE	
50	LETTURA/SCRITTURA/MODIFICA PER L'ESECUZIONE	
	51	LETTURA/SCRITTURA/MODIFICA PER IL TRIBUNALE DI SORVEGLIANZA	
	52	LETTURA/SCRITTURA/MODIFICA PER L'UFFICIO di SORVEGLIANZA	
	53	LETTURA/SCRITTURA/MODIFICA PER L'UFFICIO di ES.PEN.EST.	
	56	LETTURA/SCRITTURA/MODIFICA PER UFFICIO GIUDICE ESECUZIONE	
	90	AMMINISTRATORE D'UFFICIO	
	99	GESTORE UTENTI E PROFILI	
*/