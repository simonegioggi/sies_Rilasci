INSERT INTO JMS_CODE
VALUES
  ('TIPO_OPERAZIONE', '00034', 'TRASFERIMENTO PENA SOSTITUTIVA');
INSERT INTO JMS_CODE
VALUES
  ('TIPO_OPERAZIONE', '00035', 'ESITO TRASFERIMENTO PENA SOSTITUTIVA');
INSERT INTO CG_REF_CODES
VALUES
  ('MOTIVO_PROVVEDIMENTO',
   '1313',
   NULL,
   NULL,
   'Al Mds per l''esecuzione di pene sostitutive a seguito restituzione',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO CG_REF_CODES
VALUES
  ('MOTIVO_PROVVEDIMENTO',
   '1312',
   NULL,
   NULL,
   'Al Mds per l''esecuzione di pene sostitutive',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO CG_REF_CODES
VALUES
  ('STATO_PROCEDIMENTO',
   '0369',
   NULL,
   'In esecuzione',
   'Trasmissione atti al MdS per l''esecuzione di Pene Sostitutive',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1312',
   'NOTA_TRASM_PENSOS.rtf',
   'Trasmissione Atti Pene Sostitutive - Libero (P.G. in ''07,10,16,17, 46,47,89,90'')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1312',
   '0',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1312_2',
   'NOTA_TRASM_PENSOS_2.rtf',
   'Trasmissione Atti Pene Sostitutive - A.D.Q.C. (P.G. in ''02,23,70,71, 72'''')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1312',
   '1',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1312_3',
   'NOTA_TRASM_PENSOS_3.rtf',
   'Trasmissione Atti Pene Sostitutive - C.C.Q.C.Detenuto (P.G. in ''01,22,55, 73'''')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1312',
   '2',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1312_4',
   'NOTA_TRASM_PENSOS_4.rtf',
   'Trasmissione Atti Pene Sostitutive - C.C.A.C.Arresti Dom. (P.G. in ''78,79,80, 81'')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1312',
   '3',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1312_5',
   'NOTA_TRASM_PENSOS_5.rtf',
   'Trasmissione Atti Pene Sostitutive - C.C.A.C. Detenuto (P.G. in ''75,76,77'')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1312',
   '4',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1313',
   'NOTA_TRASM_PENSOS.rtf',
   'Trasmissione Atti Pene Sostitutive - Libero (P.G. in ''07,10,16,17, 46,47,89,90'')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1313',
   '0',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1313_2',
   'NOTA_TRASM_PENSOS_2.rtf',
   'Trasmissione Atti Pene Sostitutive - A.D.Q.C. (P.G. in ''02,23,70,71, 72'''')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1313',
   '1',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1313_3',
   'NOTA_TRASM_PENSOS_3.rtf',
   'Trasmissione Atti Pene Sostitutive - C.C.Q.C.Detenuto (P.G. in ''01,22,55, 73'''')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1313',
   '2',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1313_4',
   'NOTA_TRASM_PENSOS_4.rtf',
   'Trasmissione Atti Pene Sostitutive - C.C.A.C.Arresti Dom. (P.G. in ''78,79,80, 81'')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1313',
   '3',
   NULL,
   NULL,
   NULL,
   NULL);
INSERT INTO TEMPLATE
VALUES
  ('SIEP_SP_1313_5',
   'NOTA_TRASM_PENSOS_5.rtf',
   'Trasmissione Atti Pene Sostitutive - C.C.A.C. Detenuto (P.G. in ''75,76,77'')',
   '/var/SIES/template/siep/sp/',
   '02',
   '31',
   '1313',
   '4',
   NULL,
   NULL,
   NULL,
   NULL);