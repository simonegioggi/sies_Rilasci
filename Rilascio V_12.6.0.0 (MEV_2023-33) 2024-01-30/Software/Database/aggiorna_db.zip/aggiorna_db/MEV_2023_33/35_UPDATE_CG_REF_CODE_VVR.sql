-- =============================================================================
--   Aggiornamento della CG_REF_CODES per il codice 0622 - Ordine di ingiunzione
--   per consentire l'emissione di un VVR sull'ordine di ingiunzione
-- =============================================================================
UPDATE CG_REF_CODES
SET RV_ALT2_VALUE = 'LEGA-VVR'
WHERE RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO'
AND RV_LOW_VALUE = '0622';

-- ================================================================== 
-- Abilitazione al verbale vane ricerche anche per gli eventi
-- 1307 - Rideterminazione della Pena Pecuniaria
-- 1308 - Avviso mancato pagamento Pena Pecuniaria
-- ================================================================== 
UPDATE CG_REF_CODES set RV_ALT2_VALUE = 'LEGA-VVR'
 WHERE RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO'
   AND RV_LOW_VALUE IN ('1307','1308');

-- TipoAutoritaPolizia (30 records)
update cg_ref_codes c
   set c.rv_alt2_value = 'AP'
 where c.rv_domain = 'TIPO_AUTORITA'
   and c.rv_low_value in 
   ('19','20','28','32','33','35','58','59','60','61','62','64','65','66','67','68','69','70','71','72','73','74','79','80','91','92','93','94','95','96');