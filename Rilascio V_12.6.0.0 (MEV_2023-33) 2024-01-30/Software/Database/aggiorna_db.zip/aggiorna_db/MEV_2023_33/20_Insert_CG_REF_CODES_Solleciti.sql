-- Nuovi codici per i sollecit' OIPP. E' necessario differenzionare sul DB tra 
-- 'Ufficiali Giudiziari' e 'Autorita' di Polizia' altrimenti non si possono 
-- Dettaglio e Stampe
INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING)
VALUES('TIPO_RINNOVO', 'SU', NULL, NULL, 'Sollecito Ufficiali Giudiziari');

INSERT INTO CG_REF_CODES
(RV_DOMAIN, RV_LOW_VALUE, RV_HIGH_VALUE, RV_ABBREVIATION, RV_MEANING)
VALUES('TIPO_RINNOVO', 'SP', NULL, NULL, 'Sollecito Autorita'' di Polizia');
