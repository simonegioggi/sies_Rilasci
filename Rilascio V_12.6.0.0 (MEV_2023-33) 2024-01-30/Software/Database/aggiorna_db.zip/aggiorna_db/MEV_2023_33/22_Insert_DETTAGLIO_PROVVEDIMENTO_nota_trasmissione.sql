-- Registrazione dell'evento sulal DETTAGLIO_PROVVEDIMENTO
INSERT INTO DETTAGLIO_PROVVEDIMENTO
VALUES
  ('01',
   '12',
   '1306',
   'siap.siep.sanzionesostitutiva.action.ActLoadDettaglioNotaTrasmissione',
   'Gestione Altre Sanzioni -> Riscossione Pene Pecuniarie -> Ordine Ingiunzione -> Nota Trasmissione',
   'siap.siep.sanzionesostitutiva.action.ActUploadNotaTrasmissione');