-- FUNZIONE
insert into funzione t values (24020165, 'Load Avviso Batch PagoPA', 'L', 'siap.siep.pagoPA.action.ActLoadAvvisoBatchPagoPA');

-- RIDETERMINAZIONE P.P.
insert into funzione t values (15010007, 'Load Inserimento Rideterminazione Pena Pecuniaria', 'L', 'siap.siep.rateizzazionepp.action.ActLoadInserisciRideterminazionePP');
insert into funzione t values (15010008, 'Inserimento Rideterminazione Pena Pecuniaria', 'I', 'siap.siep.rateizzazionepp.action.ActInserisciRideterminazionePP');
insert into funzione t values (15010009, 'Dettaglio Rideterminazione Pena Pecuniaria', 'D', 'siap.siep.rateizzazionepp.action.ActDettaglioRideterminazionePP');
insert into funzione t values (15010010, 'Griglia Ordine Ingiunzione e Altri Provvedimenti', 'L', 'siap.siep.sanzionesostitutiva.action.ActGrigliaOrdineIngiunzioneAltriProvvedimenti');
insert into funzione t values (15010011, 'Load Modifica Rideterminazione Pena Pecuniaria', 'L', 'siap.siep.rateizzazionepp.action.ActLoadModificaRideterminazionePP');
insert into funzione t values (15010012, 'Modifica Rideterminazione Pena Pecuniaria', 'M', 'siap.siep.rateizzazionepp.action.ActModificaRideterminazionePP');
insert into funzione t values (15010013, 'Upload Rideterminazione Pena Pecuniaria', 'V', 'siap.siep.rateizzazionepp.action.ActUploadRideterminazionePP');
insert into funzione t values (15010014, 'Stampa Rideterminazione Pena Pecuniaria', 'S', 'siap.siep.rateizzazionepp.action.ActStampaRideterminazionePP');

-- AVVISO MANCATO PAGAMENTO
insert into funzione t values (15010016, 'Load Inserimento Avviso Mancato Pagamento', 'L', 'siap.siep.rateizzazionepp.action.ActLoadInserisciAvvisoMancatoPagamento');
insert into funzione t values (15010017, 'Inserimento Avviso Mancato Pagamento', 'I', 'siap.siep.rateizzazionepp.action.ActInserisciAvvisoMancatoPagamento');
insert into funzione t values (15010018, 'Dettaglio Avviso Mancato Pagamento', 'D', 'siap.siep.rateizzazionepp.action.ActDettaglioAvvisoMancatoPagamento');
insert into funzione t values (15010019, 'Load Modifica Avviso Mancato Pagamento', 'L', 'siap.siep.rateizzazionepp.action.ActLoadModificaAvvisoMancatoPagamento');
insert into funzione t values (15010020, 'Modifica Avviso Mancato Pagamento', 'M', 'siap.siep.rateizzazionepp.action.ActModificaAvvisoMancatoPagamento');
insert into funzione t values (15010021, 'Upload Avviso Mancato Pagamento', 'V', 'siap.siep.rateizzazionepp.action.ActUploadAvvisoMancatoPagamento');
insert into funzione t values (15010022, 'Stampa Avviso Mancato Pagamento', 'S', 'siap.siep.rateizzazionepp.action.ActStampaAvvisoMancatoPagamento');

-- PROVVEDIMENTO ESTINZIONE PENA PECUNIARIA
insert into funzione t values (15010024, 'Load Inserimento Provvedimento Estinzione Pena Pecuniaria', 'L', 'siap.siep.rateizzazionepp.action.ActLoadInserisciProvvedimentoEstinzionePP');
insert into funzione t values (15010025, 'Inserimento Provvedimento Estinzione Pena Pecuniaria', 'I', 'siap.siep.rateizzazionepp.action.ActInserisciProvvedimentoEstinzionePP');
insert into funzione t values (15010026, 'Dettaglio Provvedimento Estinzione Pena Pecuniaria', 'D', 'siap.siep.rateizzazionepp.action.ActDettaglioProvvedimentoEstinzionePP');
insert into funzione t values (15010027, 'Load Modifica Provvedimento Estinzione Pena Pecuniaria', 'L', 'siap.siep.rateizzazionepp.action.ActLoadModificaProvvedimentoEstinzionePP');
insert into funzione t values (15010028, 'Modifica Provvedimento Estinzione Pena Pecuniaria', 'M', 'siap.siep.rateizzazionepp.action.ActModificaProvvedimentoEstinzionePP');
insert into funzione t values (15010029, 'Upload Provvedimento Estinzione Pena Pecuniaria', 'V', 'siap.siep.rateizzazionepp.action.ActUploadProvvedimentoEstinzionePP');
insert into funzione t values (15010030, 'Stampa Provvedimento Estinzione Pena Pecuniaria', 'S', 'siap.siep.rateizzazionepp.action.ActStampaProvvedimentoEstinzionePP');

-- TRASMISSIONE ATTI CONVERSIONE
insert into funzione t values (15010031, 'Trasferici Atti Conversione Pene Pecuniarie',	'T', 'siap.siep.rateizzazionepp.action.ActTrasferisciAttiConversione');
insert into funzione t values (15010032, 'Load Inserimento Trasmissione Atti Conversione', 'L', 'siap.siep.rateizzazionepp.action.ActLoadInserisciTrasmissioneAttiConversione');
insert into funzione t values (15010033, 'Inserimento Trasmissione Atti Conversione', 'I', 'siap.siep.rateizzazionepp.action.ActInserisciTrasmissioneAttiConversione');
insert into funzione t values (15010034, 'Dettaglio Trasmissione Atti Conversione', 'D', 'siap.siep.rateizzazionepp.action.ActDettaglioTrasmissioneAttiConversione');
insert into funzione t values (15010035, 'Load Modifica Trasmissione Atti Conversione', 'L', 'siap.siep.rateizzazionepp.action.ActLoadModificaTrasmissioneAttiConversione');
insert into funzione t values (15010036, 'Modifica Trasmissione Atti Conversione', 'M', 'siap.siep.rateizzazionepp.action.ActModificaTrasmissioneAttiConversione');
insert into funzione t values (15010037, 'Upload Trasmissione Atti Conversione', 'V', 'siap.siep.rateizzazionepp.action.ActUploadTrasmissioneAttiConversione');
insert into funzione t values (15010038, 'Stampa Trasmissione Atti Conversione', 'S', 'siap.siep.rateizzazionepp.action.ActStampaTrasmissioneAttiConversione');
insert into funzione values (15010039, 'Load Trasferisci Atti Conversione Pene Pecuniarie', 'T', 'siap.siep.rateizzazionepp.action.ActLoadTrasferisciAttiConversione');

-- DEFINIZIONE PROCEDIMENTO PENA PECUNIARIA
insert into funzione t values (15010040, 'Load Inserimento Definizione Procedimento Pena Pecuniaria', 'L', 'siap.siep.rateizzazionepp.action.ActLoadInserisciDefinizioneProcedimentoPP');
insert into funzione t values (15010041, 'Inserimento Definizione Procedimento Pena Pecuniaria', 'I', 'siap.siep.rateizzazionepp.action.ActInserisciDefinizioneProcedimentoPP');
insert into funzione t values (15010042, 'Dettaglio Definizione Procedimento Pena Pecuniaria', 'D', 'siap.siep.rateizzazionepp.action.ActDettaglioDefinizioneProcedimentoPP');
insert into funzione t values (15010043, 'Load Modifica Definizione Procedimento Pena Pecuniaria', 'L', 'siap.siep.rateizzazionepp.action.ActLoadModificaDefinizioneProcedimentoPP');
insert into funzione t values (15010044, 'Modifica Definizione Procedimento Pena Pecuniaria', 'M', 'siap.siep.rateizzazionepp.action.ActModificaDefinizioneProcedimentoPP');
insert into funzione t values (15010045, 'Upload Definizione Procedimento Pena Pecuniaria', 'V', 'siap.siep.rateizzazionepp.action.ActUploadDefinizioneProcedimentoPP');
insert into funzione t values (15010046, 'Stampa Definizione Procedimento Pena Pecuniaria', 'S', 'siap.siep.rateizzazionepp.action.ActStampaDefinizioneProcedimentoPP');

-- Gestione Pene Sostitutive Brevi
insert into funzione t values (15010070, 'Griglia Esecuzione Pene Sostitutive Brevi', 'L', 'siap.siep.sanzionesostitutiva.action.ActGrigliaEsecuzionePeneSostitutiveBrevi');
insert into funzione t values (15010071, 'Griglia Semiliberta/Detenzione Domiciliare', 'L', 'siap.siep.sanzionesostitutiva.action.ActGrigliaSemilibertaDetenzioneDomiciliare');
insert into funzione t values (15010072, 'Load Trasmissione Atti per Esecuzione', 'L', 'siap.siep.sanzionesostitutiva.action.ActLoadTrasmissioneAttiEsecuzione');
insert into funzione t values (15010073, 'Trasmissione Atti per Esecuzione', 'I', 'siap.siep.sanzionesostitutiva.action.ActTrasmissioneAttiEsecuzione');
insert into funzione t values (15010074, 'Load Riscontro Trasmissione Atti per Esecuzione', 'L', 'siap.siep.sanzionesostitutiva.action.ActLoadRiscontroTrasmissioneAttiEsecuzione');
insert into funzione t values (15010075, 'Riscontro Trasmissione Atti per Esecuzione', 'R', 'siap.siep.sanzionesostitutiva.action.ActRiscontroTrasmissioneAttiEsecuzione');
insert into funzione t values (15010076, 'Load Dettaglio Trasmissione Atti per Esecuzione', 'D', 'siap.siep.sanzionesostitutiva.action.ActLoadDettaglioTrasmissioneAttiEsecuzione');
insert into funzione t values (15010077, 'Conferma Trasmissione Atti per Esecuzione Pena Sostitutiva', 'I', 'siap.siep.sanzionesostitutiva.action.ActConfermaTrasmissioneAttiEsecuzionePS');
insert into funzione t values (15010078, 'Upload Trasmissione Atti per Esecuzione Pena Sostitutiva', 'V', 'siap.siep.sanzionesostitutiva.action.ActUploadTrasmissioneAttiEsecuzionePS');
insert into funzione t values (15010079, 'Stampa Trasmissione Atti per Esecuzione Pena Sostitutiva', 'S', 'siap.siep.sanzionesostitutiva.action.ActStampaTrasmissioneAttiEsecuzionePS');
insert into funzione t values (15010082, 'Load Modifica Trasmissione Atti per Esecuzione Pena Sostitutiva', 'L', 'siap.siep.sanzionesostitutiva.action.ActLoadModificaTrasmissioneAttiEsecuzione');
insert into funzione t values (15010083, 'Modifica Trasmissione Atti per Esecuzione Pena Sostitutiva', 'M', 'siap.siep.sanzionesostitutiva.action.ActModificaTrasmissioneAttiEsecuzione');

-- LEGENDA: CG_REF_CODES.TIPO_FUNZIONE
/*
A			Allega documento
C			Cancellazione
D			Dettaglio
F			Compilazione Foglio Complementare
I			Inserimento
L			Load
M			Modifica
O			Svalidazione
R			Ricerca
S			Stampa
T			Trasferimento
V			Validazione
X			Inserimento_Copia
Y			Modifica difensore in Gestione Parti
*/