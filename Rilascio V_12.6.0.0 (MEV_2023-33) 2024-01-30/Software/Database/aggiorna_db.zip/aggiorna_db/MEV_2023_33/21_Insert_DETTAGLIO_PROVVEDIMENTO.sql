-- Rideterminazione della Pena Pecuniaria
insert into dettaglio_provvedimento
values
  ('01',
   '04',
   '1307',
   'siap.siep.rateizzazionepp.action.ActDettaglioRideterminazionePP',
   'Gestione Altre Sanzioni --> Riscossione Pene Pecuniarie --> Ordine Ingiunzione / Altri Provvedimenti --> Rideterminazione della Pena Pecuniaria',
   'siap.siep.rateizzazionepp.action.ActUploadRideterminazionePP');
-- Avviso Mancato Pagamento
insert into dettaglio_provvedimento
values
  ('01',
   '04',
   '1308',
   'siap.siep.rateizzazionepp.action.ActDettaglioAvvisoMancatoPagamento',
   'Gestione Altre Sanzioni --> Riscossione Pene Pecuniarie --> Ordine Ingiunzione / Altri Provvedimenti --> Avviso Mancato Pagamento',
   'siap.siep.rateizzazionepp.action.ActUploadAvvisoMancatoPagamento');
--- Avvenuto pagamento
INSERT INTO DETTAGLIO_PROVVEDIMENTO
VALUES('01',
       '04',
       '1309',
       'siap.siep.rateizzazionepp.action.ActDettaglioProvvedimentoEstinzionePP',
       'Gestione Altre Sanzioni --> Riscossione Pene Pecuniarie --> Ordine Ingiunzione / Altri Provvedimenti --> Provvedimento Avvenuto Pagamento', 
       'siap.siep.rateizzazionepp.action.ActUploadProvvedimentoEstinzionePP');
-- Trasmissione Atti per la Conversione
insert into dettaglio_provvedimento
values
  ('02',
   '31',
   '1310',
   'siap.siep.rateizzazionepp.action.ActDettaglioTrasmissioneAttiConversione',
   'Gestione Altre Sanzioni --> Riscossione Pene Pecuniarie --> Ordine Ingiunzione / Altri Provvedimenti --> Trasmissione Atti per la Conversione',
   'siap.siep.rateizzazionepp.action.ActUploadTrasmissioneAttiConversione');
-- Definizione Procedimento
INSERT INTO DETTAGLIO_PROVVEDIMENTO
VALUES('01',
       '25', 
       '1311', 
       'siap.siep.rateizzazionepp.action.ActDettaglioDefinizioneProcedimentoPP',
	   'Gestione Altre Sanzioni --> Riscossione Pene Pecuniarie --> Ordine Ingiunzione / Altri Provvedimenti --> Definizione Procedimento', 
       'siap.siep.rateizzazionepp.action.ActUploadDefinizioneProcedimentoPP');
-- Trasmissione Atti per l'Esecuzione
insert into dettaglio_provvedimento
values
  ('02',
   '31',
   '1312',
   'siap.siep.sanzionesostitutiva.action.ActLoadDettaglioTrasmissioneAttiEsecuzione',
   'Gestione Altre Sanzioni --> Esecuzione Pene Sostitutive Brevi --> Semiliberta''/Detenzione Domiciliare --> Trasmissione Atti per Esecuzione',   'siap.siep.sanzionesostitutiva.action.ActUploadTrasmissioneAttiEsecuzionePS');
-- RiTrasmissione Atti per l'Esecuzione
INSERT INTO DETTAGLIO_PROVVEDIMENTO
VALUES
  ('02',
   '31',
   '1313',
   'siap.siep.sanzionesostitutiva.action.ActLoadDettaglioTrasmissioneAttiEsecuzione',
   'Gestione Altre Sanzioni --> Esecuzione Pene Sostitutive Brevi --> Semiliberta''/Detenzione Domiciliare --> Trasmissione Atti per Esecuzione',
   'siap.siep.sanzionesostitutiva.action.ActUploadTrasmissioneAttiEsecuzionePS');