-- Aggiunto il campo ESITO per gestire l'esito della notifica agli ufficiali giudiziari
-- ESITO = serve per gestire il nuovo campo esito 
ALTER TABLE RINNOVO ADD ESITO VARCHAR2(1);
COMMENT ON COLUMN RINNOVO.ESITO IS 'MEV_2023-33  Esito positivo (P), Esito Negativo (N)';