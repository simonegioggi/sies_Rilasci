-- Aumentata la larghezza el campo COD_TIPO_RINNOVO per gestire i nuovi codice SF e SG per
-- i sollecito OIPP
ALTER TABLE RINNOVO MODIFY COD_TIPO_RINNOVO VARCHAR2(2);

