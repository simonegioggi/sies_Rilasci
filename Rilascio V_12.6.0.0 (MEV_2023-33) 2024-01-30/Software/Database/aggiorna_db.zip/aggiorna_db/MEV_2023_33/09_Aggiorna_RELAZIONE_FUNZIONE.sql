-- RELAZIONE_FUNZIONE
insert into relazione_funzione values (15010034, 15010039, 'BO', 'Trasmissione Conversione Atti Pene Pecuniarie', 1, null);
insert into relazione_funzione values (15010075, 21020075, 'BO', 'Dettaglio Provvedimento Trasmesso', 1, null);