-- ==================================================================
-- Aggiunta di 2 contatori al Batch 
-- ==================================================================
ALTER TABLE BATCH_PAGOPA ADD NUM_IUV_VERIFICATI NUMBER(4,0) NULL;
ALTER TABLE BATCH_PAGOPA ADD NUM_ERRORI_INVOCAZIONE NUMBER(4,0) NULL;



