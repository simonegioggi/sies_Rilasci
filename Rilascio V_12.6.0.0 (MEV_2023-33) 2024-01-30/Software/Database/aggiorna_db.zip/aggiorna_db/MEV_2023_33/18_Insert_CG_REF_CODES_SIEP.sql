--- INSERIMENTO nuovi Oggetti SIEP
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '1306', NULL, NULL, 'Nota trasmissione Bollettini rate successive alla prima', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '1307', NULL, NULL, 'Rideterminazione della Pena Pecuniaria', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '1308', NULL, NULL, 'Avviso mancato pagamento Pena Pecuniaria', NULL, '', NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '1309', NULL, NULL, 'Avvenuto pagamento Pena Pecuniaria', NULL, '', NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '1310', NULL, NULL, 'Atti all''UDS per la conversione pena pecuniaria', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '1311', 'ESPIAZ', NULL, 'Archiviazione a seguito provvedimento Avvenuto pagamento Pena Pecuniaria', '', NULL, NULL, NULL);
