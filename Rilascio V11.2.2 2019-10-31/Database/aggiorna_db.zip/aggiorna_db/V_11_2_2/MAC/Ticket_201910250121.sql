
update dettaglio_provvedimento
   set action_upload = 'siap.siep.sanzionesostitutiva.action.ActUploadTrasmissioneAttiEsecuzione'
 where cod_tipo_evento = '02'
   and cod_tipo_provvedimento = '31'
   and cod_motivo = '0396'
