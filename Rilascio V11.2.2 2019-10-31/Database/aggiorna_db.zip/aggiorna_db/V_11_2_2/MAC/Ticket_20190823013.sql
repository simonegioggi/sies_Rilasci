insert into cg_ref_codes
  (RV_DOMAIN,
   RV_LOW_VALUE,
   RV_HIGH_VALUE,
   RV_ABBREVIATION,
   RV_MEANING,
   RV_ALT2_VALUE,
   RV_ALT3_VALUE,
   RV_ALT4_VALUE,
   RV_ALT5_VALUE)
values
  ('FORO_AVVOCATI',
   'NAPOLI NORD',
   'VALIDO',
   null,
   'NAPOLI NORD',
   null,
   null,
   null,
   null);
