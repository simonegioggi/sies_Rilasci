<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transational//EN">

<%@ page language="java" import="f3b.web.IWebConstants" %>
<%@ page import="siap.sico.magistrato.action.ICostantiMagistrato" %>


<html>
  <head>
    <link rel="STYLESHEET" type="text/css" href="<%=IWebConstants.PG_STYLE%>">
    <script language="JavaScript" src=<%=IWebConstants.JS_VALIDATOR%>> </script>

    <script language="JavaScript">
      function  Verify()
      {
        var ritorno = true;

        /*if (document.f.<%=ICostantiMagistrato.CAMPO_COGNOME%>.value.length < 3)
        {
          alert("Occorre inserire almeno 3 caratteri iniziali del COGNOME.");
          ritorno = false;
        }*/
        return ritorno;
      }
    </script>
    </script>

    <title>{S.I.E.S.] - Filtro Magistrati</title>
  </head>

  <body class="corpo" onload=document.f.submit();>
    <FORM method="POST" action="<%= IWebConstants.PG_MAIN%>" name="f" target=listaMagistrati>
    <input type="HIDDEN" name="<%=IWebConstants.ACTION_FIELD%>" value="siap.sico.magistrato.action.ActRicercaMag">
    <input type="HIDDEN" name="formname" value="<%=request.getParameter("formname")%>">
    <input type="HIDDEN" name="fieldname" value="<%=request.getParameter("fieldname")%>">
    <input type="HIDDEN" name="field2" value="<%=request.getParameter("field2")%>">
    <input type="HIDDEN" name="field3" value="<%=request.getParameter("field3")%>">

   <table>
    <tr>
      <td class=LBG><font class="campo">Filtra la lista  per : </font></td>
    </tr>
    <tr>
      <td class="l">Cognome</td>
      <td class="l"> <input value="" type="text" name="<%=ICostantiMagistrato.CAMPO_COGNOME%>" onFocus="javascript:document.f.go.disabled=false;"> </td>
      <td><input onclick="Javascript:return Verify();" type="submit" name="go" value="Filtra >>"></td>
    </tr>



  </table>
</form>
 <script language="JavaScript" type="text/javascript">
      var frmvalidator  = new Validator("f");

      frmvalidator.setAddnlValidationFunction("Verify");
    </script>
  </body>
</html>
