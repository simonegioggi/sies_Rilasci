<%@ page import="siap.web.ISIAPCostantiWeb"%>
<%@ page import="f3b.web.IWebConstants"%>

<script language="JavaScript" src="<%=ISIAPCostantiWeb.JS_CONTROL_UPLOAD_NEW%>"></script>
<jsp:useBean id="Stampabile" scope="request" class="java.lang.String"/>

  <script language="JavaScript">

    function stampaSiep(lAzione)
   {
      var  hrefStampa = lAzione;
      var lIndice = hrefStampa.indexOf("?");

     //alert (lAzione);
      var parametri = hrefStampa.substring(lIndice+1,lAzione.length);
     // alert (ciccio);
      stampa2("<%=ISIAPCostantiWeb.PG_STAMPA%>",  parametri);
   }
 </script>


   <!-- BOTTONE DI STAMPA -->
     <td>
      <a href="Javascript:stampaSiep('<%=request.getParameter("ActionLink")%>')">
        <img src="/images/print.gif" alt="Visualizza Stampa" width="12" height="12" border="0">
      </a>
     </td>

