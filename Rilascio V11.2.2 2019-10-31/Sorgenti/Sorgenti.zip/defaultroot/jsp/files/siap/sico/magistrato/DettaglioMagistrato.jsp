<%@ page import="f3b.web.IWebConstants"%>
<%@ page import="f3b.util.DateUtils"%>
<%@ page import="f3b.util.StringUtils" %>
<%@ page import="siap.sico.magistrato.model.MagistratoModel"%>
<%@ page import="siap.sico.magistrato.action.ICostantiMagistrato"%>

<jsp:useBean id="magistrato" scope="request" class="siap.sico.magistrato.model.MagistratoModel"/>
<html>
<head>
<title>[S.I.E.S.] - Dettaglio Magistrato </title>

<link rel="STYLESHEET" type="text/css" href="<%=IWebConstants.PG_STYLE%>">

<script language="JavaScript" src="/html/conferma.js"></script>

</head>

<body class="corpo">
  <FORM name="comandi" >
    <table>
      <tr><td class="LBG"><a align="absmiddle" href="Javascript:window.print();"><img src="<%=IWebConstants.IMAGES_DIR%>quickprint24.gif" alt="Stampa questa videata" border=0></a></td>
        <td class="LBG">
          <font class="label">Funzione :</font>&nbsp;
          <font class="campo">Dettaglio Magistrato</font>
        </td>
      <td class="LBG">
          <jsp:include page="<%=IWebConstants.PG_TOOLBAR_HEADER%>">
          <jsp:param name="CampoIdEntita" value="<%=ICostantiMagistrato.CAMPO_COD_MAGISTRATO%>" />
          <jsp:param name="ValoreIdEntita" value="<%=magistrato.getCodMagistrato()%>" />
       </jsp:include>
     </td>
   </tr>
 </table>
</FORM>
		 <table cellspacing=2 cellpadding=2>
		<tr>
				<td class="l">CodMagistrato</td>
				<td class="l"><font class="campo"><%=magistrato.getCodMagistrato() %></font></td>
		</tr>
		<tr>
				<td class="l">Cognome</td>
				<td class="l"><font class="campo"><%=magistrato.getCognome() %></font></td>
		</tr>
		<tr>
				<td class="l">Nome</td>
				<td class="l"><font class="campo"><%=magistrato.getNome() %></font></td>
		</tr>
        	<tr>
				<td class="l">Email Ufficio</td>
				<td class="l"><font class="campo"><%=StringUtils.toStringJSP(magistrato.getEMailUfficio(),"-") %></font></td>
		</tr>
        	<tr>
				<td class="l">Email Privata</td>
				<td class="l"><font class="campo"><%=StringUtils.toStringJSP(magistrato.getEMailPrivata(),"-") %></font></td>
		</tr>
        	<tr>
				<td class="l">Num. cell.</td>
				<td class="l"><font class="campo"><%=StringUtils.toStringJSP(magistrato.getNumCellulare(),"-") %></font></td>
		</tr>
        	<tr>
				<td class="l">Disponibilit�</td>
				<td class="l"><font class="campo"><%=magistrato.getFlagStato() %></font></td>
		</tr>
		<tr>
				<td class="l">Data Inizio Validit�</td>
				<td class="l"><font class="campo"><%=DateUtils.getDateToString(magistrato.getDataInizioValidita(),"dd-MM-yyyy")%> </font></td>
		</tr>
		<tr>
				<td class="l">Data Fine Validit�</td>
				<td class="l"><font class="campo"><%=StringUtils.toStringJSP(DateUtils.getDateToString(magistrato.getDataFineValidita(),"dd-MM-yyyy"),"-")%> </font></td>
                </tr>

		</table>	</body>
</html>
