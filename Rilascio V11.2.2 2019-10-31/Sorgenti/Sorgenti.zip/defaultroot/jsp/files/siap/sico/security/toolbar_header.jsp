<%@ page import="java.util.Iterator" %>
<%@ page import="java.util.Collection" %>

<%@ page import="f3b.web.IWebConstants" %>
<%@ page import="f3b.security.model.FunctionModel" %>

<%@ page import="siap.web.ISIAPCostantiWeb" %>
<%@ page import="siap.sico.utente.model.UtenteModel" %>
<%@ page import="siap.sius.fascicolo.model.FascicoloSiusModel" %>
<%@ page import="siap.siep.fascicolo.model.FascicoloSiepModel" %>
<%@ page import="siap.sico.soggetto.model.SoggettoModel" %>
<%@ page import="siap.siep.sentenza.model.SentenzaModel" %>
<%@ page import="f3b.security.model.ProfileModel" %>

<%@ page import="siap.sico.security.action.ICostantiSecurity" %>
<%@ page import="siap.sico.security.ICostantiFunzioni" %>

<jsp:useBean id="TornaQui"     scope="request" class="java.lang.String"/>

<script language="JavaScript" src="<%=ISIAPCostantiWeb.JS_CONTROL_UPLOAD_NEW%>"></script>

<%
	String lCodUffAppartenenza  = request.getParameter("valoreufficio");
  
  //if (TornaQui != null) System.out.println("TornaQui ->"+ TornaQui);

  Collection lFunFiglie = (Collection)request.getAttribute(ICostantiSecurity.FUN_FIGLIE);

  String lModificabile= "SI";//Parametro che vale per la cancellazione e la modifica
  String lCancellabile= "SI";//Parametro che vale solo per la cancellazione e non per la modifica
  boolean lDiProprieta = true; //Booleno che indica se il fasicolo � prorpio o di un altro ufficio
  String lInsertAllegato= "SI";//Parametro che indica se l'utente potr� inserire allegati (solo per i procedimenti iscritti dal proprio ufficio)

  UtenteModel lUtenteMod = new UtenteModel((UtenteModel)session.getAttribute(ICostantiSecurity.SESSION_UTENTE_CONNESSO));
  String lUffUtente =  lUtenteMod.getUfficioUtente().getCodUfficio();
  ProfileModel lProfilo = (ProfileModel)lUtenteMod.getUserProfile();
	
  //Modifica 22-01-08 per mev a8-rr-012
  if (request.getParameter("Cancellabile") != null)
  {//Parametro che vale solo per la cancellazione e non per la modifica
	  lCancellabile = request.getParameter("Cancellabile");
  }

  //Modifica 14-07-2015 per mev 10 S3
  if (request.getParameter("InsertAllegato") != null)
  {
	  lInsertAllegato = request.getParameter("InsertAllegato");
  }

  if (request.getParameter("Modificabile") != null)
  {
    lModificabile = request.getParameter("Modificabile");
    // Nel caso di "Posizione Materiale Fascicolo SIUS" se il fascicolo
    // non � modificabile bisogna disattivare anche il bottone di Inserimento 
    // 31/05/2010 Bottone di inserimento Posizione Materiale riattivato.
    //if (lModificabile.equalsIgnoreCase("NO") && request.getParameter("tipo_posizione_materiale") != null)
    //{
    //   if (request.getParameter("tipo_posizione_materiale").equalsIgnoreCase("SIUS"))
		//		{
    //    	//System.out.print( ">>> Cambio boolean di propriet� (tipo_posizione_materiale) <<< " );
    //      lDiProprieta = false;
		//		}
    //}
  }
  else
  {
  	
  	if (!(	lUtenteMod.getUfficioUtente().getCodTipoUfficio().equals("UDS")||
    				lUtenteMod.getUfficioUtente().getCodTipoUfficio().equals("TDS")||
         		lUtenteMod.getUfficioUtente().getCodTipoUfficio().equals("UEPE") ||
         		lUtenteMod.getUfficioUtente().getCodTipoUfficio().equals("UEPESS") ))
   {
      FascicoloSiepModel lFas = (FascicoloSiepModel)session.getAttribute("fascicolo");

      if (lFas != null)
      {
				if (!lUffUtente.equals(lFas.getChiaveUfficio()))
				{

        	//System.out.print( ">>> Cambio boolena di propriet� (lUffUtente) <<< : " + lUffUtente );
	  			//System.out.print( ">>> Cambio boolena di propriet� (CodUfficioInserimento) <<< : " + lFas.getCodUfficioInserimento() );
					lDiProprieta = false;
        }
      }

    }
  }

  //Visualizzazione dei bottoni
  if( (lFunFiglie != null) && (lFunFiglie.size() != 0) )
  {
    Iterator lIterBottoni = lFunFiglie.iterator();
    FunctionModel lFun = null;
    while(lIterBottoni.hasNext())
    {
      lFun = (FunctionModel)lIterBottoni.next();

      if(lFun.getVisualizzazionType() != null && lFun.getVisualizzazionType().equals(ICostantiFunzioni.FUNZIONE_BOTTONE))
      {
        if(lFun.getFunctionType().equals(ICostantiFunzioni.TIPO_INSERIMENTO) && lDiProprieta)
        {
%>
          <a href="<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>=<%=lFun.getNameAction()%>&<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>=<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>&TornaQui=<%=TornaQui%>">
            <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>new24.gif" alt="Inserisci" width="24" height="24" border="0">
          </a>
<%
        }

        if(lFun.getFunctionType().equals(ICostantiFunzioni.TIPO_MODIFICA)  && (lModificabile.compareTo("SI")==0 && lDiProprieta))
        {
%>
          <a href="<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>=<%=lFun.getNameAction()%>&<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>=<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>&TornaQui=<%=TornaQui%>">
            <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>modifica24.gif" alt="Modifica" width="24" height="24" border="0">
          </a>
<%
        }

        if(lFun.getFunctionType().equals(ICostantiFunzioni.TIPO_CANCELLA) && lModificabile.equals("SI")
        		&& !("00000").equals(lCodUffAppartenenza) && lDiProprieta && lCancellabile.equals("SI"))
        {
%>
          <a href="Javascript:conferma('<%=lFun.getNameAction()%>','<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>','<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>');">
            <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>delete24.gif" alt="Cancella" width="24" height="24" border="0">
          </a>
<%
        }

        if(lFun.getFunctionType().equals(ICostantiFunzioni.TIPO_STAMPA))
        {
        // Nuova Stampa Luigi 26-11-2004
%>
          <a href="Javascript:stampa2( '<%=ISIAPCostantiWeb.PG_STAMPA%>', '<%=IWebConstants.ACTION_FIELD%>=<%=lFun.getNameAction()%>&<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>=<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>&TornaQui=<%=TornaQui%>')";>
            <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>print24.gif" alt="Stampa" width="24" height="24" border="0">
          </a>
<%
        }

        if(lFun.getFunctionType().equals(ICostantiFunzioni.TIPO_INSERIMENTO_COPIA))
        {
%>
          <a href="<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>=<%=lFun.getNameAction()%>&<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>=<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>&TornaQui=<%=TornaQui%>">
            <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>arrow24.gif" alt="Inserimento con Copia" width="24" height="24" border="0">
          </a>
<%
        }
        
        // MEV 10 - Bottoni visibili solo per SIEP
        if( lProfilo.isSiep()){
        	
        	if(lFun.getFunctionType().equals(ICostantiFunzioni.TIPO_ALLEGARE_DOC) && lInsertAllegato.equals("SI"))
            {
%>
              <a href="<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>=<%=lFun.getNameAction()%>&<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>=<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>&TipoOperazione=A&TornaQui=<%=TornaQui%>">
                <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>allegatoTrasparente.png" alt="Allegare Documento" width="24" height="24" border="0">
              </a>
<%
            }

            if(lFun.getFunctionType().equals(ICostantiFunzioni.TIPO_RICERCA))
            {
%>
              <a href="<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>=<%=lFun.getNameAction()%>&<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>=<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>&TipoOperazione=R&TornaQui=<%=TornaQui%>">
                <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>ricercaSoggettoNelProcedimentoTrasparente.png" alt="Ricerca Soggetto" width="24" height="24" border="0">
              </a>
<%
            }
            
        }

        lIterBottoni.remove();
      }
    }

    //Visualizzazione della combo
    Iterator lIterCombo = lFunFiglie.iterator();
    if( lFunFiglie.size() != 0 )
    {
       boolean inseritaPrima = false;
       boolean daInserire = false;

%>
      <SCRIPT LANGUAGE="JavaScript">
      <%-- MEV NUOVA INFRASTRUTTURA: refactoring --%>
        function submit( aAction )
        {
          var lCampoIdEntita="<%=request.getParameter(ICostantiSecurity.CAMPO_ID_ENTITA)%>";

          document.location.href='<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>='+aAction+'&'+lCampoIdEntita+'=<%=request.getParameter(ICostantiSecurity.VALORE_ID_ENTITA)%>'+'&TornaQui=<%=TornaQui%>';
        }
      </SCRIPT>
<%
        while(lIterCombo.hasNext())
        {
          lFun = (FunctionModel)lIterCombo.next();

         //System.out.println(lFun.getFunctionType());
          if(lFun.getVisualizzazionType() != null && lFun.getVisualizzazionType().equals(ICostantiFunzioni.FUNZIONE_COMBO))
          {
        		//System.out.println( "lDiProprieta : "  +  lDiProprieta );
          	//System.out.println( "lModificabile : "  +  lModificabile );

              if(lModificabile.compareTo("SI")==0 && lDiProprieta)
              {
                    //System.out.println("Presa!!");
                    daInserire = true;
              }
              else
                {
                  //System.out.println( "lDiProprieta : "  +  lDiProprieta );
                  //System.out.println( "lModificabile : "  +  lModificabile );

                  //System.out.println( "lFun.getFunctionType() : " + lFun.getFunctionType() );
                  if( lFun.getFunctionType().compareTo("I")==0
                    ||lFun.getFunctionType().compareTo("M")==0
                    ||lFun.getFunctionType().compareTo("C")==0 )
                    {
                       //System.out.println("Scartata!!");
                       daInserire = false;
                    }
                  else
                  {
                      //System.out.println("Presa!!");
                      daInserire = true;
                  }
                }
                // Inserimento della funzione nella combo
                if (daInserire )
                {
                  if (!inseritaPrima)
                  {
                     inseritaPrima = true;
%>              <select name="vai">  <%
                  }
%>              <option value="<%=lFun.getNameAction()%>"><%=lFun.getLabelFunction()%></option><%
                }
             lIterCombo.remove();
          }
        }

       if (inseritaPrima)
       {
%>
        </select>
        <a href="javascript:submit(document.forms[0].vai.value);">
          <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>vedi24.gif" alt="Vai" width="24" height="24" border="0">
        </a>
<%
       }
    }
  }

  if(   request.getParameter(ISIAPCostantiWeb.CAMPO_AZIONE_CHIAMANTE) != null
     && !request.getParameter(ISIAPCostantiWeb.CAMPO_AZIONE_CHIAMANTE).equals(""))
  {
    String lAzioneChiamante = request.getParameter(ISIAPCostantiWeb.CAMPO_AZIONE_CHIAMANTE);
%>
    <td class="LBG">
      <a href="<%=IWebConstants.PG_MAIN%>?<%=IWebConstants.ACTION_FIELD%>=<%=lAzioneChiamante%>">
        <img align="absmiddle" src="<%=IWebConstants.IMAGES_DIR%>arrowleft24.gif" alt="ritorna su" width="24" height="24" border="0">
      </a>
    </td>
<%
  }
%>
