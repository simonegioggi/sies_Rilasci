<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<%@ page import="siap.sico.magistrato.action.ICostantiMagistrato" %>
<%@ page import="siap.sico.magistrato.model.MagistratoModel" %>
<%@ page import="siap.sico.w_magistrato.model.WMagistratoModel" %>

<%@ page import="java.util.Iterator" %>
<%@ page import="java.util.Collection" %>
<%@ page import="f3b.util.StringUtils" %>
<%@ page import="f3b.util.DateUtils"%>
<%@ page import="f3b.web.IWebConstants"%>

<jsp:useBean id="magistrati" scope="request" class="java.util.Vector" />
<jsp:useBean id="modalita" scope="request" class="java.lang.String" />
<jsp:useBean id="formname" scope="request" class="java.lang.String" />
<jsp:useBean id="fieldname" scope="request" class="java.lang.String" />
<jsp:useBean id="field2" scope="request" class="java.lang.String" />
<jsp:useBean id="field3" scope="request" class="java.lang.String" />




<html>
  <head>
    <title>[S.I.E.S.] - Lista Magistrati</title>
    <link rel="STYLESHEET" type="text/css" href="/css/style.css">
    <% if (! modalita.equals("NoPop"))
    {
    %>
    <script language="JavaScript">
        function insertIT(cod,cognome,nome)
        {
          window.parent.opener.document.<%=formname%>.<%=fieldname%>.value=cod;
          window.parent.opener.document.<%=formname%>.<%=field2%>.value=cognome;
          window.parent.opener.document.<%=formname%>.<%=field3%>.value=nome;
          window.parent.close();
          return;
        }

      function checkListaComuni()
    {
      if ("<%=magistrati.size()%>" == 0)
        alert('Attenzione! Nessun Magistrato trovato.');
      if ("<%=magistrati.size()%>" == 200)
        alert('Attenzione! Visualizzati solo i primi 200 Magistrati individuati. Perfezionare la ricerca!');
    }
    </script>
    <%
    }
    %>
  </head>

  <body class=corpo onload="checkListaComuni();">
    <table>
      <tr><td class="LBG"><a align="absmiddle" href="Javascript:window.print();"><img src="<%=IWebConstants.IMAGES_DIR%>quickprint24.gif" alt="Stampa questa videata" border=0></a></td>
        <td class="LBG"><font class=label>Funzione :</font>&nbsp;<font class="campo">Elenco Magistrati Ufficio</font></td>
      </tr>
    </table>
<%if(magistrati.size()>0){%>
    <Table width="100%">
    <tr>
    <td class=int>Cod</td>
    <td class=int>Nome</td>
    <td class=int>Data Nascita</td>
    <% if (! modalita.equals("NoPop"))
    { %>
      <td class=int>Seleziona</td>
    <%
    } %>
    </tr>
    <%
    Iterator itx = magistrati.iterator();


    while ( itx.hasNext() )
    {
      MagistratoModel lMag = (MagistratoModel)itx.next();

    %>
      <tr>
        <td class=l><%=StringUtils.toStringJSP(lMag.getCodMagistrato(),"-")%></td>
        <td class=l><%=StringUtils.toStringJSP(lMag.getCognome(),"-") + " " + StringUtils.toStringJSP(lMag.getNome(),"-")%></td>
        <td class=l><%=DateUtils.getDateToString(lMag.getDataNascita(),"dd-MM-yyyy")%> </td>

      <%
      if (! modalita.equals("NoPop"))
      { %>
        <td class=c><a href="Javascript:insertIT('<%=StringUtils.cStrForJS(lMag.getCodMagistrato())%>','<%=StringUtils.cStrForJS(lMag.getCognome())%>','<%=StringUtils.cStrForJS(lMag.getNome())%>');"> <img align="absmiddle" src="/images/fileselected.gif" border=0></a></td>
        <% } %>
      </tr>
    <%
    }
    %>
    </table>
<%}%>
  </body>
</html>
