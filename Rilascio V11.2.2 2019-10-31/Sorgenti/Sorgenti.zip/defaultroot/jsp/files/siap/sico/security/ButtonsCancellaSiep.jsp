<%@ page import="f3b.web.IWebConstants"%>


	     <!-- BOTTONE DI CANCELLAZIONE -->
		     <td>
	         <a href="<%=request.getParameter("LinkAction")%>">
		         <img  align="absmiddle" src="/images/delete.gif" alt="Cancellazione" width="12" height="12" border="0">
		      </a>
		    </td>

