<%@ page import="java.util.Iterator" %>
<%@ page import="java.lang.String" %>
<%@ page import="f3b.util.DateUtils"%>
<%@ page import="f3b.util.StringUtils" %>

<%@ page import="siap.sico.libertaanticipata.action.ICostantiLibertaAnticipata"%>
<%@ page import="siap.sico.libertaanticipata.model.LicenzaPeriodiLibAnticipataModel"%>
<%@ page import="siap.sico.libertaanticipata.model.PeriodoLibAnticipataModel"%>
<%@ page import="siap.sico.libertaanticipata.model.LicenzaLibAnticipataModel"%>


<jsp:useBean id="Licenze"     scope="request" class="java.util.Vector"/>

<%
//System.out.println("Dettaglio Licenza");
  if (Licenze.size() > 0)
  {
    Iterator itx = Licenze.iterator();
    LicenzaLibAnticipataModel permesso = (LicenzaLibAnticipataModel) Licenze.get(0);
%>
    <table cellspacing="2" cellpadding="2">
    <tr> <td> <br></td></tr>
    <tr>
        <td class="Titolo" colspan=6> Quantum Pena da Computare <td>
    </tr>
          <tr>
            <td class=l><%="Giorni "+StringUtils.toStringJSP(permesso.getNumeroGiorni(),"-")%></td>
          </tr>
    <tr> <td> <br></td></tr>
   </table>
<%
  }
%>




