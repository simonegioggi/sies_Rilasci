<%@ page import="siap.web.ISIAPCostantiWeb"%>
<%@ page import="f3b.util.StringUtils"%>
<%@ page import="f3b.util.DateUtils"%>

<%@ page import="siap.bdmc.fascicolosiepbdmc.model.FascicoloSiepBdmcModel"%>
<%@ page import="siap.bdmc.fascicolosiepbdmc.action.ICostantiFascicoloSiepBdmc"%>

<jsp:useBean id="modalita" scope="request" class="java.lang.String"/>
<jsp:useBean id="fascicolosiepbdmc" scope="request" class="siap.bdmc.fascicolosiepbdmc.model.FascicoloSiepBdmcModel"/>

<jsp:useBean id="descUfficioBdmc" scope="request" class="java.lang.String"/>
<jsp:useBean id="descUfficioSiep" scope="request" class="java.lang.String"/>

<html>
<head>
  <%  if( modalita.equals("D") )  {%> 
  <title> Dettaglio Associazione Fascicolo Siep-Bdmc </title>
  <%}%> 
  <link rel="STYLESHEET" type="text/css" href="<%=ISIAPCostantiWeb.PG_STYLE%>">
  <script language="JavaScript" src="<%=ISIAPCostantiWeb.JS_CONFIRM%>"></script>
</head>

<body class="corpo">

<FORM name="comandi" >
  <table>
    <tr>
      <td class="LBG">
        <a align="absmiddle" href="Javascript:window.print();"> 
          <img src="<%=ISIAPCostantiWeb.IMAGES_DIR%>quickprint24.gif" alt="Stampa questa videata" border=0> 
        </a>
      </td>
      <td class="LBG">
        <font class="label">Funzione :</font>&nbsp;
      <%  if( modalita.equals("D") )  {%> 
        <font class="campo">Dettaglio Associazione Fascicolo Siep-Bdmc</font>
      <%} %> 
      </td>
       <td class="LBG">
          <a href="javascript:history.back()">
            <img align="absmiddle" src="/images/arrowleft24.gif" alt="ritorna su" width="24" height="24" border="0">
          </a>
        </td>
    </tr>
  </table>
</FORM>

<table cellspacing=4 cellpadding=4>
 
  <tr>
    <td class="l">Anno / Numero Bdmc</td>
    <td class="l">
	    <font class="campo"><%=StringUtils.toStringJSP(fascicolosiepbdmc.getChiaveAnnoBdmc()) %></font>&nbsp;
		<font class="campo">/</font>&nbsp;
	    <font class="campo"><%=StringUtils.toStringJSP(fascicolosiepbdmc.getChiaveProgrBdmc()) %></font>&nbsp;
    </td>

  </tr>
  <tr>
    <td class="l">Ufficio Bdmc</td>
    <td class="l"><font class="campo"><%=descUfficioBdmc %></font>&nbsp;</td>
  </tr>
  <tr>
    <td class="l">Anno / Numero Siep</td>
    <td class="l">
    <font class="campo"><%=StringUtils.toStringJSP(fascicolosiepbdmc.getChiaveAnnoSiep()) %></font>&nbsp;
    <font class="campo">/</font>&nbsp;
    <font class="campo"><%=StringUtils.toStringJSP(fascicolosiepbdmc.getChiaveProgrSiep()) %></font>&nbsp;
    </td>
  </tr>
  <tr>
    <td class="l">Ufficio Siep</td>
    <td class="l"><font class="campo"><%=descUfficioSiep %></font>&nbsp;</td>
  </tr>
  <tr>
    <td class="l">Trasmissione</td>
    <%String flag_trasm = StringUtils.toStringJSP(fascicolosiepbdmc.getFlagTrasmissione()); %>
      <%  if( flag_trasm.equalsIgnoreCase("S") )  {%> 
		<td class="l"><font class="campo">SI</font>&nbsp;</td>
      <%} %> 
      <%  if( flag_trasm.equalsIgnoreCase("N") )  {%> 
		<td class="l"><font class="campo">NO</font>&nbsp;</td>
      <%} %> 
      <%  if( flag_trasm.equalsIgnoreCase("") )  {%> 
		<td class="l"><font class="campo">&nbsp;</font>&nbsp;</td>
      <%} %> 

  </tr>
</table>
</body>
</html>
