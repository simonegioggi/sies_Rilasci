<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<%@ page import="java.util.Iterator" %>
<%@ page import="java.math.BigDecimal"%>

<%@ page import="f3b.web.IWebConstants" %>
<%@ page import="f3b.util.DateUtils" %>
<%@ page import="f3b.util.StringUtils" %>

<%@ page import="siap.sico.evento.action.ICostantiEvento"%>
<%@ page import="siap.sico.evento.model.EventoModel"%>
<%@ page import="siap.sico.misuraalternativa.model.MisuraAlternativaEventoModel"%>
<%@ page import="siap.sico.misuraalternativa.model.MisuraAlternativaModel"%>
<%@ page import="siap.siep.misuraalternativa.action.ICostantiMisuraAlternativa"%>

<%@ page import="siap.web.ISIAPCostantiWeb" %>
<%@ page import="siap.siep.beneficio.action.ICostantiBeneficio"%>
<%@ page import="siap.siep.beneficio.model.BeneficioModel"%>
<%@ page import="siap.siep.fascicolo.model.FascicoloSiepModel" %>

<jsp:useBean id="documentiSius" scope="request" class="java.util.ArrayList" />

<jsp:useBean id="benefici" 		scope="request" class="java.util.Vector" />
<jsp:useBean id="ComingFromInsert" scope="request" class="java.lang.String"/>
<jsp:useBean id="ComingFrom" 	scope="request" class="java.lang.String"/>
<jsp:useBean id="lTipoFunzione" scope="request" class="java.lang.String"/>

<html>
  <head>
    <link rel="STYLESHEET" type="text/css" href="<%=IWebConstants.PG_STYLE%>">
    <title>[S.I.E.S.] - Lista Benefici Concessi</title>

    <script language="JavaScript" src="/html/conferma.js"></script>
    <script language="JavaScript">

      function controlla()
      {
<%
        boolean esistonoDati = false;
        if( !documentiSius.isEmpty() )
          esistonoDati = true;
%>
        if(<%=!esistonoDati%>)
        {
          alert("Nessun dato presente");

          window.parent.close();
        }
      }

      function insertIT( id,
                         annoSius,
                         numeroSius,
                         annoOrdinanza,
                         numeroOrdinanza,
                         tipoAutorita,
                         sedeAutorita,
                         oggetto,
                         natura,
                         giorno,
                         mese,
                         anno,
                         luogoProva,
                         giornoInizioMisura,
                         meseInizioMisura,
                         annoInizioMisura,
                         giornoInizioRevocaMisura,
                         meseInizioRevocaMisura,
                         annoInizioRevocaMisura,
                         anniRevocaReclusione,
                         mesiRevocaReclusione,
                         giorniRevocaReclusione,
                         anniRevocaArresto,
                         mesiRevocaArresto,
                         giorniRevocaArresto,
                         note,
                         tipodecisione,
                         flagScarcerato,
                         giornoFineMisura,
                         meseFineMisura,
                         annoFineMisura,
                         giorniMisura,
                         mesiMisura,
                         anniMisura,
                         flagDecisioneTribunale,
                         sedeTdsCompetente
                         )
      {
        window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ID_DOCUMENTO_SIUS%>.value=id;

        if(annoSius!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_CHIAVE_ANNO_FASCICOLO_SIUS%>.value=annoSius;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_CHIAVE_ANNO_FASCICOLO_SIUS%>.value="";

        if(numeroSius!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_CHIAVE_PROGR_FASCICOLO_SIUS%>.value=numeroSius;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_CHIAVE_PROGR_FASCICOLO_SIUS%>.value="";

        if (annoOrdinanza!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_REGISTRO%>.value=annoOrdinanza;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_REGISTRO%>.value="";

        if (numeroOrdinanza!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUMERO_REGISTRO%>.value=numeroOrdinanza;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUMERO_REGISTRO%>.value="";

        if (tipoAutorita!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_UFFICIO_SORVEGLIANZA%>.value=tipoAutorita;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_UFFICIO_SORVEGLIANZA%>.value="";

        if (sedeAutorita!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_SEDE_TDS_EMITT%>.value=sedeAutorita;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_SEDE_TDS_EMITT%>.value="";

        if (oggetto!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiEvento.CAMPO_COD_MOTIVO%>.value=oggetto;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiEvento.CAMPO_COD_MOTIVO%>.value="";

        if (giorno!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_DECISIONE%>.value=giorno;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_DECISIONE%>.value="";

        if (mese!='-' )
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_DECISIONE%>.value=mese;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_DECISIONE%>.value="";

        if (anno!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_DECISIONE%>.value=anno;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_DECISIONE%>.value="";

        try {
          if (luogoProva!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_DESCR_LUOGO_PROVA%>.value=luogoProva;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_DESCR_LUOGO_PROVA%>.value="";
        }
        catch(err){  }
        // PP = PROSECUZIONE_PROVVISORIA
        // PC = PROSECUZIONE_PROVVISORIA_CUMULO
        if(natura!='-' && (natura == 'PP' || natura == 'PC') )
        {
          if (giornoInizioMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_INIZIO_MISURA%>.value=giornoInizioMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_INIZIO_MISURA%>.value="";

          if (meseInizioMisura!='-' )
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_INIZIO_MISURA%>.value=meseInizioMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_INIZIO_MISURA%>.value="";

          if (annoInizioMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_INIZIO_MISURA%>.value=annoInizioMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_INIZIO_MISURA%>.value="";
        }

        // RE = REVOCA
        if(    natura!='-' && natura == 'RE'
            && (    oggetto == '0086' || oggetto == '0014' || oggetto == '0015' // AFFIDAMENTO IN PROVA
                 || oggetto == '0196') // INDULTINO (L.207/2003 )
            )
        {
          if (giornoInizioRevocaMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_INIZIO_REVOCA%>.value=giornoInizioRevocaMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_INIZIO_REVOCA%>.value="";

          if (meseInizioRevocaMisura!='-' )
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_INIZIO_REVOCA%>.value=meseInizioRevocaMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_INIZIO_REVOCA%>.value="";

          if (annoInizioRevocaMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_INIZIO_REVOCA%>.value=annoInizioRevocaMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_INIZIO_REVOCA%>.value="";

          if (anniRevocaReclusione!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_ANNI_REVOCA_RECLUSIONE%>.value=anniRevocaReclusione;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_ANNI_REVOCA_RECLUSIONE%>.value="";

          if (mesiRevocaReclusione!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_MESI_REVOCA_RECLUSIONE%>.value=mesiRevocaReclusione;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_MESI_REVOCA_RECLUSIONE%>.value="";

          if (giorniRevocaReclusione!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_GIORNI_REVOCA_RECLUSIONE%>.value=giorniRevocaReclusione;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_GIORNI_REVOCA_RECLUSIONE%>.value="";

          if (anniRevocaArresto!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_ANNI_REVOCA_ARRESTO%>.value=anniRevocaArresto;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_ANNI_REVOCA_ARRESTO%>.value="";

          if (mesiRevocaArresto!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_MESI_REVOCA_ARRESTO%>.value=mesiRevocaArresto;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_MESI_REVOCA_ARRESTO%>.value="";

          if (giorniRevocaArresto!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_GIORNI_REVOCA_ARRESTO%>.value=giorniRevocaArresto;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_GIORNI_REVOCA_ARRESTO%>.value="";
        }

        if (note!='-')
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NOTE%>.value=note;
        else
          window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NOTE%>.value="";

        // CO = concessione SOSPENSIONE ESECUZIONE PENA
        if(natura!='-' && natura == 'CO'&& (oggetto == '2000' || oggetto == '2001' || oggetto == '2480'))
        {
         if (tipodecisione!='-')
           window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TIPO_DECISIONE%>.value=tipodecisione;
         else
           window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TIPO_DECISIONE%>.value="";


        }

        //===============================================================
        // CO = concessione DIFFERIMENTO PROVVISORIO/DEFINITIVO -- oggetto 2140-->concessione espulsione
        //===============================================================
        if(natura!='-' && natura == 'CO'&& (oggetto == '2010' || oggetto == '2011' || oggetto == '0030' || oggetto == '0031' || oggetto == '0032' || oggetto == '0033' || oggetto == '0201' || oggetto == '0202'|| oggetto == '2140'))
        {


          //== Quantum di differimento ==
          if (anniMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_ANNI_MISURA%>.value=anniMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_ANNI_MISURA%>.value="";
          if (mesiMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_MESI_MISURA%>.value=mesiMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_MESI_MISURA%>.value="";
          if (giorniMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_GIORNI_MISURA%>.value=giorniMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_NUM_GIORNI_MISURA%>.value="";

         if(oggetto != '2140')
         {
          if (giornoInizioMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_INIZIO_MISURA%>.value=giornoInizioMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_INIZIO_MISURA%>.value="";

          if (meseInizioMisura!='-' )
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_INIZIO_MISURA%>.value=meseInizioMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_INIZIO_MISURA%>.value="";

          if (annoInizioMisura!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_INIZIO_MISURA%>.value=annoInizioMisura;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_INIZIO_MISURA%>.value="";

          //== Da scarcerare/gi� scarcerato ==
        try {
           if (flagScarcerato=='SORV') {
             window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TIPO_UFFICIO_SCARCERAZIONE%>[1].checked=true;
             window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TIPO_UFFICIO_SCARCERAZIONE%>[0].checked=false;
           }
           else if (flagScarcerato=='PROC'){
             window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TIPO_UFFICIO_SCARCERAZIONE%>[0].checked=true;
             window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TIPO_UFFICIO_SCARCERAZIONE%>[1].checked=false;
           }
          }
          catch(err){  }


          //== Data fine differimento ==
          if (giornoFineMisura!="" && giornoFineMisura!="-") {
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_FINE_MISURA%>.value=giornoFineMisura;
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_FINE_MISURA%>.value=meseFineMisura;
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_FINE_MISURA%>.value=annoFineMisura;
          }
          else {
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_GIORNO_DATA_FINE_MISURA%>.value="";
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_MESE_DATA_FINE_MISURA%>.value="";
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_ANNO_DATA_FINE_MISURA%>.value="";
          }


          //== Fino alla decisione del TDS ==
        try {
          if (flagDecisioneTribunale=='S') {
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_FLAG_DECISIONE_TRIBUNALE%>.checked=true;
          }
          else{
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_FLAG_DECISIONE_TRIBUNALE%>.checked=false;
          }
          }
          catch(err){  }


          //== TDS Competente ==
        try {
          if (sedeTdsCompetente!='-')
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TDS_COMPETENTE%>.value=sedeTdsCompetente;
          else
            window.parent.opener.document.<%=request.getParameter("formname")%>.<%=ICostantiMisuraAlternativa.CAMPO_COD_TDS_COMPETENTE%>.value="";

          }
          catch(err){  }
        }

       }

        window.parent.close();
      }
  	</script>
  </head>

  <body class="corpo" onload="controlla();">
  <form method="POST" name="elenco" action="<%=IWebConstants.PG_MAIN%>">
  <table>
    <tr>
      <td class="LBG">
        <a align="absmiddle" href="Javascript:window.print();">
          <img src="<%=IWebConstants.IMAGES_DIR%>quickprint24.gif" alt="Stampa questa videata" border=0>
        </a>
      </td>
      <td class="LBG">
        <font class="label">Funzione :</font>
        <font class="campo">
          Elenco Benefici concessi 
<%
          if(!documentiSius.isEmpty())
          {
            MisuraAlternativaEventoModel lPrimaMisura = (MisuraAlternativaEventoModel)documentiSius.get(0);
            if(lPrimaMisura.getMisuraAlternativa() != null  && lPrimaMisura.getMisuraAlternativa().getCodTipoMisura() != null
               &&(lPrimaMisura.getMisuraAlternativa().getCodTipoMisura().equals("2000") ||
               lPrimaMisura.getMisuraAlternativa().getCodTipoMisura().equals("2001") ||
               lPrimaMisura.getMisuraAlternativa().getCodTipoMisura().equals("2480")
              )
              )
             {
%>
              - Sospensione Esecuzione Pena
<%
             }
            else
            if(lPrimaMisura.getMisuraAlternativa() != null  && lPrimaMisura.getMisuraAlternativa().getCodTipoMisura() != null
               && lPrimaMisura.getMisuraAlternativa().getCodTipoMisura().equals("2140"))
             {
%>
              - Decreti di Espulsione
<%
             } 
            else
            if(lPrimaMisura.getMisuraAlternativa() != null  && lPrimaMisura.getMisuraAlternativa().getCodTipoMisura() != null
               && lPrimaMisura.getMisuraAlternativa().getCodTipoMisura().equals("0029"))
             {
%>
              - <%=lPrimaMisura.getMisuraAlternativa().getDescrNaturaDecisione()%> 
               Opposizione su Espulsione
<%
             }               
             else
             if(   lPrimaMisura.getMisuraAlternativa() != null
               && lPrimaMisura.getMisuraAlternativa().getDescrNaturaDecisione() != null )
             {
%>
              - <%=lPrimaMisura.getMisuraAlternativa().getDescrNaturaDecisione()%>
              Misure Alternative
<%
             }
          }
%>
        </font>
      </td>
    </tr>
  </table>
  <br>
  <table>
    <tr>
      <td class="int" width=25% colspan=4>Anno/Numero Siep</td>
      <td class="int" width=25% colspan=4>Autorit� Emittente</td>
      <td class="int" width=25% colspan=4>Tipo Provv</td>
      <td class="int" width=25% colspan=4>Data Provv</td>
    </tr>
<%
    if( !documentiSius.isEmpty() )
    {
      Iterator itx = documentiSius.iterator();
      for (int i = 0; itx.hasNext(); i++)
      {
        MisuraAlternativaEventoModel misuraEventoModel = (MisuraAlternativaEventoModel)itx.next();
        MisuraAlternativaModel misuraModel = misuraEventoModel.getMisuraAlternativa();
        EventoModel eventoModel = misuraEventoModel.getEvento();

        String lUfficio = StringUtils.cStrForJS(eventoModel.getDescrUfficioEmittente());
        if( lUfficio.toUpperCase().startsWith("TRIB") )
        {
          lUfficio = "TDS";
        }
        else if(lUfficio.toUpperCase().startsWith("UFF"))
        {
          lUfficio = "UDS";
        }
%>
        <tr>
          <td class="c">
            <%=StringUtils.toStringJSP(misuraModel.getChiaveAnnoFascicoloSius(), "-")%>
            /
            <%=StringUtils.toStringJSP(misuraModel.getChiaveProgrFascicoloSius(), "-")%>
          </td>
          <td class="l">
            <%=StringUtils.toStringJSP(eventoModel.getDescrUfficioEmittente(),"-")%> di <%=StringUtils.toStringJSP(eventoModel.getDescrLuogoEmittente(), "-")%>
            <br>del&nbsp;
            <%=StringUtils.toStringJSP(DateUtils.getDateToString(eventoModel.getDataEmissione(),"dd-MM-yyyy"), "-")%>
<%
     if(misuraModel != null && "P".equalsIgnoreCase(misuraModel.getFlagUfficioInserimento()))
      {
%>
        <br>(<font class="cRosso">-- iscritto da SIEP --</font>)
<%
      }
%>
          </td>
          <td class="l">
<%
            if(misuraModel != null  && misuraModel.getCodTipoMisura() != null
               &&(misuraModel.getCodTipoMisura().equals("2000") ||misuraModel.getCodTipoMisura().equals("2001") ||
                  misuraModel.getCodTipoMisura().equals("2480")
                 )
              )
             {
%>
              <%=StringUtils.toStringJSP(misuraModel.getDescrTipoDecisione(),"-")%>
<%
             }
%>
            <%=StringUtils.toStringJSP(eventoModel.getDescrMotivo(),"-")%>
          </td>
          <td class="c">
            <a href="Javascript:insertIT('<%=StringUtils.toStringJSP(eventoModel.getIdEvento(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getChiaveAnnoFascicoloSius(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getChiaveProgrFascicoloSius(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getAnnoRegistro(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumeroRegistro(),"-")%>',
                                         '<%=lUfficio%>',
                                         '<%=StringUtils.cStrForJS(eventoModel.getDescrLuogoEmittente())%>',
                                         '<%=StringUtils.toStringJSP(eventoModel.getCodMotivo(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getCodNaturaDecisione(),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(eventoModel.getDataEmissione(),"dd"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(eventoModel.getDataEmissione(),"MM"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(eventoModel.getDataEmissione(),"yyyy"),"-")%>',
                                         '<%=StringUtils.cStrForJS(misuraModel.getDescrLuogoProva())%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataInizioMisura(),"dd"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataInizioMisura(),"MM"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataInizioMisura(),"yyyy"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataInizioRevoca(),"dd"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataInizioRevoca(),"MM"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataInizioRevoca(),"yyyy"),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumAnniRevocaReclusione(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumMesiRevocaReclusione(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumGiorniRevocaReclusione(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumAnniRevocaArresto(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumMesiRevocaArresto(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumGiorniRevocaArresto(),"-")%>',
                                         '<%=StringUtils.cStrForJS(misuraModel.getNote())%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getCodTipoDecisione(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getCodTipoUfficioScarcerazione(),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataFineMisura(),"dd"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataFineMisura(),"MM"),"-")%>',
                                         '<%=StringUtils.toStringJSP(DateUtils.getDateToString(misuraModel.getDataFineMisura(),"yyyy"),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumGiorniMisura(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumMesiMisura(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getNumAnniMisura(),"-")%>',
                                         '<%=StringUtils.toStringJSP(misuraModel.getFlagDecisioneTribunale(),"-")%>',
                                         '<%=StringUtils.cStrForJS(misuraModel.getDescSedeTdsCompetente())%>'
                                         );">
              <img align="absmiddle" src="/images/fileselected.gif" border=0>
            </a>
          </td>
        </tr>
<%
      }
    }
%>
    </table>
  </form>
</body>
</html>