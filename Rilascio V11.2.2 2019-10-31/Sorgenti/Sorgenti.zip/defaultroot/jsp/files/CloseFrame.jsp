<%@ page import="f3b.web.IWebConstants" %>

<html>
  <head>
    <title>Logout S.I.E.S.</title>
  </head>
  <body onLoad="javascript:window.close();">
  </body>
</html>