--- aggiunta di una nuova colonna alla tabella RESIDENZA
ALTER TABLE RESIDENZA ADD 
(ID_CIVILMENTE_OBBLIGATO NUMBER(38,0));
--COMMIT;