insert into funzione t values (24020160, 'Load Genera Avviso PagoPA', 'L', 'siap.siep.pagoPA.action.ActLoadGeneraAvvisoPagoPA');
insert into funzione t values (24020161, 'Genera Avviso PagoPA', 'I', 'siap.siep.pagoPA.action.ActGeneraAvvisoPagoPA');
insert into funzione t values (24020162, 'Download Avviso PagoPA', 'S', 'siap.siep.pagoPA.action.ActDownloadAvvisoPagoPA');
insert into funzione t values (24020163, 'Invoca WS Genera Avviso PagoPA', 'I', 'siap.siep.pagoPA.action.ActInvocaWSGeneraAvvisoPagoPA');
insert into funzione t values (24020164, 'Load Avviso PagoPA', 'L', 'siap.siep.pagoPA.action.ActLoadAvvisoPagoPA');

-- 24020170 e 24020171 devono essere "I" così non appaiono se fascicolo è validato! 24020170 ora è 15010001!
-- insert into funzione t values (24020170, 'Load Inserisci Modalita'' Pagamento', 'I', 'siap.siep.pagoPA.action.ActLoadInserisciModalitaPagamento');
insert into funzione t values (24020171, 'Load Inserisci Civilmente Obbligato', 'I', 'siap.siep.pagoPA.action.ActLoadInserisciCivilmenteObbligato');
insert into funzione t values (24020172, 'Inserisci Civilmente Obbligato', 'I', 'siap.siep.pagoPA.action.ActInserisciCivilmenteObbligato');
insert into funzione t values (24020173, 'Load Modifica Civilmente Obbligato', 'L', 'siap.siep.pagoPA.action.ActLoadModificaCivilmenteObbligato');
insert into funzione t values (24020174, 'Modifica Civilmente Obbligato', 'M', 'siap.siep.pagoPA.action.ActModificaCivilmenteObbligato');
insert into funzione t values (24020175, 'Dettaglio Civilmente Obbligato', 'D', 'siap.siep.pagoPA.action.ActDettaglioCivilmenteObbligato');
insert into funzione t values (24020176, 'Cancella Civilmente Obbligato', 'C', 'siap.siep.pagoPA.action.ActCancellaCivilmenteObbligato');

insert into funzione t values (15010060, 'Carica Griglia Bollettini PagoPA', 'L', 'siap.siep.sanzionesostitutiva.action.ActGrigliaBollettiniPagoPA');
insert into funzione t values (15010061, 'Carica Richiesta Bollettini PagoPA', 'L', 'siap.siep.sanzionesostitutiva.action.ActRichiestaBollettiniPagoPA');
insert into funzione t values (15010062, 'Carica Verifica Stato Pagamenti Bollettini PagoPA', 'L', 'siap.siep.sanzionesostitutiva.action.ActVerificaStatoPagamenti');
insert into funzione t values (15010063, 'Carica Elenco Stato Pagamenti Bollettini PagoPA', 'L', 'siap.siep.sanzionesostitutiva.action.ActElencoStatoPagamenti');
insert into funzione t values (15010064, 'Carica Verifica Stato Bollettino PagoPA', 'L', 'siap.siep.sanzionesostitutiva.action.ActVerificaStatoBollettino');
insert into funzione t values (15010065, 'Carica Verifica Stato Elenco Bollettino PagoPA', 'L', 'siap.siep.sanzionesostitutiva.action.ActVerificaStatoElencoBollettini');
insert into funzione t values (15010066, 'Invoca WS Verifica Stato Bollettini PagoPA', 'L', 'siap.siep.pagoPA.action.ActInvocaWSVerificaStatoBollettini');
insert into funzione t values (15010067, 'Inoltra WS Verifica Stato Bollettini PagoPA', 'L', 'siap.siep.pagoPA.action.ActInoltraDownloadAvvisoPagoPA');
insert into funzione t values (15010068, 'Stampa Massiva Bollettini PagoPA', 'S', 'siap.siep.sanzionesostitutiva.action.ActStampaMassivaBollettini');