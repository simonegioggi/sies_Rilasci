-- FUNZIONE_PROFILO
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020160, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020160, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020160, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020160, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020161, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020161, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020161, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020161, 50, null, null, null, null, 'S');
 
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020162, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020162, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020162, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020162, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020163, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020163, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020163, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020163, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020164, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020164, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020164, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020164, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020171, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020171, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020171, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020171, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020172, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020172, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020172, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020172, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020173, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020173, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020173, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020173, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020174, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020174, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020174, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020174, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020175, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020175, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020175, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020175, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020176, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020176, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020176, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 24020176, 50, null, null, null, null, 'S');
 
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010060, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010060, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010060, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010060, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010061, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010061, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010061, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010061, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010062, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010062, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010062, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010062, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010063, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010063, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010063, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010063, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010064, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010064, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010064, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010064, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010065, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010065, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010065, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010065, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010066, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010066, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010066, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010066, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010067, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010067, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010067, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010067, 50, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010068, 4, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010068, 30, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010068, 40, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 15010068, 50, null, null, null, null, 'S');