-- RELAZIONE_FUNZIONE
DELETE RELAZIONE_FUNZIONE WHERE FUN_ID_FUNZIONE = 176;
INSERT INTO RELAZIONE_FUNZIONE VALUES(176, 267, 'BO', NULL, 1, NULL);
INSERT INTO RELAZIONE_FUNZIONE VALUES(176, 278, 'BO', NULL, 2, NULL);
-- INSERT INTO RELAZIONE_FUNZIONE VALUES(176, 24020170, 'CO', 'Modalita'' Pagamento Pena Pecuniaria', 3, NULL);
-- Aggancio la funzione di inserimento alla combo del dettaglio Pena Complessiva
INSERT INTO RELAZIONE_FUNZIONE VALUES(176, 15010001, 'CO', 'Modalita'' Pagamento Pena Pecuniaria', 3, NULL);
INSERT INTO RELAZIONE_FUNZIONE VALUES(176, 24020171, 'CO', 'Civilmente Obbligato per la Pena Pecuniaria', 4, NULL);
INSERT INTO RELAZIONE_FUNZIONE VALUES(176, 265, 'CO', 'Ulteriori Sentenze in continuazione', 5, NULL);

-- LEGENDA:
--	176	Dettaglio Pena Complessiva/Sanzione Sostitutiva	D	siap.siep.penacomplessiva.action.ActLoadDettaglioPenaComplessiva