--- aggiunta di una nuova colonna alla tabella NOTIFICA
ALTER TABLE NOTIFICA ADD 
(ID_CIVILMENTE_OBBLIGATO NUMBER(38,0));
--COMMIT;