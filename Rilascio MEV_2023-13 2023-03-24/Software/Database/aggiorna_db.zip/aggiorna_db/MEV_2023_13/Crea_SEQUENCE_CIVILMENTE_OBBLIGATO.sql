-- Create sequence 
create sequence SEQ_CIVILMENTE_OBBLIGATO
minvalue 1
maxvalue 999999
start with 101
increment by 1
cache 20;