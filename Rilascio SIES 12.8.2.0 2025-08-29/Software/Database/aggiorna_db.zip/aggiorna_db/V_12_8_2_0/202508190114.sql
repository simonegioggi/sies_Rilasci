update UFFICIO_DESCR ud
   set ud.cod_provincia = 'NA'
 where ud.descr_comune = 'NAPOLI NORD'
   and ud.cod_provincia = 'CE';
update UFFICIO u
   set u.cod_provincia = 'NA'
 where u.cod_provincia = 'CE'
   and u.cod_ufficio in
       (select ud.cod_ufficio
          from UFFICIO_DESCR ud
         where ud.descr_comune = 'NAPOLI NORD');