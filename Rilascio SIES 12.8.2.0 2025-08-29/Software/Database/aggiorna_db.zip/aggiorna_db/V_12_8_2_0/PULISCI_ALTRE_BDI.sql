prompt
prompt Creating package body PULISCI_ALTRE_BDI
prompt =======================================
prompt
CREATE OR REPLACE PACKAGE BODY pulisci_altre_bdi IS

  PROCEDURE pulisci_evento(idevento           IN NUMBER,
                           esitopuliscievento IN OUT VARCHAR2) IS

	-- modifiche per integrazione BDMC
    annotazione_rec annotazione_manuale%ROWTYPE;

    TYPE annotazione_cur IS REF CURSOR RETURN annotazione_rec%TYPE;

    annotazione_cur1 annotazione_cur;
    idordinanza           NUMBER := 0;
    iddecreto             NUMBER := 0;
    appo_evento           NUMBER := 0;
    idmisuraalternativa   NUMBER := 0;
    idlicenzaliban        NUMBER := 0;
    idpenaresidua         NUMBER := 0;
    v_ann_id_annot        NUMBER := NULL;
    v_id_annotazione      NUMBER := NULL;
    v_eve_annot           NUMBER := NULL;
    v_pen_id_pena_residua NUMBER := NULL;
    v_id_pena_residua     NUMBER := NULL;
    v_eve_pena_residua    NUMBER := NULL;

    -- Ticket#202103180118 - variabili START
    TYPE elenco_PG_per_evento_cur IS REF CURSOR;

    v_elenco_PG_per_evento_cur elenco_PG_per_evento_cur;
    v_id_posizione_giuridica NUMBER := NULL;
    v_id_altra_causa         NUMBER := NULL;
    -- Ticket#202103180118 - variabili END

    CURSOR lic_lib IS
      SELECT id_licenza_libanticipata
        FROM licenza_libanticipata
       WHERE eve_id_evento = idevento;

  BEGIN
    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('--------------------- INIZIO PULISCI EVENTO ');
    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('id_evento = ' || idevento);

    DELETE FROM beneficio WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete BENEFICIO ------ >>>  OK!');

    DELETE FROM campo_nota WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete CAMPO_NOTA ------ >>>  OK!');

    DELETE FROM pena_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo FROM cumulo WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete PENA_CUMULO ------ >>>  OK!');
    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');
    ---aggiunto il 13/12/2006

    DELETE FROM ulteriore_sanzione_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo FROM cumulo WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');

    DELETE FROM cumulo WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete CUMULO ------ >>>  OK!');

    DELETE FROM documento_allegato WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete DOCUMENTO_ALLEGATO ------ >>>  OK!');

    DELETE FROM scadenzario_siep
     WHERE not_id_notifica IN
           (SELECT id_notifica FROM notifica WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete SCADENZARIO_SIEP ------ >>>  OK!');

    DELETE FROM rinnovo
     WHERE not_id_notifica IN
           (SELECT id_notifica FROM notifica WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete RINNOVO ------ >>>  OK!');

    DELETE FROM rinnovo
     WHERE ver_id_verbale IN
           (SELECT id_verbale FROM verbale WHERE eve_id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete RINNOVO ------ >>>  OK!');

    DELETE FROM verbale WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete VERBALE ------ >>>  OK!');

    DELETE FROM notifica WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete NOTIFICA ------ >>>  OK!');

    DELETE FROM nome_provvedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete NOME_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM motivo_evento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MOTIVO_EVENTO ------ >>>  OK!');

    DELETE FROM motivazione_decreto WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MOTIVAZIONE_DECRETO  ------ >>>  OK!');

    DELETE FROM referto_scarcerazione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete REFERTO_SCARCERAZIONE ------ >>>  OK!');

    DELETE FROM istanza WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete ISTANZA ------ >>>  OK!');

    /* -- 17/01/2018[EC]: commento a favore di quanto riportato sottoSIESTO
    DELETE FROM nuova_istanza
            WHERE eve_id_evento = idevento;*/

    -- 17/01/2018[EC] CANCELLO LE NUOVE ISTANZE COLLEGATE A LIVELLO AL FASCICOLO_SIEP
    -- PERCH?????? SE L'EVENTO E' STATO ANNULLATO LA CANCELLAZIONE NON VA A BUON FINE
    DELETE FROM nuova_istanza aa
     WHERE aa.fas_sie_id_fascicolo_siep IN
           (SELECT e.fas_sie_id_fascicolo_siep
              FROM evento e
             WHERE e.id_evento = idevento);

    DBMS_OUTPUT.put_line('Delete NUOVA_ISTANZA ------ >>>  OK!');

    -- Ticket#202103180118 - La cancellazione a tappeto dei record ALTRA_CAUSA
    -- collegati al fascicolo genera un errore di FK se collegati ad altre posizioni giuridiche
    -- Si cancellano solo i record AC collegati alla PG oggetto di cancellazione
    -- in questa fase. Gli altri record saranno cancellati dalla PULISCI_FASCICOLO
    BEGIN
	  DBMS_OUTPUT.put_line('APERTURA CURSORE su PG collegatie ad EVENTO');

      OPEN v_elenco_PG_per_evento_cur FOR
	  	SELECT ID_POSIZIONE_GIURIDICA, ALT_CAU_ID_ALTRA_CAUSA
		FROM POSIZIONE_GIURIDICA
		WHERE ID_EVENTO_RIFERIMENTO = idevento;

	  DBMS_OUTPUT.put_line('INIZIO LOOP');
      LOOP
      	DBMS_OUTPUT.put_line('LOOP...');
        FETCH v_elenco_PG_per_evento_cur
          INTO v_id_posizione_giuridica, v_id_altra_causa;

        EXIT WHEN v_elenco_PG_per_evento_cur%NOTFOUND;

        DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA v_id_posizione_giuridica = '||v_id_posizione_giuridica);
	    DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA v_id_altra_causa         = '||v_id_altra_causa);

        DELETE FROM posizione_giuridica WHERE id_posizione_giuridica = v_id_posizione_giuridica;
        DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA NEW  id: '||v_id_posizione_giuridica||' ------ >>>  OK!');

        DELETE FROM altra_causa WHERE id_altra_causa = v_id_altra_causa;
        DBMS_OUTPUT.put_line('Delete ALTRA_CAUSA NEW  id: '||v_id_altra_causa||' ------ >>>  OK!');
      END LOOP;

      CLOSE v_elenco_PG_per_evento_cur;

	EXCEPTION
	    WHEN OTHERS THEN
	      -- Comunque PG e AC verranno cancellate dalla PULISCI_FASCICOLO
	      DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA OTHERS');
	      DBMS_OUTPUT.put_line(SQLCODE);
	      DBMS_OUTPUT.put_line(SQLERRM);
	END;

    /*
     * VECCHIO CODICE COMMENTATO
    DELETE FROM posizione_giuridica WHERE id_evento_riferimento = idevento;

    DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA ------ >>>  OK!');

    -- 12/10/2018[EC] INIZIO MEV_67 CANCELLO DALLA TABELLA ALTRA CAUSA
    DELETE FROM altra_causa aa
     where aa.fas_sie_id_fascicolo_siep =
           (SELECT e.fas_sie_id_fascicolo_siep
              FROM evento e
             WHERE e.id_evento = idevento);
    -- FINE MEV_67
    */
   -- Ticket#202103180118 - FINE

    -- MEV26 CUMULO aggiunta cancellazione record COMPETENZA caricato in
    --              fase di presa in carico (01/2016)
    DELETE FROM COMPETENZA WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete COMPETENZA ------ >>>  OK!');

    BEGIN
      SELECT id_misura_alternativa
        INTO idmisuraalternativa
        FROM misura_alternativa
       WHERE eve_id_evento = idevento;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        idmisuraalternativa := 0;
    END;

    IF idmisuraalternativa != 0 THEN
      DELETE FROM pena_residua
       WHERE mis_alt_id_misura_alternativa = idmisuraalternativa;

      DBMS_OUTPUT.put_line('Delete PENA_RESIDUA per MA------ >>>  OK!');
    END IF;

    BEGIN
      SELECT ann_id_annotazione_manuale
        INTO v_ann_id_annot
        FROM evento
       WHERE id_evento = idevento;

      DBMS_OUTPUT.put_line('v_ann_id_annot ' || v_ann_id_annot);

      IF v_ann_id_annot IS NOT NULL THEN
        BEGIN
          SELECT eve_id_evento
            INTO v_eve_annot
            FROM annotazione_manuale
           WHERE id_annotazione_manuale = v_ann_id_annot;

          DBMS_OUTPUT.put_line('v_eve_annot ' || v_eve_annot);

          IF v_eve_annot IS NOT NULL THEN
            DBMS_OUTPUT.put_line('v_eve_annot ?????? not null' || v_eve_annot);

            IF v_eve_annot = idevento THEN
              ----quindi ?????? unico evento
              DBMS_OUTPUT.put_line('v_eve_annot ?????? unico evento' ||
                                   v_eve_annot);

              UPDATE evento
                 SET ann_id_annotazione_manuale = NULL
               WHERE id_evento = idevento;

              -- modifiche per integrazione bdmc
              BEGIN
                OPEN annotazione_cur1 FOR
                  SELECT *
                    FROM annotazione_manuale
                   WHERE eve_id_evento = idevento;

                LOOP
                  FETCH annotazione_cur1
                    INTO annotazione_rec;

                  EXIT WHEN annotazione_cur1%NOTFOUND;

                  UPDATE misura_cautelare_bdmc
                     SET flag_stato = 'C'
                   WHERE id_annotazione_manuale =
                         annotazione_rec.id_annotazione_manuale;
                END LOOP;

                CLOSE annotazione_cur1;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  CLOSE annotazione_cur1;
              END;

              -- fine modifiche per integrazione bdmc
              DELETE FROM annotazione_manuale
               WHERE eve_id_evento = idevento;

              DBMS_OUTPUT.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');
            ELSIF v_eve_annot != idevento THEN
              ----l'annotazione ?????? legata ad un altro evento e non si pu?????? cancellare
              DBMS_OUTPUT.put_line('UPDATE EVENTO PER ANNOTAZIONE_MANUALE ------ >>>  OK!');

              UPDATE evento
                 SET ann_id_annotazione_manuale = NULL
               WHERE id_evento = idevento;
            END IF;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      ELSE
        DBMS_OUTPUT.put_line('v_eve_annot ?????? null' || v_eve_annot);

        -- modifiche per integrazione bdmc
        BEGIN
          OPEN annotazione_cur1 FOR
            SELECT *
              FROM annotazione_manuale
             WHERE eve_id_evento = idevento;

          LOOP
            FETCH annotazione_cur1
              INTO annotazione_rec;

            EXIT WHEN annotazione_cur1%NOTFOUND;

            UPDATE misura_cautelare_bdmc
               SET flag_stato = 'C'
             WHERE id_annotazione_manuale =
                   annotazione_rec.id_annotazione_manuale;
          END LOOP;

          CLOSE annotazione_cur1;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            CLOSE annotazione_cur1;
        END;

        -- fine modifiche per integrazione bdmc
        DELETE FROM annotazione_manuale WHERE eve_id_evento = idevento;

        DBMS_OUTPUT.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.put_line('non ci sono dati v_ann_id_annot  ?????? null');
        NULL;
    END;

    --==========================================================================
    -- Gestione PENA RESIDUA
    --==========================================================================
    BEGIN
      SELECT pen_id_pena_residua
        INTO v_pen_id_pena_residua
        FROM evento
       WHERE id_evento = idevento;

      DBMS_OUTPUT.put_line('v_pen_id_pena_residua ' ||
                           v_pen_id_pena_residua);
      DBMS_OUTPUT.put_line('IdEvento ' || idevento);

      IF v_pen_id_pena_residua IS NOT NULL THEN
        -- L'evento punta una pena residua, devo verificare se ?????? cancellabile o meno
        -- n.b. la PR ?????? cancellabile solo se a sua volta punta l'evento
        DBMS_OUTPUT.put_line('v_pen_id_pena_residua ?????? not null');

        BEGIN
          SELECT eve_id_evento
            INTO v_eve_pena_residua
            FROM pena_residua
           WHERE id_pena_residua = v_pen_id_pena_residua;

          DBMS_OUTPUT.put_line('v_eve_pena_residua ' || v_eve_pena_residua);

          IF v_eve_pena_residua IS NOT NULL OR v_eve_pena_residua != 0 THEN
            DBMS_OUTPUT.put_line('v_eve_pena_residua ?????? not null');

            IF TO_CHAR(v_eve_pena_residua) = TO_CHAR(idevento) THEN
              -- la PR punta a sua volta l'evento, posso cancellarla
              DBMS_OUTPUT.put_line('v_eve_pena_residua ?????? unico evento' ||
                                   v_eve_annot);

              -- if idpenaresidua!=0 then
              DELETE FROM sospensione
               WHERE pen_res_id_pena_residua IN
                     (SELECT id_pena_residua
                        FROM pena_residua
                       WHERE eve_id_evento = idevento);

              DBMS_OUTPUT.put_line('Delete SOSPENSIONE ------ >>>  OK!');

              -- end if;
              DELETE FROM sanzione_sost_residua
               WHERE pen_res_id_pena_residua IN
                     (SELECT id_pena_residua
                        FROM pena_residua
                       WHERE eve_id_evento = idevento);

              UPDATE evento
                 SET pen_id_pena_residua = NULL
               WHERE id_evento = idevento;

              DELETE FROM pena_residua WHERE eve_id_evento = idevento;

              DBMS_OUTPUT.put_line('Delete PENA_RESIDUA ------ >>>  OK!');
            ELSIF v_eve_pena_residua != idevento THEN
              ----la pena ?????? legata ad un altro evento e non si pu?????? cancellare
              DBMS_OUTPUT.put_line('UPDATE EVENTO PER PENA RESIDUA ------ >>>  OK!');

              UPDATE evento
                 SET pen_id_pena_residua = NULL
               WHERE id_evento = idevento;
            END IF;
          END IF;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;
      ELSE
        --=================================================================
        -- L'evento NON punta direttamente una PR, vado in cancellazione delle PR
        -- che puntano l'evento e dei record collegati alle PR:
        -- SOSPENSIONE
        -- SANZIONE_SOST_RESIDUA
        --=================================================================
        DBMS_OUTPUT.put_line('v_pen_id_pena_residua ?????? null');

        -- if idpenaresidua!=0 then
        DELETE FROM sospensione
         WHERE pen_res_id_pena_residua IN
               (SELECT id_pena_residua
                  FROM pena_residua
                 WHERE eve_id_evento = idevento);

        DBMS_OUTPUT.put_line('Delete SOSPENSIONE ------ >>>  OK!');

        -- end if;
        DELETE FROM sanzione_sost_residua
         WHERE pen_res_id_pena_residua IN
               (SELECT id_pena_residua
                  FROM pena_residua
                 WHERE eve_id_evento = idevento);

        DELETE FROM pena_residua WHERE eve_id_evento = idevento;

        DBMS_OUTPUT.put_line('Delete PENA_RESIDUA ------ >>>  OK!');
      END IF;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.put_line('non ci sono dati v_pen_id_pena_residua ?????? null');
        NULL;
    END;

    -- FINE gestione ENA_RESIDUA
    DELETE FROM misura_alternativa WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MISURA_ALTERNATIVA ------ >>>  OK!');

    DELETE FROM fungibilita WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete FUNGIBILITA ------ >>>  OK!');

    DELETE FROM archiviazione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete ARCHIVIAZIONE ------ >>>  OK!');

    BEGIN
      OPEN lic_lib;
      LOOP
        FETCH lic_lib
          INTO idLicenzaLiban;
        EXIT WHEN lic_lib%NOTFOUND;

        DELETE FROM PERIODO_LIBANTICIPATA
         WHERE lic_id_licenza_libanticipata = idLicenzaLiban;
        DBMS_OUTPUT.PUT_LINE('Delete PERIODO_LIBANTICIPATA ------ >>>  OK!');

      END LOOP;

      DELETE FROM LICENZA_LIBANTICIPATA WHERE EVE_ID_EVENTO = idevento;
      DBMS_OUTPUT.PUT_LINE('Delete LICENZA_LIBANTICIPATA ------ >>>  OK!');

      CLOSE lic_lib;
    END;

    DELETE FROM misura_cautelare WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MISURA_CAUTELARE ------ >>>  OK!');

    DELETE FROM misura_sicurezza WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete MISURA_SICUREZZA ------ >>>  OK!');

    --DELETE FROM PASSAGGIO_EVENTO WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete PASSAGGIO_EVENTO ------ >>>  OK!');

    --DELETE FROM PENA_ACCESSORIA WHERE Eve_ID_EVENTO = IdEvento;
    --dbms_output.put_line('Delete PENA_ACCESSORIA ------ >>>  OK!');
    DELETE FROM pena_pecuniaria WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete PENA_PECUNIARIA ------ >>>  OK!');

    DELETE FROM prescrizione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete PRESCRIZIONE ------ >>>  OK!');

    DELETE FROM sanzione_amministrativa WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete SANZIONE_AMMINISTRATIVA ------ >>>  OK!');

    --==================================================
    -- GESTIONE DECRETI E ORDINANZE
    --==================================================
    BEGIN
      SELECT id_deposito_ordinanza_pc
        INTO idordinanza
        FROM deposito_ordinanza_pc
       WHERE id_evento_generato = idevento;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        idordinanza := 0;
    END;

    BEGIN
      SELECT id_deposito_decreto
        INTO iddecreto
        FROM deposito_decreto
       WHERE id_evento_generato = idevento;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        iddecreto := 0;
    END;

    IF idordinanza != 0 OR iddecreto != 0 THEN
      DELETE FROM tenore
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete TENORE ------ >>>  OK!');

      DELETE FROM esecuzione_misura_alternativa
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete ESECUZIONE_MISURA_ALTERNATIVA ------ >>>  OK!');

      DELETE FROM impugnazione
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete IMPUGNAZIONE ------ >>>  OK!');

      DELETE FROM motivazione_decreto
       WHERE dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete MOTIVAZIONE_DECRETO ------ >>>  OK!');

      DELETE FROM rinvio_provvedimento
       WHERE dep_opid_deposito_ordinanza_pc = idordinanza
          OR dep_dec_id_deposito_decreto = iddecreto;

      DBMS_OUTPUT.put_line('Delete RINVIO_PROVVEDIMENTO ------ >>>  OK!');
    END IF;

    DELETE FROM decreto_ordinanza_siep WHERE id_evento_generato = idevento;

    DBMS_OUTPUT.put_line('Delete DECRETO_ORDINANZA_SIEP ------ >>>  OK!');

    DELETE FROM deposito_ordinanza_pc WHERE id_evento_generato = idevento;

    DBMS_OUTPUT.put_line('Delete DEPOSITO_ORDINANZA_PC ------ >>>  OK!');

    DELETE FROM riepilogo_provvedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete RIEPILOGO_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM udienza_procedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete UDIENZA_PROCEDIMENTO ------ >>>  OK!');

    DELETE FROM scadenzario_siep WHERE eve_id_evento = idevento;

    --dbms_output.put_line('Delete SCADENZARIO_SIEP  ------ >>>  OK!');
    DELETE FROM scambio_sanzione WHERE eve_id_evento = idevento;

    --dbms_output.put_line('Delete SCAMBIO_SANZIONE  ------ >>>  OK!');
    DELETE FROM periodo_altra_sanzione WHERE eve_id_evento = idevento;

    --dbms_output.put_line('Delete PERIODO_ALTRA_SANZIONE  ------ >>>  OK!');
    DELETE FROM deposito_decreto WHERE id_evento_generato = idevento;

    DBMS_OUTPUT.put_line('Delete DEPOSITO_DECRETO ------ >>>  OK!');

    -- Cherubini Giugno 2010
    -- Inizio
    DELETE FROM stato_procedimento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete STATO_PROCEDIMENTO ------ >>>  OK!');
    -- Fine

    --========================================================================
    -- Ticket 202010140112 aggiunta la cancellazione delle richiesta
    -- conversione che punta l'evento
    DELETE FROM richiesta_conversione WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete RICHIESTA_CONVERSIONE ------ >>>  OK!');
    --========================================================================

    DELETE FROM evento WHERE eve_id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete EVENTO ------ >>>  OK!');

    DELETE FROM evento WHERE id_evento = idevento;

    DBMS_OUTPUT.put_line('Delete EVENTO ------ >>>  OK!');
    --COMMIT;
    esitopuliscievento := 'Evviva Abbiamo pulito tutto!!!';
  END pulisci_evento;

  --==============================================================================
  --
  --==============================================================================
  PROCEDURE pulisci_fascicolo(idfascicolo           IN NUMBER,
                              esitopuliscifascicolo IN OUT VARCHAR2) IS

    CURSOR elenco_eventi(idfascicolo IN NUMBER) IS
      SELECT id_evento
        FROM evento
       WHERE fas_sie_id_fascicolo_siep = idfascicolo
       ORDER BY id_evento DESC;

    appo_evento         NUMBER;
    esito_pulisci       VARCHAR2(100);
    ctrl_sius           NUMBER := 0;
    idreato             NUMBER := 0;
    idpenacomplessiva   NUMBER := 0;
    idlicenzaliban      NUMBER := 0;
    idpenaresidua       NUMBER := 0;
    idmisuraalternativa NUMBER := 0;
    idavvocato          NUMBER := 0;

    CURSOR avv_fas_sie IS
      SELECT id_avvocato_fascicolo_siep
        FROM avvocato_fascicolo_siep
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR pen_comp IS
      SELECT id_pena_complessiva
        FROM pena_complessiva
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR lic_lib IS
      SELECT id_licenza_libanticipata
        FROM licenza_libanticipata
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR pen_res IS
      SELECT id_pena_residua
        FROM pena_residua
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    CURSOR mis_alt IS
      SELECT id_misura_alternativa
        FROM misura_alternativa
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    --MEV 42 Cumulo - Aggiunta cancellazione Istruttorie
    v_idIstruttoria    NUMBER := 0;
    esito_pulisci_istr VARCHAR2(50) := null;
    CURSOR elenco_istruttorie_cur(idfascicolo IN NUMBER) IS
      SELECT ID_ISTRUTTORIA_CUMULO
        FROM ISTRUTTORIA_CUMULO
       WHERE FAS_SIE_ID_FASCICOLO_SIEP = idfascicolo
       ORDER BY ID_ISTRUTTORIA_CUMULO DESC;
  BEGIN
    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('--------------------- INIZIO PULISCI ALTRE BDI ---------------------');
    DBMS_OUTPUT.put_line('*************************************************************************************************');

    OPEN elenco_eventi(idfascicolo);

    LOOP
      FETCH elenco_eventi
        INTO appo_evento;

      EXIT WHEN elenco_eventi%NOTFOUND;

      BEGIN
        SELECT fas_siu_id_fascicolo_sius
          INTO ctrl_sius
          FROM evento
         WHERE id_evento = appo_evento;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          ctrl_sius := 0;
      END;

      DBMS_OUTPUT.put_line('ctrl_sius = ' || ctrl_sius);

      IF ctrl_sius = 0 OR ctrl_sius IS NULL THEN
        DBMS_OUTPUT.put_line('chiamo pulisci evento ');
        pulisci_altre_bdi.pulisci_evento(appo_evento, esito_pulisci);
      END IF;
    END LOOP;

    DBMS_OUTPUT.put_line('appo_evento = ' || appo_evento);

    CLOSE elenco_eventi;

    DBMS_OUTPUT.put_line('*************************************************************************************************');
    DBMS_OUTPUT.put_line('--------------------- INIZIO PULISCI FASCICOLO ---------------------');
    DBMS_OUTPUT.put_line('*************************************************************************************************');

    DELETE FROM annotazione_manuale
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete ANNOTAZIONE_MANUALE ------ >>>  OK!');

    BEGIN
      OPEN avv_fas_sie;

      LOOP
        FETCH avv_fas_sie
          INTO idavvocato;

        EXIT WHEN avv_fas_sie%NOTFOUND;

        DELETE FROM notifica
         WHERE avv_id_avvocato_fascicolo_siep = idavvocato;

        DBMS_OUTPUT.put_line('Delete NOTIFICA ------ >>>  OK!');

        DELETE FROM avvocato_fascicolo_siep
         WHERE fas_sie_id_fascicolo_siep = idfascicolo;

        --AND avv_id_avvocato = IdAvvocato;
        DBMS_OUTPUT.put_line('Delete AVVOCATO_FASCICOLO_SIEP ------ >>>  OK!');
      END LOOP;

      CLOSE avv_fas_sie;
    END;

    DELETE FROM beneficio WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete BENEFICIO ------ >>>  OK!');

    DELETE FROM archiviazione
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete ARCHIVIAZIONE ------ >>>  OK!');

    DELETE FROM campo_nota WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete CAMPO_NOTA ------ >>>  OK!');

    DELETE FROM circostanza WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete CIRCOSTANZA ------ >>>  OK!');

    DELETE FROM reato WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete REATO ------ >>>  OK!');

    BEGIN
      OPEN pen_comp;

      LOOP
        FETCH pen_comp
          INTO idpenacomplessiva;

        EXIT WHEN pen_comp%NOTFOUND;

        DELETE FROM continuazione
         WHERE pen_com_id_pena_complessiva = idpenacomplessiva;

        DBMS_OUTPUT.put_line('Delete CONTINUAZIONE ------ >>>  OK!');

        DELETE FROM sanzione_sostitutiva
         WHERE pen_com_id_pena_complessiva = idpenacomplessiva;

        DBMS_OUTPUT.put_line('Delete SANZIONE_SOSTITUTIVA ------ >>>  OK!');
      END LOOP;

      DELETE FROM pena_complessiva
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

      DBMS_OUTPUT.put_line('Delete PENA_COMPLESSIVA ------ >>>  OK!');

      CLOSE pen_comp;
    END;

    DELETE FROM pena_pecuniaria
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete PENA_PECUNIARIA ------ >>>  OK!');

    DELETE FROM sanzione_sost_residua
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DELETE FROM pena_presunta
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete PENA_PRESUNTA ------ >>>  OK!');

    DELETE FROM pena_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo
              FROM cumulo
             WHERE fas_sie_id_fascicolo_siep = idfascicolo);

    DBMS_OUTPUT.put_line('Delete PENA_CUMULO ------ >>>  OK!');
    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');
    ---aggiunto il 13/12/2006

    DELETE FROM ulteriore_sanzione_cumulo
     WHERE cum_id_cumulo IN
           (SELECT id_cumulo
              FROM cumulo
             WHERE fas_sie_id_fascicolo_siep = idfascicolo);

    DBMS_OUTPUT.put_line('Delete ULTERIORE_SANZIONE_CUMULO ------ >>>  OK!');

    DELETE FROM cumulo WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete CUMULO ------ >>>  OK!');

    DELETE FROM fungibilita WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete FUNGIBILITA ------ >>>  OK!');

    --   UMBERTO 29-6-2009 - Commentato ciclo cancellazione LICENZA_LIBANTICIPATA e PERIODO_LIBANTICIPATA
    --                       la cancellazione viene effettuata solo pergli eventi privi di fascicolo_sius e
    --                       pilotati da cancella evento
    --    BEGIN
    --      OPEN lic_lib;
    --      LOOP
    --         FETCH lic_lib  INTO   idLicenzaLiban;
    --         EXIT WHEN lic_lib%NOTFOUND;
    --
    --         DELETE FROM PERIODO_LIBANTICIPATA WHERE lic_id_licenza_libanticipata = idLicenzaLiban;
    --        DBMS_OUTPUT.PUT_LINE('Delete PERIODO_LIBANTICIPATA ------ >>>  OK!');
    --
    --     END LOOP;
    --
    --      DELETE FROM LICENZA_LIBANTICIPATA WHERE FAS_SIE_ID_FASCICOLO_SIEP = IdFascicolo;
    --      DBMS_OUTPUT.PUT_LINE('Delete LICENZA_LIBANTICIPATA ------ >>>  OK!');
    --
    --
    --     CLOSE lic_lib;
    --    END;
    --
    --    FINE INTERVENTO UMBERTO 29-6-2009
    DELETE FROM magistrato_competente
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MAGISTRATO_COMPETENTE ------ >>>  OK!');

    BEGIN
      OPEN pen_res;

      LOOP
        FETCH pen_res
          INTO idpenaresidua;

        EXIT WHEN pen_res%NOTFOUND;

        DELETE FROM sospensione
         WHERE pen_res_id_pena_residua = idpenaresidua;

        DBMS_OUTPUT.put_line('Delete SOSPENSIONE------ >>>  OK!');
      END LOOP;

      DELETE FROM pena_residua
       WHERE fas_sie_id_fascicolo_siep = idfascicolo;

      DBMS_OUTPUT.put_line('Delete PENA_RESIDUA ------ >>>  OK!');

      CLOSE pen_res;
    END;

    --     BEGIN
    --      OPEN mis_alt;
    --      LOOP
    --          FETCH mis_alt  INTO   idMisuraAlternativa;
    --          EXIT WHEN mis_alt%NOTFOUND;
    --
    --        DELETE FROM PENA_RESIDUA WHERE Mis_alt_id_misura_alternativa = idMisuraAlternativa;
    --     dbms_output.put_line('Delete PENA_RESIDUA per MA------ >>>  OK!');
    --
    --    END LOOP;
    --
    DELETE FROM misura_alternativa
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MISURA_ALTERNATIVA ------ >>>  OK!');

    --
    --    CLOSE mis_alt;
    --
    --     END;
    DELETE FROM reato WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete REATO ------ >>>  OK!');

    DELETE FROM misura_cautelare
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MISURA_CAUTELARE ------ >>>  OK!');

    DELETE FROM misura_sicurezza
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete MISURA_SICUREZZA ------ >>>  OK!');

    DELETE FROM pena_accessoria
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete PENA_ACCESSORIA ------ >>>  OK!');

    DELETE FROM residenza_fascicolo_siep
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete RESIDENZA_FASCICOLO_SIEP ------ >>>  OK!');

    DELETE FROM sanzione_amministrativa
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete SANZIONE_AMMINISTRATIVA ------ >>>  OK!');

    DELETE FROM scadenzario_siep
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete SCADENZARIO_SIEP ------ >>>  OK!');

    DELETE FROM luogo_detenzione
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete LUOGO_DETENZIONE ------ >>>  OK!');

    DELETE FROM stato_procedimento
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete STATO_PROCEDIMENTO ------ >>>  OK!');

    -- Ticket#20200915014 invertito ordine di cancellazione tra PG e AC
    -- in quanto PG punta AC se presente ed andava in errore di violazione
    -- referenziale
    DELETE FROM posizione_giuridica
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete POSIZIONE_GIURIDICA ------ >>>  OK!');

    -- MEV_67 : SPOSTO LA CANCELLAZIONE DALLA TABELLA ALTRA_CAUSA
    -- DOPO LA CANCELLAZIONE DELLA POSIZIONE_GIURIDICA
    DELETE FROM altra_causa WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete ALTRA_CAUSA ------ >>>  OK!');
    -- MEV_67
    -- END Ticket#20200915014

    DELETE FROM riepilogo_provvedimento
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete RIEPILOGO_PROVVEDIMENTO ------ >>>  OK!');

    DELETE FROM decreto_ordinanza_siep
     WHERE fas_sie_id_fascicolo_siep = idfascicolo;

    DBMS_OUTPUT.put_line('Delete DECRETO_ORDINANZA_SIEP ------ >>>  OK!');

    DBMS_OUTPUT.put_line('Inizio Delete ISTRUTTORIE CUMULO E DATI ANNESSI...!');
    OPEN elenco_istruttorie_cur(idfascicolo);
    LOOP
      FETCH elenco_istruttorie_cur
        INTO v_idIstruttoria;

      EXIT WHEN elenco_istruttorie_cur%NOTFOUND;

      BEGIN
        DBMS_OUTPUT.put_line('v_idIstruttoria = ' || v_idIstruttoria);
        --esito_pulisci_istr
        PULISCI_ALTRE_BDI.PULISCI_ISTRUTTORIA_CUM(v_idIstruttoria,
                                                  esito_pulisci_istr);

        DBMS_OUTPUT.put_line('esito_pulisci_istr = ' || esito_pulisci_istr);
      END;
    END LOOP;

    DBMS_OUTPUT.put_line('Uscita dal LOOP sulle ISTRUTTORIE');

    CLOSE elenco_istruttorie_cur;

    ---   COMMIT;
    esitopuliscifascicolo := '0000';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.put_line('ERRORE NO_DATA_FOUND!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      esitopuliscifascicolo := '1111';
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      -- esitopuliscifascicolo := '1111';
      esitopuliscifascicolo := SQLCODE||' - '||SQLERRM;
  END;

  --==============================================================================
  --
  --==============================================================================
  PROCEDURE pulisci_istruttoria_cum(p_IdIstrutoria            IN NUMBER,
                                    p_EsitoPulisciIstruttoria IN OUT VARCHAR2) IS
    v_esito_pulisci VARCHAR2(100);

    --v_idIstruttoria  ISTRUTTORIA_CUMULO.ID_ISTRUTTORIA_CUMULO%type:= 0;
    v_idTitolo TITOLO_CUMULATO.ID_TITOLO_CUMULATO%type := 0;

    CURSOR titoli_cur(idIstruttoria IN NUMBER) IS
      SELECT ID_TITOLO_CUMULATO
        FROM TITOLO_CUMULATO
       WHERE ISTR_ID_ISTRUTTORIA_CUMULO = idIstruttoria;

  BEGIN
    DBMS_OUTPUT.put_line('************************************************');
    DBMS_OUTPUT.put_line('-----  INIZIO Cancellazione Istruttoria id = ' ||
                         p_IdIstrutoria);
    DBMS_OUTPUT.put_line('-----  DATA ' ||
                         to_char(sysdate, 'dd/MM/yyyy hh24:mi:ss'));
    DBMS_OUTPUT.put_line('************************************************');

    --========================================================================
    -- Cancellazione delle RICHIESTE in CUMULO
    --========================================================================
    DBMS_OUTPUT.put_line('================================');
    DBMS_OUTPUT.put_line(' INIZIO CANCELLAZIONE RICHIESTE ');
    DBMS_OUTPUT.put_line('================================');

    DBMS_OUTPUT.put_line('DELETE RICHPM_BENEFICIO_CUM...');
    DELETE FROM RICHPM_BENEFICIO_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_BENEFICIO_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_MISSICUR_CUM...');
    DELETE FROM RICHPM_MISSICUR_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_MISSICUR_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_PENACC_CUM...');
    DELETE FROM RICHPM_PENACC_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_PENACC_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_REATO_CUM...');
    DELETE FROM RICHPM_REATO_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_REATO_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_SANZIONE_SOST_CUM...');
    DELETE FROM RICHPM_SANZIONE_SOST_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_SANZIONE_SOST_CUM = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_STATO_ESEC_CUM...');
    DELETE FROM RICHPM_STATO_ESEC_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_STATO_ESEC_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHPM_TITOLO_CUM...');
    DELETE FROM RICHPM_TITOLO_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE RICHPM_TITOLO_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('UPDATE RICHIESTE_PM_IN_CUMULO set FK RICH INVIATE NULL');
    UPDATE RICHIESTE_PM_IN_CUMULO
       SET RIC_ID_RICHIESTE_INVIATE_CUM = null
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE RICHIESTE_PM_IN_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHIESTE_INVIATE_CUM...');
    DELETE FROM RICHIESTE_INVIATE_CUM
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE RICHIESTE_INVIATE_CUM = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE PROVVEDIMENTO_GE_SORV_CUM...');
    DELETE FROM PROVVEDIMENTO_GE_SORV_CUM
     WHERE RIC_ID_RICHIESTE_PM_IN_CUMULO IN
           (SELECT ID_RICHIESTE_PM_IN_CUMULO
              FROM RICHIESTE_PM_IN_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE PROVVEDIMENTO_GE_SORV_CUM = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE RICHIESTE_PM_IN_CUMULO...');
    DELETE FROM RICHIESTE_PM_IN_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE RICHIESTE_PM_IN_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('==============================');
    DBMS_OUTPUT.put_line(' FINE CANCELLAZIONE RICHIESTE ');
    DBMS_OUTPUT.put_line('==============================');
    --========================================================================
    -- Cancellazione delle RICHIESTE in CUMULO
    --========================================================================

    OPEN titoli_cur(p_IdIstrutoria);
    LOOP
      FETCH titoli_cur
        INTO v_idTitolo;

      EXIT WHEN titoli_cur%NOTFOUND;

      BEGIN
        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE DATI ANALITICI PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');

        DBMS_OUTPUT.put_line('DELETE MISURA_SICUREZZA_CUMULO...');
        DELETE FROM MISURA_SICUREZZA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE MISURA_SICUREZZA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE PENA_ACCESSORIA_CUMULO...');
        DELETE FROM PENA_ACCESSORIA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE PENA_ACCESSORIA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE MISURA_CAUTELARE_CUMULO...');
        DELETE FROM MISURA_CAUTELARE_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE MISURA_CAUTELARE_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE CONTINUAZIONE_CUMULO...');
        DELETE FROM CONTINUAZIONE_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE CONTINUAZIONE_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE REATO_CUMULO...');
        DELETE FROM REATO_CUMULO WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE REATO_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE CIRCOSTANZA_CUMULO...');
        DELETE FROM CIRCOSTANZA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE CIRCOSTANZA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE SANZIONE_SOST_CUM...');
        DELETE FROM SANZIONE_SOST_CUM
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE SANZIONE_SOST_CUM = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE PENA_COMPLESSIVA_CUMULO...');
        DELETE FROM PENA_COMPLESSIVA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE MISURA_CAUTELARE_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO collegate a benefici_cumulo...');
        DELETE FROM TIPOLOGIA_ORARIO
         WHERE BEN_ID_BENEFICIO_CUMULO IN
               (SELECT ID_BENEFICIO_CUMULO
                  FROM BENEFICIO_CUMULO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);

        DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE BENEFICIO_CUMULO...');
        DELETE FROM BENEFICIO_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE BENEFICIO_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('FINE CANCELLAZIONE DATI ANALITICI PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('');
        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE STATO ESECUZIONE PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');

        DBMS_OUTPUT.put_line('DELETE PERIODO_LIB_ANT_CUMULO ...');
        DELETE FROM PERIODO_LIB_ANT_CUMULO
         WHERE LIB_ID_LIB_ANTICIPATA_CUMULO IN
               (SELECT ID_LIB_ANTICIPATA_CUMULO
                  FROM LIB_ANTICIPATA_CUMULO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);
        DBMS_OUTPUT.put_line('DELETE PERIODO_LIB_ANT_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE LIB_ANTICIPATA_CUMULO...');
        DELETE FROM LIB_ANTICIPATA_CUMULO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE LIB_ANTICIPATA_CUMULO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE NOTIFICA_CUMULO...');
        DELETE FROM NOTIFICA_CUMULO
         WHERE STAT_ID_STATO_ESEC_TIT_CUM IN
               (SELECT ID_STATO_ESEC_TITOLO_CUMULATO
                  FROM STATO_ESEC_TITOLO_CUMULATO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);
        DBMS_OUTPUT.put_line('DELETE NOTIFICA_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE COMPUTI_CUMULO...');
        DELETE FROM COMPUTI_CUMULO
         WHERE STAT_ID_STATO_ESEC_TIT_CUM IN
               (SELECT ID_STATO_ESEC_TITOLO_CUMULATO
                  FROM STATO_ESEC_TITOLO_CUMULATO
                 WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo);
        DBMS_OUTPUT.put_line('DELETE COMPUTI_CUMULO = ' || Sql%Rowcount);

        DBMS_OUTPUT.put_line('DELETE STATO_ESEC_TITOLO_CUMULATO...');
        DELETE FROM STATO_ESEC_TITOLO_CUMULATO
         WHERE TIT_ID_TITOLO_CUMULATO = v_idTitolo;
        DBMS_OUTPUT.put_line('DELETE STATO_ESEC_TITOLO_CUMULATO = ' ||
                             Sql%Rowcount);

        DBMS_OUTPUT.put_line('====================================================');
        DBMS_OUTPUT.put_line('FINE CANCELLAZIONE STATO ESECUZIONE PER IL TITOLO = ' ||
                             v_idTitolo);
        DBMS_OUTPUT.put_line('====================================================');

      END;
    END LOOP;
    CLOSE titoli_cur;

    DBMS_OUTPUT.put_line('Uscita dal LOOP sui titoli');

    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE DATI FINALI ');
    DBMS_OUTPUT.put_line('====================================================');

    DBMS_OUTPUT.put_line('DELETE POSIZIONE_GIURIDICA_CUMULO...');
    DELETE FROM POSIZIONE_GIURIDICA_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE POSIZIONE_GIURIDICA_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE PENA_RIDETERMINATA_CUMULO...');
    DELETE FROM PENA_RIDETERMINATA_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE PENA_RIDETERMINATA_CUMULO = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO collegate a DATI_FINALI_ULTERIORI_SANZIONI...');
    DELETE FROM TIPOLOGIA_ORARIO
     WHERE DAT_FIN_CUM_ULT_SANZIONI IN
           (SELECT ID_DATI_FINALI_ULTERIORI_SANZ
              FROM DATI_FINALI_ULTERIORI_SANZIONI
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_ULTERIORI_SANZIONI...');
    DELETE FROM DATI_FINALI_ULTERIORI_SANZIONI
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_ULTERIORI_SANZIONI = ' ||
                         Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE COMPUTI_CUMULO collegate a DATI_FINALI...');
    DELETE FROM COMPUTI_CUMULO
     WHERE DAT_ID_DATI_FINALI_CUMULO IN
           (SELECT ID_DATI_FINALI_CUMULO
              FROM DATI_FINALI_CUMULO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE TIPOLOGIA_ORARIO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_CUMULO...');
    DELETE FROM DATI_FINALI_CUMULO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE DATI_FINALI_CUMULO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('FINE CANCELLAZIONE DATI FINALI ');
    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('');
    DBMS_OUTPUT.put_line('====================================================');
    DBMS_OUTPUT.put_line('INIZIO CANCELLAZIONE DATI ISTRUTTORIA ');
    DBMS_OUTPUT.put_line('====================================================');

    DBMS_OUTPUT.put_line('DELETE PROCEDIMENTO_CUMULATO collegate a DATI_FINALI...');
    DELETE FROM PROCEDIMENTO_CUMULATO
     WHERE TIT_ID_TITOLO_CUMULATO IN
           (SELECT ID_TITOLO_CUMULATO
              FROM TITOLO_CUMULATO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE PROCEDIMENTO_CUMULATO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE SOGGETTO_CUMULATO collegate a DATI_FINALI...');
    DELETE FROM SOGGETTO_CUMULATO
     WHERE TIT_ID_TITOLO_CUMULATO IN
           (SELECT ID_TITOLO_CUMULATO
              FROM TITOLO_CUMULATO
             WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria);
    DBMS_OUTPUT.put_line('DELETE SOGGETTO_CUMULATO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE TITOLO_CUMULATO collegate a DATI_FINALI...');
    DELETE FROM TITOLO_CUMULATO
     WHERE ISTR_ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE TITOLO_CUMULATO = ' || Sql%Rowcount);

    DBMS_OUTPUT.put_line('DELETE ISTRUTTORIA_CUMULO...');
    DELETE FROM ISTRUTTORIA_CUMULO
     WHERE ID_ISTRUTTORIA_CUMULO = p_IdIstrutoria;
    DBMS_OUTPUT.put_line('DELETE ISTRUTTORIA_CUMULO = ' || Sql%Rowcount);

    p_EsitoPulisciIstruttoria := '0000';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.put_line('ERRORE NO_DATA_FOUND!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      p_EsitoPulisciIstruttoria := '1111';
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('ERRORE OTHERS!!!');
      DBMS_OUTPUT.put_line(SQLCODE);
      DBMS_OUTPUT.put_line(SQLERRM);
      p_EsitoPulisciIstruttoria := '1111';
  END;

END;
/