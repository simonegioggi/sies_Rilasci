-- Insert per registrare la funzione di dettaglio fascicolo siep come figlia della funzione di ricerca
-- ActListaFascicoloPerSoggettoCodCui. Consente la visualizzazione della lente sull'elenco dei risultati della ricerca
INSERT INTO RELAZIONE_FUNZIONE
(FUN_ID_FUNZIONE, FUN_ID_FUNZIONE_FIGLIA, COD_TIPO_VISUALIZZAZIONE, LABEL_FUNZIONE, ORDINE_VISUALIZZAZIONE, IMMAGINE)
VALUES(90110782, 25, 'BO', 'Dettaglio Fascicolo', 1, NULL);