-------------------------------------------------------------------------------
-- Scopo ..: Creazione degli oggetti del database del sistema informativo
-- Note ...: eseguire da SQLPLUS /NOLOG
--
-- VERSIONE_SIES_12.5.4.0-MEV_2019_09
-------------------------------------------------------------------------------

WHENEVER SQLERROR CONTINUE
WHENEVER OSERROR CONTINUE

PROMPT Procedura di installazione versione VERSIONE_SIES_12_5_4_0-MEV_2019_09 di SIES
PROMPT
PROMPT Se non si intende procedere chiudere SQL*Plus premendo adesso CTRL+C
PAUSE oppure premere INVIO...

ACCEPT dbsid PROMPT 'Inserire il SID dell''istanza Oracle  ... : ';
ACCEPT siesuser PROMPT 'Inserire il nome dello schema SIES ... : ';
ACCEPT pwd_sies PROMPT 'Inserire la password dello schema SIES ... : ';

PROMPT
PROMPT Per generare il file di log ed il percorso dei datafile in modo opportuno
PROMPT occorre indicare un nome mnemonico per questa installazione.
PROMPT Valore di default: &dbsid
PROMPT
ACCEPT nomeinstallazione PROMPT 'Inserire il nome di questa installazione : ' DEFAULT &dbsid

DEFINE logpath=log
HOST mkdir -p &logpath

PROMPT
PROMPT Inserimento dati completato
PAUSE Premere INVIO per continuare...
PROMPT
SPOOL &logpath/creazione_&nomeinstallazione..log

PROMPT
PROMPT ==============================================================================
PROMPT Riassunto dei dati immessi per questa installazione
PROMPT Nome ....................: &nomeinstallazione
PROMPT ==============================================================================
PROMPT SID Oracle ..............: &dbsid
PROMPT Utente_SIES..............: &siesuser
PROMPT Password_SIES............: &pwd_sies
PROMPT ==============================================================================
!echo '=============================================================================='
!echo '***** DATA INIZIO PROCEDURA:' `date +%d/%m/%Y_%r`
!echo '=============================================================================='
PROMPT
PROMPT Se non si intende procedere chiudere adesso SQL*Plus premendo CTRL+C
PAUSE altrimenti premere INVIO per continuare...

!cd $ORACLE_HOME/bin

CONNECT &siesuser/&pwd_sies@&dbsid

SET TERMOUT ON;
PROMPT
PROMPT ===================================================
PROMPT  LANCIO AGGIORNAMENTO DATI...
PROMPT ===================================================
PROMPT
SET TERMOUT OFF;

SET TERMOUT ON;
PROMPT
PROMPT ===================================================
PROMPT  LANCIO CG_REF_CODES...
PROMPT ===================================================
PROMPT
@MEV_2019_09/CG_REF_CODES.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO DEPOSITO_DECRETO...
PROMPT ===================================================
PROMPT
@MEV_2019_09/DEPOSITO_DECRETO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO DEPOSITO_ORDINANZA_PC...
PROMPT ===================================================
PROMPT
@MEV_2019_09/DEPOSITO_ORDINANZA_PC.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO EVENTO...
PROMPT ===================================================
PROMPT
@MEV_2019_09/EVENTO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO FUNZIONE...
PROMPT ===================================================
PROMPT
@MEV_2019_09/FUNZIONE.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO FUNZIONE_PROFILO...
PROMPT ===================================================
PROMPT
@MEV_2019_09/FUNZIONE_PROFILO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO GENERALE_PROCEDIMENTO...
PROMPT ===================================================
PROMPT
@MEV_2019_09/GENERALE_PROCEDIMENTO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO ISP_CONTEGGIO_OGGETTI...
PROMPT ===================================================
PROMPT
@MEV_2019_09/ISP_CONTEGGIO_OGGETTI.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO ISP_CONTEGGIO_RELATORI...
PROMPT ===================================================
PROMPT
@MEV_2019_09/ISP_CONTEGGIO_RELATORI.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO ISP_ESITO_PROVVEDIMENTO...
PROMPT ===================================================
PROMPT
@MEV_2019_09/ISP_ESITO_PROVVEDIMENTO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO ISP_OGGETTO_PROCEDIMENTO...
PROMPT ===================================================
PROMPT
@MEV_2019_09/ISP_OGGETTO_PROCEDIMENTO.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO ISPETTORATO_SIUS...
PROMPT ===================================================
PROMPT
@MEV_2019_09/ISPETTORATO_SIUS.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO RELAZIONE_FUNZIONE...
PROMPT ===================================================
PROMPT
@MEV_2019_09/RELAZIONE_FUNZIONE.sql
PROMPT
PROMPT ===================================================
PROMPT  LANCIO TEMPLATE...
PROMPT ===================================================
PROMPT
@MEV_2019_09/TEMPLATE.sql

SET TERMOUT ON;
COMMIT;

PROMPT 
PROMPT ===================================================
PROMPT  LANCIO AGGIORNAMENTO VERSIONE...
PROMPT ===================================================
PROMPT
SET TERMOUT OFF;
@aggiorna_versione.sql

SET TERMOUT ON;
COMMIT;

PROMPT
PROMPT ==============================================================================
PROMPT *******          ******** | Operazioni completate | *******           ********
PROMPT ==============================================================================
PROMPT Le operazioni sono state registrate sul file
PROMPT &logpath/creazione_&nomeinstallazione..log
PROMPT ==============================================================================
!echo '=============================================================================='
!echo '***** DATA FINE PROCEDURA:' `date +%d/%m/%Y_%r`
!echo '=============================================================================='
PROMPT

DISCONNECT

SPOOL off

PAUSE Premere INVIO per concludere...
EXIT
