ALTER TABLE EVENTO ADD DATA_RESTITUZIONE_AI DATE;
COMMENT ON COLUMN EVENTO.DATA_RESTITUZIONE_AI IS 'Campo Atti da restituire entro il (per Fase istruttoria - Richiesta Atti)';