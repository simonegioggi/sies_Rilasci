-- FUNZIONE_PROFILO
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111917, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111917, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111917, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111917, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111918, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111918, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111918, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111918, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111919, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111919, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111919, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111919, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111920, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111920, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111920, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111920, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111921, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111921, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111921, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111921, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111922, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111922, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111922, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111922, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111924, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111924, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111924, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111924, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111926, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111926, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111926, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111932, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111932, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111933, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111933, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111933, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111933, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111928, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111928, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111928, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111928, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111929, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111929, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111929, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111929, 51, null, null, null, null, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 90111931, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 90111931, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 90111931, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 90111931, 51, NULL, NULL, NULL, NULL, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111934, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111934, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111934, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111934, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111935, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111935, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111935, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111936, 14, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111937, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111937, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111938, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111938, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111938, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111938, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111939, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111939, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111939, 51, null, null, null, null, 'S');

insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111950, 14, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111950, 31, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111950, 41, null, null, null, null, 'S');
insert into FUNZIONE_PROFILO values
 (trunc(sysdate), null, 90111950, 51, null, null, null, null, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105000, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105000, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105000, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105000, 51, NULL, NULL, NULL, NULL, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105001, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105001, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105001, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105001, 51, NULL, NULL, NULL, NULL, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105002, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105002, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105002, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105002, 51, NULL, NULL, NULL, NULL, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105003, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105003, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105003, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (trunc(sysdate), NULL, 38105003, 51, NULL, NULL, NULL, NULL, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101044, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101044, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101044, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101044, 51, NULL, NULL, NULL, NULL, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101045, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101045, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101045, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101045, 51, NULL, NULL, NULL, NULL, 'S');

INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101046, 14, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101046, 31, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101046, 41, NULL, NULL, NULL, NULL, 'S');
INSERT INTO FUNZIONE_PROFILO VALUES
 (TIMESTAMP '2000-01-01 00:00:00.000000', NULL, 38101046, 51, NULL, NULL, NULL, NULL, 'S');

--- Cancellazione profili per funzioni gi� esistenti
--- profili 31 e 32 per funzione 10707 siap.sius.depositoordinanzapc.action.ActStampaEmissioneOrdinanza
DELETE FUNZIONE_PROFILO WHERE FUN_ID_FUNZIONE = 10707 AND PRF_COD_PROFILO IN ('31','32');
--- profili 31 e 32 per funzione 10588 siap.sius.udienza.action.ActStampaFissazioneUdienza
DELETE FUNZIONE_PROFILO WHERE FUN_ID_FUNZIONE = 10588 AND PRF_COD_PROFILO IN ('31','32');
--- profili 31 e 32 per funzione 31140310 siap.sius.depositodecreto.action.ActStampaDepositoDecreto
DELETE FUNZIONE_PROFILO WHERE FUN_ID_FUNZIONE = 31140310 AND PRF_COD_PROFILO IN ('31','32');
--- profili 51 e 52 per funzione 31130570 siap.sius.depositoordinanzapc.action.ActCancellaEmissioneOrdinanza
DELETE FUNZIONE_PROFILO WHERE FUN_ID_FUNZIONE = 31130570 AND PRF_COD_PROFILO IN ('51','52');