--- aggiunta due nuove colonne alla tabella DEPOSITO_DECRETO
ALTER TABLE DEPOSITO_DECRETO ADD 
(DATA_TERMINE_EMISSIONE DATE, 
NUM_GIORNI_TERMINE_EMISSIONE NUMBER(4,0));
comment on column DEPOSITO_DECRETO.DATA_TERMINE_EMISSIONE
  is 'Data termine emissione';
comment on column DEPOSITO_DECRETO.NUM_GIORNI_TERMINE_EMISSIONE
  is 'Numero giorni termine emissione';