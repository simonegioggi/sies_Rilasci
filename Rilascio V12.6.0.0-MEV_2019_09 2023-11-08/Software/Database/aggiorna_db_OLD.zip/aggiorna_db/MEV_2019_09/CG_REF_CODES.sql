-- OGGETTO_PROCEDIMENTO
INSERT INTO CG_REF_CODES VALUES ('OGGETTO_PROCEDIMENTO', 'C050', 'S01', 'MA', 'Concessione Misure Alternative alla Detenzione (art. 678 comma 1 ter c.p.p.)', 'SER', NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('OGGETTO_PROCEDIMENTO', 'C051', 'S01', 'MA', 'Concessione Misure Penali di Comunita'' / Misure Alternative alla Detenzione (art. 2 D.lgs. 121/2018, art. 678 comma 1 ter c.p.p.)', 'SER', NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('OGGETTO_PROCEDIMENTO', 'MACA', NULL, NULL, 'Conferma Misure Alternative brevi - Adulti', 'SER', NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('OGGETTO_PROCEDIMENTO', 'MACM', NULL, NULL, 'Conferma Misure Alternative brevi -Minorenni', 'SER', NULL, NULL, NULL);

-- MOTIVO_PROVVEDIMENTO
insert into CG_REF_CODES values ('MOTIVO_PROVVEDIMENTO', '0680', 'C050', null, 'Affidamento in Prova al Servizio Sociale (Art. 47 O.P. - Art. 678 comma 1-ter c.p.p.)', null, null, 'CONCUM', null);
insert into CG_REF_CODES values ('MOTIVO_PROVVEDIMENTO', '0681', 'C050', null, 'Affidamento in Prova al Servizio Sociale (Art. 94 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', null, null, 'CONCUM', null);
insert into CG_REF_CODES values ('MOTIVO_PROVVEDIMENTO', '0682', 'C050', null, 'Detenzione Domiciliare (Art. 47 ter O.P. - Art. 678 comma 1-ter c.p.p.)', null, null, 'CONCUM', null);
insert into CG_REF_CODES values ('MOTIVO_PROVVEDIMENTO', '0683', 'C050', null, 'Semiliberta'' (Art. 50 comma 1 O.P. - Art. 678 comma 1-ter c.p.p.)', null, null, 'CONCUM', null);
insert into CG_REF_CODES values ('MOTIVO_PROVVEDIMENTO', '0684', 'C050', null, 'Sospensione dell''Esecuzione della Pena (Art. 90 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', null, null, 'CONCUM', null);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0690', 'C051', NULL, 'Affidamento in Prova al Servizio Sociale (art.4 D.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', NULL, NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0691', 'C051', NULL, 'Affidamento in Prova in casi particolari (artt.4 D.lgs. 121/2018 - 94 DPR 309/90, art. 678 comma 1 ter cp.p.)', NULL, NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0692', 'C051', NULL, 'Affidamento in prova in prova con detenzione domiciliare (art.5 d.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', NULL, NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0693', 'C051', NULL, 'Detenzione domiciliare (art.6 d.lgs. 121/2018 , art. 678 comma 1 ter cp.p.)', NULL, NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0694', 'C051', NULL, 'Semiliberta'' (art.7 d.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', NULL, NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0695', 'C051', NULL, 'Sospensione dell''Esecuzione della Pena (Art. 90 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', NULL, NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0720', 'MACA', NULL, 'Conferma appl. provv. Affidamento in Prova al S.S. (Art. 47 O.P. - Art. 678 comma 1-ter c.p.p.)', '0680', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0721', 'MACA', NULL, 'Conferma appl. provv. Affidamento in Prova al S.S. (Art. 94 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', '0681', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0722', 'MACA', NULL, 'Conferma appl. provv. Detenzione Domiciliare (Art. 47 ter O.P. - Art. 678 comma 1-ter c.p.p.)', '0682', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0723', 'MACA', NULL, 'Conferma appl. provv. Semiliberta'' (Art. 50 comma 1 O.P. - Art. 678 comma 1-ter c.p.p.)', '0683', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0724', 'MACA', NULL, 'Conferma appl. provv. Sospensione dell''Esecuzione della Pena (Art. 90 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', '0684', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0730', 'MACM', NULL, 'Conferma appl. provv. Affidamento in Prova al S.S. (art.4 D.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', '0690', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0731', 'MACM', NULL, 'Conferma appl. provv. Affidamento in Prova in casi particolari (artt.4 D.lgs. 121/2018 - 94 DPR 309/90, art. 678 comma 1 ter cp.p.)', '0691', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0732', 'MACM', NULL, 'Conferma appl. provv. Affidamento in prova in prova con detenzione domiciliare (art.5 d.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', '0692', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0733', 'MACM', NULL, 'Conferma appl. provv. Detenzione Domiciliare (art.6 d.lgs. 121/2018 , art. 678 comma 1 ter cp.p.)', '0693', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0734', 'MACM', NULL, 'Conferma appl. provv. Semiliberta'' (art.7 d.lgs. 121/2018, art. 678 comma 1 ter cp.p.)', '0694', NULL, 'CONCUM', NULL);
INSERT INTO CG_REF_CODES VALUES ('MOTIVO_PROVVEDIMENTO', '0735', 'MACM', NULL, 'Conferma appl. provv. Sospensione dell''Esecuzione della Pena (Art. 90 DPR 309/90 - Art. 678 comma 1-ter c.p.p.)', '0695', NULL, 'CONCUM', NULL);

-- ESITO_TENORE (il valore rv_abbreviation si riferisce a quello delle tabelle ESITO_PROVVEDIMENTO e PESO_ESITO_TENORE!)
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0680', 'C050', '0270', 'Applica Provvisoriamente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0681', 'C050', '0002', 'Rigetta', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0682', 'C050', '0003', 'Dichiara l''Inammissibilita''', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0683', 'C050', '0004', 'Dichiara N.D.P. / N.L.P.', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0684', 'C050', '0005', 'Dichiara la Propria Incompetenza', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0685', 'C050', '0001', 'Concede', NULL, NULL, NULL, NULL);

INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0690', 'C051', '0270', 'Applica provvisoriamente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0691', 'C051', '0002', 'Rigetta', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0692', 'C051', '0003', 'Dichiara l''Inammissibilita''', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0693', 'C051', '0004', 'Dichiara N.D.P. / N.L.P.', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0694', 'C051', '0005', 'Dichiara la Propria Incompetenza', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0695', 'C051', '0001', 'Concede', NULL, NULL, NULL, NULL);

INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0700', 'MACA', '0271', 'Conferma Decisione del Magistrato Relatore', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_TENORE', '0702', 'MACM', '0271', 'Conferma Decisione del Magistrato Relatore', NULL, NULL, NULL, NULL);

-- ESITO_PROVVEDIMENTO
INSERT INTO CG_REF_CODES VALUES ('ESITO_PROVVEDIMENTO', '0270', NULL, NULL, 'Applica provvisoriamente ', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('ESITO_PROVVEDIMENTO', '0271', NULL, NULL, 'Conferma Decisione del Magistrato Relatore', NULL, NULL, NULL, NULL);
insert into CG_REF_CODES VALUES ('ESITO_PROVVEDIMENTO', '0610', null, null, 'Designa Magistrato art. 678 1-ter', null, null, null, null);

-- PESO_ESITO_TENORE
INSERT INTO CG_REF_CODES VALUES ('PESO_ESITO_TENORE', '0270', 'A01', NULL, 'Applica provvisoriamente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('PESO_ESITO_TENORE', '0271', 'A01', NULL, 'Conferma Decisione del Magistrato Relatore', NULL, NULL, NULL, NULL);

-- DETTAGLIO_MOTIVO
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0100', '0682', NULL, 'Detenzione Domiciliare Donna Incinta o Madre di Prole di Eta'' Inferiore Ad Anni Dieci con Lei Convivente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0101', '0682', NULL, 'Detenzione Domiciliare Padre, Esercente la Potesta'', di Prole di Eta'' Inferiore Ad Anni Dieci con Lui Convivente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0102', '0682', NULL, 'Detenzione Domiciliare Persona in Condizioni di Salute Particolarmente Gravi, Che Richiedano Costanti Contatti con i Presidi Sanitari Territoriali', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0103', '0682', NULL, 'Detenzione Domiciliare Persona di Eta'' Superiore a Sessanta Anni Se Inabile Anche Parzialmente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0104', '0682', NULL, 'Detenzione Domiciliare Persona Minore di Anni Ventuno per Comprovate Esigenze di Salute, di Studio, di Lavoro e di Famiglia', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0105', '0682', NULL, 'Detenzione Domiciliare (Art. 47 ter comma 1 bis O.P. - Art. 678 comma 1-ter c.p.p.)', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0106', '0682', NULL, 'Detenzione Domiciliare per Ultrasettantenni (Art. 47 ter comma 01 O.P. - Art. 678 comma 1-ter c.p.p.)', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0110', '0693', NULL, 'Detenzione Domiciliare Donna Incinta o Madre di Prole di Eta'' Inferiore Ad Anni Dieci con Lei Convivente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0111', '0693', NULL, 'Detenzione Domiciliare Padre, Esercente la Potesta'', di Prole di Eta'' Inferiore Ad Anni Dieci con Lui Convivente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0112', '0693', NULL, 'Detenzione Domiciliare Persona in Condizioni di Salute Particolarmente Gravi, Che Richiedano Costanti Contatti con i Presidi Sanitari Territoriali', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0114', '0693', NULL, 'Detenzione Domiciliare Persona Minore di Anni Ventuno per Comprovate Esigenze di Salute, di Studio, di Lavoro e di Famiglia', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0115', '0693', NULL, 'Detenzione Domiciliare (Art. 47 ter comma 1 bis O.P. - Art. 678 comma 1-ter c.p.p.)', NULL, NULL, NULL, NULL);
/*
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0113', '0692', NULL, 'Detenzione Domiciliare Persona di Eta'' Superiore a Sessanta Anni Se Inabile Anche Parzialmente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('DETTAGLIO_MOTIVO', '0116', '0692', NULL, 'Detenzione Domiciliare per Ultrasettantenni (Art. 47 ter comma 01 O.P. - Art. 678 comma 1-ter c.p.p.)', NULL, NULL, NULL, NULL);
*/

-- STATO_PROCEDIMENTO
INSERT INTO CG_REF_CODES VALUES ('STATO_PROCEDIMENTO', '0255', NULL, 'In esecuzione', 'Emesso Decreto Designazione', NULL, NULL, NULL, NULL);

-- CONTENUTO_ISTANZA
insert into CG_REF_CODES values ('CONTENUTO_ISTANZA', 'C050', null, null, 'Concessione Misure Alternative alla Detenzione (art. 678 comma 1 ter c.p.p.)', null, null, null, null);
insert into CG_REF_CODES values ('CONTENUTO_ISTANZA', 'C051', null, null, 'Concessione Misure Penali di Comunita'' / Misure Alternative alla Detenzione (art. 678 comma 1 ter c.p.p.)', null, null, null, null);

-- INSERIMENTO_MA
insert into CG_REF_CODES values ('INSERIMENTO_MA', 'C050', null, null, 'Concessione Misure Alternative alla Detenzione (art. 678 comma 1 ter c.p.p.)', null, null, null, null);
insert into CG_REF_CODES values ('INSERIMENTO_MA', 'C051', null, null, 'Concessione Misure Penali di Comunita'' / Misure Alternative alla Detenzione (art. 678 comma 1 ter c.p.p.)', null, null, null, null);
insert into CG_REF_CODES values ('INSERIMENTO_MA', 'MACA', null, null, 'Conferma Applicazione Provv Misure Alternative (art. 678 comma 1 ter c.p.p.)', null, null, null, null);
insert into CG_REF_CODES values ('INSERIMENTO_MA', 'MACM', null, null, 'Conferma Applicazione Provv Misure Penali di Comunita'' / Misure Alternative alla Detenzione (art. 678 comma 1 ter c.p.p.)', null, null, null, null);

-- MITTENTE_ATTO
insert into CG_REF_CODES values ('MITTENTE_ATTO', '35', null, null, 'Gruppo di Osservazione e Trattamento', null, null, null, null);

-- STATO_FASCICOLO
insert into CG_REF_CODES values ('STATO_FASCICOLO', '22', null, 'Utilizzato in SIUS a seguito designazione Magistrato Relatore per MA art. 678 c. 1-ter c.p.p.', 'Emesso Decreto Designazione', null, null, null, null);
INSERT INTO CG_REF_CODES VALUES ('STATO_FASCICOLO', '23', NULL, 'Utilizzato in SIUS a seguito restituzione atti art. 678 c. 1-ter c.p.p.', 'Restituiti Atti al Presidente', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('STATO_FASCICOLO', '24', NULL, 'Utilizzato in SIUS a seguito Emissione Ord. Appl. Provvisoria art. 678 c. 1-ter c.p.p.', 'Emessa Ordinanza Applicazione Provvisoria', NULL, NULL, NULL, NULL);

-- TIPO_DECRETO
insert into CG_REF_CODES values ('TIPO_DECRETO', 'DM', null, null, 'Decreto Designazione Magistrato Relatore per MA', null, null, null, null);

-- TIPO_ORDINANZA
INSERT INTO CG_REF_CODES VALUES ('TIPO_ORDINANZA', 'AM', NULL, NULL, 'Ordinanza Applicazione Provv. Misura D.Lgs. 123/2018', NULL, NULL, NULL, NULL);
INSERT INTO CG_REF_CODES VALUES ('TIPO_ORDINANZA', 'CM', NULL, NULL, 'Ordinanza Conferma Applicazione Provvisoria Misura D.Lgs. 123/2018', NULL, NULL, NULL, NULL);