-- FUNZIONE
insert into FUNZIONE values
 (90111917, 'Designazione Magistrato Relatore', 'R', null);
insert into FUNZIONE values
 (90111918, 'Designazione Magistrato Relatore', 'R', 'siap.sius.depositodecreto.action.ActLoadFSPDesignazioneMagistratoRelatore');
insert into FUNZIONE values
 (90111919, 'Conferma Decisione Magistrato Relatore', 'R', 'siap.sius.depositoordinanzapc.action.ActLoadFSPConfermaDecisioneMagistratoRelatore');
insert into FUNZIONE values
 (90111920, 'Carica Designazione Magistrato Relatore', 'I', 'siap.sius.depositodecreto.action.ActLoadInserisciDesignazioneMagistratoRelatore');
insert into FUNZIONE values
 (90111921, 'Carica Conferma Decisione Magistrato Relatore', 'I', 'siap.sius.depositoordinanzapc.action.ActLoadInserisciConfermaDecisioneMagistratoRelatore');
insert into FUNZIONE values
 (90111922, 'Carica Dettaglio Designazione Magistrato Relatore', 'D', 'siap.sius.depositodecreto.action.ActLoadDettaglioDesignazioneMagistratoRelatore');
insert into FUNZIONE values
 (90111924, 'Inserisci Designazione Magistrato Relatore', 'I', 'siap.sius.depositodecreto.action.ActInserisciDesignazioneMagistratoRelatore');
insert into FUNZIONE values
 (90111926, 'Stampa Dettaglio Designazione Magistrato Relatore', 'S', 'siap.sius.depositodecreto.action.ActStampaDesignazioneMagistratoRelatore'); 
insert into FUNZIONE values
 (90111928, 'Applicazione Provvisoria M.A. - Conferma Decisione Magistrato Relatore', 'R', null);
insert into FUNZIONE values
 (90111929, 'Applicazione Provvisoria M.A.', 'R', 'siap.sius.depositoordinanzapc.action.ActLoadFSPApplicazioneProvvisoriaMA');
INSERT INTO FUNZIONE VALUES 
 (90111931, 'Applicazione Provvisoria M.A.', 'I', 'siap.sius.depositoordinanzapc.action.ActLoadEmissioneApplicazioneProvvisoriaMA');
insert into FUNZIONE values
 (90111932, 'Carica Modifica Designazione Magistrato Relatore', 'L', 'siap.sius.depositodecreto.action.ActLoadModificaDesignazioneMagistratoRelatore');
insert into FUNZIONE values
 (90111933, 'Modifica Designazione Magistrato Relatore', 'M', 'siap.sius.depositodecreto.action.ActModificaDesignazioneMagistratoRelatore');
insert into FUNZIONE values
 (90111934, 'Carica Applicazione Provvisoria M.A.', 'I', 'siap.sius.depositoordinanzapc.action.ActLoadInserisciApplicazioneProvvisoriaMA');
insert into FUNZIONE values
 (90111935, 'Load Gestione Restituzione Atti al Presidente', 'D', 'siap.sius.fascicolo.action.ActLoadGestioneRestituzioneAttiPresidente');
insert into FUNZIONE values
 (90111936, 'Cancella Restituzione Atti al Presidente', 'C', 'siap.sius.fascicolo.action.ActCancellaRestituzioneAttiPresidente');
insert into FUNZIONE values
 (90111937, 'Load Modifica Restituzione Atti al Presidente', 'L', 'siap.sius.fascicolo.action.ActLoadModificaRestituzioneAttiPresidente');
insert into FUNZIONE values
 (90111938, 'Modifica Restituzione Atti al Presidente', 'M', 'siap.sius.fascicolo.action.ActModificaRestituzioneAttiPresidente');
insert into FUNZIONE values
 (90111939, 'Load Registrazione Esecutività Applicazione Provvisoria M.A.', 'I', 'siap.sius.fascicolo.action.ActLoadRegistrazioneEsecutivitaApplicazioneProvvisoriaMA');
insert into FUNZIONE values
 (90111950, 'Registrazione Esecutività Applicazione Provvisoria M.A.', 'I', 'siap.sius.fascicolo.action.ActRegistrazioneEsecutivitaApplicazioneProvvisoriaMA');
INSERT INTO FUNZIONE VALUES
 (38105000, 'Monitoraggio Misure Alternative (art. 678 comma 1-ter c.p.p.)', 'A', 'siap.sius.statistiche.action.ActLoadRicercaStatisticaMisureAlter678c1tercpp');
INSERT INTO FUNZIONE VALUES
 (38105001, 'Ricerca Procedimenti Misure Alternative (art. 678 comma 1-ter c.p.p.)', 'R', 'siap.sius.statistiche.action.ActRicercaStatisticaMisureAlter678c1tercpp');
INSERT INTO FUNZIONE VALUES
 (38105002, 'Ricerca Procedimenti Misure Alternative (art. 678 comma 1-ter c.p.p.) Excel', 'R', 'siap.sius.statistiche.action.ActRicercaStatisticaMisureAlter678c1tercppExcel');
INSERT INTO FUNZIONE VALUES
 (38105003, 'Stampa Ricerca Procedimenti Misure Alternative (art. 678 comma 1-ter c.p.p.) Excel', 'R', 'siap.sius.statistiche.util.excel.ProcPerStatisticaMisureAlternativeExcel');
INSERT INTO FUNZIONE VALUES
 (38101044, 'Ricerca Atti istruttori con data restituzione', 'R', 'siap.sius.statistiche.action.ActLoadRicercaAttiIstruttoriDataRest');
INSERT INTO FUNZIONE VALUES
 (38101045, 'Ricerca Atti istruttori con data restituzione', 'R', 'siap.sius.statistiche.action.ActRicercaAttiIstruttoriDataRest');
INSERT INTO FUNZIONE VALUES
 (38101046, 'Stampa Excel Ricerca Atti istruttori con data restituzione', 'R', 'siap.sius.statistiche.action.ActRicercaAttiIstruttoriDataRestExcel');