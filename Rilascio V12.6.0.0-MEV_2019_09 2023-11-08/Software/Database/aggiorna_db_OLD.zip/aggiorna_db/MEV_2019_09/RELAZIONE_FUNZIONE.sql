-- RELAZIONE_FUNZIONE
insert into RELAZIONE_FUNZIONE values
 (10538, 90111917, 'ME', 'Designazione Magistrato Relatore', 5, null);
insert into RELAZIONE_FUNZIONE values
 (90111917, 90111918, 'ME', 'Designazione Magistrato Relatore', 1, null);
insert into RELAZIONE_FUNZIONE values
 (90111922, 90111926, 'BO', 'Stampa Designazione Magistrato Relatore', 1, null);
insert into RELAZIONE_FUNZIONE values
 (10816, 90111928, 'ME', 'Applicazione Provvisoria M.A. - Conferma Decisione Magistrato Relatore', 3, null);
insert into RELAZIONE_FUNZIONE values
 (90111928, 90111919, 'ME', 'Conferma Decisione Magistrato Relatore', 2, null);
insert into RELAZIONE_FUNZIONE values
 (90111928, 90111929, 'ME', 'Applicazione Provvisoria M.A.', 1, null);
insert into RELAZIONE_FUNZIONE values
 (10569, 90111935, 'CO', 'Gestione Restituzione Atti al Presidente', 46, null);
insert into RELAZIONE_FUNZIONE values
 (10569, 90111939, 'CO', 'Esecutivita'' Ordinanza Applicazione Provvisoria M.A.', 47, null);
insert into RELAZIONE_FUNZIONE values
 (90111950, 10707, 'BO', 'Stampa Data Esecutivita'' Ordinanza Applicazione Provvisoria M.A.', 1, null);
INSERT INTO RELAZIONE_FUNZIONE VALUES
 (38100000, 38105000, 'ME', 'Monitoraggio Misure Alternative (art. 678 comma 1-ter c.p.p.)', 5, NULL);
INSERT INTO RELAZIONE_FUNZIONE VALUES
 (38101000, 38101044, 'BO', 'Atti istruttori con data restituzione', 15, NULL);

/* update RELAZIONE_FUNZIONE r set r.ordine_visualizzazione = 3
 where r.fun_id_funzione = 10816 and r.fun_id_funzione_figlia = 31130620 and r.ordine_visualizzazione = 2; */
update RELAZIONE_FUNZIONE r set r.ordine_visualizzazione = 4
 where r.fun_id_funzione = 10816 and r.fun_id_funzione_figlia = 31130820 and r.ordine_visualizzazione = 3;
update RELAZIONE_FUNZIONE r set r.ordine_visualizzazione = 5
 where r.fun_id_funzione = 10816 and r.fun_id_funzione_figlia = 10813 and r.ordine_visualizzazione = 4;
update RELAZIONE_FUNZIONE r set r.ordine_visualizzazione = 6
 where r.fun_id_funzione = 10816 and r.fun_id_funzione_figlia = 31130591 and r.ordine_visualizzazione = 5;
update RELAZIONE_FUNZIONE r set r.ordine_visualizzazione = 7
 where r.fun_id_funzione = 10816 and r.fun_id_funzione_figlia = 10805 and r.ordine_visualizzazione = 6;

-- LEGENDA:
-- 	10538		Decreti												I
-- 	10816		Ordinanze											I
-- 	10569		Visualizza dettaglio Fascicolo SIUS					D	siap.sius.fascicolo.action.ActLoadDettaglioFascicolo
-- 	10707		Stampa Ordinanza Affidamento						S	siap.sius.depositoordinanzapc.action.ActStampaEmissioneOrdinanza
-- 	31130620	Load Ricerca Fascicolo SIUS per Ins. Data Deposito	R	siap.sius.depositoordinanzapc.action.ActLoadFSPInserisciDataDeposito
-- 	31130820	Ricerca Procedimento per Rimessione 				I	siap.sius.depositoordinanzapc.action.ActLoadFSPRimessioneAtti
-- 	10813		Ricerca Fascicolo SIUS per Modelli Ordinanza		R	siap.sius.depositoordinanzapc.action.ActLoadFSPModelliOrdinanza
-- 	31130591	Load Ricerca Provvedimenti per Fascicolo SIUS		R	siap.sius.provvedimento.action.ActLoadRicercaFSProvvedimenti
--	10805		Load Ricerca Fascicolo per Notifica Provvedimenti	R	siap.sius.provvedimento.action.ActLoadRicercaFSPNotifica
--  38100000	Statistiche/monitoraggio							R