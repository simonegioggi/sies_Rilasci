insert into ISP_ESITO_PROVVEDIMENTO values ('0270', '9', 'Applica provvisoriamente', 'Accolto');
insert into ISP_ESITO_PROVVEDIMENTO values ('0271', '1', 'Conferma Decisione del Magistrato Relatore', 'Accolto');
insert into ISP_ESITO_PROVVEDIMENTO values ('0610', '6', 'Magistrato Designato art. 678 1-ter', 'Altra Definizione');
