CREATE OR REPLACE PACKAGE BODY ISPETTORATO_SIUS IS

  -- Ultima modifica 21/05/2014

  -- Ultima modifica Correzione: modificata ricercaDateUdienza() 5-02-2008 . Luigi
  -- Ultima modifica 06-02-2008 . Luigi
  -- Ultima modifica 07-02-2008 . Luigi
  -- Descrizione: modificata analisiFascicoliDefiniti() e
  -- Ultima modifica 08-02-2008 . Luigi
  -- Descrizione: aggiunta l'estrazione dei campi COD_POSIZIONE_GIURIDICA e TIPO_DEFINIZIONE da GENERALE_PROCEDIMENTO.
  -- Ultima modifica 13-02-2008 . Luigi
  -- Descrizione: Inserimento di funzioni di apertura cursore tramite REF CURSOR.
  -- Ultima modifica 15-02-2008 . Luigi
  -- Descrizione: gestione del filtro su Cancelleria Assegnataria nelle funzioni di estrazione
  -- Ultima modifica 18/02/2008
  -- Ultima modifica 19-02-2008 . Luigi
  -- Descrizione: ricercaDateUdienza() viene letta la data Udienza non quella di Inserimento Udienza.
  -- Ultima modifica 20-02-2008 . Luigi
  -- Descrizione: select dinamica nei cursori sui fascicoli
  -- Ultima modifica 22-02-2008 . Luigi
  -- Descrizione: filtro su collaboratore di giustizia
  -- Ultima modifica 21-04-2008 . Luigi
  -- Descrizione: Modificati tutti i confronti tra date usando la funzione trunc() per troncare le date in tabella.
  -- Ultima modifica 12-06-2008 . Luigi
  -- Descrizione: Segnalazione discrepanza tra "pendenti fine periodo" e "pendenti inizio periodo" nel periodo immediatamente successivo.
  --   Modificati il CURSOR  curTuttiTenoriFascicolo () ed il CURSOR curAltriTenori ()
  --   eliminando la condizione di  data_inserimento < data_fine.
  --   In questo modo vengono sempre selezionati tutti i tenori indipendentemente dalla loro data di inserimento.
  -- Ultima modifica 20-06-2008 . Luigi
  -- Descrizione: Nell''estrazione dei Fascicoli 'iscritti' e 'definiti' viene inserito il COD_MAGISTRATO  che prima rimaneva null.
  --  Si � aggiunta la funzione getCodMagistratoRelatore(...) che ricava il cod del Magistrato Relatore "attivo in quel momento"per il fascicolo.
  -- Questa nuova funzione viene richiamata da analisiFascicoliIscritti() e analisiFascicoliDefiniti() per determinare il COD_MAGISTRATO
  -- da inserire nella tabella ISP_ESTRAZIONE_OGGETTI_TRIB.
  --
  -- Ultima modifica: 25-07-2008    UMBERTO
  -- Nell'estrazione dei provvedimenti definiti e depositati vengono scartati i provvedimenti di decreto irreperibilit� (0602),
  -- decreto fissazione udienza (0601), ordinanza di rinvio (0602); viene inoltre controllato che flag_documento_registrato dell'evento sia ='S'.
  --
  -- Sulla selezione della data udienza viene aggiunto lo stato del FLAG_RINVIATA = 'M' e vengono inoltre selezionati i record Udienza_procedimento,
  -- che oltre ad avere i valori di flag_rinviata = 'P','F','R','M' abbia eve_id_evento valorizzato

  -- Private type declarations
  -- type <TypeName> is <Datatype>;

  -- Private constant declarations
  -- <ConstantName> constant <Datatype> := <Value>;

  /*
    Cursore sulla CG_REF_CODES utilizzato
   per ottenere l'elenco degli oggetti e relativo contenuto
  */
  /*CURSOR  curDecodificaOggetti
  IS SELECT RV_LOW_VALUE, RV_MEANING, RV_HIGH_VALUE
  FROM CG_REF_CODES WHERE RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO';*/
  /* Solo Oggetti Estratti (Att. Uffici) - modificato da michele (30/03/2010)*/

  PAR_MPCOD   VARCHAR(4);
  PAR_MPDESC  VARCHAR2(200);
  PAR_OPCOD   VARCHAR2(4);
  PAR_OPDESC  VARCHAR2(200);
  PAR_TIPOUFF VARCHAR2(3);

  CURSOR CURMOTIVOOGGETTO IS
    SELECT MP.RV_LOW_VALUE,
           MP.RV_MEANING,
           OP.RV_LOW_VALUE,
           OP.RV_MEANING,
           SUBSTR(OP.RV_LOW_VALUE, 1, 1)
      FROM CG_REF_CODES MP, CG_REF_CODES OP
     WHERE (MP.RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO' AND
           (MP.RV_HIGH_VALUE LIKE 'C%' OR MP.RV_HIGH_VALUE LIKE 'U%' OR MP.RV_HIGH_VALUE LIKE 'M%'))
       AND (OP.RV_DOMAIN = 'OGGETTO_PROCEDIMENTO' AND
           OP.RV_LOW_VALUE = MP.RV_HIGH_VALUE)
     ORDER BY MP.RV_MEANING;

  CURSOR CURDECODIFICAOGGETTI(PAR_UFFICIO IN VARCHAR2) IS
    SELECT RV_LOW_VALUE, RV_MEANING, RV_HIGH_VALUE
      FROM CG_REF_CODES
     WHERE RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO'
       AND RV_LOW_VALUE IN
           (SELECT DISTINCT COD_OGGETTO_TENORE
              FROM ISP_ESTRAZIONE_OGGETTI_TRIB);

  /*
       Cursore per la ricerca dei cod_oggetti di tutti i
    tenori collegati al GENERALE_PROCEDIMENTO
    ed inseriti prima della fine del periodo osservato
  */
  CURSOR CURTUTTITENORIFASCICOLO(PAR_ID_GEN_PROCEDURE IN NUMBER,
                                 PAR_DATA_FINE        IN VARCHAR2) IS
    SELECT DISTINCT COD_OGGETTO_TENORE
      FROM TENORE
     WHERE GEN_PRID_GENERALE_PROCEDIMENTO = PAR_ID_GEN_PROCEDURE
       AND TRUNC(DATA_INSERIMENTO, 'dd') <=
           TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy');

  -- Cursore per la ricerca dei Tenori collegati ad uno specifico decreto
  CURSOR CURTENORIXDECRETOOLD(PAR_ID_DEPOSITO_DECRETO IN NUMBER) IS
    SELECT *
      FROM TENORE
     WHERE TENORE.DEP_DEC_ID_DEPOSITO_DECRETO = PAR_ID_DEPOSITO_DECRETO;

  CURSOR CURTENORIXDECRETO(PAR_ID_DEPOSITO_DECRETO IN NUMBER) IS
    SELECT COD_OGGETTO_TENORE,
           MIN(COD_ESITO_TENORE) COD_ESITO_TENORE,
           MIN(DATA) DATA,
           MIN(DEP_OPID_DEPOSITO_ORDINANZA_PC) DEP_OPID_DEPOSITO_ORDINANZA_PC,
           MIN(DEP_DEC_ID_DEPOSITO_DECRETO) DEP_DEC_ID_DEPOSITO_DECRETO,
           MIN(DATA_INSERIMENTO) DATA_INSERIMENTO,
           MIN(DATA_FINE) DATA_FINE,
           MIN(COD_MAGISTRATO) COD_MAGISTRATO,
           --bvn
           MIN(DEP_ID_DEPOSITO_SENTENZA) DEP_ID_DEPOSITO_SENTENZA
    --fine bvn
      FROM TENORE
     WHERE TENORE.DEP_DEC_ID_DEPOSITO_DECRETO = PAR_ID_DEPOSITO_DECRETO
     GROUP BY COD_OGGETTO_TENORE;

  -- Cursore per la ricerca dei Tenori collegati ad una specifica ordinanza
  CURSOR CURTENORIXORDINANZAOLD(PAR_ID_DEPOSITO_ORDINANZA_PC IN NUMBER) IS
    SELECT *
      FROM TENORE
     WHERE TENORE.DEP_OPID_DEPOSITO_ORDINANZA_PC =
           PAR_ID_DEPOSITO_ORDINANZA_PC;

  CURSOR CURTENORIXORDINANZA(PAR_ID_DEPOSITO_ORDINANZA_PC IN NUMBER) IS
    SELECT COD_OGGETTO_TENORE,
           MIN(COD_ESITO_TENORE) COD_ESITO_TENORE,
           MIN(DATA) DATA,
           MIN(DEP_OPID_DEPOSITO_ORDINANZA_PC) DEP_OPID_DEPOSITO_ORDINANZA_PC,
           MIN(DEP_DEC_ID_DEPOSITO_DECRETO) DEP_DEC_ID_DEPOSITO_DECRETO,
           MIN(DATA_INSERIMENTO) DATA_INSERIMENTO,
           MIN(DATA_FINE) DATA_FINE,
           MIN(COD_MAGISTRATO) COD_MAGISTRATO,
           --bvn
           MIN(DEP_ID_DEPOSITO_SENTENZA) DEP_ID_DEPOSITO_SENTENZA
    --fine bvn
      FROM TENORE
     WHERE TENORE.DEP_OPID_DEPOSITO_ORDINANZA_PC =
           PAR_ID_DEPOSITO_ORDINANZA_PC
     GROUP BY COD_OGGETTO_TENORE;

  --bvn 31/03/2015
  CURSOR CURTENORIXSENTENZAOLD(PAR_ID_DEPOSITO_SENTENZA IN NUMBER) IS
    SELECT *
      FROM TENORE
     WHERE TENORE.DEP_ID_DEPOSITO_SENTENZA = PAR_ID_DEPOSITO_SENTENZA;

  CURSOR CURTENORIXSENTENZA(PAR_ID_DEPOSITO_SENTENZA IN NUMBER) IS
    SELECT COD_OGGETTO_TENORE,
           MIN(COD_ESITO_TENORE) COD_ESITO_TENORE,
           MIN(DATA) DATA,
           MIN(DEP_OPID_DEPOSITO_ORDINANZA_PC) DEP_OPID_DEPOSITO_ORDINANZA_PC,
           MIN(DEP_DEC_ID_DEPOSITO_DECRETO) DEP_DEC_ID_DEPOSITO_DECRETO,
           MIN(DATA_INSERIMENTO) DATA_INSERIMENTO,
           MIN(DATA_FINE) DATA_FINE,
           MIN(COD_MAGISTRATO) COD_MAGISTRATO,
           MIN(DEP_ID_DEPOSITO_SENTENZA) DEP_ID_DEPOSITO_SENTENZA
      FROM TENORE
     WHERE TENORE.DEP_ID_DEPOSITO_SENTENZA = PAR_ID_DEPOSITO_SENTENZA
     GROUP BY COD_OGGETTO_TENORE;
  --fine bvn

  -- Definizione del tipo riferimento al cursore variabile utilizzato sulla ricerca Fascicoli
  TYPE CURFASCTYPE IS REF CURSOR;

  /*
      Funzione di inizializzazione per la cancellazione delle tabelle
      utilizzate per le Statistiche Oggetti.
  */
  PROCEDURE INIZIALIZZA(PAR_UFFICIO_INI IN VARCHAR2) IS
  BEGIN
    -- Cancellazione tabelle di appoggio (mod. da michele 25/11/2008)
    DELETE FROM STATIS.ISP_ESTRAZIONE_OGGETTI_TRIB
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO_INI;
    DELETE FROM ISP_CONTEGGIO_OGGETTI
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO_INI;
    DELETE FROM ISP_MOTIVO_OGGETTO;

    OPEN CURMOTIVOOGGETTO;
    LOOP
      FETCH CURMOTIVOOGGETTO
        INTO PAR_MPCOD, PAR_MPDESC, PAR_OPCOD, PAR_OPDESC, PAR_TIPOUFF;
      EXIT WHEN CURMOTIVOOGGETTO%NOTFOUND;
      -- DBMS_OUTPUT.PUT_LINE('INIZIALIZZA ' || PAR_MPCOD);
      -- Inserimento
      -- modificato da Michele 25/11/2008
      IF PAR_TIPOUFF = 'C' THEN
        PAR_TIPOUFF := 'TDS';
      ELSE
        PAR_TIPOUFF := 'UDS';
      END IF;

      INSERT INTO ISP_MOTIVO_OGGETTO
        (COD_MOTIVO, DESC_MOTIVO, COD_OGGETTO, DESC_OGGETTO, TIPO_UFFICIO)
      VALUES
        (PAR_MPCOD, PAR_MPDESC, PAR_OPCOD, PAR_OPDESC, PAR_TIPOUFF);

    END LOOP;

    CLOSE CURMOTIVOOGGETTO;

  END INIZIALIZZA;

  /*
    La funzione ritorna null se c'� almeno una occorrenza null per l'oggetto_tenore
    relativo all'id procedimento
  */
  FUNCTION DATAFINETENOREFASCICOLO(PAR_ID_GEN_PROCEDURE   IN NUMBER,
                                   PAR_COD_OGGETTO_TENORE IN VARCHAR2)
    RETURN DATE IS

    CURSOR CURDATAFINETENOREFASCICOLO IS
      SELECT DATA_FINE
        FROM TENORE
       WHERE GEN_PRID_GENERALE_PROCEDIMENTO = PAR_ID_GEN_PROCEDURE
         AND COD_OGGETTO_TENORE = PAR_COD_OGGETTO_TENORE
       ORDER BY DATA_FINE DESC;

    DATAFINE DATE;

  BEGIN

    OPEN CURDATAFINETENOREFASCICOLO;
    LOOP
      FETCH CURDATAFINETENOREFASCICOLO
        INTO DATAFINE;
      DBMS_OUTPUT.PUT_LINE('GEN_PRID_GENERALE_PROCEDIMENTO ' ||
                           PAR_ID_GEN_PROCEDURE);
      DBMS_OUTPUT.PUT_LINE('COD_OGGETTO_TENORE ' || PAR_COD_OGGETTO_TENORE);
      DBMS_OUTPUT.PUT_LINE('DATA_FINE ' || DATAFINE);
      IF DATAFINE IS NULL THEN
        RETURN DATAFINE;
      END IF;
      IF CURDATAFINETENOREFASCICOLO%NOTFOUND THEN
        EXIT;
      END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('USCITA ');
    DBMS_OUTPUT.PUT_LINE('GEN_PRID_GENERALE_PROCEDIMENTO ' ||
                         PAR_ID_GEN_PROCEDURE);
    DBMS_OUTPUT.PUT_LINE('COD_OGGETTO_TENORE ' || PAR_COD_OGGETTO_TENORE);
    DBMS_OUTPUT.PUT_LINE('DATA_FINE ' || DATAFINE);
    RETURN DATAFINE;

  END DATAFINETENOREFASCICOLO;

  /*
    La funzione ritorna null se c'� almeno una occorrenza null per l'oggetto_tenore
    relativo all'id procedimento
  */
  FUNCTION GETDATAINSTENORE(PAR_ID_GEN_PROCEDURE   IN NUMBER,
                            PAR_COD_OGGETTO_TENORE IN VARCHAR2) RETURN DATE IS

    RETVALUE     DATE;
    DATAISCRFASC DATE;

  BEGIN
    SELECT FS.DATA_ISCRIZIONE
      INTO DATAISCRFASC
      FROM GENERALE_PROCEDIMENTO GP, FASCICOLO_SIUS FS
     WHERE GP.ID_GENERALE_PROCEDIMENTO = PAR_ID_GEN_PROCEDURE
       AND FS.ID_FASCICOLO_SIUS = GP.FAS_SIU_ID_FASCICOLO_SIUS;

    SELECT MIN(DATA_INSERIMENTO)
      INTO RETVALUE
      FROM TENORE
     WHERE GEN_PRID_GENERALE_PROCEDIMENTO = PAR_ID_GEN_PROCEDURE
       AND COD_OGGETTO_TENORE = PAR_COD_OGGETTO_TENORE;

    IF (RETVALUE < DATAISCRFASC) THEN
      RETURN DATAISCRFASC;
    END IF;
    RETURN RETVALUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        RETVALUE := NULL;
        RETURN RETVALUE;
      END;
  END GETDATAINSTENORE;

  /*
    La funzione valuta se l'ogetto estratto risulta definito nel perodo di riferimento.
     Poich� l'ogetto estratto ha la data di definizione (deposito) >= della data di inizio
     occorre solo valutare se la data in questione � <= della data di fine.
     Se tale condizione � soddisfatta il provvedimento � stato depositato in data
    utile e quindi il flag DEFINITO assumer� valore 'S' nella tabella di estrazione.
  */
  FUNCTION DEFINITONELPERIODO(PAR_DATA_DEFINIZIONE DATE,
                              PAR_DATA_FINE        VARCHAR2) RETURN VARCHAR2 IS

  BEGIN
    IF (TRUNC(PAR_DATA_DEFINIZIONE, 'dd') <=
       TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')) THEN
      RETURN 'S';
    END IF;
    RETURN 'N';

  END DEFINITONELPERIODO;

  /*
       La funzione classifica il codice contenuto nel Contenuto Statistico
       utilizzando la tabella di trascodifica ISP_OGGETTO_PROCEDIMENTO.
  */
  FUNCTION CODCONTENUTOSTATISTICO(PAR_COD_CONTENUTO IN VARCHAR2)
    RETURN VARCHAR IS

    RETVALUE VARCHAR(20);

  BEGIN
    SELECT ISP_COD_OGGETTO_PROCEDIMENTO
      INTO RETVALUE
      FROM ISP_OGGETTO_PROCEDIMENTO
     WHERE COD_OGGETTO_PROCEDIMENTO = PAR_COD_CONTENUTO;

    RETURN RETVALUE;

    -- Eccezione gestisce il caso in cui non venga trovato in tabella il COD_OGGETTO_PROCEDIMENTO
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND ');

        RETVALUE := '-';
        RETURN RETVALUE;
      END;
  END CODCONTENUTOSTATISTICO;

  /*
      La funzione trascodifica il cod esito tenore in cod esito statistico
      utilizzando  la tabella di trascodifica ISP_COD_ESITO_PROVVEDIMENTO
  */
  FUNCTION CODESITOSTATDATENORE(PAR_COD_ESITO_TENORE IN VARCHAR2)
    RETURN VARCHAR IS

    -- codice dell'Esito secondo la classificazione statistica
    RETVALUE VARCHAR(4) := '';

  BEGIN

    DBMS_OUTPUT.PUT_LINE('Cod Esito Tenore ' || PAR_COD_ESITO_TENORE);

    SELECT ISP_COD_ESITO_PROVVEDIMENTO
      INTO RETVALUE
      FROM ISP_ESITO_PROVVEDIMENTO
     WHERE COD_ESITO_PROVVEDIMENTO = PAR_COD_ESITO_TENORE;

    DBMS_OUTPUT.PUT_LINE('Cod Esito Statistica ' || RETVALUE);
    RETURN RETVALUE;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        DBMS_OUTPUT.PUT_LINE('Cod Esito Statistica NO_DATA_FOUND ');

        RETVALUE := '-';
        RETURN RETVALUE;
      END;

  END CODESITOSTATDATENORE;

  /*
  La funzione ritorna il Contenuto Statistico a
  partire dal Cod Oggetto Tenore.
  */
  FUNCTION CODOGGETTOSTATDATENORE(PAR_COD_OGGETTO_TENORE IN VARCHAR2)
    RETURN VARCHAR IS

    CODAPPOGGIO VARCHAR2(4);

  BEGIN

    DBMS_OUTPUT.PUT_LINE('Cod Oggetto Tenore ' || PAR_COD_OGGETTO_TENORE);

    SELECT RV_HIGH_VALUE
      INTO CODAPPOGGIO
      FROM CG_REF_CODES
     WHERE RV_LOW_VALUE = PAR_COD_OGGETTO_TENORE
       AND RV_DOMAIN = 'MOTIVO_PROVVEDIMENTO';

    DBMS_OUTPUT.PUT_LINE('Cod Contenuto ' || CODAPPOGGIO);

    RETURN CODCONTENUTOSTATISTICO(CODAPPOGGIO);

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        DBMS_OUTPUT.PUT_LINE('NO_DATA_FOUND Contenuto Tenore ');
        RETURN '-';
      END;

  END CODOGGETTOSTATDATENORE;

  /*
  La funzione in base al parametro par_collaboratore pu� aggiunge alla select utilizzata nella ricerca fascicoli
  passata come primo parametro la condizione sul Collaboratore di Giustizia.
  La funzione � utilizzata dalle analisiFascicoliIscritti(), analisiFascicoliDepositati(),
  analisiFascicoliDefiniti().
  */

  PROCEDURE FILTROCOLLAB(PAR_SELECT        IN OUT VARCHAR2,
                         PAR_COLLABORATORE IN VARCHAR2) IS

  BEGIN
    IF (PAR_COLLABORATORE = 'SI') THEN
      PAR_SELECT := PAR_SELECT ||
                    ' and  COLLA.COLL.isCollab(f.chiave_ufficio, f.id_fascicolo_sius) > 0';
    ELSIF (PAR_COLLABORATORE = 'NO') THEN
      PAR_SELECT := PAR_SELECT ||
                    ' and  COLLA.COLL.isCollab(f.chiave_ufficio, f.id_fascicolo_sius) = 0';
    END IF;
  END FILTROCOLLAB;

  /*
  La funzione come la precedente aggiunge una condizione di filtro sulla select passata.
   Se il secondo parametro non � null viene aggiunta alla select utilizzata nella ricerca fascicoli
  la condizione di essere assegnati alla Cancelleria Assegnataria individuata dal parametro.
  La funzione � utilizzata dalle analisiFascicoliIscritti(), analisiFascicoliDepositati(),
  analisiFascicoliDefiniti(), estraiProcedimentiDepositati().
  */

  PROCEDURE FILTROCANCELLERIA(PAR_SELECT      IN OUT VARCHAR2,
                              PAR_CANCELLERIA IN VARCHAR2) IS

  BEGIN
    IF (PAR_CANCELLERIA IS NOT NULL) THEN
      PAR_SELECT := PAR_SELECT || ' and f.id_fascicolo_sius IN' ||
                    ' (SELECT FAS_SIUS_ID_FASCICOLO_SIUS FROM CANC_ASS_FASC_SIUS' ||
                    ' WHERE COD_CANCELLERIA_ASSEGNATARIA = :par_cancelleria)';
    END IF;

  END FILTROCANCELLERIA;

  /*
  La funzione come la precedente aggiunge una condizione di filtro sulla select passata.
  Se il secondo parametro non � null viene aggiunta alla select utilizzata nella ricerca fascicoli
  la condizione di essere relativi alla Posizione Giuridica individuata dal parametro.
  La funzione � utilizzata dalle analisiFascicoliIscritti(), analisiFascicoliDepositati(),
  analisiFascicoliDefiniti(), estraiProcedimentiDepositati().
  */

  PROCEDURE FILTROPOSIZIONEGIURIDICA(PAR_SELECT        IN OUT VARCHAR2,
                                     PAR_POS_GIURIDICA IN VARCHAR2) IS

  BEGIN
    IF (PAR_POS_GIURIDICA <> 'tutti') THEN
      PAR_SELECT := PAR_SELECT || ' and g.cod_posizione_giuridica IN' ||
                    ' (SELECT COD_POSIZIONE_GIURIDICA FROM ISP_POSIZIONE_GIURIDICA' ||
                    ' WHERE ISP_DESCR_POSIZIONE_GIURIDICA = :par_pos_giuridica)';
    END IF;

  END FILTROPOSIZIONEGIURIDICA;

  /*
    Luigi 19-06-2008
       La funzione restituisce il codice del Magistrato Relatore attuale di un Fascicolo SIUS.
       Se il magistrato non esiste la funzione restituisce null.
  */
  FUNCTION GETCODMAGISTRATORELATORE(PAR_ID_FASCICOLO IN NUMBER)
    RETURN VARCHAR IS

    RETVALUE VARCHAR(20);

  BEGIN
    --inserita distinct bvn - per risolvere anomalia n. 2 plo mev 55
    SELECT distinct MAG_COD_MAGISTRATO
      INTO RETVALUE
      FROM MAGISTRATO_RELATORE
     WHERE FAS_SIU_ID_FASCICOLO_SIUS = PAR_ID_FASCICOLO
       AND DATA_FINE IS NULL;

    -- Il COD Magistrato � lungo 6 caratteri
    IF (LENGTH(RETVALUE) < 2) THEN
      RETVALUE := NULL;
    END IF;

    -- dbms_output.put_line ('Cod Magistrato Relatore '|| retValue);
    -- dbms_output.put_line ('Per il Fascicolo SIUS ->'|| par_id_fascicolo);
    RETURN RETVALUE;

    -- Eccezione gestisce il caso in cui non venga trovato alcun record
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        RETVALUE := NULL;
        RETURN RETVALUE;
      END;
  END GETCODMAGISTRATORELATORE;

  /*
    La funzione restituisce l' identificativo dell' Esperto Relatore attuale di un Fascicolo SIUS.
       Se l' esperto non esiste la funzione restituisce null.
  */
  FUNCTION GETIDESPERTORELATORE(PAR_ID_FASCICOLO IN NUMBER) RETURN VARCHAR IS

    RETVALUE VARCHAR(20);

  BEGIN
    SELECT TO_CHAR(ESP_ID_ESPERTO) || ' (ESPERTO)'
      INTO RETVALUE
      FROM MAGISTRATO_RELATORE
     WHERE FAS_SIU_ID_FASCICOLO_SIUS = PAR_ID_FASCICOLO
       AND ESP_ID_ESPERTO IS NOT NULL
       AND DATA_FINE IS NULL;

    -- Il COD Magistrato � lungo 6 caratteri
     if (length(retValue) < 2 ) then
         retValue := null;
     end if;

    -- dbms_output.put_line ('Cod Magistrato Relatore '|| retValue);
    -- dbms_output.put_line ('Per il Fascicolo SIUS ->'|| par_id_fascicolo);
    RETURN RETVALUE;

    -- Eccezione gestisce il caso in cui non venga trovato alcun record
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      BEGIN
        RETVALUE := NULL;
        RETURN RETVALUE;
      END;
  END GETIDESPERTORELATORE;

  /*
    Ricerca Fascicoli in stato Iscritto.
    Vengono selezionati tutti i fascicoli con stato = '02'
    e data di iscrizione antecedente la data di fine.
    Per ognuno di questi si cercano i tenori collegati che vengono
    inseriti nella tabella di estrazione ISP_ESTRAZIONE_OGGETTI_TRIB.
  */
  PROCEDURE ANALISIFASCICOLIISCRITTI(PAR_UFFICIO             IN VARCHAR2,
                                     PAR_DATA_FINE           IN VARCHAR2,
                                     PAR_CANC_ASS            IN VARCHAR2,
                                     PAR_COLLABORATORE       IN VARCHAR2,
                                     PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS

    -- Definizione variabili
    CONTARECORD2 INTEGER := 0;

    -- Codice CANCELLERIA ASSEGNATARIA
    COD_CANCELLERIA CANCELLERIA_ASSEGNATARIA.COD_CANCELLERIA_ASSEGNATARIA%TYPE := NULL;

    -- cursore per la determinazione dei fascicoli.
    -- Non viene utilizzato direttamente ma serve a definire la tupla da utilizzare nella fetch
    CURSOR CURFASCICOLOISCRITTO IS
      SELECT ID_FASCICOLO_SIUS,
             CHIAVE_ANNO,
             CHIAVE_PROGR,
             CHIAVE_UFFICIO,
             COD_STATO_FASCICOLO,
             F.DATA_INSERIMENTO,
             F.DATA_ISCRIZIONE,
             F.DATA_DEFINIZIONE,
             G.ID_GENERALE_PROCEDIMENTO,
             G.COD_OGGETTO_PROCEDIMENTO,
             G.COD_POSIZIONE_GIURIDICA,
             G.TIPO_DEFINIZIONE
        FROM FASCICOLO_SIUS F
        JOIN GENERALE_PROCEDIMENTO G
          ON F.ID_FASCICOLO_SIUS = G.FAS_SIU_ID_FASCICOLO_SIUS;

    -- tupla da utilizzare nella fetch
    TUPLAFASCICOLOISCRITTO CURFASCICOLOISCRITTO%ROWTYPE;

    -- cursore variabile sui fascicoli
    CURFASCICOLI CURFASCTYPE;

    CODOGGETTOTENORE VARCHAR2(4);
    DATAINSTENORE    DATE;

    -- Codice Magistrato Relatore
    CODMAGISTRATO VARCHAR(20);

    /*
    Funzione che apre il cursore per la ricerca dei Fascicoli in stato Iscritto
    */
    PROCEDURE OPENFASCCUR(CUR                     IN OUT CURFASCTYPE,
                          P_UFFICIO               IN VARCHAR2,
                          P_DATA_FINE             IN VARCHAR2,
                          P_COD_CANCELLERIA       IN VARCHAR2,
                          PAR_COLLABORATORE       IN VARCHAR2,
                          PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS
      -- Select base per la ricerca dei Fascicoli Iscritti
      MYSELECT VARCHAR2(2000) := ' select id_fascicolo_sius, chiave_anno,chiave_progr,chiave_ufficio,' ||
                                 ' cod_stato_fascicolo, f.data_inserimento, f.data_iscrizione, f.data_definizione, ' ||
                                 ' g.ID_GENERALE_PROCEDIMENTO, g.cod_oggetto_procedimento, g.cod_posizione_giuridica, g.tipo_definizione' ||
                                 ' from fascicolo_sius f join generale_procedimento g on f.ID_FASCICOLO_SIUS = g.FAS_SIU_ID_FASCICOLO_SIUS' ||
                                 ' where (f.cod_stato_fascicolo =''02'' or f.cod_stato_fascicolo =''10'' or f.cod_stato_fascicolo =''13'' 
                                   or f.cod_stato_fascicolo =''22'' or f.cod_stato_fascicolo =''23'' ) ' ||
                                 ' and f.chiave_ufficio = :p_ufficio' ||
                                 ' and trunc(f.data_iscrizione, ''dd'')   <= to_date(:p_data_fine,''dd/mm/yyyy'') ';
--  or f.cod_stato_fascicolo =''24''
    BEGIN
      -- Preparazione della select dinamica ottenuta aggiungendo le condizioni di filtro alla select base

      -- Eventuale filtro Cancelleria Assegnataria
      FILTROCANCELLERIA(MYSELECT, P_COD_CANCELLERIA);

      -- Eventuale filtro su collaboratore di giustizia
      FILTROCOLLAB(MYSELECT, PAR_COLLABORATORE);

      -- Eventuale filtro Posizione Giuridica
      FILTROPOSIZIONEGIURIDICA(MYSELECT, PAR_POSIZIONE_GIURIDICA);

      -- OPEN CURSOR
      IF ((P_COD_CANCELLERIA IS NULL) AND
         (PAR_POSIZIONE_GIURIDICA = 'tutti')) THEN
        -- Senza filtro su Cancelleria Assegnataria e Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_FINE;
      ELSIF ((P_COD_CANCELLERIA IS NULL) AND
            (PAR_POSIZIONE_GIURIDICA <> 'tutti')) THEN
        -- Filtro su Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_FINE, PAR_POSIZIONE_GIURIDICA;
      ELSIF ((P_COD_CANCELLERIA IS NOT NULL) AND
            (PAR_POSIZIONE_GIURIDICA = 'tutti')) THEN
        -- Filtro su Cancelleria Assegnataria
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_FINE, P_COD_CANCELLERIA;
      ELSE
        -- Filtro su Cancelleria Assegnataria e Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_FINE, P_COD_CANCELLERIA, PAR_POSIZIONE_GIURIDICA;
      END IF;

    END OPENFASCCUR;

  BEGIN
    DBMS_OUTPUT.PUT_LINE('analisiFascicoliIscritti: inizio');

    -- Valorizzazione del codice Cancelleria Assegnataria
    IF (PAR_CANC_ASS = '0') THEN
      COD_CANCELLERIA := NULL;
    ELSE
      COD_CANCELLERIA := PAR_CANC_ASS;
    END IF;

    -- Apertura del cursore
    OPENFASCCUR(CURFASCICOLI,
                PAR_UFFICIO,
                PAR_DATA_FINE,
                COD_CANCELLERIA,
                PAR_COLLABORATORE,
                PAR_POSIZIONE_GIURIDICA);

    -- Ciclo di lettura Fascicoli Iscritti
    LOOP
      FETCH CURFASCICOLI
        INTO TUPLAFASCICOLOISCRITTO;

      IF (CURFASCICOLI%NOTFOUND) THEN
        EXIT;
      END IF;

      -- Lettura dei Fascicoli in stato iscritto
      --for tuplaFascicoloIscritto in curFascicoloIscritto loop
      CONTARECORD2 := CONTARECORD2 + 1;
      DBMS_OUTPUT.PUT_LINE('ID GENERALE PROC ->' ||
                           TUPLAFASCICOLOISCRITTO.ID_GENERALE_PROCEDIMENTO);

      -- Ciclo di lettura dei tenori collegati al fascicolo corrente
      FOR CODOGGETTOTENORE IN CURTUTTITENORIFASCICOLO(TUPLAFASCICOLOISCRITTO.ID_GENERALE_PROCEDIMENTO,
                                                      PAR_DATA_FINE) LOOP

        -- Determinazione del Magistrato Relatore del Fascicolo
        CODMAGISTRATO := GETCODMAGISTRATORELATORE(TUPLAFASCICOLOISCRITTO.ID_FASCICOLO_SIUS);
        IF (CODMAGISTRATO IS NULL) THEN
          CODMAGISTRATO := GETIDESPERTORELATORE(TUPLAFASCICOLOISCRITTO.ID_FASCICOLO_SIUS);
        END IF;
        DATAINSTENORE := GETDATAINSTENORE(TUPLAFASCICOLOISCRITTO.ID_GENERALE_PROCEDIMENTO,
                                          CODOGGETTOTENORE.COD_OGGETTO_TENORE);

        -- inserimento in tabella dei tenori individuati
        INSERT INTO ISP_ESTRAZIONE_OGGETTI_TRIB
          (FAS_SIU_ID_FASCICOLO_SIUS,
           FAS_SIU_CHIAVE_ANNO,
           FAS_SIU_CHIAVE_PROGR,
           FAS_SIU_CHIAVE_UFFICIO,
           FAS_SIU_COD_STATO_FASCICOLO,
           FAS_SIU_DATA_ISCRIZIONE,
           FAS_SIU_DATA_DEFINIZIONE,
           GEN_PRID_GENERALE_PROCEDIMENTO,
           COD_OGGETTO_PROCEDIMENTO,
           COD_OGGETTO_TENORE,
           TEN_DATA_INS,
           DEFINITO,
           COD_POSIZIONE_GIURIDICA,
           TIPO_DEFINIZIONE,
           COD_MAGISTRATO)
        VALUES
          (TUPLAFASCICOLOISCRITTO.ID_FASCICOLO_SIUS,
           TUPLAFASCICOLOISCRITTO.CHIAVE_ANNO,
           TUPLAFASCICOLOISCRITTO.CHIAVE_PROGR,
           TUPLAFASCICOLOISCRITTO.CHIAVE_UFFICIO,
           TUPLAFASCICOLOISCRITTO.COD_STATO_FASCICOLO,
           TUPLAFASCICOLOISCRITTO.DATA_ISCRIZIONE,
           TUPLAFASCICOLOISCRITTO.DATA_DEFINIZIONE,
           TUPLAFASCICOLOISCRITTO.ID_GENERALE_PROCEDIMENTO,
           TUPLAFASCICOLOISCRITTO.COD_OGGETTO_PROCEDIMENTO,
           CODOGGETTOTENORE.COD_OGGETTO_TENORE,
           DATAINSTENORE,
           'N',
           TUPLAFASCICOLOISCRITTO.COD_POSIZIONE_GIURIDICA,
           TUPLAFASCICOLOISCRITTO.TIPO_DEFINIZIONE,
           CODMAGISTRATO);
      END LOOP;
    END LOOP;
    -- chiusura cursore
    CLOSE CURFASCICOLI;

    DBMS_OUTPUT.PUT_LINE('N.ro record Fascicoli Iscritti ' || CONTARECORD2);
    DBMS_OUTPUT.PUT_LINE('analisiFascicoliIscritti: fine');

  END ANALISIFASCICOLIISCRITTI;

  /*
    Ricerca Fascicoli SIUS "Definiti".
    Vengono selezionati tutti i fascicoli con data di
    definizione >= della data iniziale e data di iscrizione <= della data finale.
    Per ognuno di questi si cercano poi i tenori collegati che vengono inseriti
      nella tabella di estrazione ISP_ESTRAZIONE_OGGETTI_TRIB.
      Modifica del 6-2-2008:
      I tenori selezionati sono tutti quelli collegati al fascicolo,
      non solo quelli attivi, non si legge per questi il COD_MAGISTRATO,
      non si codifica l'Esito poich� sar� sempre ALTRO,

  */
  PROCEDURE ANALISIFASCICOLIDEFINITI(PAR_UFFICIO             IN VARCHAR2,
                                     PAR_DATA_INIZIO         IN VARCHAR2,
                                     PAR_DATA_FINE           IN VARCHAR2,
                                     PAR_CANC_ASS            IN VARCHAR2,
                                     PAR_COLLABORATORE       IN VARCHAR2,
                                     PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS

    -- Codice CANCELLERIA ASSEGNATARIA
    COD_CANCELLERIA CANCELLERIA_ASSEGNATARIA.COD_CANCELLERIA_ASSEGNATARIA%TYPE := NULL;

    -- cursore di ricerca fascicoli definiti.
    -- Non utilizzato ma serve per definire la tupla da utilizzare nella fetch.
    CURSOR CURFASCICOLODEFINITO IS
      SELECT ID_FASCICOLO_SIUS,
             CHIAVE_ANNO,
             CHIAVE_PROGR,
             CHIAVE_UFFICIO,
             COD_STATO_FASCICOLO,
             F.DATA_INSERIMENTO,
             F.DATA_ISCRIZIONE,
             F.DATA_DEFINIZIONE,
             G.ID_GENERALE_PROCEDIMENTO,
             G.COD_OGGETTO_PROCEDIMENTO,
             G.COD_POSIZIONE_GIURIDICA,
             G.TIPO_DEFINIZIONE
        FROM FASCICOLO_SIUS F
        JOIN GENERALE_PROCEDIMENTO G
          ON F.ID_FASCICOLO_SIUS = G.FAS_SIU_ID_FASCICOLO_SIUS;

    -- tupla da utilizzare nella fetch
    TUPLAFASCICOLODEFINITO CURFASCICOLODEFINITO%ROWTYPE;

    CONTARECORD1 INTEGER := 0;

    -- cursore  variabile sui fascicoli
    CURFASCICOLI CURFASCTYPE;

    FLAGDEFINITO ISP_ESTRAZIONE_OGGETTI_TRIB.DEFINITO%TYPE;
    TENDATAFINE  ISP_ESTRAZIONE_OGGETTI_TRIB.TEN_DATA_FINE%TYPE;

    -- tupla utilizzata nella ricerca dei tenori
    CODOGGETTOTENORE CURTUTTITENORIFASCICOLO%ROWTYPE;
    DATAINSTENORE    DATE;

    -- Codice Magistrato Relatore ed Id Esperto
    CODMAGISTRATO VARCHAR(20);

    /*
    Funzione che apre il cursore per la ricerca dei Fascicoli Definiti
    */
    PROCEDURE OPENFASCCUR(CUR                     IN OUT CURFASCTYPE,
                          P_UFFICIO               IN VARCHAR2,
                          P_DATA_INIZIO           IN VARCHAR2,
                          P_DATA_FINE             IN VARCHAR2,
                          P_COD_CANCELLERIA       IN VARCHAR2,
                          PAR_COLLABORATORE       IN VARCHAR2,
                          PAR_POSIZIONE_GIURIDICA IN VARCHAR2)

     IS

      -- Select base
      MYSELECT VARCHAR2(2000) := 'select id_fascicolo_sius, chiave_anno, chiave_progr, chiave_ufficio,' ||
                                 ' cod_stato_fascicolo, f.data_inserimento, f.data_iscrizione, f.data_definizione,' ||
                                 ' g.ID_GENERALE_PROCEDIMENTO, cod_oggetto_procedimento, g.cod_posizione_giuridica, g.tipo_definizione' ||
                                 ' from fascicolo_sius f join generale_procedimento g on' ||
                                 ' f.ID_FASCICOLO_SIUS = g.FAS_SIU_ID_FASCICOLO_SIUS' ||
                                 ' where  f.chiave_ufficio = :p_ufficio' ||
                                 ' and trunc(f.data_definizione, ''dd'') >= to_date(:p_data_inizio, ''dd/mm/yyyy'' )' ||
                                 ' and trunc(f.data_iscrizione, ''dd'')   < = to_date(:p_data_fine, ''dd/mm/yyyy'' )';

    BEGIN
      DBMS_OUTPUT.PUT_LINE('openFascCur: inizio');

      -- Preparazione della select dinamica aggiungendo condizioni di filtro alla select base

      -- Eventuale filtro Cancelleria Assegnataria
      FILTROCANCELLERIA(MYSELECT, P_COD_CANCELLERIA);

      -- Eventuale filtro su collaboratore di giustizia
      FILTROCOLLAB(MYSELECT, PAR_COLLABORATORE);

      -- Eventuale filtro Posizione Giuridica
      FILTROPOSIZIONEGIURIDICA(MYSELECT, PAR_POSIZIONE_GIURIDICA);

      -- OPEN CURSOR
      IF ((P_COD_CANCELLERIA IS NULL) AND
         (PAR_POSIZIONE_GIURIDICA = 'tutti')) THEN
        -- Senza filtro su Cancelleria Assegnataria e Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_INIZIO, P_DATA_FINE;
      ELSIF ((P_COD_CANCELLERIA IS NULL) AND
            (PAR_POSIZIONE_GIURIDICA <> 'tutti')) THEN
        -- Filtro su Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_INIZIO, P_DATA_FINE, PAR_POSIZIONE_GIURIDICA;
      ELSIF ((P_COD_CANCELLERIA IS NOT NULL) AND
            (PAR_POSIZIONE_GIURIDICA = 'tutti')) THEN
        -- Filtro su Cancelleria Assegnataria
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_INIZIO, P_DATA_FINE, P_COD_CANCELLERIA;
      ELSE
        -- Filtro su Cancelleria Assegnataria e Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_UFFICIO, P_DATA_INIZIO, P_DATA_FINE, P_COD_CANCELLERIA, PAR_POSIZIONE_GIURIDICA;
      END IF;

      DBMS_OUTPUT.PUT_LINE('openFascCur: fine');

    END OPENFASCCUR;

  BEGIN
    DBMS_OUTPUT.PUT_LINE('analisiFascicoliDefiniti: inizio');

    -- Valorizzazione del codice Cancelleria Assegnataria
    IF (PAR_CANC_ASS = '0') THEN
      COD_CANCELLERIA := NULL;
    ELSE
      COD_CANCELLERIA := PAR_CANC_ASS;
    END IF;

    -- Ricerca dei Fascicoli in stato definito

    -- apertura del cursore
    OPENFASCCUR(CURFASCICOLI,
                PAR_UFFICIO,
                PAR_DATA_INIZIO,
                PAR_DATA_FINE,
                COD_CANCELLERIA,
                PAR_COLLABORATORE,
                PAR_POSIZIONE_GIURIDICA);

    -- Ciclo di lettura Fascicoli Definiti
    LOOP
      FETCH CURFASCICOLI
        INTO TUPLAFASCICOLODEFINITO;

      IF (CURFASCICOLI%NOTFOUND) THEN
        EXIT;
      END IF;

      --for tuplaFascicoloDefinito in curFascicoloDefinito loop
      CONTARECORD1 := CONTARECORD1 + 1;

      -- valutazione se definito
      FLAGDEFINITO := DEFINITONELPERIODO(TUPLAFASCICOLODEFINITO.DATA_DEFINIZIONE,
                                         PAR_DATA_FINE);

      -- Lettura dei tenori collegati
      FOR CODOGGETTOTENORE IN CURTUTTITENORIFASCICOLO(TUPLAFASCICOLODEFINITO.ID_GENERALE_PROCEDIMENTO,
                                                      PAR_DATA_FINE) LOOP

        -- Data di fine validit�
        TENDATAFINE := DATAFINETENOREFASCICOLO(TUPLAFASCICOLODEFINITO.ID_GENERALE_PROCEDIMENTO,
                                               CODOGGETTOTENORE.COD_OGGETTO_TENORE);
        -- tenDataFine := null;

        -- Determinazione del Magistrato Relatore del Fascicolo
        CODMAGISTRATO := GETCODMAGISTRATORELATORE(TUPLAFASCICOLODEFINITO.ID_FASCICOLO_SIUS);
        IF (CODMAGISTRATO IS NULL) THEN
          CODMAGISTRATO := GETIDESPERTORELATORE(TUPLAFASCICOLODEFINITO.ID_FASCICOLO_SIUS);
        END IF;
        DATAINSTENORE := GETDATAINSTENORE(TUPLAFASCICOLODEFINITO.ID_GENERALE_PROCEDIMENTO,
                                          CODOGGETTOTENORE.COD_OGGETTO_TENORE);

        -- inserimento in tabella dei tenori individuati
        INSERT INTO ISP_ESTRAZIONE_OGGETTI_TRIB
          (
           -- Dati del Fascicolo
           FAS_SIU_ID_FASCICOLO_SIUS,
           FAS_SIU_CHIAVE_ANNO,
           FAS_SIU_CHIAVE_PROGR,
           FAS_SIU_CHIAVE_UFFICIO,
           FAS_SIU_COD_STATO_FASCICOLO,
           FAS_SIU_DATA_ISCRIZIONE,
           FAS_SIU_DATA_DEFINIZIONE,
           GEN_PRID_GENERALE_PROCEDIMENTO,
           COD_OGGETTO_PROCEDIMENTO,
           COD_POSIZIONE_GIURIDICA,
           TIPO_DEFINIZIONE,
           COD_MAGISTRATO,
           -- Dati del Tenore
           COD_OGGETTO_TENORE,
           TEN_DATA_INS,
           TEN_DATA_FINE,
           DEFINITO)

        VALUES
          (TUPLAFASCICOLODEFINITO.ID_FASCICOLO_SIUS,
           TUPLAFASCICOLODEFINITO.CHIAVE_ANNO,
           TUPLAFASCICOLODEFINITO.CHIAVE_PROGR,
           TUPLAFASCICOLODEFINITO.CHIAVE_UFFICIO,
           TUPLAFASCICOLODEFINITO.COD_STATO_FASCICOLO,
           TUPLAFASCICOLODEFINITO.DATA_ISCRIZIONE,
           TUPLAFASCICOLODEFINITO.DATA_DEFINIZIONE,
           TUPLAFASCICOLODEFINITO.ID_GENERALE_PROCEDIMENTO,
           TUPLAFASCICOLODEFINITO.COD_OGGETTO_PROCEDIMENTO,
           TUPLAFASCICOLODEFINITO.COD_POSIZIONE_GIURIDICA,
           TUPLAFASCICOLODEFINITO.TIPO_DEFINIZIONE,
           CODMAGISTRATO,
           CODOGGETTOTENORE.COD_OGGETTO_TENORE,
           DATAINSTENORE,
           TENDATAFINE,
           FLAGDEFINITO);
      END LOOP;
    END LOOP;
    CLOSE CURFASCICOLI;
    DBMS_OUTPUT.PUT_LINE('N.ro record Fascicoli in stato definito ' ||
                         CONTARECORD1);
    DBMS_OUTPUT.PUT_LINE('analisiFascicoliDefiniti: fine');

  END ANALISIFASCICOLIDEFINITI;

  /*
    Ricerca Fascicoli SIUS in stato 07 ovvero "Emesso Provvedimento".
    Vengono selezionati tutti i fascicoli iscritti con
    data_iscrizione <= data fine e che abbiano almeno un provvedimento
    (ordinanza o decreto) depositato con data_deposito >= data inizio.
    Per ognuno di questi si cercano poi prima i tenori collegati
    ai provvedimenti depositati, poi gli altri tenori collegati solo al fascicolo.
      Tutti vengono inseriti nella tabella di estrazione.
  */
  PROCEDURE ANALISIFASCICOLIDEPOSITATI(PAR_UFFICIO             IN VARCHAR2,
                                       PAR_DATA_INIZIO         IN VARCHAR2,
                                       PAR_DATA_FINE           IN VARCHAR2,
                                       PAR_CANC_ASS            IN VARCHAR2,
                                       PAR_COLLABORATORE       IN VARCHAR2,
                                       PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS

    COD_CANCELLERIA CANCELLERIA_ASSEGNATARIA.COD_CANCELLERIA_ASSEGNATARIA%TYPE := NULL;

    -- Cursore per la ricerca di tutti i Fascicoli collegati ad Ordinanze o Decreti depositati in data utile
    CURSOR CURFASCPROVV IS
      SELECT F.ID_FASCICOLO_SIUS ID_SIUS,
             ID_FASCICOLO_SIUS,
             CHIAVE_ANNO,
             CHIAVE_PROGR,
             CHIAVE_UFFICIO,
             COD_STATO_FASCICOLO,
             F.DATA_INSERIMENTO,
             F.DATA_ISCRIZIONE,
             F.DATA_DEFINIZIONE,
             G.ID_GENERALE_PROCEDIMENTO,
             G.COD_OGGETTO_PROCEDIMENTO,
             G.COD_POSIZIONE_GIURIDICA,
             G.TIPO_DEFINIZIONE,
             D.DATA_DEPOSITO            DATA_DEP_DEC,
             D.ID_DEPOSITO_DECRETO      ID_DEC,
             O.DATA_DEPOSITO            DATA_DEP_ORD,
             O.ID_DEPOSITO_ORDINANZA_PC ID_ORD,
             --bvn
             OO.DATA_DEPOSITO        DATA_DEP_SEN,
             OO.ID_DEPOSITO_SENTENZA ID_SEN
      --fine bvn
        FROM FASCICOLO_SIUS F
        JOIN GENERALE_PROCEDIMENTO G
          ON F.ID_FASCICOLO_SIUS = G.FAS_SIU_ID_FASCICOLO_SIUS
        JOIN EVENTO E
          ON E.FAS_SIU_ID_FASCICOLO_SIUS = F.ID_FASCICOLO_SIUS
        LEFT OUTER JOIN DEPOSITO_DECRETO D
          ON D.ID_EVENTO_GENERATO = E.ID_EVENTO
         AND TRUNC(D.DATA_DEPOSITO, 'dd') >=
             TO_DATE(PAR_DATA_INIZIO, 'dd/mm/yyyy')
        LEFT OUTER JOIN DEPOSITO_ORDINANZA_PC O
          ON O.ID_EVENTO_GENERATO = E.ID_EVENTO
         AND TRUNC(O.DATA_DEPOSITO, 'dd') >=
             TO_DATE(PAR_DATA_INIZIO, 'dd/mm/yyyy')
      --bvn
        LEFT OUTER JOIN DEPOSITO_SENTENZA OO
          ON OO.ID_EVENTO_GENERATO = E.ID_EVENTO
         AND TRUNC(OO.DATA_DEPOSITO, 'dd') >=
             TO_DATE(PAR_DATA_INIZIO, 'dd/mm/yyyy')
      --fine bvn
       WHERE F.COD_STATO_FASCICOLO IN ('07')
         AND F.CHIAVE_UFFICIO = PAR_UFFICIO
         AND TRUNC(F.DATA_ISCRIZIONE, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')
       ORDER BY ID_SIUS;

    -- tupla utilizzata nella fetch
    TUPLAFASCPROVV CURFASCPROVV%ROWTYPE;

    CONTARECORD INTEGER := 0;

    -- cursore per la ricerca dei cod_oggetti di tutti i tenori collegati
    -- al GENERALE_PROCEDIMENTO esclusi quelli legati a decreto o ordinanza
    -- CURSOR curAltriTenori (par_id_gen_proc IN NUMBER)
    CURSOR CURALTRITENORI(PAR_ID_GEN_PROC IN NUMBER,
                          P_DATA_FINE     IN VARCHAR2) IS
      SELECT DISTINCT COD_OGGETTO_TENORE, MIN(DATA_INSERIMENTO)
        FROM TENORE
       WHERE GEN_PRID_GENERALE_PROCEDIMENTO = PAR_ID_GEN_PROC
         AND TRUNC(DATA_INSERIMENTO, 'dd') <=
             TO_DATE(P_DATA_FINE, 'dd/mm/yyyy')
         AND COD_OGGETTO_TENORE NOT IN
             (SELECT DISTINCT COD_OGGETTO_TENORE
                FROM TENORE A
               WHERE GEN_PRID_GENERALE_PROCEDIMENTO = PAR_ID_GEN_PROC
                 AND (DEP_DEC_ID_DEPOSITO_DECRETO IS NOT NULL OR
                     DEP_OPID_DEPOSITO_ORDINANZA_PC IS NOT NULL
                     --bvn
                     OR A.DEP_ID_DEPOSITO_SENTENZA IS NOT NULL
                     --fine bvn
                     ))
       GROUP BY COD_OGGETTO_TENORE;

    ---- Variabili di appoggio ----------------

    TUPLATENORE      TENORE%ROWTYPE;
    TUPLATENOREPROVV CURTENORIXDECRETO%ROWTYPE;

    -- ID GENERALE_PROCEDIMENTO corrente
    IDGENPROC TENORE.GEN_PRID_GENERALE_PROCEDIMENTO%TYPE;
    -- ID GENERALE_PROCEDIMENTO ultimo fascicolo inserito
    IDGENPROCOLD TENORE.GEN_PRID_GENERALE_PROCEDIMENTO%TYPE;

    DEF ISP_ESTRAZIONE_OGGETTI_TRIB.DEFINITO%TYPE;

    -- cursore sui fascicoli
    CURFASCICOLI CURFASCTYPE;

    /*
    Funzione che apre il cursore per la ricerca dei Fascicoli Depositati
    */
    PROCEDURE OPENFASCCUR(CUR                     IN OUT CURFASCTYPE,
                          P_UFFICIO               IN VARCHAR2,
                          P_DATA_INIZIO           IN VARCHAR2,
                          P_DATA_FINE             IN VARCHAR2,
                          P_COD_CANCELLERIA       IN VARCHAR2,
                          PAR_COLLABORATORE       IN VARCHAR2,
                          PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS

      -- select base
      --
      -- IN DATA 25/7/2008 INSERITE MODIFICHE PER SCARTO ORDINANZE/DECRETO IRREPERIBILITA', FISSAZIONE UDIENZA E RINVIO UDIENZA E
      --                   EVENTI NON VALIDATI
      MYSELECT VARCHAR2(2000) := 'select f.id_fascicolo_sius ID_SIUS,id_fascicolo_sius,chiave_anno,' ||
                                 ' chiave_progr,chiave_ufficio, cod_stato_fascicolo, f.data_inserimento, f.data_iscrizione,' ||
                                 ' f.data_definizione, g.ID_GENERALE_PROCEDIMENTO, g.cod_oggetto_procedimento, g.cod_posizione_giuridica, g.tipo_definizione,' ||
                                 ' d.data_deposito DATA_DEP_DEC, d.id_deposito_decreto ID_DEC,' ||
                                 ' o.data_deposito DATA_DEP_ORD, o.id_deposito_ordinanza_pc ID_ORD,' ||
                                --bvn
                                 ' oo.data_deposito DATA_DEP_SEN, oo.id_deposito_sentenza ID_SEN' ||
                                --fine bvn
                                 ' from fascicolo_sius f join generale_procedimento g' ||
                                 ' on f.ID_FASCICOLO_SIUS = g.FAS_SIU_ID_FASCICOLO_SIUS' ||
                                 ' join evento e on e.FAS_SIU_ID_FASCICOLO_SIUS = f.ID_FASCICOLO_SIUS' ||
                                --               MODIFICHE 25/7/2008
                                 --  24/1/2023   Umberto aggiunto scarto Decreti Designazione (0610) 
                                 '  and ( e.COD_ESITO <> ''0601'' AND e.COD_ESITO <> ''0602'' and e.COD_ESITO <> ''0603'' and e.COD_ESITO <> ''0605'' AND e.COD_ESITO <> ''0610'' )' ||
                                 '  and e.FLAG_DOCUMENTO_REGISTRATO = ''S'' ' ||
                                --               FINE MODIFICHE 25/7/2008
                                 ' left outer join deposito_decreto d on d.ID_EVENTO_GENERATO = e.ID_EVENTO' ||

                                 '  and trunc(d.data_deposito, ''dd'') >= to_date(:p_data_inizio1,''dd/mm/yyyy'')' ||
                                 ' left outer join deposito_ordinanza_pc o on o.ID_EVENTO_GENERATO = e.ID_EVENTO' ||
                                 '  and trunc(o.data_deposito, ''dd'') >= to_date(:p_data_inizio2,''dd/mm/yyyy'')' ||
                                --bvn
                                 ' left outer join deposito_sentenza oo on oo.ID_EVENTO_GENERATO = e.ID_EVENTO' ||
                                 '  and trunc(oo.data_deposito, ''dd'') >= to_date(:p_data_inizio3,''dd/mm/yyyy'')' ||
                                --fine bvn
                                 -- MEV9 si aggiunge lo stato 24 (Emessa ordinanza di ammissione provvisoria) per i definito 
                                 -- ' where  f.cod_stato_fascicolo = ''07''  and f.chiave_ufficio = :p_ufficio  ' ||
                                 ' where  f.cod_stato_fascicolo in (''07'',''24'')  and f.chiave_ufficio = :p_ufficio  ' ||
                                  -- MEV9 - FINE
                                 ' and trunc(f.data_iscrizione, ''dd'') <= to_date(:p_data_fine,''dd/mm/yyyy'')'
                                 -- MEV 9 ottimizzazione
                                 ||' AND ( D.DATA_DEPOSITO IS NOT NULL OR O.DATA_DEPOSITO IS NOT NULL OR OO.DATA_DEPOSITO IS NOT NULL)'
                                 ;

      -- condizione di ordering
      ORDERCLAUSE VARCHAR2(50) := ' order by ID_SIUS';

    BEGIN
      -- Preparazione della select dinamica aggiungendo condizioni di filtro alla select base

      -- Eventuale filtro Cancelleria Assegnataria
      FILTROCANCELLERIA(MYSELECT, P_COD_CANCELLERIA);

      -- Eventuale filtro su collaboratore di giustizia
      FILTROCOLLAB(MYSELECT, PAR_COLLABORATORE);

      -- Eventuale filtro Posizione Giuridica
      FILTROPOSIZIONEGIURIDICA(MYSELECT, PAR_POSIZIONE_GIURIDICA);

      -- aggiunta dell' ordering
      MYSELECT := MYSELECT || ORDERCLAUSE;

      -- OPEN CURSOR
      IF ((P_COD_CANCELLERIA IS NULL) AND
         (PAR_POSIZIONE_GIURIDICA = 'tutti')) THEN
        -- Senza filtro su Cancelleria Assegnataria e Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_DATA_INIZIO, P_DATA_INIZIO, P_DATA_INIZIO, P_UFFICIO, P_DATA_FINE;
      ELSIF ((P_COD_CANCELLERIA IS NULL) AND
            (PAR_POSIZIONE_GIURIDICA <> 'tutti')) THEN
        -- Filtro su Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_DATA_INIZIO, P_DATA_INIZIO, P_DATA_INIZIO, P_UFFICIO, P_DATA_FINE, PAR_POSIZIONE_GIURIDICA;
      ELSIF ((P_COD_CANCELLERIA IS NOT NULL) AND
            (PAR_POSIZIONE_GIURIDICA = 'tutti')) THEN
        -- Filtro su Cancelleria Assegnataria
        OPEN CUR FOR MYSELECT
          USING P_DATA_INIZIO, P_DATA_INIZIO, P_DATA_INIZIO, P_UFFICIO, P_DATA_FINE, P_COD_CANCELLERIA;
      ELSE
        -- Filtro su Cancelleria Assegnataria e Posizione Giuridica
        OPEN CUR FOR MYSELECT
          USING P_DATA_INIZIO, P_DATA_INIZIO, P_DATA_INIZIO, P_UFFICIO, P_DATA_FINE, P_COD_CANCELLERIA, PAR_POSIZIONE_GIURIDICA;
      END IF;

    END OPENFASCCUR;

    /*
       Resetta quei campi del Tenore utilizzati nell'Inserimento
    */
    FUNCTION RESETTENORE RETURN TENORE%ROWTYPE IS
      -- Tupla restituita
      PAR_TENORE TENORE%ROWTYPE;

    BEGIN
      PAR_TENORE.GEN_PRID_GENERALE_PROCEDIMENTO := NULL;
      PAR_TENORE.COD_OGGETTO_TENORE             := NULL;
      PAR_TENORE.DATA_INSERIMENTO               := NULL;
      PAR_TENORE.COD_ESITO_TENORE               := NULL;
      PAR_TENORE.COD_MAGISTRATO                 := NULL;
      PAR_TENORE.DATA                           := NULL;
      PAR_TENORE.DATA_FINE                      := NULL;
      PAR_TENORE.DEP_OPID_DEPOSITO_ORDINANZA_PC := NULL;
      PAR_TENORE.DEP_DEC_ID_DEPOSITO_DECRETO    := NULL;
      --bvn
      PAR_TENORE.DEP_ID_DEPOSITO_SENTENZA := NULL;
      --fine bvn

      RETURN PAR_TENORE;
    END RESETTENORE;

    /*
    Procedura di inserimento nella tabella ISP_ESTRAZIONE_OGGETTI_TRIB.
    */

    PROCEDURE INSERIMENTO(PAR_FASCICOLO IN CURFASCPROVV%ROWTYPE,
                          PAR_TENORE    IN TENORE%ROWTYPE,
                          PAR_DEFINITO  ISP_ESTRAZIONE_OGGETTI_TRIB.DEFINITO%TYPE) IS

      CODESITOSTATISTICA VARCHAR2(4);
      CODMAGISTRATO      VARCHAR2(20);

      DATA_DEPOSITO DATE;

    BEGIN
      -- Valorizzazione data di deposito

      IF (PAR_FASCICOLO.DATA_DEP_DEC IS NOT NULL) THEN
        DATA_DEPOSITO := PAR_FASCICOLO.DATA_DEP_DEC;
        --bvn
      ELSIF (PAR_FASCICOLO.DATA_DEP_ORD IS NOT NULL) THEN
        DATA_DEPOSITO := PAR_FASCICOLO.DATA_DEP_ORD;

      ELSIF (PAR_FASCICOLO.DATA_DEP_SEN IS NOT NULL) THEN
        DATA_DEPOSITO := PAR_FASCICOLO.DATA_DEP_SEN;
        --fine bvn
      END IF;

      -- trascodifica esito tenore
      CODESITOSTATISTICA := CODESITOSTATDATENORE(PAR_TENORE.COD_ESITO_TENORE);

      -- id dell' esperto relatore
      CODMAGISTRATO := PAR_TENORE.COD_MAGISTRATO;
      IF (CODMAGISTRATO IS NULL) THEN
        CODMAGISTRATO := GETIDESPERTORELATORE(PAR_FASCICOLO.ID_FASCICOLO_SIUS);
      END IF;

      -- inserimento in tabella dei tenori passati
      INSERT INTO ISP_ESTRAZIONE_OGGETTI_TRIB
        (
         -- Dati del Fascicolo
         FAS_SIU_ID_FASCICOLO_SIUS,
         FAS_SIU_CHIAVE_ANNO,
         FAS_SIU_CHIAVE_PROGR,
         FAS_SIU_CHIAVE_UFFICIO,
         FAS_SIU_COD_STATO_FASCICOLO,
         FAS_SIU_DATA_ISCRIZIONE,
         FAS_SIU_DATA_DEFINIZIONE,
         DATA_DEPOSITO,
         GEN_PRID_GENERALE_PROCEDIMENTO,
         COD_OGGETTO_PROCEDIMENTO,
         COD_POSIZIONE_GIURIDICA,
         TIPO_DEFINIZIONE,
         COD_OGGETTO_TENORE,
         TEN_DATA_INS,
         COD_ESITO_TENORE,
         COD_MAGISTRATO,
         TEN_DATA,
         TEN_DATA_FINE,
         DEP_OPID_DEPOSITO_ORDINANZA_PC,
         DEP_DEC_ID_DEPOSITO_DECRETO,
         DEFINITO,
         COD_ESITO_STATISTICA,
         --bvn
         DEP_DEC_ID_DEPOSITO_SENTENZA)
      --fine bvn)

      VALUES
        (PAR_FASCICOLO.ID_FASCICOLO_SIUS,
         PAR_FASCICOLO.CHIAVE_ANNO,
         PAR_FASCICOLO.CHIAVE_PROGR,
         PAR_FASCICOLO.CHIAVE_UFFICIO,
         PAR_FASCICOLO.COD_STATO_FASCICOLO,
         PAR_FASCICOLO.DATA_ISCRIZIONE,
         PAR_FASCICOLO.DATA_DEFINIZIONE,
         DATA_DEPOSITO,
         PAR_FASCICOLO.ID_GENERALE_PROCEDIMENTO,
         PAR_FASCICOLO.COD_OGGETTO_PROCEDIMENTO,
         PAR_FASCICOLO.COD_POSIZIONE_GIURIDICA,
         PAR_FASCICOLO.TIPO_DEFINIZIONE,
         PAR_TENORE.COD_OGGETTO_TENORE,
         PAR_TENORE.DATA_INSERIMENTO,
         PAR_TENORE.COD_ESITO_TENORE,
         -- par_tenore.Cod_Magistrato,
         CODMAGISTRATO,
         PAR_TENORE.DATA,
         PAR_TENORE.DATA_FINE,
         PAR_TENORE.DEP_OPID_DEPOSITO_ORDINANZA_PC,
         PAR_TENORE.DEP_DEC_ID_DEPOSITO_DECRETO,
         PAR_DEFINITO,
         CODESITOSTATISTICA,
         --bvn
         PAR_TENORE.DEP_ID_DEPOSITO_SENTENZA);
      --fine bvn);

      DBMS_OUTPUT.PUT_LINE('Inserito record per ID GEN procedure ->' ||
                           PAR_TENORE.GEN_PRID_GENERALE_PROCEDIMENTO);

    END INSERIMENTO;

    /*
    Effettua la ricerca di tutti i tenori distinti legati al fascicolo
    ma non legati a decreto o ordinanza. Di questi viene letto solo il COD_OGGETTO.
    Per ognuno di questi viene inserito un nuovo record in ISP_ESTRAZIONE_OGGETTI_TRIB,
    i dati del fascicolo  e lo stato di DEFINITO sono quelli passati alla funzione.
    */
    PROCEDURE INSTENORISTORICI(PAR_FASCICOLO   IN CURFASCPROVV%ROWTYPE,
                               PAR_ID_GEN_PROC IN NUMBER,
                               PAR_DEFINITO    ISP_ESTRAZIONE_OGGETTI_TRIB.DEFINITO%TYPE,
                               PAR_DATA_FINE   IN VARCHAR2) IS

      TUPLATENORESTORICO TENORE%ROWTYPE := RESETTENORE;

      TENORECUR CURALTRITENORI%ROWTYPE;

      NUMRECORD INTEGER := 0;
    BEGIN
      DBMS_OUTPUT.PUT_LINE('InsTenoriStorici ID GEN procedure ->' ||
                           PAR_ID_GEN_PROC);

      -- Valorizzazione dell'ID GENERALE PROCEDIMENTO
      TUPLATENORESTORICO.GEN_PRID_GENERALE_PROCEDIMENTO := PAR_ID_GEN_PROC;

      -- Lettura dei tenori collegati allo stesso fascicolo non collegati a decreto o ordinanza (Storici)
      FOR TENORECUR IN CURALTRITENORI(PAR_ID_GEN_PROC, PAR_DATA_FINE) LOOP
        TUPLATENORESTORICO.COD_OGGETTO_TENORE := TENORECUR.COD_OGGETTO_TENORE;
        TUPLATENORESTORICO.DATA_INSERIMENTO   := GETDATAINSTENORE(PAR_ID_GEN_PROC,
                                                                  TENORECUR.COD_OGGETTO_TENORE);
        TUPLATENORESTORICO.DATA_FINE          := DATAFINETENOREFASCICOLO(PAR_ID_GEN_PROC,
                                                                         TENORECUR.COD_OGGETTO_TENORE);
        NUMRECORD                             := NUMRECORD + 1;
        INSERIMENTO(PAR_FASCICOLO, TUPLATENORESTORICO, PAR_DEFINITO);
      END LOOP;
      DBMS_OUTPUT.PUT_LINE('InsTenoriStorici Num Rec inseriti ->' ||
                           NUMRECORD);

    END INSTENORISTORICI;

    -- Inizio analisiFascicoliDepositati
  BEGIN

    -- Valorizzazione del codice Cancelleria Assegnataria
    IF (PAR_CANC_ASS = '0') THEN
      COD_CANCELLERIA := NULL;
    ELSE
      COD_CANCELLERIA := PAR_CANC_ASS;
    END IF;

    -- Lettura dei Fascicoli in stato "emesso provvedimento" con data di deposito > data inizio collegati a Decreto o ad Ordinanza
    DBMS_OUTPUT.PUT_LINE('analisiFascicoliDepositati: inizio');

    CONTARECORD  := 0;
    IDGENPROCOLD := 0;

    -- apertura del cursore
    OPENFASCCUR(CURFASCICOLI,
                PAR_UFFICIO,
                PAR_DATA_INIZIO,
                PAR_DATA_FINE,
                COD_CANCELLERIA,
                PAR_COLLABORATORE,
                PAR_POSIZIONE_GIURIDICA);

    -- Ciclo di lettura Fascicoli Depositati
    LOOP
      FETCH CURFASCICOLI
        INTO TUPLAFASCPROVV;

      IF (CURFASCICOLI%NOTFOUND) THEN
        EXIT;
      END IF;
      CONTARECORD := CONTARECORD + 1;

      IDGENPROC := TUPLAFASCPROVV.ID_GENERALE_PROCEDIMENTO;

      DBMS_OUTPUT.PUT_LINE('analisiFascicoliDepositati: ***************   Record n.ro->' ||
                           CONTARECORD);

      IF (TUPLAFASCPROVV.ID_DEC IS NOT NULL) THEN
        DBMS_OUTPUT.PUT_LINE('analisiFascicoliDepositati: ***************   Decreto');

        -- Valorizzazione del flag DEFINITO
        DEF := DEFINITONELPERIODO(TUPLAFASCPROVV.DATA_DEP_DEC,
                                  PAR_DATA_FINE);

        -- Lettura dei tenori collegati al decreto ed inserimento in tabella
        FOR TUPLATENOREPROVV IN CURTENORIXDECRETO(TUPLAFASCPROVV.ID_DEC) LOOP
          TUPLATENORE.COD_OGGETTO_TENORE             := TUPLATENOREPROVV.COD_OGGETTO_TENORE;
          TUPLATENORE.COD_ESITO_TENORE               := TUPLATENOREPROVV.COD_ESITO_TENORE;
          TUPLATENORE.COD_MAGISTRATO                 := TUPLATENOREPROVV.COD_MAGISTRATO;
          TUPLATENORE.DATA                           := TUPLATENOREPROVV.DATA;
          TUPLATENORE.DEP_OPID_DEPOSITO_ORDINANZA_PC := TUPLATENOREPROVV.DEP_OPID_DEPOSITO_ORDINANZA_PC;
          TUPLATENORE.DEP_DEC_ID_DEPOSITO_DECRETO    := TUPLATENOREPROVV.DEP_DEC_ID_DEPOSITO_DECRETO;
          --bvn
          TUPLATENORE.DEP_ID_DEPOSITO_SENTENZA := TUPLATENOREPROVV.DEP_ID_DEPOSITO_SENTENZA;
          --fine bvn

          TUPLATENORE.DATA_INSERIMENTO := GETDATAINSTENORE(TUPLAFASCPROVV.ID_GENERALE_PROCEDIMENTO,
                                                           TUPLATENORE.COD_OGGETTO_TENORE);
          TUPLATENORE.DATA_FINE        := DATAFINETENOREFASCICOLO(TUPLAFASCPROVV.ID_GENERALE_PROCEDIMENTO,
                                                                  TUPLATENORE.COD_OGGETTO_TENORE);
          IF TRUNC(TUPLATENORE.DATA_INSERIMENTO, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy') THEN
            INSERIMENTO(TUPLAFASCPROVV, TUPLATENORE, DEF);
          END IF;
        END LOOP;

        -- Lettura dei tenori collegati allo stesso fascicolo non collegati a decreto o ordinanza (Storici)
        -- e loro inserimento in tabella Va richiamata una sola volta per Fascicolo
        IF (IDGENPROC <> IDGENPROCOLD) THEN
          INSTENORISTORICI(TUPLAFASCPROVV, IDGENPROC, DEF, PAR_DATA_FINE);
          IDGENPROCOLD := IDGENPROC;
        END IF;

      ELSIF (TUPLAFASCPROVV.ID_ORD IS NOT NULL) THEN

        DBMS_OUTPUT.PUT_LINE('analisiFascicoliDepositati: ***************   Ordinanza');

        -- Valorizzazione del flag DEFINITO
        DEF := DEFINITONELPERIODO(TUPLAFASCPROVV.DATA_DEP_ORD,
                                  PAR_DATA_FINE);

        -- Lettura dei tenori collegati ed inserimento in tabella
        FOR TUPLATENOREPROVV IN CURTENORIXORDINANZA(TUPLAFASCPROVV.ID_ORD) LOOP
          TUPLATENORE.COD_OGGETTO_TENORE             := TUPLATENOREPROVV.COD_OGGETTO_TENORE;
          TUPLATENORE.COD_ESITO_TENORE               := TUPLATENOREPROVV.COD_ESITO_TENORE;
          TUPLATENORE.COD_MAGISTRATO                 := TUPLATENOREPROVV.COD_MAGISTRATO;
          TUPLATENORE.DATA                           := TUPLATENOREPROVV.DATA;
          TUPLATENORE.DEP_OPID_DEPOSITO_ORDINANZA_PC := TUPLATENOREPROVV.DEP_OPID_DEPOSITO_ORDINANZA_PC;
          TUPLATENORE.DEP_DEC_ID_DEPOSITO_DECRETO    := TUPLATENOREPROVV.DEP_DEC_ID_DEPOSITO_DECRETO;
          --bvn
          TUPLATENORE.DEP_ID_DEPOSITO_SENTENZA := TUPLATENOREPROVV.DEP_ID_DEPOSITO_SENTENZA;
          --fine bvn

          TUPLATENORE.DATA_INSERIMENTO := GETDATAINSTENORE(TUPLAFASCPROVV.ID_GENERALE_PROCEDIMENTO,
                                                           TUPLATENORE.COD_OGGETTO_TENORE);
          TUPLATENORE.DATA_FINE        := DATAFINETENOREFASCICOLO(TUPLAFASCPROVV.ID_GENERALE_PROCEDIMENTO,
                                                                  TUPLATENORE.COD_OGGETTO_TENORE);
          IF TRUNC(TUPLATENORE.DATA_INSERIMENTO, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy') THEN
            INSERIMENTO(TUPLAFASCPROVV, TUPLATENORE, DEF);
          END IF;
        END LOOP;

        -- Lettura dei tenori collegati allo stesso fascicolo non collegati a decreto o ordinanza (Storici) e loro inserimento in tabella
        IF (IDGENPROC <> IDGENPROCOLD) THEN
          INSTENORISTORICI(TUPLAFASCPROVV, IDGENPROC, DEF, PAR_DATA_FINE);
          IDGENPROCOLD := IDGENPROC;
        END IF;

        --bvn
      ELSIF (TUPLAFASCPROVV.ID_SEN IS NOT NULL) THEN

        DBMS_OUTPUT.PUT_LINE('analisiFascicoliDepositati: ***************   Sentenza');

        -- Valorizzazione del flag DEFINITO
        DEF := DEFINITONELPERIODO(TUPLAFASCPROVV.DATA_DEP_SEN,
                                  PAR_DATA_FINE);

        -- Lettura dei tenori collegati ed inserimento in tabella
        --bvn 31/05/2016 modificato TUPLAFASCPROVV.ID_ORD in TUPLAFASCPROVV.ID_SEN
        --bvn 31/05/2016 modificato CURTENORIXORDINANZA in CURTENORIXSENTENZA
        FOR TUPLATENOREPROVV IN CURTENORIXSENTENZA(TUPLAFASCPROVV.ID_SEN) LOOP
          TUPLATENORE.COD_OGGETTO_TENORE             := TUPLATENOREPROVV.COD_OGGETTO_TENORE;
          TUPLATENORE.COD_ESITO_TENORE               := TUPLATENOREPROVV.COD_ESITO_TENORE;
          TUPLATENORE.COD_MAGISTRATO                 := TUPLATENOREPROVV.COD_MAGISTRATO;
          TUPLATENORE.DATA                           := TUPLATENOREPROVV.DATA;
          TUPLATENORE.DEP_OPID_DEPOSITO_ORDINANZA_PC := TUPLATENOREPROVV.DEP_OPID_DEPOSITO_ORDINANZA_PC;
          TUPLATENORE.DEP_DEC_ID_DEPOSITO_DECRETO    := TUPLATENOREPROVV.DEP_DEC_ID_DEPOSITO_DECRETO;
          --bvn
          TUPLATENORE.DEP_ID_DEPOSITO_SENTENZA := TUPLATENOREPROVV.DEP_ID_DEPOSITO_SENTENZA;
          --fine bvn

          TUPLATENORE.DATA_INSERIMENTO := GETDATAINSTENORE(TUPLAFASCPROVV.ID_GENERALE_PROCEDIMENTO,
                                                           TUPLATENORE.COD_OGGETTO_TENORE);
          TUPLATENORE.DATA_FINE        := DATAFINETENOREFASCICOLO(TUPLAFASCPROVV.ID_GENERALE_PROCEDIMENTO,
                                                                  TUPLATENORE.COD_OGGETTO_TENORE);
          IF TRUNC(TUPLATENORE.DATA_INSERIMENTO, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy') THEN
            INSERIMENTO(TUPLAFASCPROVV, TUPLATENORE, DEF);
          END IF;
        END LOOP;

        -- Lettura dei tenori collegati allo stesso fascicolo non collegati a decreto o ordinanza (Storici) e loro inserimento in tabella
        IF (IDGENPROC <> IDGENPROCOLD) THEN
          INSTENORISTORICI(TUPLAFASCPROVV, IDGENPROC, DEF, PAR_DATA_FINE);
          IDGENPROCOLD := IDGENPROC;
        END IF;

        --fine bvn
      END IF; /* Fine if su Decreto Ordinanza */
    END LOOP;
    CLOSE CURFASCICOLI;

    DBMS_OUTPUT.PUT_LINE('analisiFascicoliDepositati: fine. Num fasc depositati ->' ||
                         CONTARECORD);

  END ANALISIFASCICOLIDEPOSITATI;

  /*
   La funzione restituisce il numero di procedimenti estratti che erano nello
   stato "Pendenti Inizio Periodo".
   Tale valutazione viene fatta confrontando la data di iscrizione del procedimento
   con la data di inizio; sono conteggiati gli oggetti collegati ai procedimenti che
   hanno data di iscrizione < data inizio.
   I procedimenti sono filtrati per oggetto e opzionalmente
   per magistrato.
  */
  -- modificato da Michele 02/12/2008
  FUNCTION CONTAPENDENTIINIZIOPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                         PAR_COD_OGGETTO    IN VARCHAR2,
                                         PAR_DATA_INI       IN VARCHAR2,
                                         PAR_DATA_FINE      IN VARCHAR2,
                                         PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN

    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy'));
        -- AND ( trunc(FAS_SIU_DATA_ISCRIZIONE, 'dd') < to_date(par_data_ini,'dd/mm/yyyy'));
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy'));
      END IF;

    ELSE

      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy'));
        -- AND ( trunc(FAS_SIU_DATA_ISCRIZIONE, 'dd') < to_date(par_data_ini,'dd/mm/yyyy'));
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy'));
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTAPENDENTIINIZIOPERIODOMAG;

  /*
   La funzione restituisce il numero di procedimenti estratti che erano nello
   stato "Pendenti Inizio Periodo".
   Tale valutazione viene fatta confrontando la data di iscrizione del procedimento
   con la data di inizio; sono conteggiati gli oggetti collegati ai procedimenti che
   hanno data di iscrizione < data inizio.
   I procedimenti sono filtrati per magistrato relatore.
  */

  FUNCTION CONTAPENDENTIINIZIOPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                         PAR_DATA_INI       IN VARCHAR2,
                                         PAR_DATA_FINE      IN VARCHAR2,
                                         PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN

    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND (TRUNC(TEN_DATA_INS, 'dd') <
             TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy'));
      -- AND ( trunc(FAS_SIU_DATA_ISCRIZIONE, 'dd') < to_date(par_data_ini,'dd/mm/yyyy'));
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND (TRUNC(TEN_DATA_INS, 'dd') <
             TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy'));
      -- AND ( trunc(FAS_SIU_DATA_ISCRIZIONE, 'dd') < to_date(par_data_ini,'dd/mm/yyyy'));
    END IF;

    RETURN RETVALUE;

  END CONTAPENDENTIINIZIOPERIODOMAG;

  /*
   La funzione restituisce il numero di procedimenti estratti che risultino nello stato
   "Sopravvenuti" ovvero iscritti nel periodo di riferimento.
   Tale valutazione viene fatta confrontando la data di iscrizione del procedimento
   con data di inizio e data di fine.
   Sono conteggiati gli oggetti collegati ai procedimenti che
   hanno data di iscrizione compresa nell'intervallo.
   Il confronto tra date viene fatto solo con la data di inizio
   perch� quello con la data di fine � gi� stato fatto all'atto
   dell'estrazione.
   I procedimenti sono filtrati per oggetto e opzionalmente
   per magistrato.
  */

  -- modificato da Michele 02/12/2008
  FUNCTION CONTASOPRAVVENUTIMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                PAR_COD_OGGETTO    IN VARCHAR2,
                                PAR_DATA_INI       IN VARCHAR2,
                                PAR_DATA_FINE      IN VARCHAR2,
                                PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TRUNC(TEN_DATA_INS, 'dd') >=
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy');
        -- AND trunc( FAS_SIU_DATA_ISCRIZIONE, 'dd') >= to_date(par_data_ini,'dd/mm/yyyy');
        --AND FAS_SIU_DATA_ISCRIZIONE <= to_date(par_data_fine,'dd/mm/yyyy');
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TRUNC(TEN_DATA_INS, 'dd') >=
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy');
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TRUNC(TEN_DATA_INS, 'dd') >=
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy');
        -- AND trunc( FAS_SIU_DATA_ISCRIZIONE, 'dd') >= to_date(par_data_ini,'dd/mm/yyyy');
        --AND FAS_SIU_DATA_ISCRIZIONE <= to_date(par_data_fine,'dd/mm/yyyy');
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TRUNC(TEN_DATA_INS, 'dd') >=
               TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy');
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTASOPRAVVENUTIMAG;

  /*
   La funzione restituisce il numero di procedimenti estratti che risultino nello stato
   "Sopravvenuti" ovvero iscritti nel periodo di riferimento.
   Tale valutazione viene fatta confrontando la data di iscrizione del procedimento
   con data di inizio e data di fine.
   Sono conteggiati gli oggetti collegati ai procedimenti che
   hanno data di iscrizione compresa nell'intervallo.
   Il confronto tra date viene fatto solo con la data di inizio
   perch� quello con la data di fine � gi� stato fatto all'atto
   dell'estrazione.
   I procedimenti sono filtrati per magistrato relatore.
  */

  FUNCTION CONTASOPRAVVENUTIMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                PAR_DATA_INI       IN VARCHAR2,
                                PAR_DATA_FINE      IN VARCHAR2,
                                PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN

    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND TRUNC(TEN_DATA_INS, 'dd') >=
             TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy')
         AND TRUNC(TEN_DATA_INS, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy');
      -- AND trunc( FAS_SIU_DATA_ISCRIZIONE, 'dd') >= to_date(par_data_ini,'dd/mm/yyyy');
      -- AND FAS_SIU_DATA_ISCRIZIONE <= to_date(par_data_fine,'dd/mm/yyyy');
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND TRUNC(TEN_DATA_INS, 'dd') >=
             TO_DATE(PAR_DATA_INI, 'dd/mm/yyyy')
         AND TRUNC(TEN_DATA_INS, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy');
      -- AND trunc( FAS_SIU_DATA_ISCRIZIONE, 'dd') >= to_date(par_data_ini,'dd/mm/yyyy');
      -- AND FAS_SIU_DATA_ISCRIZIONE <= to_date(par_data_fine,'dd/mm/yyyy');
    END IF;

    RETURN RETVALUE;

  END CONTASOPRAVVENUTIMAG;

  /*
   La funzione restituisce il numero di procedimenti estratti che risultino nello stato
   "Pendenti Fine Periodo" ovvero non definiti alla data di fine periodo di riferimento.
   iscritti nel periodo di riferimento.
   Ricadono in questa categoria tutti gli oggetti con flag di non DEFINITO.
   I procedimenti sono filtrati per oggetto e opzionalmente
   per magistrato.
  */
  -- modificato da Michele 02/12/2008
  FUNCTION CONTAPENDENTIFINEPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                       PAR_COD_OGGETTO    IN VARCHAR2,
                                       PAR_DATA_INI       VARCHAR2,
                                       PAR_DATA_FINE      VARCHAR2,
                                       PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy'))
           AND DEFINITO = 'N';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy'))
           AND DEFINITO = 'N';
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy'))
           AND DEFINITO = 'N';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND (TRUNC(TEN_DATA_INS, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy'))
           AND DEFINITO = 'N';
      END IF;
    END IF;
    RETURN RETVALUE;

  END CONTAPENDENTIFINEPERIODOMAG;

  /*
   La funzione restituisce il numero di procedimenti estratti che risultino nello stato
   "Pendenti Fine Periodo" ovvero non definiti alla data di fine periodo di riferimento.
   iscritti nel periodo di riferimento.
   Ricadono in questa categoria tutti gli oggetti con flag di non DEFINITO.
   I procedimenti sono filtrati per magistrato relatore.
  */

  FUNCTION CONTAPENDENTIFINEPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                       PAR_DATA_INI       VARCHAR2,
                                       PAR_DATA_FINE      VARCHAR2,
                                       PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN

    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND (TRUNC(TEN_DATA_INS, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy'))
         AND DEFINITO = 'N';
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND (TRUNC(TEN_DATA_INS, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy'))
         AND DEFINITO = 'N';
    END IF;

    RETURN RETVALUE;

  END CONTAPENDENTIFINEPERIODOMAG;

  /*
   La funzione restituisce il numero di procedimenti estratti che risultino nello stato
   "DEFINITO NEL PERIODO" ovvero che siano stati definiti all'interno del periodo
   di riferimento.
   Ricadono in questa categoria tutti gli oggetti con flag di  DEFINITO.
   I procedimenti sono filtrati per oggetto e opzionalmente
   per magistrato.
  */
  -- modificato da Michele 02/12/2008
  FUNCTION CONTADEFINITINELPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                      PAR_COD_OGGETTO    IN VARCHAR2,
                                      PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND DEFINITO = 'S';
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND DEFINITO = 'S';
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTADEFINITINELPERIODOMAG;

  /*
   La funzione restituisce il numero di procedimenti estratti che risultino nello stato
   "DEFINITO NEL PERIODO" ovvero che siano stati definiti all'interno del periodo
   di riferimento.
   Ricadono in questa categoria tutti gli oggetti con flag di  DEFINITO.
   I procedimenti sono filtrati per magistrato relatore.
  */

  FUNCTION CONTADEFINITINELPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                      PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND DEFINITO = 'S';
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND DEFINITO = 'S';
    END IF;

    RETURN RETVALUE;

  END CONTADEFINITINELPERIODOMAG;

  /*
    La funzione restituisce il numero di procedimenti nello stato "DEFINITO NEL PERIODO"
    per un determinato COD_OGGETTO_TENORE e per un determinato COD_ESITO_STATISTICA
  */
  -- modificato da Michele 02/12/2008
  FUNCTION CONTADEFINITIXESITOPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                         PAR_COD_OGGETTO    IN VARCHAR2,
                                         PAR_COD_ESITO_STAT IN VARCHAR2,
                                         PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_STATISTICA =
               PAR_COD_ESITO_STAT
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_STATISTICA =
               PAR_COD_ESITO_STAT
           AND DEFINITO = 'S';
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_STATISTICA =
               PAR_COD_ESITO_STAT
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_STATISTICA =
               PAR_COD_ESITO_STAT
           AND DEFINITO = 'S';
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTADEFINITIXESITOPERIODOMAG;

  /*
    La funzione restituisce il numero di procedimenti nello stato "DEFINITO NEL PERIODO"
    per un determinato COD_MAGISTRATO e per un determinato COD_ESITO_STATISTICA
  */

  FUNCTION CONTADEFINITIXESITOPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                         PAR_COD_ESITO_STAT IN VARCHAR2,
                                         PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_STATISTICA =
             PAR_COD_ESITO_STAT
         AND DEFINITO = 'S';
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_STATISTICA =
             PAR_COD_ESITO_STAT
         AND DEFINITO = 'S';
    END IF;

    RETURN RETVALUE;

  END CONTADEFINITIXESITOPERIODOMAG;

  --------- nuovo 8-2-2008 -----------------------------

  /*
  La funzione restituisce il numero di procedimenti nello stato "DEFINITO NEL PERIODO"
  per un determinato COD_OGGETTO_TENORE ed eventualmente  per un determinato MAGISTRATO
    che siano stati definiti come: "Iscritto per errore" (cod. 94) .
    */
  -- modificato da Michele 02/12/2008
  FUNCTION CONTADEFISCRITTIXERROREMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                      PAR_COD_OGGETTO    IN VARCHAR2,
                                      PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.TIPO_DEFINIZIONE = '94'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.TIPO_DEFINIZIONE = '94'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.TIPO_DEFINIZIONE = '94'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.TIPO_DEFINIZIONE = '94'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTADEFISCRITTIXERROREMAG;

  -----------------------------------------------------

  /*
  La funzione restituisce il numero di procedimenti nello stato "DEFINITO NEL PERIODO"
  per un determinato MAGISTRATO che siano stati definiti come: "Iscritto per errore" (cod. 94) .
  */

  FUNCTION CONTADEFISCRITTIXERROREMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                      PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND ISP_ESTRAZIONE_OGGETTI_TRIB.TIPO_DEFINIZIONE = '94'
         AND TEN_DATA_FINE IS NULL
         AND DEFINITO = 'S';
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND ISP_ESTRAZIONE_OGGETTI_TRIB.TIPO_DEFINIZIONE = '94'
         AND TEN_DATA_FINE IS NULL
         AND DEFINITO = 'S';
    END IF;

    RETURN RETVALUE;

  END CONTADEFISCRITTIXERROREMAG;

  /*
    La funzione restituisce il numero di oggetti cancellati
    nel periodo per un determinato COD_OGGETTO_TENORE
  */

  FUNCTION CONTACANCELLATIPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                     PAR_COD_OGGETTO    IN VARCHAR2,
                                     PAR_COD_MAGISTRATO IN VARCHAR2,
                                     PAR_DATA_INI       IN VARCHAR2,
                                     PAR_DATA_FINE      IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TEN_DATA_FINE IS NOT NULL
              -- AND TRUNC( TEN_DATA_FINE, 'dd') >= TO_DATE(par_data_ini,'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_FINE, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TEN_DATA_FINE IS NOT NULL
              -- AND TRUNC( TEN_DATA_FINE, 'dd') >= TO_DATE(par_data_ini,'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_FINE, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')
           AND DEFINITO = 'S';
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TEN_DATA_FINE IS NOT NULL
              -- AND TRUNC( TEN_DATA_FINE, 'dd') >= TO_DATE(par_data_ini,'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_FINE, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND TEN_DATA_FINE IS NOT NULL
              -- AND TRUNC( TEN_DATA_FINE, 'dd') >= TO_DATE(par_data_ini,'dd/mm/yyyy')
           AND TRUNC(TEN_DATA_FINE, 'dd') <=
               TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')
           AND DEFINITO = 'S';
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTACANCELLATIPERIODOMAG;

  /*
    La funzione restituisce il numero di oggetti cancellati
    nel periodo per un determinato COD_MAGISTRATO
  */

  FUNCTION CONTACANCELLATIPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                     PAR_COD_MAGISTRATO IN VARCHAR2,
                                     PAR_DATA_INI       IN VARCHAR2,
                                     PAR_DATA_FINE      IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND TEN_DATA_FINE IS NOT NULL
            -- AND TRUNC( TEN_DATA_FINE, 'dd') >= TO_DATE(par_data_ini,'dd/mm/yyyy')
         AND TRUNC(TEN_DATA_FINE, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')
         AND DEFINITO = 'S';
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND TEN_DATA_FINE IS NOT NULL
            -- AND TRUNC( TEN_DATA_FINE, 'dd') >= TO_DATE(par_data_ini,'dd/mm/yyyy')
         AND TRUNC(TEN_DATA_FINE, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy')
         AND DEFINITO = 'S';
    END IF;

    RETURN RETVALUE;

  END CONTACANCELLATIPERIODOMAG;

  /*
    La funzione restituisce il numero di oggetti unificati
    nel periodo per un determinato COD_OGGETTO_TENORE
  */

  FUNCTION CONTAUNIFICATIPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                    PAR_COD_OGGETTO    IN VARCHAR2,
                                    PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND FAS_SIU_COD_STATO_FASCICOLO = '05'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND FAS_SIU_COD_STATO_FASCICOLO = '05'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND FAS_SIU_COD_STATO_FASCICOLO = '05'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND FAS_SIU_COD_STATO_FASCICOLO = '05'
           AND TEN_DATA_FINE IS NULL
           AND DEFINITO = 'S';
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTAUNIFICATIPERIODOMAG;

  /*
    La funzione restituisce il numero di oggetti unificati
    nel periodo per un determinato COD_MAGISTRATO
  */

  FUNCTION CONTAUNIFICATIPERIODOMAG(PAR_COD_UFFICIO    IN VARCHAR2,
                                    PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO = PAR_COD_MAGISTRATO
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND FAS_SIU_COD_STATO_FASCICOLO = '05'
         AND TEN_DATA_FINE IS NULL
         AND DEFINITO = 'S';
    ELSE
      SELECT COUNT(*)
        INTO RETVALUE
        FROM ISP_ESTRAZIONE_OGGETTI_TRIB
       WHERE COD_MAGISTRATO IS NULL
         AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
         AND FAS_SIU_COD_STATO_FASCICOLO = '05'
         AND TEN_DATA_FINE IS NULL
         AND DEFINITO = 'S';
    END IF;

    RETURN RETVALUE;

  END CONTAUNIFICATIPERIODOMAG;
 
  -- MEV9 aggiunto contatore per i fascicoli con ammissione provvisoria non 
  -- ancora confermati o confermati
  FUNCTION CONTA_APP_PROVVISORIE(PAR_COD_UFFICIO    IN VARCHAR2,
                                 PAR_COD_OGGETTO    IN VARCHAR2,
                                 PAR_COD_MAGISTRATO IN VARCHAR2)
    RETURN INTEGER IS

    RETVALUE INTEGER := 0;

  BEGIN
    IF (PAR_COD_MAGISTRATO IS NOT NULL) THEN
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_TENORE = '0270'
           -- AND ISP_ESTRAZIONE_OGGETTI_TRIB.FAS_SIU_COD_STATO_FASCICOLO = '24'
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND COD_MAGISTRATO = PAR_COD_MAGISTRATO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_TENORE = '0270'
           -- AND ISP_ESTRAZIONE_OGGETTI_TRIB.FAS_SIU_COD_STATO_FASCICOLO = '24'
           AND DEFINITO = 'S';
      END IF;
    ELSE
      IF (PAR_COD_OGGETTO IS NOT NULL) THEN
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE = PAR_COD_OGGETTO
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_TENORE = '0270'
           -- AND ISP_ESTRAZIONE_OGGETTI_TRIB.FAS_SIU_COD_STATO_FASCICOLO = '24'
           AND DEFINITO = 'S';
      ELSE
        SELECT COUNT(*)
          INTO RETVALUE
          FROM ISP_ESTRAZIONE_OGGETTI_TRIB
         WHERE COD_OGGETTO_TENORE IN
               (SELECT COD_MOTIVO
                  FROM ISP_MOTIVO_OGGETTO_SELEZIONATI
                 WHERE COD_UFFICIO = PAR_COD_UFFICIO)
           AND FAS_SIU_CHIAVE_UFFICIO = PAR_COD_UFFICIO
           AND ISP_ESTRAZIONE_OGGETTI_TRIB.COD_ESITO_TENORE = '0270'
           -- AND ISP_ESTRAZIONE_OGGETTI_TRIB.FAS_SIU_COD_STATO_FASCICOLO = '24'
           AND DEFINITO = 'S';
      END IF;
    END IF;

    RETURN RETVALUE;

  END CONTA_APP_PROVVISORIE; 

  /*
     -- Questa funzione analizza gli Oggetti nella
     -- tabella ISP_ESTRAZIONE_OGGETTI_TRIB, calcola i
     -- conteggi statistici ad essi relativi e memorizza
     -- i risultati nella tabella ISP_CONTEGGIO_OGGETTI.
  */

  PROCEDURE CREASTATISTICAOGGETTI(
                                  -- modificato da Michele 25/11/2008
                                  PAR_UFFICIO        IN VARCHAR2,
                                  PAR_COD_MAGISTRATO IN VARCHAR2,
                                  PAR_DATA_INIZIO    IN VARCHAR2,
                                  PAR_DATA_FINE      IN VARCHAR2) IS

    LISTAOGGETTI CURDECODIFICAOGGETTI%ROWTYPE;
    CONTARECORD  INTEGER := 0;

    -- Tupla utilizzata per l'operazione di inserimento
    TUPLASTATISTICA ISP_CONTEGGIO_OGGETTI%ROWTYPE;

    COD_MAGISTRATO VARCHAR2(20);
    -- numero degli oggetti definiti nel periodo
    NUMDEFINITIPERIODO INTEGER := 0;

  BEGIN

    -- dbms_output.put_line ('creaStatisticaOggetti: inizio ' || systimestamp);

    DBMS_OUTPUT.PUT_LINE('par_cod_magistrato: ' || PAR_COD_MAGISTRATO);

    IF (PAR_COD_MAGISTRATO = '0') THEN
      COD_MAGISTRATO := NULL;
    ELSE
      COD_MAGISTRATO := PAR_COD_MAGISTRATO;
    END IF;
    DBMS_OUTPUT.PUT_LINE('cod_magistrato: ' || COD_MAGISTRATO);

    -- reset tabella
    -- modificato da Michele 25/11/2008
    DELETE FROM ISP_CONTEGGIO_OGGETTI
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO;

    CONTARECORD := 0;
    -- FOR listaOggetti IN curDecodificaOggetti LOOP
    OPEN CURDECODIFICAOGGETTI(PAR_UFFICIO);
    LOOP
      FETCH CURDECODIFICAOGGETTI
        INTO LISTAOGGETTI;
      EXIT WHEN CURDECODIFICAOGGETTI%NOTFOUND;

      CONTARECORD                  := CONTARECORD + 1;
      NUMDEFINITIPERIODO           := CONTADEFINITINELPERIODOMAG(PAR_UFFICIO,
                                                                 LISTAOGGETTI.RV_LOW_VALUE,
                                                                 COD_MAGISTRATO);
      TUPLASTATISTICA.COD_OGGETTO  := LISTAOGGETTI.RV_LOW_VALUE;
      TUPLASTATISTICA.DESC_OGGETTO := LISTAOGGETTI.RV_MEANING;

      TUPLASTATISTICA.NUM_PENDENTI_INIZIO := CONTAPENDENTIINIZIOPERIODOMAG(PAR_UFFICIO,
                                                                           LISTAOGGETTI.RV_LOW_VALUE,
                                                                           PAR_DATA_INIZIO,
                                                                           PAR_DATA_FINE,
                                                                           COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_SOPRAVVENUTI    := CONTASOPRAVVENUTIMAG(PAR_UFFICIO,
                                                                  LISTAOGGETTI.RV_LOW_VALUE,
                                                                  PAR_DATA_INIZIO,
                                                                  PAR_DATA_FINE,
                                                                  COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_PENDENTI_FINE   := CONTAPENDENTIFINEPERIODOMAG(PAR_UFFICIO,
                                                                         LISTAOGGETTI.RV_LOW_VALUE,
                                                                         PAR_DATA_INIZIO,
                                                                         PAR_DATA_FINE,
                                                                         COD_MAGISTRATO);
      --tuplaStatistica.Num_Def_Esito1 := ContaDefinitiNelPeriodoMag(par_ufficio, listaOggetti.Rv_Low_Value, cod_magistrato);
      TUPLASTATISTICA.NUM_DEF_ESITO1 := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                      LISTAOGGETTI.RV_LOW_VALUE,
                                                                      '1',
                                                                      COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO2 := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                      LISTAOGGETTI.RV_LOW_VALUE,
                                                                      '2',
                                                                      COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO3 := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                      LISTAOGGETTI.RV_LOW_VALUE,
                                                                      '3',
                                                                      COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO4 := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                      LISTAOGGETTI.RV_LOW_VALUE,
                                                                      '4',
                                                                      COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO5 := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                      LISTAOGGETTI.RV_LOW_VALUE,
                                                                      '5',
                                                                      COD_MAGISTRATO);
      -- MEV9 si classificano gli iscritti provvisoriamente                                                               
      TUPLASTATISTICA.NUM_APP_PROVV := CONTA_APP_PROVVISORIE(PAR_UFFICIO,
                                                             LISTAOGGETTI.RV_LOW_VALUE,
                                                             COD_MAGISTRATO);     
      -- MEV9 - FINE                                                               
      -- N.ro procedimenti iscritti per errore
      TUPLASTATISTICA.NUM_DEF_ISC_ERR := CONTADEFISCRITTIXERROREMAG(PAR_UFFICIO,
                                                                    LISTAOGGETTI.RV_LOW_VALUE,
                                                                    COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_CANCELLATI  := CONTACANCELLATIPERIODOMAG(PAR_UFFICIO,
                                                                   LISTAOGGETTI.RV_LOW_VALUE,
                                                                   COD_MAGISTRATO,
                                                                   PAR_DATA_INIZIO,
                                                                   PAR_DATA_FINE);
      TUPLASTATISTICA.NUM_UNIFICATI   := CONTAUNIFICATIPERIODOMAG(PAR_UFFICIO,
                                                                  LISTAOGGETTI.RV_LOW_VALUE,
                                                                  COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO6  := NUMDEFINITIPERIODO -
                                         (TUPLASTATISTICA.NUM_DEF_ESITO1 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO2 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO3 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO4 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO5 +
                                         TUPLASTATISTICA.NUM_APP_PROVV + -- MEV9
                                         TUPLASTATISTICA.NUM_CANCELLATI +
                                         TUPLASTATISTICA.NUM_UNIFICATI +
                                         TUPLASTATISTICA.NUM_DEF_ISC_ERR);
      -- Inserimento nella tabella dei Conteggi solo se uno dei contatori � maggiore di 0
      IF (TUPLASTATISTICA.NUM_PENDENTI_INIZIO > 0 OR
         (TUPLASTATISTICA.NUM_SOPRAVVENUTI > 0) OR
         (NUMDEFINITIPERIODO > 0) OR
         (TUPLASTATISTICA.NUM_PENDENTI_FINE > 0) OR
         (TUPLASTATISTICA.NUM_CANCELLATI > 0)) THEN

        -- Classificazione del contenuto statistico
        TUPLASTATISTICA.DESC_CONTENUTO_STATIS := CODCONTENUTOSTATISTICO(LISTAOGGETTI.RV_HIGH_VALUE);

        -- modificato da Michele 25/11/2008
        TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO := PAR_UFFICIO;

        -- Inserimento
        -- modificato da Michele 25/11/2008
        INSERT INTO ISP_CONTEGGIO_OGGETTI
          (ISP_CONTEGGIO_OGGETTI.COD_OGGETTO,
           ISP_CONTEGGIO_OGGETTI.DESC_OGGETTO,
           NUM_PENDENTI_INIZIO,
           NUM_SOPRAVVENUTI,
           NUM_DEF_ESITO1,
           NUM_DEF_ESITO2,
           NUM_DEF_ESITO3,
           NUM_DEF_ESITO4,
           NUM_DEF_ESITO5,
           NUM_DEF_ESITO6,
           NUM_DEF_ISC_ERR,
           NUM_PENDENTI_FINE,
           NUM_APP_PROVV, --MEV9
           DESC_CONTENUTO_STATIS,
           FAS_SIU_CHIAVE_UFFICIO,
           NUM_CANCELLATI,
           NUM_UNIFICATI)
        VALUES
          (TUPLASTATISTICA.COD_OGGETTO,
           TUPLASTATISTICA.DESC_OGGETTO,
           TUPLASTATISTICA.NUM_PENDENTI_INIZIO,
           TUPLASTATISTICA.NUM_SOPRAVVENUTI,
           TUPLASTATISTICA.NUM_DEF_ESITO1,
           TUPLASTATISTICA.NUM_DEF_ESITO2,
           TUPLASTATISTICA.NUM_DEF_ESITO3,
           TUPLASTATISTICA.NUM_DEF_ESITO4,
           TUPLASTATISTICA.NUM_DEF_ESITO5,
           TUPLASTATISTICA.NUM_DEF_ESITO6,
           TUPLASTATISTICA.NUM_DEF_ISC_ERR,
           TUPLASTATISTICA.NUM_PENDENTI_FINE,
           TUPLASTATISTICA.NUM_APP_PROVV,  -- MEV9
           TUPLASTATISTICA.DESC_CONTENUTO_STATIS,
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO,
           TUPLASTATISTICA.NUM_CANCELLATI,
           TUPLASTATISTICA.NUM_UNIFICATI);

      END IF;
    END LOOP;
    CLOSE CURDECODIFICAOGGETTI;
    DBMS_OUTPUT.PUT_LINE('N.ro oggetti nella CG_REF_CODES : ' ||
                         CONTARECORD);

     dbms_output.put_line ('creaStatisticaOggetti: fine ' || TO_CHAR(systimestamp, 'hh:mi:ss.ff'));

  END CREASTATISTICAOGGETTI;

  /*
     -- Questa funzione analizza i Relatori (Magistrati o Esperti) nella
     -- tabella ISP_ESTRAZIONE_OGGETTI_TRIB, calcola i
     -- conteggi statistici ad essi relativi e memorizza
     -- i risultati nella tabella ISP_CONTEGGIO_RELATORI.
  */

  PROCEDURE CREASTATISTICARELATORI(PAR_UFFICIO     IN VARCHAR2,
                                   PAR_DATA_INIZIO IN VARCHAR2,
                                   PAR_DATA_FINE   IN VARCHAR2) IS

    CURSOR CURRELATORI IS
      SELECT DISTINCT COD_MAGISTRATO FROM ISP_ESTRAZIONE_OGGETTI_TRIB;

    LISTARELATORI CURRELATORI%ROWTYPE;
    CONTARECORD   INTEGER := 0;

    -- Tupla utilizzata per l'operazione di inserimento
    TUPLASTATISTICA ISP_CONTEGGIO_RELATORI%ROWTYPE;

    COD_MAGISTRATO VARCHAR2(20);
    -- numero degli oggetti definiti nel periodo
    NUMDEFINITIPERIODO INTEGER := 0;

  BEGIN

    DBMS_OUTPUT.PUT_LINE('creaStatisticaRelatori: inizio ');
    DBMS_OUTPUT.PUT_LINE('creaStatisticaRelatori: PAR_UFFICIO     = '||PAR_UFFICIO);
    DBMS_OUTPUT.PUT_LINE('creaStatisticaRelatori: PAR_DATA_INIZIO = '||PAR_DATA_INIZIO);
    DBMS_OUTPUT.PUT_LINE('creaStatisticaRelatori: PAR_DATA_FINE   = '||PAR_DATA_FINE);

    -- reset tabella
    -- modificato da Michele 25/11/2008
    DELETE FROM ISP_CONTEGGIO_RELATORI
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO;

    CONTARECORD := 0;
    FOR LISTARELATORI IN CURRELATORI LOOP
      
      -- DBMS_OUTPUT.PUT_LINE('creaStatisticaRelatori: LISTARELATORI.COD_MAGISTRATO = '||LISTARELATORI.COD_MAGISTRATO);
     
      CONTARECORD := CONTARECORD + 1;
      -- modificato da Michele 02/12/2008
      NUMDEFINITIPERIODO                  := CONTADEFINITINELPERIODOMAG(PAR_UFFICIO,
                                                                        LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.COD_RELATORE        := LISTARELATORI.COD_MAGISTRATO;
      TUPLASTATISTICA.NUM_PENDENTI_INIZIO := CONTAPENDENTIINIZIOPERIODOMAG(PAR_UFFICIO,
                                                                           PAR_DATA_INIZIO,
                                                                           PAR_DATA_FINE,
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_SOPRAVVENUTI    := CONTASOPRAVVENUTIMAG(PAR_UFFICIO,
                                                                  PAR_DATA_INIZIO,
                                                                  PAR_DATA_FINE,
                                                                  LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_PENDENTI_FINE   := CONTAPENDENTIFINEPERIODOMAG(PAR_UFFICIO,
                                                                         PAR_DATA_INIZIO,
                                                                         PAR_DATA_FINE,
                                                                         LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO1      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           '1',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO2      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           '2',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO3      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           '3',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO4      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           '4',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO5      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           '5',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      -- MEV9 si classificano gli iscritti provvisoriamente                                                                    
      TUPLASTATISTICA.NUM_APP_PROVV       := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           '9',
                                                                           LISTARELATORI.COD_MAGISTRATO);                                                                    
      -- MEV9 - FINE                                                                    
                                                                          
      -- N.ro procedimenti iscritti per errore
      TUPLASTATISTICA.NUM_DEF_ISC_ERR := CONTADEFISCRITTIXERROREMAG(PAR_UFFICIO,
                                                                    LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_CANCELLATI  := CONTACANCELLATIPERIODOMAG(PAR_UFFICIO,
                                                                   LISTARELATORI.COD_MAGISTRATO,
                                                                   PAR_DATA_INIZIO,
                                                                   PAR_DATA_FINE);
      TUPLASTATISTICA.NUM_UNIFICATI   := CONTAUNIFICATIPERIODOMAG(PAR_UFFICIO,
                                                                  LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO6  := NUMDEFINITIPERIODO -
                                         (TUPLASTATISTICA.NUM_DEF_ESITO1 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO2 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO3 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO4 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO5 +
                                         TUPLASTATISTICA.NUM_APP_PROVV + -- MEV9
                                         TUPLASTATISTICA.NUM_CANCELLATI +
                                         TUPLASTATISTICA.NUM_UNIFICATI +
                                         TUPLASTATISTICA.NUM_DEF_ISC_ERR);

      -- Inserimento nella tabella dei Conteggi solo se uno dei contatori � maggiore di 0
      IF (TUPLASTATISTICA.NUM_PENDENTI_INIZIO > 0 OR
         (TUPLASTATISTICA.NUM_SOPRAVVENUTI > 0) OR
         (NUMDEFINITIPERIODO > 0) OR
         (TUPLASTATISTICA.NUM_PENDENTI_FINE > 0) OR
         (TUPLASTATISTICA.NUM_CANCELLATI > 0)) THEN

        -- modificato da Michele 25/11/2008
        TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO := PAR_UFFICIO;

        IF (TUPLASTATISTICA.COD_RELATORE IS NULL) THEN
          TUPLASTATISTICA.COD_RELATORE := 'privi di magistrato';
        END IF;

        -- Inserimento
        INSERT INTO ISP_CONTEGGIO_RELATORI
          (COD_RELATORE,
           FAS_SIU_CHIAVE_UFFICIO,
           NUM_PENDENTI_INIZIO,
           NUM_SOPRAVVENUTI,
           NUM_DEF_ESITO1,
           NUM_DEF_ESITO2,
           NUM_DEF_ESITO3,
           NUM_DEF_ESITO4,
           NUM_DEF_ESITO5,
           NUM_DEF_ESITO6,
           NUM_DEF_ISC_ERR,
           NUM_PENDENTI_FINE,
           NUM_CANCELLATI,
           NUM_APP_PROVV, -- MEV9
           NUM_UNIFICATI)
        VALUES
          (TUPLASTATISTICA.COD_RELATORE,
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO,
           TUPLASTATISTICA.NUM_PENDENTI_INIZIO,
           TUPLASTATISTICA.NUM_SOPRAVVENUTI,
           TUPLASTATISTICA.NUM_DEF_ESITO1,
           TUPLASTATISTICA.NUM_DEF_ESITO2,
           TUPLASTATISTICA.NUM_DEF_ESITO3,
           TUPLASTATISTICA.NUM_DEF_ESITO4,
           TUPLASTATISTICA.NUM_DEF_ESITO5,
           TUPLASTATISTICA.NUM_DEF_ESITO6,
           TUPLASTATISTICA.NUM_DEF_ISC_ERR,
           TUPLASTATISTICA.NUM_PENDENTI_FINE,
           TUPLASTATISTICA.NUM_CANCELLATI,
           TUPLASTATISTICA.NUM_APP_PROVV,   -- MEV9
           TUPLASTATISTICA.NUM_UNIFICATI);
      END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Relatori: fine ');

  END CREASTATISTICARELATORI;

  PROCEDURE CREASTATRELATORIMOTOGGSEL(PAR_UFFICIO     IN VARCHAR2,
                                      PAR_DATA_INIZIO IN VARCHAR2,
                                      PAR_DATA_FINE   IN VARCHAR2) IS

    CURSOR CURRELATORI IS
      SELECT COD_MAGISTRATO
        FROM ISP_RELATORE_SELEZIONATI
       WHERE COD_UFFICIO = PAR_UFFICIO;
    /*
    select distinct trib.cod_magistrato
      from isp_estrazione_oggetti_trib trib
      WHERE TRIB.COD_OGGETTO_TENORE in ( select cod_motivo
                                         from isp_motivo_oggetto_selezionati
                                        where cod_ufficio = par_ufficio );
    */
    --select distinct cod_magistrato from isp_estrazione_oggetti_trib where  fas_siu_chiave_ufficio = par_ufficio;

    LISTARELATORI CURRELATORI%ROWTYPE;
    CONTARECORD   INTEGER := 0;

    -- Tupla utilizzata per l'operazione di inserimento
    TUPLASTATISTICA ISP_CONTEGGIO_RELATORI%ROWTYPE;

    COD_MAGISTRATO VARCHAR2(20);
    -- numero degli oggetti definiti nel periodo
    NUMDEFINITIPERIODO INTEGER := 0;

  BEGIN

    DBMS_OUTPUT.PUT_LINE('creaStatRelatoriMotOggSel: inizio ');

    -- reset tabella
    -- modificato da Michele 25/11/2008
    DELETE FROM ISP_CONTEGGIO_RELATORI
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO;

    CONTARECORD := 0;
    FOR LISTARELATORI IN CURRELATORI LOOP
      CONTARECORD := CONTARECORD + 1;
      -- modificato da Michele 02/12/2008
      NUMDEFINITIPERIODO                  := CONTADEFINITINELPERIODOMAG(PAR_UFFICIO,
                                                                        NULL,
                                                                        LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.COD_RELATORE        := LISTARELATORI.COD_MAGISTRATO;
      TUPLASTATISTICA.NUM_PENDENTI_INIZIO := CONTAPENDENTIINIZIOPERIODOMAG(PAR_UFFICIO,
                                                                           NULL,
                                                                           PAR_DATA_INIZIO,
                                                                           PAR_DATA_FINE,
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_SOPRAVVENUTI    := CONTASOPRAVVENUTIMAG(PAR_UFFICIO,
                                                                  NULL,
                                                                  PAR_DATA_INIZIO,
                                                                  PAR_DATA_FINE,
                                                                  LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_PENDENTI_FINE   := CONTAPENDENTIFINEPERIODOMAG(PAR_UFFICIO,
                                                                         NULL,
                                                                         PAR_DATA_INIZIO,
                                                                         PAR_DATA_FINE,
                                                                         LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO1      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           NULL,
                                                                           '1',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO2      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           NULL,
                                                                           '2',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO3      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           NULL,
                                                                           '3',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO4      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           NULL,
                                                                           '4',
                                                                           LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO5      := CONTADEFINITIXESITOPERIODOMAG(PAR_UFFICIO,
                                                                           NULL,
                                                                           '5',
                                                                           LISTARELATORI.COD_MAGISTRATO);
                                                                          
       -- MEV9 2023.05.18 si classificano gli iscritti provvisoriamente                                                               
      TUPLASTATISTICA.NUM_APP_PROVV := CONTA_APP_PROVVISORIE(PAR_UFFICIO,
                                                             null,
                                                             LISTARELATORI.COD_MAGISTRATO);     
      -- MEV9 - FINE                                                                          
                                                                          
      -- N.ro procedimenti iscritti per errore
      TUPLASTATISTICA.NUM_DEF_ISC_ERR := CONTADEFISCRITTIXERROREMAG(PAR_UFFICIO,
                                                                    NULL,
                                                                    LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_CANCELLATI  := CONTACANCELLATIPERIODOMAG(PAR_UFFICIO,
                                                                   NULL,
                                                                   LISTARELATORI.COD_MAGISTRATO,
                                                                   PAR_DATA_INIZIO,
                                                                   PAR_DATA_FINE);
      TUPLASTATISTICA.NUM_UNIFICATI   := CONTAUNIFICATIPERIODOMAG(PAR_UFFICIO,
                                                                  NULL,
                                                                  LISTARELATORI.COD_MAGISTRATO);
      TUPLASTATISTICA.NUM_DEF_ESITO6  := NUMDEFINITIPERIODO -
                                         (TUPLASTATISTICA.NUM_DEF_ESITO1 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO2 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO3 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO4 +
                                         TUPLASTATISTICA.NUM_DEF_ESITO5 +
                                         TUPLASTATISTICA.NUM_APP_PROVV + -- MEV9 2023.05.18
                                         TUPLASTATISTICA.NUM_CANCELLATI +
                                         TUPLASTATISTICA.NUM_UNIFICATI +
                                         TUPLASTATISTICA.NUM_DEF_ISC_ERR);

      -- Inserimento nella tabella dei Conteggi solo se uno dei contatori � maggiore di 0

      --IF (tuplaStatistica.Num_Pendenti_Inizio >  0 OR (tuplaStatistica.Num_Sopravvenuti > 0) OR
      --(numDefinitiPeriodo > 0 ) OR (tuplaStatistica.Num_Pendenti_Fine > 0) OR (tuplaStatistica.Num_Cancellati > 0))
      --THEN

      -- modificato da Michele 25/11/2008
      TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO := PAR_UFFICIO;

      IF (TUPLASTATISTICA.COD_RELATORE IS NULL) THEN
        TUPLASTATISTICA.COD_RELATORE := 'privi di magistrato';
      END IF;

      -- Inserimento
      INSERT INTO ISP_CONTEGGIO_RELATORI
        (COD_RELATORE,
         FAS_SIU_CHIAVE_UFFICIO,
         NUM_PENDENTI_INIZIO,
         NUM_SOPRAVVENUTI,
         NUM_DEF_ESITO1,
         NUM_DEF_ESITO2,
         NUM_DEF_ESITO3,
         NUM_DEF_ESITO4,
         NUM_DEF_ESITO5,
         NUM_DEF_ESITO6,
         NUM_DEF_ISC_ERR,
         NUM_APP_PROVV, --MEV9 2023.05.18
         NUM_PENDENTI_FINE,
         NUM_CANCELLATI,
         NUM_UNIFICATI)
      VALUES
        (TUPLASTATISTICA.COD_RELATORE,
         TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO,
         TUPLASTATISTICA.NUM_PENDENTI_INIZIO,
         TUPLASTATISTICA.NUM_SOPRAVVENUTI,
         TUPLASTATISTICA.NUM_DEF_ESITO1,
         TUPLASTATISTICA.NUM_DEF_ESITO2,
         TUPLASTATISTICA.NUM_DEF_ESITO3,
         TUPLASTATISTICA.NUM_DEF_ESITO4,
         TUPLASTATISTICA.NUM_DEF_ESITO5,
         TUPLASTATISTICA.NUM_DEF_ESITO6,
         TUPLASTATISTICA.NUM_DEF_ISC_ERR,
         TUPLASTATISTICA.NUM_APP_PROVV,  -- MEV9 2023.05.18
         TUPLASTATISTICA.NUM_PENDENTI_FINE,
         TUPLASTATISTICA.NUM_CANCELLATI,
         TUPLASTATISTICA.NUM_UNIFICATI);
      --END IF;
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('creaStatRelatoriMotOggSel: fine ');

  END CREASTATRELATORIMOTOGGSEL;

  -- 20140129 - FI021 - FR022 - FA023 - FA024
  PROCEDURE SVUOTACONTEGGIOOGGETTI(PAR_UFFICIO IN VARCHAR2) IS
  BEGIN
    DELETE FROM ISP_CONTEGGIO_OGGETTI
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO;
    COMMIT;
  END SVUOTACONTEGGIOOGGETTI;

  -- Function and procedure implementations

  -- Function and procedure implementations

  PROCEDURE STATO_OGGETTI_SIUS_COMP_MAG(PAR_UFFICIO             IN VARCHAR2,
                                        PAR_DATA_INIZIO         IN VARCHAR2,
                                        PAR_DATA_FINE           IN VARCHAR2,
                                        PAR_CANC_ASS            IN VARCHAR2,
                                        PAR_COLLABORATORE       IN VARCHAR2,
                                        PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS

  BEGIN
    DBMS_OUTPUT.PUT_LINE('inizio ');

    INIZIALIZZA(PAR_UFFICIO);

    DBMS_OUTPUT.PUT_LINE('data inizio -> ' || PAR_DATA_INIZIO);
    DBMS_OUTPUT.PUT_LINE('codice ufficio -> ' || PAR_UFFICIO);

    DELETE FROM ISP_MOTIVO_OGGETTO
     WHERE COD_MOTIVO NOT IN (SELECT COD_MOTIVO
                                FROM STATIS.ISP_MOTIVO_OGGETTO_SELEZIONATI
                               WHERE STATIS.ISP_MOTIVO_OGGETTO_SELEZIONATI.COD_UFFICIO =
                                     PAR_UFFICIO);

    COMMIT;

    ANALISIFASCICOLIDEFINITI(PAR_UFFICIO,
                             PAR_DATA_INIZIO,
                             PAR_DATA_FINE,
                             PAR_CANC_ASS,
                             PAR_COLLABORATORE,
                             PAR_POSIZIONE_GIURIDICA);
    ANALISIFASCICOLIISCRITTI(PAR_UFFICIO,
                             PAR_DATA_FINE,
                             PAR_CANC_ASS,
                             PAR_COLLABORATORE,
                             PAR_POSIZIONE_GIURIDICA);
    ANALISIFASCICOLIDEPOSITATI(PAR_UFFICIO,
                               PAR_DATA_INIZIO,
                               PAR_DATA_FINE,
                               PAR_CANC_ASS,
                               PAR_COLLABORATORE,
                               PAR_POSIZIONE_GIURIDICA);

    --creaStatisticaOggetti(par_ufficio,par_ufficio, par_data_inizio,par_data_fine );

    -- Aggiorna Codice Esito Statistica per dicitura corretta in caso di oggetti Cancellati
    UPDATE ISP_ESTRAZIONE_OGGETTI_TRIB
       SET COD_ESITO_STATISTICA = '8'
     WHERE TEN_DATA_FINE IS NOT NULL;
    COMMIT;
    -- Aggiorna Codice Esito Statistica per dicitura corretta in caso di oggetti Unificati
    UPDATE ISP_ESTRAZIONE_OGGETTI_TRIB
       SET COD_ESITO_STATISTICA = '7'
     WHERE FAS_SIU_COD_STATO_FASCICOLO = '05'
       AND TEN_DATA_FINE IS NULL;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('fine ');
  END;

  PROCEDURE STATO_OGGETTI_SIUS(PAR_UFFICIO             IN VARCHAR2,
                               PAR_DATA_INIZIO         IN VARCHAR2,
                               PAR_DATA_FINE           IN VARCHAR2,
                               PAR_CANC_ASS            IN VARCHAR2,
                               PAR_COLLABORATORE       IN VARCHAR2,
                               PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS

  BEGIN
    DBMS_OUTPUT.PUT_LINE('inizio '||sysdate);

    INIZIALIZZA(PAR_UFFICIO);

    DBMS_OUTPUT.PUT_LINE('data inizio -> ' || PAR_DATA_INIZIO);

    DBMS_OUTPUT.PUT_LINE('codice ufficio -> ' || PAR_UFFICIO);

    ANALISIFASCICOLIDEFINITI(PAR_UFFICIO,
                             PAR_DATA_INIZIO,
                             PAR_DATA_FINE,
                             PAR_CANC_ASS,
                             PAR_COLLABORATORE,
                             PAR_POSIZIONE_GIURIDICA);
    ANALISIFASCICOLIISCRITTI(PAR_UFFICIO,
                             PAR_DATA_FINE,
                             PAR_CANC_ASS,
                             PAR_COLLABORATORE,
                             PAR_POSIZIONE_GIURIDICA);
    ANALISIFASCICOLIDEPOSITATI(PAR_UFFICIO,
                               PAR_DATA_INIZIO,
                               PAR_DATA_FINE,
                               PAR_CANC_ASS,
                               PAR_COLLABORATORE,
                               PAR_POSIZIONE_GIURIDICA);

    --creaStatisticaOggetti(par_ufficio,par_ufficio, par_data_inizio,par_data_fine );

    -- Aggiorna Codice Esito Statistica per dicitura corretta in caso di oggetti Cancellati
    UPDATE ISP_ESTRAZIONE_OGGETTI_TRIB
       SET COD_ESITO_STATISTICA = '8'
     WHERE TEN_DATA_FINE IS NOT NULL;
    COMMIT;
    -- Aggiorna Codice Esito Statistica per dicitura corretta in caso di oggetti Unificati
    UPDATE ISP_ESTRAZIONE_OGGETTI_TRIB
       SET COD_ESITO_STATISTICA = '7'
     WHERE FAS_SIU_COD_STATO_FASCICOLO = '05'
       AND TEN_DATA_FINE IS NULL;
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('fine ');
  END;

  /*
  A partire dall'ID del GENERALE_PROCEDIMENTO
  la funzione cerca nella tabella UDIENZA_PROCEDIMENTO la data
  iniziale e quella finale corrispondenti alla prima ed ultima
  fissazione Udienza. */
  PROCEDURE RICERCADATEUDIENZA(ID_GENERALE_PROC    IN NUMBER,
                               DATA_PRIMA_UDIENZA  OUT DATE,
                               DATA_ULTIMA_UDIENZA OUT DATE) IS

    -- select per la determinazione della data ultima
    -- Viene selezionata la data di inserimento pi� recente
    CURSOR CURUDIENZAPROCEDIMENTO1 IS
      SELECT U.DATA_UDIENZA
        FROM UDIENZA U
        JOIN UDIENZA_PROCEDIMENTO UP
          ON (U.ID_UDIENZA = UP.UDI_ID_UDIENZA AND
             UP.GEN_PRID_GENERALE_PROCEDIMENTO = ID_GENERALE_PROC)
       WHERE UP.FLAG_RINVIATA = 'F'
          OR UP.FLAG_RINVIATA = 'S'
       ORDER BY U.DATA_UDIENZA DESC;

    -- select per la determinazione della data prima
    --
    -- IN DATA 25/7/2008 INSERITE MODIFICHE PER FLAG_RINVIATA ='M' E VALORIZZAZIONE DI EVE_ID_EVENTO
    --
    CURSOR CURUDIENZAPROCEDIMENTO2 IS
      SELECT U.DATA_UDIENZA, UP.FLAG_RINVIATA
        FROM UDIENZA U
        JOIN UDIENZA_PROCEDIMENTO UP
          ON (U.ID_UDIENZA = UP.UDI_ID_UDIENZA AND
             UP.GEN_PRID_GENERALE_PROCEDIMENTO = ID_GENERALE_PROC)
       WHERE (UP.FLAG_RINVIATA = 'P' OR UP.FLAG_RINVIATA = 'F' OR
             UP.FLAG_RINVIATA = 'R' OR UP.FLAG_RINVIATA = 'M')
         AND UP.EVE_ID_EVENTO IS NOT NULL
       ORDER BY U.DATA_UDIENZA ASC;

    FLAGRINVIO UDIENZA_PROCEDIMENTO.FLAG_RINVIATA%TYPE;

    DATO_NON_TROVATO EXCEPTION;

  BEGIN
    DBMS_OUTPUT.PUT_LINE('inizio ricercaDateUdienza');

    -- Data Ultima Udienza � la data di inserimento pi� alta
    OPEN CURUDIENZAPROCEDIMENTO1;
    FETCH CURUDIENZAPROCEDIMENTO1
      INTO DATA_ULTIMA_UDIENZA;
    CLOSE CURUDIENZAPROCEDIMENTO1;

    DBMS_OUTPUT.PUT_LINE('Data Ultima Udienza: ' ||
                         TO_CHAR(DATA_ULTIMA_UDIENZA, 'dd/mm/yyyy'));

    -- Data Prima Udienza � la data di inserimento pi� bassa
    OPEN CURUDIENZAPROCEDIMENTO2;
    FETCH CURUDIENZAPROCEDIMENTO2
      INTO DATA_PRIMA_UDIENZA, FLAGRINVIO;

    WHILE (CURUDIENZAPROCEDIMENTO2%FOUND AND FLAGRINVIO = 'P') LOOP
      FETCH CURUDIENZAPROCEDIMENTO2
        INTO DATA_PRIMA_UDIENZA, FLAGRINVIO;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Data Prima Udienza: ' ||
                         TO_CHAR(DATA_PRIMA_UDIENZA, 'dd/mm/yyyy'));

    IF (DATA_ULTIMA_UDIENZA IS NULL) THEN
      DBMS_OUTPUT.PUT_LINE('Non trovo la fissazione udienza ');
      DBMS_OUTPUT.PUT_LINE('ID GEN.PROC->' || ID_GENERALE_PROC);
    END IF;
    DBMS_OUTPUT.PUT_LINE('fine ricercaDateUdienza');

  END RICERCADATEUDIENZA;

  /*
  Questa funzione estrae i Procedimenti depositati
  nel periodo di riferimento.
    */
  PROCEDURE ESTRAIPROCEDIMENTIDEPOSITATI(PAR_UFFICIO             IN VARCHAR2,
                                         PAR_DATA_INIZIO         IN VARCHAR2,
                                         PAR_DATA_FINE           IN VARCHAR2,
                                         PAR_CANC_ASS            IN VARCHAR2,
                                         PAR_COLLABORATORE       IN VARCHAR2,
                                         PAR_POSIZIONE_GIURIDICA IN VARCHAR2) IS

    COD_CANCELLERIA CANCELLERIA_ASSEGNATARIA.COD_CANCELLERIA_ASSEGNATARIA%TYPE := NULL;

    -- dichiarazione del cursore  unico di ricerca fascicoli associati ad ordinanze o decreti
    --
    --  25/7/2008 INSERITA MODIFICA PER SCARTO DECRETO/ORDINANZE IRREPERIBILITA', FISSAZIONE UDIENZA E RINVIO UDIENZA
    --
    CURSOR CURFASCICOLIPROVVEDIMENTI IS
      SELECT F.ID_FASCICOLO_SIUS,
             F.CHIAVE_ANNO,
             F.CHIAVE_PROGR,
             F.CHIAVE_UFFICIO,
             F.COD_STATO_FASCICOLO,
             F.DATA_INSERIMENTO,
             F.DATA_ISCRIZIONE,
             F.DATA_DEFINIZIONE,
             O.DATA_DEPOSITO            DATA_DEP_ORD,
             O.ID_DEPOSITO_ORDINANZA_PC ID_ORD,
             D.DATA_DEPOSITO            DATA_DEP_DEC,
             D.ID_DEPOSITO_DECRETO      ID_DEC,
             --bvn
             OO.DATA_DEPOSITO        DATA_DEP_SEN,
             OO.ID_DEPOSITO_SENTENZA ID_SEN,
             --fine bvn
             E.DATA_EMISSIONE,
             E.ID_EVENTO,
             G.DATA_ARRIVO_CANCELLERIA,
             G.ID_GENERALE_PROCEDIMENTO,
             G.COD_POSIZIONE_GIURIDICA
        FROM FASCICOLO_SIUS F
        JOIN EVENTO E
          ON E.FAS_SIU_ID_FASCICOLO_SIUS = F.ID_FASCICOLO_SIUS
        JOIN GENERALE_PROCEDIMENTO G
          ON G.FAS_SIU_ID_FASCICOLO_SIUS = F.ID_FASCICOLO_SIUS
        LEFT OUTER JOIN DEPOSITO_DECRETO D
          ON (D.ID_EVENTO_GENERATO = E.ID_EVENTO AND
             TRUNC(D.DATA_DEPOSITO, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy') AND
             TRUNC(D.DATA_DEPOSITO, 'dd') >=
             TO_DATE(PAR_DATA_INIZIO, 'dd/mm/yyyy'))
        LEFT OUTER JOIN DEPOSITO_ORDINANZA_PC O
          ON (O.ID_EVENTO_GENERATO = E.ID_EVENTO AND
             TRUNC(O.DATA_DEPOSITO, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy') AND
             TRUNC(O.DATA_DEPOSITO, 'dd') >=
             TO_DATE(PAR_DATA_INIZIO, 'dd/mm/yyyy'))
      --bvn
        LEFT OUTER JOIN DEPOSITO_SENTENZA OO
          ON (OO.ID_EVENTO_GENERATO = E.ID_EVENTO AND
             TRUNC(OO.DATA_DEPOSITO, 'dd') <=
             TO_DATE(PAR_DATA_FINE, 'dd/mm/yyyy') AND
             TRUNC(OO.DATA_DEPOSITO, 'dd') >=
             TO_DATE(PAR_DATA_INIZIO, 'dd/mm/yyyy'))
      --fine bvn
       WHERE E.FLAG_DOCUMENTO_REGISTRATO = 'S'
            --   MODIFICA DEL 25/7/2008
            --  24/1/2023   Umberto aggiunto scarto Decreti Designazione (0610)
         AND (E.COD_ESITO <> '0601' AND E.COD_ESITO <> '0602' AND
             E.COD_ESITO <> '0603' AND e.COD_ESITO <> '0610')
            --   FINE MODIFICA DEL 25/7/2008 e 24/1/2023
         AND F.CHIAVE_UFFICIO = PAR_UFFICIO;

    -- tupla da utilizzare nella fetch
    TUPLAFASCICOLOPROVV CURFASCICOLIPROVVEDIMENTI%ROWTYPE;

    -- cursore sui fascicoli
    CURFASCICOLI CURFASCTYPE;

    CONTARECORD INTEGER := 0;

    -- Date Udienza
    DATA_UDIENZA_PRIMA  DATE;
    DATA_UDIENZA_ULTIMA DATE;

    TUPLATENORE TENORE%ROWTYPE;

    /*
    Funzione che apre il cursore per la ricerca dei Procedimenti Depositati
    */
    PROCEDURE OPENFASCCUR(CUR                   IN OUT CURFASCTYPE,
                          P_UFFICIO             IN VARCHAR2,
                          P_DATA_INIZIO         IN VARCHAR2,
                          P_DATA_FINE           IN VARCHAR2,
                          P_COD_CANCELLERIA     IN VARCHAR2,
                          PAR_COLLABORATORE     IN VARCHAR2,
                          P_POSIZIONE_GIURIDICA IN VARCHAR2) IS

      -- select base
      --
      -- IN DATA 25/7/2008 INSERITE MODIFICHE PER SCARTO ORDINANZE/DECRETO IRREPERIBILITA', FISSAZIONE UDIENZA E RINVIO UDIENZA E
      --                   EVENTI NON VALIDATI

      MYSELECT VARCHAR2(2000) := 'select f.id_fascicolo_sius, f.chiave_anno, f.chiave_progr, f.chiave_ufficio,' ||
                                 ' f.cod_stato_fascicolo, f.data_inserimento, f.data_iscrizione, f.data_definizione,' ||
                                 ' o.data_deposito DATA_DEP_ORD, o.id_deposito_ordinanza_pc ID_ORD,' ||
                                 ' d.data_deposito DATA_DEP_DEC, d.id_deposito_decreto ID_DEC,' ||
                                --bvn
                                 ' oo.data_deposito DATA_DEP_SEN, oo.id_deposito_sentenza ID_SEN,' ||
                                --fine bvn
                                 ' e.data_emissione, e.id_evento,' ||
                                 ' g.data_arrivo_cancelleria , g.id_generale_procedimento, g.cod_posizione_giuridica' ||
                                 ' from fascicolo_sius f join evento e on e.FAS_SIU_ID_FASCICOLO_SIUS = f.ID_FASCICOLO_SIUS' ||
                                --  MODIFICHE DEL 25/7/2008
                                --  24/1/2023   Umberto aggiunto scarto Decreti Designazione (0610) 
                                 ' AND ( e.COD_ESITO <> ''0601'' AND e.COD_ESITO <> ''0602'' AND e.COD_ESITO <> ''0603'' AND e.COD_ESITO <> ''0610'' ) ' ||
                                 ' AND e.FLAG_DOCUMENTO_REGISTRATO = ''S'' ' ||
                                --  FINE MODIFICHE DEL 25/7/2008
                                 ' join generale_procedimento g on g.fas_siu_id_fascicolo_sius = f.id_fascicolo_sius' ||
                                 ' left outer join deposito_decreto d on (d.ID_EVENTO_GENERATO = e.ID_EVENTO and trunc (d.data_deposito, ''dd'') ' ||
                                 ' <= to_date(:p_data_fine1,''dd/mm/yyyy'')  AND  trunc(d.data_deposito, ''dd'') >= to_date(:p_data_inizio1,''dd/mm/yyyy''))' ||
                                 ' left outer join deposito_ordinanza_pc o on (o.ID_EVENTO_GENERATO = e.ID_EVENTO  and trunc( o.data_deposito, ''dd'') ' ||
                                 ' <= to_date(:p_data_fine2,''dd/mm/yyyy'')   AND trunc(o.data_deposito, ''dd'') >= to_date(:p_data_inizio2,''dd/mm/yyyy''))' ||
                                --bvn
                                 ' left outer join deposito_sentenza oo on (oo.ID_EVENTO_GENERATO = e.ID_EVENTO  and trunc( oo.data_deposito, ''dd'') ' ||
                                 ' <= to_date(:p_data_fine3,''dd/mm/yyyy'')   AND trunc(oo.data_deposito, ''dd'') >= to_date(:p_data_inizio3,''dd/mm/yyyy''))' ||
                                --fine bvn
                                 ' where f.chiave_ufficio = :p_ufficio ' ||
                                 -- Ticket#202211300113 — Esecuzione statistiche
                                 '  AND (d.ID_DEPOSITO_DECRETO IS NOT NULL OR o.ID_DEPOSITO_ORDINANZA_PC IS NOT NULL OR oo.ID_DEPOSITO_SENTENZA IS NOT NULL)  ';
                                 -- Ticket#202211300113 -- FINE

    BEGIN
      -- Preparazione della select dinamica aggiungendo condizioni di filtro alla select base

      -- Eventuale filtro Cancelleria Assegnataria
      FILTROCANCELLERIA(MYSELECT, P_COD_CANCELLERIA);

      -- Eventuale filtro su collaboratore di giustizia
      FILTROCOLLAB(MYSELECT, PAR_COLLABORATORE);

      -- Eventuale filtro Posizione Giuridica
      FILTROPOSIZIONEGIURIDICA(MYSELECT, P_POSIZIONE_GIURIDICA);

      -- OPEN CURSOR
      IF ((P_COD_CANCELLERIA IS NULL) AND (P_POSIZIONE_GIURIDICA = 'tutti')) THEN
        DBMS_OUTPUT.PUT_LINE('mySelect --> ' || MYSELECT);
        -- Senza filtro su cancelleria assegnataria e posizione giuridica
        OPEN CUR FOR MYSELECT
          USING P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_UFFICIO;
      ELSIF ((P_COD_CANCELLERIA IS NULL) AND
            (P_POSIZIONE_GIURIDICA <> 'tutti')) THEN
        -- Senza filtro su cancelleria assegnataria ma su posizione giuridica
        OPEN CUR FOR MYSELECT
          USING P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_UFFICIO, P_POSIZIONE_GIURIDICA;
      ELSIF ((P_COD_CANCELLERIA IS NOT NULL) AND
            (P_POSIZIONE_GIURIDICA = 'tutti')) THEN
        -- Filtro su cancelleria ma non su pos giu
        OPEN CUR FOR MYSELECT
          USING P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_UFFICIO, P_COD_CANCELLERIA;
      ELSE
        -- Filtro sia su cancelleria assegnataria che su posizione giuridica
        OPEN CUR FOR MYSELECT
          USING P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_DATA_FINE, P_DATA_INIZIO, P_UFFICIO, P_COD_CANCELLERIA, P_POSIZIONE_GIURIDICA;
      END IF;

    END OPENFASCCUR;

    -- La funzione calcola il numero di giorni intercorso tra 2 date
    FUNCTION CONTAGIORNI(PAR_DATA_INIZIALE IN DATE,
                         PAR_DATA_FINALE   IN DATE) RETURN NUMBER IS
      -- numero di giorni risultato
      RETVALUE NUMBER;

    BEGIN
      IF (PAR_DATA_INIZIALE IS NOT NULL AND PAR_DATA_FINALE IS NOT NULL) THEN

        RETVALUE := ROUND(TRUNC(PAR_DATA_FINALE) - TRUNC(PAR_DATA_INIZIALE));
       
        DBMS_OUTPUT.PUT_LINE('Data iniziale->' || TO_CHAR(PAR_DATA_INIZIALE, 'dd/mm/yyyy:HH:MM') 
                          || ' Data finale->' || TO_CHAR(PAR_DATA_FINALE, 'dd/mm/yyyy:HH:MM')
                          || ' Tempo intercorso->' || RETVALUE );       
       
--        DBMS_OUTPUT.PUT_LINE('Data iniziale->' || TO_CHAR(PAR_DATA_INIZIALE, 'dd/mm/yyyy:HH:MM'));
--        DBMS_OUTPUT.PUT_LINE('Data finale->' || TO_CHAR(PAR_DATA_FINALE, 'dd/mm/yyyy:HH:MM'));
--        DBMS_OUTPUT.PUT_LINE('Tempo intercorso->' || RETVALUE);
      ELSE
        RETVALUE := NULL;
      END IF;
      RETURN RETVALUE;
    END CONTAGIORNI;

    -- Procedura di inserimento record nella tabella isp_proc_intervalli
    PROCEDURE INSERIMENTO(PAR_FASCICOLO       IN CURFASCICOLIPROVVEDIMENTI%ROWTYPE,
                          PAR_TENORE          IN TENORE%ROWTYPE,
                          DATA_UDIENZA_PRIMA  IN DATE,
                          DATA_UDIENZA_ULTIMA IN DATE) IS

      CODESITOSTATISTICA VARCHAR2(4);
      CONTENUTOSTATIS    ISP_PROC_INTERVALLI.DESC_CONTENUTO_STATIS%TYPE;
      CODMAGISTRATO      VARCHAR2(20);

      TEMPODECISIONEDEPOSITO    NUMBER;
      TEMPORICEZIONEFISSAZIONE1 NUMBER;
      TEMPOFISSAZIONE2DEPOSITO  NUMBER;
      TEMPORICEZIONEDEPOSITO    NUMBER;
      DATA_DEPOSITO             DATE;

    BEGIN

      -- Valorizzazione data di deposito
      IF (PAR_FASCICOLO.DATA_DEP_DEC IS NOT NULL) THEN
        DATA_DEPOSITO := PAR_FASCICOLO.DATA_DEP_DEC;
        --bvn
      ELSIF (PAR_FASCICOLO.DATA_DEP_ORD IS NOT NULL) THEN
        DATA_DEPOSITO := PAR_FASCICOLO.DATA_DEP_ORD;
      ELSIF (PAR_FASCICOLO.DATA_DEP_SEN IS NOT NULL) THEN
        DATA_DEPOSITO := PAR_FASCICOLO.DATA_DEP_SEN;
        --fine bvn
      END IF;

      -- trascodifica esito tenore ed oggetto tenore
      CODESITOSTATISTICA := CODESITOSTATDATENORE(PAR_TENORE.COD_ESITO_TENORE);
      CONTENUTOSTATIS    := CODOGGETTOSTATDATENORE(PAR_TENORE.COD_OGGETTO_TENORE);

      -- calcolo Tempi
      TEMPODECISIONEDEPOSITO    := CONTAGIORNI(PAR_FASCICOLO.DATA_EMISSIONE,
                                               DATA_DEPOSITO);
      TEMPORICEZIONEFISSAZIONE1 := CONTAGIORNI(PAR_FASCICOLO.DATA_ARRIVO_CANCELLERIA,
                                               DATA_UDIENZA_PRIMA);
      TEMPOFISSAZIONE2DEPOSITO  := CONTAGIORNI(DATA_UDIENZA_ULTIMA,
                                               DATA_DEPOSITO);
      TEMPORICEZIONEDEPOSITO    := CONTAGIORNI(PAR_FASCICOLO.DATA_ARRIVO_CANCELLERIA,
                                               DATA_DEPOSITO);

      -- Determinazione del Magistrato Relatore del Fascicolo
      CODMAGISTRATO := PAR_TENORE.COD_MAGISTRATO;
      IF (CODMAGISTRATO IS NULL) THEN
        CODMAGISTRATO := GETIDESPERTORELATORE(PAR_FASCICOLO.ID_FASCICOLO_SIUS);
      END IF;

      -- inserimento in tabella dei tenori passati
      INSERT INTO ISP_PROC_INTERVALLI
        (
         -- Dati del Fascicolo
         FAS_SIU_ID_FASCICOLO_SIUS,
         FAS_SIU_CHIAVE_ANNO,
         FAS_SIU_CHIAVE_PROGR,
         FAS_SIU_CHIAVE_UFFICIO,
         FAS_SIU_COD_STATO_FASCICOLO,
         FAS_SIU_DATA_ISCRIZIONE,
         FAS_SIU_DATA_DEFINIZIONE,
         DATA_DEPOSITO,
         GEN_PRID_GENERALE_PROCEDIMENTO,
         COD_POSIZIONE_GIURIDICA,
         COD_OGGETTO_TENORE,
         COD_ESITO_TENORE,
         COD_MAGISTRATO,
         TEN_DATA,
         TEN_DATA_FINE,
         DEP_OPID_DEPOSITO_ORDINANZA_PC,
         DEP_DEC_ID_DEPOSITO_DECRETO,
         COD_ESITO_STATISTICA,
         DESC_CONTENUTO_STATIS,
         DATA_RICEZIONE,
         DATA_PRIMA_UDIENZA,
         DATA_ULTIMA_UDIENZA,
         DATA_DECISIONE,
         TEMPO_DECISIONE_DEPOSITO,
         TEPO_RICEZIONE_FISSAZIONE1,
         TEMPO_FISSAZIONE2_DEPOSITO,
         TEMPO_RICEZIONE_DEPOSITO,
         --bvn
         DEP_DEC_ID_DEPOSITO_SENTENZA)
      --fine bvn)

      VALUES
        (PAR_FASCICOLO.ID_FASCICOLO_SIUS,
         PAR_FASCICOLO.CHIAVE_ANNO,
         PAR_FASCICOLO.CHIAVE_PROGR,
         PAR_FASCICOLO.CHIAVE_UFFICIO,
         PAR_FASCICOLO.COD_STATO_FASCICOLO,
         PAR_FASCICOLO.DATA_ISCRIZIONE,
         PAR_FASCICOLO.DATA_DEFINIZIONE,
         DATA_DEPOSITO,
         PAR_FASCICOLO.ID_GENERALE_PROCEDIMENTO,
         PAR_FASCICOLO.COD_POSIZIONE_GIURIDICA,
         PAR_TENORE.COD_OGGETTO_TENORE,
         PAR_TENORE.COD_ESITO_TENORE,
         -- par_tenore.Cod_Magistrato,
         CODMAGISTRATO,
         PAR_TENORE.DATA,
         PAR_TENORE.DATA_FINE,
         PAR_FASCICOLO.ID_ORD, /*  par_tenore.Dep_Opid_Deposito_Ordinanza_Pc,*/
         PAR_FASCICOLO.ID_DEC, /*par_tenore.Dep_Dec_Id_Deposito_Decreto, */
         CODESITOSTATISTICA,
         CONTENUTOSTATIS,
         PAR_FASCICOLO.DATA_ARRIVO_CANCELLERIA,
         DATA_UDIENZA_PRIMA,
         DATA_UDIENZA_ULTIMA,
         PAR_FASCICOLO.DATA_EMISSIONE,
         TEMPODECISIONEDEPOSITO,
         TEMPORICEZIONEFISSAZIONE1,
         TEMPOFISSAZIONE2DEPOSITO,
         TEMPORICEZIONEDEPOSITO,
         --bvn
         PAR_FASCICOLO.ID_SEN
         --fine bvn
         );
    END INSERIMENTO;

  BEGIN
    DBMS_OUTPUT.PUT_LINE('estraiProcedimentiDepositati: inizio');

    -- Valorizzazione del codice Cancelleria Assegnataria
    IF (PAR_CANC_ASS = '0') THEN
      COD_CANCELLERIA := NULL;
    ELSE
      COD_CANCELLERIA := PAR_CANC_ASS;
    END IF;

    -- reset
    -- DELETE FROM isp_proc_intervalli;
    -- michele 25/11/2008
    DELETE FROM ISP_PROC_INTERVALLI
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO;
    DELETE FROM ISP_MOTIVO_OGGETTO;

    -- Estrazione Decreti depositati
    CONTARECORD := 0;

    OPEN CURMOTIVOOGGETTO;
    LOOP
      FETCH CURMOTIVOOGGETTO
        INTO PAR_MPCOD, PAR_MPDESC, PAR_OPCOD, PAR_OPDESC, PAR_TIPOUFF;
      EXIT WHEN CURMOTIVOOGGETTO%NOTFOUND;
      DBMS_OUTPUT.PUT_LINE('INIZIALIZZA: MOTIVO_PROVV --> ' || PAR_MPCOD);
      -- Inserimento
      -- modificato da Michele 25/11/2008
      IF PAR_TIPOUFF = 'C' THEN
        PAR_TIPOUFF := 'TDS';
      ELSE
        PAR_TIPOUFF := 'UDS';
      END IF;

      INSERT INTO ISP_MOTIVO_OGGETTO
        (COD_MOTIVO, DESC_MOTIVO, COD_OGGETTO, DESC_OGGETTO, TIPO_UFFICIO)
      VALUES
        (PAR_MPCOD, PAR_MPDESC, PAR_OPCOD, PAR_OPDESC, PAR_TIPOUFF);

    END LOOP;

    CLOSE CURMOTIVOOGGETTO;

    -- apertura del cursore
    OPENFASCCUR(CURFASCICOLI,
                PAR_UFFICIO,
                PAR_DATA_INIZIO,
                PAR_DATA_FINE,
                COD_CANCELLERIA,
                PAR_COLLABORATORE,
                PAR_POSIZIONE_GIURIDICA);

    -- Ciclo di lettura Fascicoli Depositati
    LOOP
      FETCH CURFASCICOLI
        INTO TUPLAFASCICOLOPROVV;

      IF (CURFASCICOLI%NOTFOUND) THEN
        EXIT;
      END IF;

      -- for tuplaFascicoloProvv in curFascicoliProvvedimenti loop
      CONTARECORD         := CONTARECORD + 1;
      DATA_UDIENZA_PRIMA  := NULL;
      DATA_UDIENZA_ULTIMA := NULL;
      --Valorizzazione di data prima ed ultima fissazione udienza
      RICERCADATEUDIENZA(TUPLAFASCICOLOPROVV.ID_GENERALE_PROCEDIMENTO,
                         DATA_UDIENZA_PRIMA,
                         DATA_UDIENZA_ULTIMA);
      IF (TUPLAFASCICOLOPROVV.ID_DEC IS NOT NULL) THEN
        DBMS_OUTPUT.PUT_LINE('estraiProcedimentiDepositati: ***************   Decreto');
        -- Lettura dei tenori collegati ed inserimento in tabella
        --for tuplaTenore in curTenoriAttiviDecreti(tuplaFascicoloProvv.ID_DEC) loop  curTenoriXdecreto
        FOR TUPLATENORE IN CURTENORIXDECRETOOLD(TUPLAFASCICOLOPROVV.ID_DEC) LOOP
          INSERIMENTO(TUPLAFASCICOLOPROVV,
                      TUPLATENORE,
                      DATA_UDIENZA_PRIMA,
                      DATA_UDIENZA_ULTIMA);
        END LOOP;
      ELSIF (TUPLAFASCICOLOPROVV.ID_ORD IS NOT NULL) THEN
        DBMS_OUTPUT.PUT_LINE('estraiProcedimentiDepositati: ***************   Ordinanza');
        -- Lettura dei tenori collegati ed inserimento in tabella
        --for tuplaTenore in curTenoriAttiviOrdinanze(tuplaFascicoloProvv.ID_ORD) loop
        FOR TUPLATENORE IN CURTENORIXORDINANZAOLD(TUPLAFASCICOLOPROVV.ID_ORD) LOOP
          INSERIMENTO(TUPLAFASCICOLOPROVV,
                      TUPLATENORE,
                      DATA_UDIENZA_PRIMA,
                      DATA_UDIENZA_ULTIMA);
        END LOOP;
        --ultima modifica bvn per correzione anomalia sius
      ELSIF (TUPLAFASCICOLOPROVV.ID_SEN IS NOT NULL) THEN
        DBMS_OUTPUT.PUT_LINE('estraiProcedimentiDepositati: ***************   Sentenza');
        -- Lettura dei tenori collegati ed inserimento in tabella
        --for tuplaTenore in curTenoriAttiviOrdinanze(tuplaFascicoloProvv.ID_ORD) loop
        FOR TUPLATENORE IN CURTENORIXSENTENZAOLD(TUPLAFASCICOLOPROVV.ID_SEN) LOOP
          INSERIMENTO(TUPLAFASCICOLOPROVV,
                      TUPLATENORE,
                      DATA_UDIENZA_PRIMA,
                      DATA_UDIENZA_ULTIMA);
        END LOOP;
      END IF;

    END LOOP;
    DBMS_OUTPUT.PUT_LINE('N.ro RECORD: ' || CONTARECORD);

    DBMS_OUTPUT.PUT_LINE('estraiProcedimentiDepositati: fine');

  END ESTRAIPROCEDIMENTIDEPOSITATI;
  -- modificata da Michele 25/11/2008
  FUNCTION INIZIALIZZATUPLA(PAR_COD_OGGETTO   IN VARCHAR2,
                            PAR_DESC_OGGETTO  IN VARCHAR2,
                            PAR_COD_CONTENUTO IN VARCHAR2,
                            PAR_COD_UFFICIO   IN VARCHAR2)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA.COD_OGGETTO  := PAR_COD_OGGETTO;
    TUPLASTATISTICA.DESC_OGGETTO := PAR_DESC_OGGETTO;
    -- Classificazione del contenuto statistico
    TUPLASTATISTICA.DESC_CONTENUTO_STATIS := CODCONTENUTOSTATISTICO(PAR_COD_CONTENUTO);
    TUPLASTATISTICA.COD_INTERVALLO        := '01';
    TUPLASTATISTICA.DESC_INTERVALLO       := 'Dalla data di ricezione alla data di fissazione prima udienza';
    TUPLASTATISTICA.NUM_TEMPO1            := 0;
    TUPLASTATISTICA.NUM_TEMPO2            := 0;
    TUPLASTATISTICA.NUM_TEMPO3            := 0;
    TUPLASTATISTICA.NUM_TEMPO4            := 0;
    TUPLASTATISTICA.NUM_TEMPO5            := 0;
    TUPLASTATISTICA.NUM_TEMPO6            := 0;
    TUPLASTATISTICA.NUM_TOTALE            := 0;
    TUPLASTATISTICA.DURATA_MEDIA          := 0;
    -- modificata da Michele 25/11/2008
    TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO := PAR_COD_UFFICIO;

    RETURN TUPLASTATISTICA;
  END INIZIALIZZATUPLA;

  -- Procedura di Calcolo contatori relativi ad intervallo Ricezione-Fissazione prima Udienza
  FUNCTION CONTEGGIOINTERVALLO1(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;

    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di ricezione alla data di fissazione prima udienza';
    -- calcolo Somma procedimenti
    SELECT SUM(TEPO_RICEZIONE_FISSAZIONE1),
           COUNT(TEPO_RICEZIONE_FISSAZIONE1)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEPO_RICEZIONE_FISSAZIONE1 IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    DBMS_OUTPUT.PUT_LINE('conteggioIntervallo1 - tuplaStatistica.NUM_TOTALE : ' ||
                         TUPLASTATISTICA.NUM_TOTALE);

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := (DURATA / TUPLASTATISTICA.NUM_TOTALE);

      -- calcolo somme parziali
      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 10
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 30
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 45
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 60
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO1;

  FUNCTION CONTEGGIOINTERVALLO1(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE,
                                PAR_RELATORE        IN VARCHAR2)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;

    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di ricezione alla data di fissazione prima udienza';
    -- calcolo Somma procedimenti
    SELECT SUM(TEPO_RICEZIONE_FISSAZIONE1),
           COUNT(TEPO_RICEZIONE_FISSAZIONE1)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEPO_RICEZIONE_FISSAZIONE1 IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
       AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    DBMS_OUTPUT.PUT_LINE('conteggioIntervallo1bis - tuplaStatistica.NUM_TOTALE : ' ||
                         TUPLASTATISTICA.NUM_TOTALE);

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := (DURATA / TUPLASTATISTICA.NUM_TOTALE);

      -- calcolo somme parziali
      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 10
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 30
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 45
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 60
         AND TEPO_RICEZIONE_FISSAZIONE1 <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEPO_RICEZIONE_FISSAZIONE1)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEPO_RICEZIONE_FISSAZIONE1 > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO1;

  -- Procedura di Calcolo contatori relativi ad intervallo: "Data Ultima Udienza - Data deposito"
  FUNCTION CONTEGGIOINTERVALLO2(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;

    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di fissazione ultima udienza alla data di deposito';
    -- calcolo Somma procedimenti
    SELECT SUM(TEMPO_FISSAZIONE2_DEPOSITO),
           COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEMPO_FISSAZIONE2_DEPOSITO IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := DURATA / TUPLASTATISTICA.NUM_TOTALE;
      -- calcolo somme parziali
      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 10
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 30
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 45
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 60
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO2;

  FUNCTION CONTEGGIOINTERVALLO2(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE,
                                PAR_RELATORE        IN VARCHAR2)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;

    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di fissazione ultima udienza alla data di deposito';
    -- calcolo Somma procedimenti
    SELECT SUM(TEMPO_FISSAZIONE2_DEPOSITO),
           COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEMPO_FISSAZIONE2_DEPOSITO IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
       AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := DURATA / TUPLASTATISTICA.NUM_TOTALE;
      -- calcolo somme parziali
      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 10
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 30
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 45
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 60
         AND TEMPO_FISSAZIONE2_DEPOSITO <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_FISSAZIONE2_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_FISSAZIONE2_DEPOSITO > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO2;

  -- Procedura di Calcolo contatori relativi ad intervallo: "Data Ricezione - Data deposito"
  FUNCTION CONTEGGIOINTERVALLO3(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;
    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di ricezione alla data di deposito';
    -- calcolo Somma procedimenti
    SELECT SUM(TEMPO_RICEZIONE_DEPOSITO), COUNT(TEMPO_RICEZIONE_DEPOSITO)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEMPO_RICEZIONE_DEPOSITO IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := DURATA / TUPLASTATISTICA.NUM_TOTALE;
      -- calcolo somme parziali
      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 10
         AND TEMPO_RICEZIONE_DEPOSITO <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 30
         AND TEMPO_RICEZIONE_DEPOSITO <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 45
         AND TEMPO_RICEZIONE_DEPOSITO <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 60
         AND TEMPO_RICEZIONE_DEPOSITO <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO3;

  FUNCTION CONTEGGIOINTERVALLO3(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE,
                                PAR_RELATORE        IN VARCHAR2)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;
    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di ricezione alla data di deposito';
    -- calcolo Somma procedimenti
    SELECT SUM(TEMPO_RICEZIONE_DEPOSITO), COUNT(TEMPO_RICEZIONE_DEPOSITO)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEMPO_RICEZIONE_DEPOSITO IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
       AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := DURATA / TUPLASTATISTICA.NUM_TOTALE;
      -- calcolo somme parziali
      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 10
         AND TEMPO_RICEZIONE_DEPOSITO <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 30
         AND TEMPO_RICEZIONE_DEPOSITO <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 45
         AND TEMPO_RICEZIONE_DEPOSITO <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 60
         AND TEMPO_RICEZIONE_DEPOSITO <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_RICEZIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_RICEZIONE_DEPOSITO > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO3;

  -- Procedura di Calcolo contatori relativi ad intervallo: "Data Decisione - Data deposito"
  FUNCTION CONTEGGIOINTERVALLO4(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;
    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di decisione alla data di deposito';
    -- calcolo Somma procedimenti
    SELECT SUM(TEMPO_DECISIONE_DEPOSITO), COUNT(TEMPO_DECISIONE_DEPOSITO)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEMPO_DECISIONE_DEPOSITO IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := DURATA / TUPLASTATISTICA.NUM_TOTALE;
      -- calcolo somme parziali
      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 10
         AND TEMPO_DECISIONE_DEPOSITO <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 30
         AND TEMPO_DECISIONE_DEPOSITO <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 45
         AND TEMPO_DECISIONE_DEPOSITO <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 60
         AND TEMPO_DECISIONE_DEPOSITO <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO4;

  FUNCTION CONTEGGIOINTERVALLO4(PAR_TUPLASTATISTICA IN ISP_CONTEGGIO_TEMPI%ROWTYPE,
                                PAR_RELATORE        IN VARCHAR2)
    RETURN ISP_CONTEGGIO_TEMPI%ROWTYPE IS
    DURATA          INTEGER := 0;
    TUPLASTATISTICA ISP_CONTEGGIO_TEMPI%ROWTYPE;

  BEGIN
    TUPLASTATISTICA := PAR_TUPLASTATISTICA;
    -- inizializzazione descrizione intervallo
    TUPLASTATISTICA.DESC_INTERVALLO := 'Dalla data di decisione alla data di deposito';
    -- calcolo Somma procedimenti
    SELECT SUM(TEMPO_DECISIONE_DEPOSITO), COUNT(TEMPO_DECISIONE_DEPOSITO)
      INTO DURATA, TUPLASTATISTICA.NUM_TOTALE
      FROM ISP_PROC_INTERVALLI
     WHERE TEMPO_DECISIONE_DEPOSITO IS NOT NULL
       AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
           TUPLASTATISTICA.COD_OGGETTO
          -- modificato da Michele 25/11/2008
       AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
           TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
       AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    IF (TUPLASTATISTICA.NUM_TOTALE > 0) THEN

      -- calcolo durata media
      TUPLASTATISTICA.DURATA_MEDIA := DURATA / TUPLASTATISTICA.NUM_TOTALE;
      -- calcolo somme parziali
      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO1
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO <= 10
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO2
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 10
         AND TEMPO_DECISIONE_DEPOSITO <= 30
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO3
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 30
         AND TEMPO_DECISIONE_DEPOSITO <= 45
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO4
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 45
         AND TEMPO_DECISIONE_DEPOSITO <= 60
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO5
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 60
         AND TEMPO_DECISIONE_DEPOSITO <= 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

      SELECT COUNT(TEMPO_DECISIONE_DEPOSITO)
        INTO TUPLASTATISTICA.NUM_TEMPO6
        FROM ISP_PROC_INTERVALLI
       WHERE TEMPO_DECISIONE_DEPOSITO > 120
         AND ISP_PROC_INTERVALLI.COD_OGGETTO_TENORE =
             TUPLASTATISTICA.COD_OGGETTO
            -- modificato da Michele 25/11/2008
         AND ISP_PROC_INTERVALLI.FAS_SIU_CHIAVE_UFFICIO =
             TUPLASTATISTICA.FAS_SIU_CHIAVE_UFFICIO
         AND ISP_PROC_INTERVALLI.COD_MAGISTRATO = PAR_RELATORE;

    END IF;
    RETURN TUPLASTATISTICA;
  END CONTEGGIOINTERVALLO4;

  -- Procedura di Calcolo Statistiche per Oggetto.
  -- Per ogni oggetto vengono generati 4 record di conteggi relativi
  -- ai 4 intervalli di tempo previsti.
  PROCEDURE CONTEGGIOTEMPI
  -- modificata da Michele 25/11/2008
  (PAR_COD_OGGETTO   IN VARCHAR2,
   PAR_DESC_OGGETTO  IN VARCHAR2,
   PAR_COD_CONTENUTO IN VARCHAR2,
   PAR_COD_UFFICIO   IN VARCHAR2,
   PAR_RELATORE      IN VARCHAR2) IS
    -- Tupla utilizzata per l'operazione di inserimento
    TUPLASTATISTICA1 ISP_CONTEGGIO_TEMPI%ROWTYPE;
    TUPLASTATISTICA2 ISP_CONTEGGIO_TEMPI%ROWTYPE;
    TUPLASTATISTICA3 ISP_CONTEGGIO_TEMPI%ROWTYPE;
    TUPLASTATISTICA4 ISP_CONTEGGIO_TEMPI%ROWTYPE;

    PROCEDURE INSERIMENTOT(TUPLA IN ISP_CONTEGGIO_TEMPI%ROWTYPE) IS

    BEGIN
      -- modificata da Michele 25/11/2008
      INSERT INTO ISP_CONTEGGIO_TEMPI
        (DESC_CONTENUTO_STATIS,
         COD_OGGETTO,
         DESC_OGGETTO,
         COD_INTERVALLO,
         DESC_INTERVALLO,
         NUM_TEMPO1,
         NUM_TEMPO2,
         NUM_TEMPO3,
         NUM_TEMPO4,
         NUM_TEMPO5,
         NUM_TEMPO6,
         NUM_TOTALE,
         DURATA_MEDIA,
         FAS_SIU_CHIAVE_UFFICIO)
      VALUES
        (TUPLA.DESC_CONTENUTO_STATIS,
         TUPLA.COD_OGGETTO,
         TUPLA.DESC_OGGETTO,
         TUPLA.COD_INTERVALLO,
         TUPLA.DESC_INTERVALLO,
         TUPLA.NUM_TEMPO1,
         TUPLA.NUM_TEMPO2,
         TUPLA.NUM_TEMPO3,
         TUPLA.NUM_TEMPO4,
         TUPLA.NUM_TEMPO5,
         TUPLA.NUM_TEMPO6,
         TUPLA.NUM_TOTALE,
         TUPLA.DURATA_MEDIA,
         TUPLA.FAS_SIU_CHIAVE_UFFICIO);
    END INSERIMENTOT;

  BEGIN

    DBMS_OUTPUT.PUT_LINE('conteggioTempi: inizio ');
    -- Inizializzazione e conteggio
    -- modificata da Michele 25/11/2008
    TUPLASTATISTICA1 := INIZIALIZZATUPLA(PAR_COD_OGGETTO,
                                         PAR_DESC_OGGETTO,
                                         PAR_COD_CONTENUTO,
                                         PAR_COD_UFFICIO);
    IF (PAR_RELATORE IS NULL) THEN
      DBMS_OUTPUT.PUT_LINE('Eseguo conteggioIntervallo1 ');
      TUPLASTATISTICA1 := CONTEGGIOINTERVALLO1(TUPLASTATISTICA1);
    ELSE
      DBMS_OUTPUT.PUT_LINE('Eseguo conteggioIntervallo1-bis ');
      TUPLASTATISTICA1 := CONTEGGIOINTERVALLO1(TUPLASTATISTICA1,
                                               PAR_RELATORE);
    END IF;

    -- modificata da Michele 25/11/2008
    TUPLASTATISTICA2 := INIZIALIZZATUPLA(PAR_COD_OGGETTO,
                                         PAR_DESC_OGGETTO,
                                         PAR_COD_CONTENUTO,
                                         PAR_COD_UFFICIO);
    IF (PAR_RELATORE IS NULL) THEN
      TUPLASTATISTICA2 := CONTEGGIOINTERVALLO2(TUPLASTATISTICA2);
    ELSE
      TUPLASTATISTICA2 := CONTEGGIOINTERVALLO2(TUPLASTATISTICA2,
                                               PAR_RELATORE);
    END IF;

    -- modificata da Michele 25/11/2008
    TUPLASTATISTICA3 := INIZIALIZZATUPLA(PAR_COD_OGGETTO,
                                         PAR_DESC_OGGETTO,
                                         PAR_COD_CONTENUTO,
                                         PAR_COD_UFFICIO);
    IF (PAR_RELATORE IS NULL) THEN
      TUPLASTATISTICA3 := CONTEGGIOINTERVALLO3(TUPLASTATISTICA3);
    ELSE
      TUPLASTATISTICA3 := CONTEGGIOINTERVALLO3(TUPLASTATISTICA3,
                                               PAR_RELATORE);
    END IF;

    -- modificata da Michele 25/11/2008
    TUPLASTATISTICA4 := INIZIALIZZATUPLA(PAR_COD_OGGETTO,
                                         PAR_DESC_OGGETTO,
                                         PAR_COD_CONTENUTO,
                                         PAR_COD_UFFICIO);
    IF (PAR_RELATORE IS NULL) THEN
      TUPLASTATISTICA4 := CONTEGGIOINTERVALLO4(TUPLASTATISTICA4);
    ELSE
      TUPLASTATISTICA4 := CONTEGGIOINTERVALLO4(TUPLASTATISTICA4,
                                               PAR_RELATORE);
    END IF;

    -- L'inserimento viene eggettuato solo se almeno una delle misure
    -- ha individuato 1 procedimento.
    IF ((TUPLASTATISTICA1.NUM_TOTALE > 0) OR
       (TUPLASTATISTICA2.NUM_TOTALE > 0) OR
       (TUPLASTATISTICA3.NUM_TOTALE > 0) OR
       (TUPLASTATISTICA4.NUM_TOTALE > 0)) THEN
      INSERIMENTOT(TUPLASTATISTICA1);
      INSERIMENTOT(TUPLASTATISTICA2);
      INSERIMENTOT(TUPLASTATISTICA3);
      INSERIMENTOT(TUPLASTATISTICA4);
      DBMS_OUTPUT.PUT_LINE('Inserimento effettuato per  ' ||
                           PAR_DESC_OGGETTO);
    END IF;

    DBMS_OUTPUT.PUT_LINE('conteggioTempi: fine ');
  END CONTEGGIOTEMPI;

  /*
   La funzione crea la Statistica relativa ai tempi procedurali
   dei Provvedimenti depositati.
   Viene analizzata la tabella ISP_ROC_INTERVALLI che contiene i tempi caratteristici per ogni provvedimento depositato
  */

  PROCEDURE CREASTATISTICATEMPI(PAR_UFFICIO     IN VARCHAR2,
                                PAR_MAGISTRATO  IN VARCHAR2,
                                PAR_DATA_INIZIO IN VARCHAR2,
                                PAR_DATA_FINE   IN VARCHAR2) IS

    LISTAOGGETTI   CURDECODIFICAOGGETTI%ROWTYPE;
    CONTARECORD    INTEGER := 0;
    COD_MAGISTRATO VARCHAR2(20);

    -- Tupla utilizzata per l'operazione di inserimento
    -- tuplaStatistica   ISP_CONTEGGIO_OGGETTI%rowtype;

  BEGIN

    DBMS_OUTPUT.PUT_LINE('creaStatisticaTempi: inizio ');

    IF (PAR_MAGISTRATO = '0') THEN
      COD_MAGISTRATO := NULL;
    ELSE
      COD_MAGISTRATO := PAR_MAGISTRATO;
    END IF;

    DBMS_OUTPUT.PUT_LINE('cod_magistrato: ' || COD_MAGISTRATO);
    -- Chiama la procedura per l'estrazione dei dati nella tabella ISP_PROC_INTERVALLI
    -- estraiProcedimentiDepositati(par_ufficio, par_data_inizio, par_data_fine, par_canc_ass, par_collaboratore);

    -- reset tabella
    -- DELETE FROM ISP_CONTEGGIO_TEMPI;
    -- michele 25/11/2008
    DELETE FROM ISP_CONTEGGIO_TEMPI
     WHERE FAS_SIU_CHIAVE_UFFICIO = PAR_UFFICIO;

    CONTARECORD := 0;
    FOR LISTAOGGETTI IN CURDECODIFICAOGGETTI(PAR_UFFICIO) LOOP
      CONTARECORD := CONTARECORD + 1;
      -- modificata da Michele 25/11/2008
      CONTEGGIOTEMPI(LISTAOGGETTI.RV_LOW_VALUE,
                     LISTAOGGETTI.RV_MEANING,
                     LISTAOGGETTI.RV_HIGH_VALUE,
                     PAR_UFFICIO,
                     COD_MAGISTRATO);
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('N.ro oggetti nella CG_REF_CODES : ' ||
                         CONTARECORD);

    DBMS_OUTPUT.PUT_LINE('creaStatisticaTempi: fine ');

  END CREASTATISTICATEMPI;

-- 20140205 - FI021-FR022-FA023-FA024
/*
   PROCEDURE creaOggettiSelezionati ( par_cod_oggetti IN VARCHAR2, par_cod_ufficio IN VARCHAR2 )
   IS BEGIN

  INSERT INTO ISP_OGGETTI_SELEZIONATI
    SELECT OGGETTI.RV_LOW_VALUE COD_OGGETTO,
           OGGETTI.
           OGGETTI.RV_MEANING DESC_OGGETTO,
       UFFICIO.COD_TIPO_UFFICIO,
       UFFICIO.COD_UFFICIO
    FROM CG_REF_CODES OGGETTI,
       UFFICIO
    WHERE ( OGGETTI.RV_LOW_VALUE IN ( par_cod_oggetti ) AND OGGETTI.RV_DOMAIN ='OGGETTO_PROCEDIMENTO' )
    AND UFFICIO.COD_UFFICIO = par_cod_ufficio;
  COMMIT;

   END creaOggettiSelezionati;
  */
END ISPETTORATO_SIUS;
/