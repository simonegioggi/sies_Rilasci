#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV_2019_09/aggiorna_db.sql