-- TEMPLATE
-- SIUS_OR
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_680', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Affidamento in prova', '/var/SIES/template/sius/or/', '01', '03', '0680', '1', '0270', 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_681', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Affidamento in prova', '/var/SIES/template/sius/or/', '01', '03', '0681', '1', '0270', 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_682', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Detenzione Domiciliare', '/var/SIES/template/sius/or/', '01', '03', '0682', '1', '0270', 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_683', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Semiliberta''', '/var/SIES/template/sius/or/', '01', '03', '0683', '1', '0270', 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_684', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Sospensione Esecuzione Pena', '/var/SIES/template/sius/or/', '01', '03', '0684', '1', '0270', 'C050', NULL, NULL);
INSERT INTO TEMPLATE
VALUES('SIUS_OR_690', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Affidamento in prova art. 47 O.P.', '/var/SIES/template/sius/or/', '01', '03', '0690', '1', '0270', 'C051', NULL, NULL);
INSERT INTO TEMPLATE
VALUES('SIUS_OR_691', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Affidamento in prova DPR 309/90', '/var/SIES/template/sius/or/', '01', '03', '0691', '1', '0270', 'C051', NULL, NULL);
INSERT INTO TEMPLATE
VALUES('SIUS_OR_692', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Affidamento in casi particolari', '/var/SIES/template/sius/or/', '01', '03', '0692', '1', '0270', 'C051', NULL, NULL);
INSERT INTO TEMPLATE
VALUES('SIUS_OR_693', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Detenzione Domiciliare', '/var/SIES/template/sius/or/', '01', '03', '0693', '1', '0270', 'C051', NULL, NULL);
INSERT INTO TEMPLATE
VALUES('SIUS_OR_694', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Semiliberta''', '/var/SIES/template/sius/or/', '01', '03', '0694', '1', '0270', 'C051', NULL, NULL);
INSERT INTO TEMPLATE
VALUES('SIUS_OR_695', 'SIUS_OR_APPLPROVMA.rtf', 'Ordinanza di Applicazione Provvisoria Sospensione Esecuzione Pena', '/var/SIES/template/sius/or/', '01', '03', '0695', '1', '0270', 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_003_1', 'SIUS_OR_RIGETTOGENERICO.rtf', 'Ordinanza di Rigetto Generico', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_009_1', 'SIUS_OR_SEMILIBERTA+ALTRI.rtf', 'Ordinanza di Concessione della Semilibertà, Rigetta  altre richieste', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_008_1', 'SIUS_OR_SEMILIBERTA.rtf', 'Ordinanza di Concessione della Semilibertà (senza altre richieste)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_001_1', 'SIUS_OR_AFFIDAMENTO.rtf', 'Ordinanza di Affidamento in Prova a Servizio Sociale ', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_002_1', 'SIUS_OR_AFFIDAMENTOTD.rtf', 'Ordinanza di Affidamento in Prova a Servizio Sociale per Tossicodipendente', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_004_1', 'SIUS_OR_DETDOMICILIARE.rtf', 'Ordinanza di Concessione della Detenzione Domiciliare (senza altre richieste)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_005_1', 'SIUS_OR_DETDOMICILIARE2.rtf', 'Ordinanza di Concessione della Detenzione Domiciliare (con altre richieste)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_006_1', 'SIUS_OR_DETDOMICILIARE3.rtf', 'Ordinanza di Concessione della Detenzione Domiciliare per pena espianda fino a 2 anni (47 ter 1 bis)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_007_1', 'SIUS_OR_DETDOM+RINPENA.rtf', 'Ordinanza di Concessione Detenzione Domiciliare e Rigetto differimento pena', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_9031_1', 'SIUS_OR_MODGENERICO.rtf', 'Ordinanza Generica', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_019_1', 'SIUS_OR_NLPGENERICO.rtf', 'Ordinanza generica di Non Luogo a Provvedere', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C050', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_003_2', 'SIUS_OR_RIGETTOGENERICO.rtf', 'Ordinanza di Rigetto Generico', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_009_2', 'SIUS_OR_SEMILIBERTA+ALTRI.rtf', 'Ordinanza di Concessione della Semilibertà, Rigetta  altre richieste', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_008_2', 'SIUS_OR_SEMILIBERTA.rtf', 'Ordinanza di Concessione della Semilibertà (senza altre richieste)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_001_2', 'SIUS_OR_AFFIDAMENTO.rtf', 'Ordinanza di Affidamento in Prova a Servizio Sociale ', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_002_2', 'SIUS_OR_AFFIDAMENTOTD.rtf', 'Ordinanza di Affidamento in Prova a Servizio Sociale per Tossicodipendente', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_004_2', 'SIUS_OR_DETDOMICILIARE.rtf', 'Ordinanza di Concessione della Detenzione Domiciliare (senza altre richieste)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_005_2', 'SIUS_OR_DETDOMICILIARE2.rtf', 'Ordinanza di Concessione della Detenzione Domiciliare (con altre richieste)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_006_2', 'SIUS_OR_DETDOMICILIARE3.rtf', 'Ordinanza di Concessione della Detenzione Domiciliare per pena espianda fino a 2 anni (47 ter 1 bis)', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_007_2', 'SIUS_OR_DETDOM+RINPENA.rtf', 'Ordinanza di Concessione Detenzione Domiciliare e Rigetto differimento pena', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_9031_2', 'SIUS_OR_MODGENERICO.rtf', 'Ordinanza Generica', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_019_2', 'SIUS_OR_NLPGENERICO.rtf', 'Ordinanza generica di Non Luogo a Provvedere', '/var/SIES/template/sius/or/', '01', '03', NULL, NULL, NULL, 'C051', NULL, NULL);
--Comunicazione annotazione data esecutività ordinanza
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0270', 'SIUS_OR_COMESECORD.rtf', 'Comunicazione annotazione data esecutività ordinanza', '/var/SIES/template/sius/or/', NULL, '15', NULL, '0', NULL, NULL, NULL, NULL);
-- Ordinanza Conferma Applicazione Provvisoria
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0720', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0720', NULL, NULL, 'MACA', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0721', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0721', NULL, NULL, 'MACA', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0722', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0722', NULL, NULL, 'MACA', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0723', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0723', NULL, NULL, 'MACA', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0730', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0730', NULL, NULL, 'MACM', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0724', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0724', NULL, NULL, 'MACA', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0731', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0731', NULL, NULL, 'MACM', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0732', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0732', NULL, NULL, 'MACM', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0733', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0733', NULL, NULL, 'MACM', NULL, NULL);
INSERT INTO TEMPLATE
 VALUES('SIUS_OR_0734', 'SIUS_OR_CONFAPPLPROV.rtf', 'Ordinanza di Conferma Applicazione Provvisoria MA', '/var/SIES/template/sius/or/', '01', '03', '0734', NULL, NULL, 'MACM', NULL, NULL);

-- SIUS_DE
-- Decreto Designazione Magistrato Relatore
INSERT INTO TEMPLATE
 VALUES('SIUS_DE_0610', 'SIUS_DE_DECRDESMAGREL.rtf', 'Decreto Designazione Magistrato Relatore', '/var/SIES/template/sius/de/', '01', '02', NULL, 'T', '0610', NULL, NULL, NULL);