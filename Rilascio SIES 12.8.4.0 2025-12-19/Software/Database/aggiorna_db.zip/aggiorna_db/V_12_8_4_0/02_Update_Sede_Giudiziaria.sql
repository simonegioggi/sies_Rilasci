update sede_giudiziaria sg
   set sg.cod_distretto =
       (select uf.cod_distretto
          from ufficio uf
         where sg.cod_comune = uf.cod_comune
           and uf.cod_tipo_ufficio = 'DIB');