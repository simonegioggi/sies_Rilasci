#!/bin/sh
$ORACLE_HOME/bin/sqlplus /nolog @/home/oracle/MEV-2019_21/aggiorna_db/restore_db.sql