DELETE FROM versione WHERE cod_versione='12.4.12.0-MEV_2019_21';
--COMMIT;


