CREATE OR REPLACE PROCEDURE POST_XBA_CAR_AVV_CON_PENDENZE IS

    -- variabili per la fetch
    V_ID_AVVOCATO                    AVVOCATO.ID_AVVOCATO%TYPE;
    V_COGNOME                        AVVOCATO.COGNOME%TYPE;
    V_NOME                            AVVOCATO.NOME%TYPE;
    V_FORO                            AVVOCATO.FORO%TYPE;
    V_INDIRIZZO                        AVVOCATO.INDIRIZZO%TYPE;
    V_TELEFONO                        AVVOCATO.TELEFONO%TYPE;
    V_FAX                            AVVOCATO.FAX%TYPE;
    V_E_MAIL                        AVVOCATO.E_MAIL%TYPE;
    V_COD_COMUNE_RESIDENZA            AVVOCATO.COD_COMUNE_RESIDENZA%TYPE;
    V_COD_LUOGO_NASCITA                AVVOCATO.COD_LUOGO_NASCITA%TYPE;
    V_DATA_NASCITA                    AVVOCATO.DATA_NASCITA%TYPE;
    V_DATA_SOSPESO_FINO_AL            AVVOCATO.DATA_SOSPESO_FINO_AL%TYPE; 
    V_DATA_RADIATO_DAL                AVVOCATO.DATA_RADIATO_DAL%TYPE;
    V_COD_NON_ATTIVITA                AVVOCATO.COD_NON_ATTIVITA%TYPE;
    V_NOTE                            AVVOCATO.NOTE%TYPE;
    V_FLAG_CANCELLATO                AVVOCATO.FLAG_CANCELLATO%TYPE;
    V_COD_UFFICIO_APPARTENENZA        AVVOCATO.COD_UFFICIO_APPARTENENZA%TYPE;
    V_COD_OPERATORE_INSERIMENTO        AVVOCATO.COD_OPERATORE_INSERIMENTO%TYPE;
    V_DATA_INSERIMENTO                AVVOCATO.DATA_INSERIMENTO%TYPE;
    V_COD_UFFICIO_INSERIMENTO        AVVOCATO.COD_UFFICIO_INSERIMENTO%TYPE;
    V_COD_OPERATORE_AGGIORNAMENTO    AVVOCATO.COD_OPERATORE_AGGIORNAMENTO%TYPE;
    V_DATA_AGGIORNAMENTO            AVVOCATO.DATA_AGGIORNAMENTO%TYPE;
    V_COD_UFFICIO_AGGIORNAMENTO        AVVOCATO.COD_UFFICIO_AGGIORNAMENTO%TYPE;
    V_COD_FISCALE                    AVVOCATO.COD_FISCALE%TYPE;
    V_PROVINCIA                        AVVOCATO.PROVINCIA%TYPE;
    V_CAP                            AVVOCATO.CAP%TYPE;
    V_ID_AVVOCATO_STANDARD            AVVOCATO.ID_AVVOCATO_STANDARD%TYPE;
    V_FLAG_VISUALIZZA                AVVOCATO.FLAG_VISUALIZZA%TYPE;
    V_PEC                            AVVOCATO.PEC%TYPE;
    V_FLAG_REGINDE                    AVVOCATO.FLAG_REGINDE%TYPE;
    V_DESCR_COMUNE_STUDIO            AVVOCATO.DESCR_COMUNE_STUDIO%TYPE;
    V_COD_STATO_NASCITA_AVV            AVVOCATO.COD_STATO_NASCITA_AVV%TYPE;
    V_DESC_LUOGO_NAS_REGINDE        AVVOCATO.DESC_LUOGO_NAS_REGINDE%TYPE;
    V_ID_AVVOCATO_BONIFICATO        AVVOCATO.ID_AVVOCATO_BONIFICATO%TYPE;
	V_ID_FASCICOLO_SIEP				FASCICOLO_SIEP.ID_FASCICOLO_SIEP%TYPE;
	V_ID_FASCICOLO_SIUS				FASCICOLO_SIUS.ID_FASCICOLO_SIUS%TYPE;
	V_ID_FASCICOLO_SIGE				FASCICOLO_SIGE.ID_FASCICOLO_SIGE%TYPE;
	V_CHIAVE_ANNO 					NUMBER;
	V_CHIAVE_PROGR					NUMBER	;
	V_CHIAVE_UFFICIO				VARCHAR2(11);
	V_COD_STATO_FASCICOLO			VARCHAR2(2);
	V_COD_TIPO_UFF  				VARCHAR2(10);
	V_DESCRCOMUNE				    VARCHAR2(50);
    
    -- variabile generali
    num_pendenze_avv_SIUS        NUMBER:=0;
    num_pendenze_avv_SIEP        NUMBER:=0;
    NUM_PENDENZE_AVV_SIGE        NUMBER:=0;

    num_avv_SIEP_con_pendenze    NUMBER:=0;
    num_avv_SIUS_con_pendenze    NUMBER:=0;
    num_avv_SIGE_con_pendenze    NUMBER:=0;
    
    tot_Fascicoli_SIEP_pendenti NUMBER:=0;
    tot_Fascicoli_SIUS_pendenti NUMBER:=0;
    tot_Fascicoli_SIGE_pendenti NUMBER:=0;
    
    w_cod_distretto          NUMBER:=0;
    w_codice_distretto       NUMBER:=0;


    -- Cursore avvocati con pendenze SIUS per procedimenti appartenenti al Distretto

    CURSOR cur_avv_sius(w_codice_distretto IN NUMBER ) IS
		SELECT  a.*, fs.ID_FASCICOLO_SIUS, fs.chiave_anno, fs.chiave_progr, fs.CHIAVE_UFFICIO, fs.COD_STATO_FASCICOLO 
          FROM AVVOCATO a 
          JOIN AVVOCATO_FASCICOLO_SIUS afs ON (afs.AVV_ID_AVVOCATO = a.ID_AVVOCATO and SUBSTR(afs.FAS_SIU_ID_FASCICOLO_SIUS,-6, 2) = w_codice_distretto)
          JOIN FASCICOLO_SIUS fs ON (fs.ID_FASCICOLO_SIUS = afs.FAS_SIU_ID_FASCICOLO_SIUS 
                                  and fs.COD_STATO_FASCICOLO NOT in ('01', '07', '05'))
         ORDER BY a.id_avvocato, a.cognome, a.nome, a.foro, a.cod_fiscale;
                              
    -- Cursore avvocati con pendenze SIEP per procedimenti appartenenti al Distretto
    CURSOR cur_avv_siep(w_codice_distretto IN NUMBER) IS 
        SELECT a.*, fs.ID_FASCICOLO_SIEP, fs.chiave_anno, fs.chiave_progr, fs.CHIAVE_UFFICIO, fs.COD_STATO_FASCICOLO
          FROM AVVOCATO a
          JOIN AVVOCATO_FASCICOLO_SIEP afs ON (afs.AVV_ID_AVVOCATO = a.ID_AVVOCATO and SUBSTR(afs.FAS_SIE_ID_FASCICOLO_SIEP,-6, 2) = w_codice_distretto)
          JOIN FASCICOLO_SIEP fs ON (fs.ID_FASCICOLO_SIEP = afs.FAS_SIE_ID_FASCICOLO_SIEP 
                                  and  fs.COD_STATO_FASCICOLO <> '01')
         ORDER BY a.id_avvocato, a.cognome, a.nome, a.foro, a.cod_fiscale;

    -- Cursore avvocati con pendenze SIGE per procedimenti appartenenti al Distretto
    CURSOR cur_avv_sige(w_codice_distretto IN NUMBER) IS
        SELECT  a.*, fs.ID_FASCICOLO_SIGE, fs.chiave_anno, fs.chiave_progr, fs.CHIAVE_UFFICIO, fs.COD_STATO_FASCICOLO
          FROM AVVOCATO a
          JOIN AVVOCATO_FASCICOLO_SIGE afs ON (afs.AVV_ID_AVVOCATO = a.ID_AVVOCATO and SUBSTR(afs.FAS_SIGE_ID_FASCICOLO_SIGE,-6, 2) = w_codice_distretto)
          JOIN FASCICOLO_SIGE fs ON (fs.ID_FASCICOLO_SIGE = afs.FAS_SIGE_ID_FASCICOLO_SIGE 
                                  and  fs.DATA_DEFINIZIONE IS NULL )
         ORDER BY a.id_avvocato, a.cognome, a.nome, a.foro, a.cod_fiscale;

    -- Finto Cursore per consentire la valorizzazione del codice distretto della BDI sulla base del codice BDI, più frequente, incluso in ID_FASCICOLO_SIUS
    CURSOR cur_cod_distretto IS
        SELECT SUBSTR(FASCICOLO_SIUS.ID_FASCICOLO_SIUS,-6, 2) FROM FASCICOLO_SIUS
        GROUP BY SUBSTR(FASCICOLO_SIUS.ID_FASCICOLO_SIUS,-6, 2)
        ORDER BY count(SUBSTR(FASCICOLO_SIUS.ID_FASCICOLO_SIUS,-6, 2)) DESC;


BEGIN
----------------------------------------------------------
-------------------INIZIO PROCEDURA-----------------------
----------------------------------------------------------
  -- Ricerca e valorizzazione del codice Distretto
   BEGIN
   
    OPEN cur_cod_distretto;
        FETCH cur_cod_distretto INTO w_cod_distretto;
        CLOSE cur_cod_distretto;
        w_codice_distretto :=w_cod_distretto;
        dbms_output.put_line('= Codice Distretto : '||w_codice_distretto);
   END;
   
    -- Scrittura di XBA_LOG_BONIFICA_AVVOCATI
    BEGIN 
    -- Inizio POST_CARICA_AVV_CON_PENDENZE. Si estraggono gli avvocati SIES per i quali sussistono fascicoli pendenti in almeno un sottosistema (SIEP, SIUS, SIGE). I dati estratti vengono inseriti nella tabella XBA_AVVOCATI_CON_PENDENZE.
    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('Inizio POST_XBA_CAR_AVV_CON_PENDENZE. Si estraggono gli avvocati SIES con fascicoli pendenti del Distretto in almeno un sottosistema (SIEP, SIUS, SIGE). I dati estratti sono inseriti nella tabella POST_XBA_AVVOCATI_CON_PENDENZE. Il valore indica il Codice Distretto ',
            w_codice_distretto,
            current_timestamp);
    END;


  -- Elaborazione per pendenze SIEP
  OPEN cur_avv_siep(w_codice_distretto);
    LOOP
        FETCH cur_avv_siep INTO
            V_ID_AVVOCATO, V_COGNOME, V_NOME, V_FORO, V_INDIRIZZO, V_TELEFONO, V_FAX, V_E_MAIL,
            V_COD_COMUNE_RESIDENZA, V_COD_LUOGO_NASCITA, V_DATA_NASCITA, V_DATA_SOSPESO_FINO_AL,
            V_DATA_RADIATO_DAL, V_COD_NON_ATTIVITA, V_NOTE, V_FLAG_CANCELLATO, V_COD_UFFICIO_APPARTENENZA,
            V_COD_OPERATORE_INSERIMENTO, V_DATA_INSERIMENTO, V_COD_UFFICIO_INSERIMENTO,    V_COD_OPERATORE_AGGIORNAMENTO, 
            V_DATA_AGGIORNAMENTO, V_COD_UFFICIO_AGGIORNAMENTO, V_COD_FISCALE, V_PROVINCIA, V_CAP, 
            V_ID_AVVOCATO_STANDARD, V_FLAG_VISUALIZZA, V_PEC, V_FLAG_REGINDE, V_DESCR_COMUNE_STUDIO,
            V_COD_STATO_NASCITA_AVV, V_DESC_LUOGO_NAS_REGINDE, V_ID_AVVOCATO_BONIFICATO,
            V_ID_FASCICOLO_SIEP, V_CHIAVE_ANNO, V_CHIAVE_PROGR, V_CHIAVE_UFFICIO, V_COD_STATO_FASCICOLO;
        SELECT COUNT(*)INTO num_pendenze_avv_SIEP
            FROM AVVOCATO_FASCICOLO_SIEP afs 
            JOIN FASCICOLO_SIEP fs ON (fs.ID_FASCICOLO_SIEP = afs.FAS_SIE_ID_FASCICOLO_SIEP 
                                  AND afs.AVV_ID_AVVOCATO = V_ID_AVVOCATO AND SUBSTR(afs.FAS_SIE_ID_FASCICOLO_SIEP,-6, 2) = w_codice_distretto)
            WHERE fs.COD_STATO_FASCICOLO <> '01';
    
     
        EXIT WHEN cur_avv_siep%NOTFOUND;

              tot_Fascicoli_SIEP_pendenti := tot_Fascicoli_SIEP_pendenti + 1;
             
        BEGIN
--            num_avv_SIEP_con_pendenze := num_avv_SIEP_con_pendenze + 1;

	        SELECT COD_TIPO_UFFICIO, DESCRIZIONE INTO V_COD_TIPO_UFF, V_DESCRCOMUNE
			FROM UFFICIO U, COMUNE C WHERE COD_UFFICIO = V_CHIAVE_UFFICIO AND C.COD_COMUNE = U.COD_COMUNE;
		
            INSERT INTO POST_XBA_AVVOCATI_CON_PENDENZE
                ( ID_AVVOCATO, COGNOME, NOME, FORO, INDIRIZZO, TELEFONO, FAX, E_MAIL,
                  COD_COMUNE_RESIDENZA, COD_LUOGO_NASCITA, DATA_NASCITA, DATA_SOSPESO_FINO_AL,
                  DATA_RADIATO_DAL, COD_NON_ATTIVITA, NOTE, FLAG_CANCELLATO, COD_UFFICIO_APPARTENENZA,
                  COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO,
                  COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO,
                  COD_FISCALE, PROVINCIA, CAP, ID_AVVOCATO_STANDARD, FLAG_VISUALIZZA,
                  AMBIENTE, NUM_PENDENZE, ID_AVV_CERT_REGINDE, ID_FASCICOLO_SIEP, ID_FASCICOLO_SIUS, ID_FASCICOLO_SIGE, 
                  CHIAVE_ANNO, CHIAVE_PROGR, CHIAVE_UFFICIO, COD_STATO_FASCICOLO,COD_TIPO_UFF, DESCRCOMUNE, FLAG_REGINDE )
            VALUES (V_ID_AVVOCATO, V_COGNOME, V_NOME, V_FORO, V_INDIRIZZO, V_TELEFONO, V_FAX, V_E_MAIL,
                  V_COD_COMUNE_RESIDENZA, V_COD_LUOGO_NASCITA, V_DATA_NASCITA, V_DATA_SOSPESO_FINO_AL,
                  V_DATA_RADIATO_DAL, V_COD_NON_ATTIVITA, V_NOTE, V_FLAG_CANCELLATO, V_COD_UFFICIO_APPARTENENZA,
                  V_COD_OPERATORE_INSERIMENTO, V_DATA_INSERIMENTO, V_COD_UFFICIO_INSERIMENTO,
                  V_COD_OPERATORE_AGGIORNAMENTO, V_DATA_AGGIORNAMENTO, V_COD_UFFICIO_AGGIORNAMENTO,
                  V_COD_FISCALE, V_PROVINCIA, V_CAP, V_ID_AVVOCATO_STANDARD, V_FLAG_VISUALIZZA,
                  'SIEP', num_pendenze_avv_SIEP, V_ID_AVVOCATO_BONIFICATO, V_ID_FASCICOLO_SIEP, NULL, NULL, 
                  V_CHIAVE_ANNO, V_CHIAVE_PROGR, V_CHIAVE_UFFICIO, V_COD_STATO_FASCICOLO, V_COD_TIPO_UFF, V_DESCRCOMUNE, V_FLAG_REGINDE);    
    
        END;
    END LOOP;
   
  CLOSE cur_avv_siep;

-- Elaborazione per pendenze SIUS
  OPEN cur_avv_sius(w_codice_distretto);
    LOOP
        FETCH cur_avv_sius INTO
            V_ID_AVVOCATO, V_COGNOME, V_NOME, V_FORO, V_INDIRIZZO, V_TELEFONO, V_FAX, V_E_MAIL,
            V_COD_COMUNE_RESIDENZA, V_COD_LUOGO_NASCITA, V_DATA_NASCITA, V_DATA_SOSPESO_FINO_AL,
            V_DATA_RADIATO_DAL, V_COD_NON_ATTIVITA, V_NOTE, V_FLAG_CANCELLATO, V_COD_UFFICIO_APPARTENENZA,
            V_COD_OPERATORE_INSERIMENTO, V_DATA_INSERIMENTO, V_COD_UFFICIO_INSERIMENTO,    V_COD_OPERATORE_AGGIORNAMENTO, 
            V_DATA_AGGIORNAMENTO, V_COD_UFFICIO_AGGIORNAMENTO, V_COD_FISCALE, V_PROVINCIA, V_CAP, 
            V_ID_AVVOCATO_STANDARD, V_FLAG_VISUALIZZA, V_PEC, V_FLAG_REGINDE, V_DESCR_COMUNE_STUDIO,
            V_COD_STATO_NASCITA_AVV, V_DESC_LUOGO_NAS_REGINDE, V_ID_AVVOCATO_BONIFICATO,
            V_ID_FASCICOLO_SIUS, V_CHIAVE_ANNO, V_CHIAVE_PROGR, V_CHIAVE_UFFICIO, V_COD_STATO_FASCICOLO;
        
        SELECT COUNT(*)INTO num_pendenze_avv_SIUS
            FROM AVVOCATO_FASCICOLO_SIUS afs 
            JOIN FASCICOLO_SIUS fs ON (fs.ID_FASCICOLO_SIUS = afs.FAS_SIU_ID_FASCICOLO_SIUS
                                  AND afs.AVV_ID_AVVOCATO = V_ID_AVVOCATO AND SUBSTR(afs.FAS_SIU_ID_FASCICOLO_SIUS,-6, 2) = w_codice_distretto)
            WHERE fs.COD_STATO_FASCICOLO NOT in ('01', '07', '05');

            
        EXIT WHEN cur_avv_sius%NOTFOUND;

        		tot_Fascicoli_SIUS_pendenti := tot_Fascicoli_SIUS_pendenti + 1;
       
        BEGIN
 --          num_avv_SIUS_con_pendenze:= num_avv_SIUS_con_pendenze + 1;

	        SELECT COD_TIPO_UFFICIO, DESCRIZIONE INTO V_COD_TIPO_UFF, V_DESCRCOMUNE
			FROM UFFICIO U, COMUNE C WHERE COD_UFFICIO = V_CHIAVE_UFFICIO AND C.COD_COMUNE = U.COD_COMUNE;

	        
            INSERT INTO POST_XBA_AVVOCATI_CON_PENDENZE
                ( ID_AVVOCATO, COGNOME, NOME, FORO, INDIRIZZO, TELEFONO, FAX, E_MAIL,
                  COD_COMUNE_RESIDENZA, COD_LUOGO_NASCITA, DATA_NASCITA, DATA_SOSPESO_FINO_AL,
                  DATA_RADIATO_DAL, COD_NON_ATTIVITA, NOTE, FLAG_CANCELLATO, COD_UFFICIO_APPARTENENZA,
                  COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO,
                  COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO,
                  COD_FISCALE, PROVINCIA, CAP, ID_AVVOCATO_STANDARD, FLAG_VISUALIZZA,
                  AMBIENTE, NUM_PENDENZE, ID_AVV_CERT_REGINDE, ID_FASCICOLO_SIEP, ID_FASCICOLO_SIUS, ID_FASCICOLO_SIGE, 
                  CHIAVE_ANNO, CHIAVE_PROGR, CHIAVE_UFFICIO, COD_STATO_FASCICOLO, COD_TIPO_UFF, DESCRCOMUNE, FLAG_REGINDE )
            VALUES (V_ID_AVVOCATO, V_COGNOME, V_NOME, V_FORO, V_INDIRIZZO, V_TELEFONO, V_FAX, V_E_MAIL,
                  V_COD_COMUNE_RESIDENZA, V_COD_LUOGO_NASCITA, V_DATA_NASCITA, V_DATA_SOSPESO_FINO_AL,
                  V_DATA_RADIATO_DAL, V_COD_NON_ATTIVITA, V_NOTE, V_FLAG_CANCELLATO, V_COD_UFFICIO_APPARTENENZA,
                  V_COD_OPERATORE_INSERIMENTO, V_DATA_INSERIMENTO, V_COD_UFFICIO_INSERIMENTO,
                  V_COD_OPERATORE_AGGIORNAMENTO, V_DATA_AGGIORNAMENTO, V_COD_UFFICIO_AGGIORNAMENTO,
                  V_COD_FISCALE, V_PROVINCIA, V_CAP, V_ID_AVVOCATO_STANDARD, V_FLAG_VISUALIZZA,
                  'SIUS', num_pendenze_avv_SIUS, V_ID_AVVOCATO_BONIFICATO, NULL, V_ID_FASCICOLO_SIUS, NULL, 
                  V_CHIAVE_ANNO, V_CHIAVE_PROGR, V_CHIAVE_UFFICIO, V_COD_STATO_FASCICOLO, V_COD_TIPO_UFF, V_DESCRCOMUNE, V_FLAG_REGINDE);    
    
        END;
    END LOOP;
   
  CLOSE cur_avv_sius;
 
-- Elaborazione per pendenze SIGE
  OPEN cur_avv_sige(w_codice_distretto);
    LOOP
        FETCH cur_avv_sige INTO
            V_ID_AVVOCATO, V_COGNOME, V_NOME, V_FORO, V_INDIRIZZO, V_TELEFONO, V_FAX, V_E_MAIL,
            V_COD_COMUNE_RESIDENZA, V_COD_LUOGO_NASCITA, V_DATA_NASCITA, V_DATA_SOSPESO_FINO_AL,
            V_DATA_RADIATO_DAL, V_COD_NON_ATTIVITA, V_NOTE, V_FLAG_CANCELLATO, V_COD_UFFICIO_APPARTENENZA,
            V_COD_OPERATORE_INSERIMENTO, V_DATA_INSERIMENTO, V_COD_UFFICIO_INSERIMENTO,    V_COD_OPERATORE_AGGIORNAMENTO, 
            V_DATA_AGGIORNAMENTO, V_COD_UFFICIO_AGGIORNAMENTO, V_COD_FISCALE, V_PROVINCIA, V_CAP, 
             V_ID_AVVOCATO_STANDARD, V_FLAG_VISUALIZZA, V_PEC, V_FLAG_REGINDE, V_DESCR_COMUNE_STUDIO,
            V_COD_STATO_NASCITA_AVV, V_DESC_LUOGO_NAS_REGINDE, V_ID_AVVOCATO_BONIFICATO,
            V_ID_FASCICOLO_SIGE, V_CHIAVE_ANNO, V_CHIAVE_PROGR, V_CHIAVE_UFFICIO, V_COD_STATO_FASCICOLO;
        
        SELECT COUNT(*)INTO num_pendenze_avv_SIGE
            FROM AVVOCATO_FASCICOLO_SIGE afs 
            JOIN FASCICOLO_SIGE fs ON (fs.ID_FASCICOLO_SIGE = afs.FAS_SIGE_ID_FASCICOLO_SIGE
                                  AND afs.AVV_ID_AVVOCATO = V_ID_AVVOCATO AND SUBSTR(afs.FAS_SIGE_ID_FASCICOLO_SIGE,-6, 2) = w_codice_distretto)
            WHERE fs.DATA_DEFINIZIONE IS NULL;

           
        EXIT WHEN cur_avv_sige%NOTFOUND;

               tot_Fascicoli_SIGE_pendenti := tot_Fascicoli_SIGE_pendenti + 1;
              
        BEGIN
--            num_avv_SIGE_con_pendenze:= num_avv_SIGE_con_pendenze + 1;

	        SELECT COD_TIPO_UFFICIO, DESCRIZIONE INTO V_COD_TIPO_UFF, V_DESCRCOMUNE
			FROM UFFICIO U, COMUNE C WHERE COD_UFFICIO = V_CHIAVE_UFFICIO AND C.COD_COMUNE = U.COD_COMUNE;

	        
            INSERT INTO POST_XBA_AVVOCATI_CON_PENDENZE
                ( ID_AVVOCATO, COGNOME, NOME, FORO, INDIRIZZO, TELEFONO, FAX, E_MAIL,
                  COD_COMUNE_RESIDENZA, COD_LUOGO_NASCITA, DATA_NASCITA, DATA_SOSPESO_FINO_AL,
                  DATA_RADIATO_DAL, COD_NON_ATTIVITA, NOTE, FLAG_CANCELLATO, COD_UFFICIO_APPARTENENZA,
                  COD_OPERATORE_INSERIMENTO, DATA_INSERIMENTO, COD_UFFICIO_INSERIMENTO,
                  COD_OPERATORE_AGGIORNAMENTO, DATA_AGGIORNAMENTO, COD_UFFICIO_AGGIORNAMENTO,
                  COD_FISCALE, PROVINCIA, CAP, ID_AVVOCATO_STANDARD, FLAG_VISUALIZZA,
                  AMBIENTE, NUM_PENDENZE, ID_AVV_CERT_REGINDE, ID_FASCICOLO_SIEP, ID_FASCICOLO_SIUS, ID_FASCICOLO_SIGE, 
                  CHIAVE_ANNO, CHIAVE_PROGR, CHIAVE_UFFICIO, COD_STATO_FASCICOLO, COD_TIPO_UFF, DESCRCOMUNE,FLAG_REGINDE)
            VALUES (V_ID_AVVOCATO, V_COGNOME, V_NOME, V_FORO, V_INDIRIZZO, V_TELEFONO, V_FAX, V_E_MAIL,
                  V_COD_COMUNE_RESIDENZA, V_COD_LUOGO_NASCITA, V_DATA_NASCITA, V_DATA_SOSPESO_FINO_AL,
                  V_DATA_RADIATO_DAL, V_COD_NON_ATTIVITA, V_NOTE, V_FLAG_CANCELLATO, V_COD_UFFICIO_APPARTENENZA,
                  V_COD_OPERATORE_INSERIMENTO, V_DATA_INSERIMENTO, V_COD_UFFICIO_INSERIMENTO,
                  V_COD_OPERATORE_AGGIORNAMENTO, V_DATA_AGGIORNAMENTO, V_COD_UFFICIO_AGGIORNAMENTO,
                  V_COD_FISCALE, V_PROVINCIA, V_CAP, V_ID_AVVOCATO_STANDARD, V_FLAG_VISUALIZZA,
                  'SIGE', num_pendenze_avv_SIGE, V_ID_AVVOCATO_STANDARD, NULL,  NULL, V_ID_FASCICOLO_SIGE, 
                  V_CHIAVE_ANNO, V_CHIAVE_PROGR, V_CHIAVE_UFFICIO, V_COD_STATO_FASCICOLO, V_COD_TIPO_UFF, V_DESCRCOMUNE, V_FLAG_REGINDE);
    
        END;
    END LOOP;
   
  CLOSE cur_avv_sige;
 
 	SELECT count(DISTINCT ID_AVVOCATO) INTO num_avv_SIEP_con_pendenze FROM POST_XBA_AVVOCATI_CON_PENDENZE pacp WHERE ambiente = 'SIEP';
 	SELECT count(DISTINCT ID_AVVOCATO) INTO num_avv_SIUS_con_pendenze FROM POST_XBA_AVVOCATI_CON_PENDENZE pacp WHERE ambiente = 'SIUS';
 	SELECT count(DISTINCT ID_AVVOCATO) INTO num_avv_SIGE_con_pendenze FROM POST_XBA_AVVOCATI_CON_PENDENZE pacp WHERE ambiente = 'SIGE';
 
    dbms_output.put_line('============================================');
    dbms_output.put_line('= Totale Avvocati SIEP con pendenze : '||num_avv_SIEP_con_pendenze);
    dbms_output.put_line('=');
    dbms_output.put_line('= Totale Avvocati SIUS con pendenze : '||num_avv_SIUS_con_pendenze);
    dbms_output.put_line('=');
    dbms_output.put_line('= Totale Avvocati SIGE con pendenze : '||num_avv_SIGE_con_pendenze);
    dbms_output.put_line('=');
    dbms_output.put_line('= Totale Fascicoli SIEP pendenti : '||tot_Fascicoli_SIEP_pendenti);
    dbms_output.put_line('=');
    dbms_output.put_line('= Totale Fascicoli SIUS pendenti : '||tot_Fascicoli_SIUS_pendenti);
    dbms_output.put_line('=');
    dbms_output.put_line('= Totale Fascicoli SIGE pendenti : '||tot_Fascicoli_SIGE_pendenti);
    dbms_output.put_line('============================================');

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('============================================ ',
            NULL,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('= Totale Avvocati SIEP con pendenze : ',
            num_avv_SIEP_con_pendenze,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('= Totale Avvocati SIUS con pendenze : ',
            num_avv_SIUS_con_pendenze,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('= Totale Avvocati SIGE con pendenze : ',
            num_avv_SIGE_con_pendenze,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('= Totale Fascicoli SIEP pendenti : ',
            tot_Fascicoli_SIEP_pendenti,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('= Totale Fascicoli SIUS pendenti : ',
            tot_Fascicoli_SIUS_pendenti,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('= Totale Fascicoli SIGE pendenti : ',
            tot_Fascicoli_SIGE_pendenti,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('============================================ ',
            NULL,
            current_timestamp);

    INSERT INTO XBA_LOG_BONIFICA_AVVOCATI
    VALUES('Fine POST_XBA_CAR_AVV_CON_PENDENZE. ',
            NULL,
            current_timestamp);

END POST_XBA_CAR_AVV_CON_PENDENZE;
/
