update ufficio u set u.cod_provincia = 'FC' where u.cod_provincia = 'FO';
update ufficio u set u.cod_provincia = 'PU' where u.cod_provincia = 'PS';
update UFFICIO_DESCR d set d.cod_provincia = 'PU' where d.descr_comune = 'PESARO' and d.cod_provincia = 'PS';
update UFFICIO_DESCR d set d.cod_provincia = 'PU' where d.descr_comune like 'URBINO' and d.cod_provincia = 'PS';
update UFFICIO_DESCR d set d.cod_provincia = 'FC' where d.descr_comune like 'FORLI''' and d.cod_provincia = 'FO';
update UFFICIO_DESCR d set d.cod_provincia = 'FC' where d.descr_comune like 'CESENA' and d.cod_provincia = 'FO';
update UFFICIO_DESCR d set d.cod_provincia = 'MB' where d.descr_comune like 'MONZA' and d.cod_provincia = 'MI';
update cg_ref_codes c set c.RV_ALT2_VALUE = '108033' where c.rv_domain = 'FORO_AVVOCATI' and c.rv_low_value = 'MONZA' and c.RV_ALT2_VALUE = '015149';
update ufficio u set u.cod_provincia = 'MB', u.cod_comune = '108033' where u.cod_comune = '015149' and u.cod_provincia = 'MI';
-- Ticket#202505210127
update funzione_profilo fp
   set fp.data_fine_validita = sysdate - 1
 where fp.fun_id_funzione in (31130701, 31030560)
   and fp.prf_cod_profilo in (30, 31, 32, 36);